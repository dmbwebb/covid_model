


# (0) ACTUAL CASES DATA ---------------------------------------------------

# Import actual case data -------------------------------------------------


stratum_pops <- data_save$sds_case_data %>% 
  mutate(stratum = as.integer(stratum)) %>% 
  mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                             stratum %in% c(3, 4) ~ stratum - 1L,
                             stratum %in% c(5, 6) ~ 4L)) %>% 
  group_by(stratum, stratum_pop) %>% 
  summarise() %>% 
  filter(!is.na(stratum)) %>% 
  summarise(stratum_pop = sum(stratum_pop))


sum(stratum_pops$stratum_pop)
monthly_positivity$n_pop_total[[1]] # same


confirmed_cases_actual <- data_save$sds_case_data %>% 
  mutate(stratum = as.integer(stratum)) %>% 
  mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                             stratum %in% c(3, 4) ~ stratum - 1L,
                             stratum %in% c(5, 6) ~ 4L)) %>% 
  filter(!is.na(stratum)) %>% 
  group_by(stratum, date_results) %>% 
  summarise(n_cases_day = n()) %>% 
  full_join(
    crossing(stratum = 1:4, date_results = ymd("2020-03-01") + days(1:400)), by = c("stratum", "date_results")
  ) %>% 
  mutate(n_cases_day = if_else(is.na(n_cases_day), 0L, n_cases_day)) %>% 
  left_join(
    stratum_pops, by = "stratum"
  ) %>% 
  # Calculate model t in real data
  # mutate(t = interval_days(ymd("2020-04-01"), date_results) + start_t) %>% 
  arrange(stratum, date_results) %>% 
  group_by(stratum, stratum_pop) %>% 
  mutate(n_new_cases_week_roll = zoo::rollsum(n_cases_day, k = 7, fill = NA, align = "right")) %>% 
  mutate(new_cases_per_cap = (n_new_cases_week_roll / stratum_pop)) %>% 
  mutate(n_confirmed_cum = cumsum(n_cases_day) / stratum_pop,
         n_confirmed_cum_abs = cumsum(n_cases_day)) %>% 
  ungroup %>% 
  filter(
    # date_results <= ymd("2020-11-01")
    # date_results > ymd("2020-04-01")
  ) %>% 
  mutate(
    new_cases_per_cap = ifelse(date_results >= ymd("2020-12-01"), NA, new_cases_per_cap),
    n_confirmed_cum = ifelse(date_results >= ymd("2020-12-01"), NA, n_confirmed_cum)
  ) %>% 
  select(i_group = stratum, date_results, new_cases_per_cap, n_confirmed_cum, n_confirmed_cum_abs)
# mutate(source = "data")




confirmed_cases_all <- confirmed_cases_actual %>% 
  group_by(date_results) %>% 
  summarise(n_confirmed_cum = sum(n_confirmed_cum_abs))


overall_prev <- data_save$sds_case_data %>% 
  select(case_id, date_results) %>% 
  group_by(date_results) %>% 
  summarise(new_cases = n()) %>% 
  full_join(tibble(date_results = ymd("2020-03-01") + days(0:300))) %>% 
  arrange(date_results) %>% 
  mutate(new_cases = if_else(is.na(new_cases), 0L, new_cases)) %>% print(n = 500) %>% 
  mutate(days_since_march_1 = interval_days("2020-03-01", date_results)) %>% 
  mutate(ln_new_cases = log(new_cases))





# Positivity data ---------------------------------------------------------


monthly_positivity <- readxl::read_excel("data/positivity_rates.xlsx") %>% 
  left_join(
    tibble(day = ymd("2020-06-01") + days(1:200),
           month = month(day)),
    by = "month"
  ) %>% 
  print_all



# .......... --------------------------------------------------------------


# (1)  --------------------------------------------------------------------



# Import tweaks -----------------------------------------------------------

    load("data/processed/tweaks_v4.RData", verbose = TRUE)

    tweaks_df_slim
    
    

# Plot mobility adjustments -----------------------------------------------

    # 1. Plot mobility adjustments
    policy_vec_tweaks <- tweaks_df_slim %>% 
      rowwise() %>% 
      mutate(diff_times = list(lead(policy_start_times) - policy_start_times),
             diff_times = list(if_else(is.na(diff_times), 500, diff_times)),
             policy_vec = list(rep(mobility_factors, times = diff_times)),
             t = list(0:(length(policy_vec) -  1))) %>% 
      filter(iteration %in% c(5)) %>%
      # filter(iteration %in% c(0, 10, 15, 16, 17)) %>%
      unnest(c(policy_vec, t)) %>% 
      filter(t <= 235)
      # mutate(policy_vec = if_else(t > 235, 
      #                             policy_vec[t == 235],
      #                             policy_vec))

    
    policy_vec_tweaks %>% 
      ggplot(aes(x = t, y = policy_vec, colour = factor(iteration))) + 
      geom_line() + 
      coord_cartesian(xlim = c(0, 250)) + 
      scale_y_continuous(breaks = seq(0, 3, 0.5), minor_breaks = seq(0, 3, 0.1))
    
    
    policy_vec_final <- policy_vec_tweaks$policy_vec
    policy_start_times_final <- policy_vec_tweaks$t
    
    data_save$mobility_factors <- policy_vec_final
    data_save$policy_start_times <- policy_start_times_final
    
    
    save(data_save, file = "data/processed/data_save.RData")

# Run a sim to check ------------------------------------------------------

    n_pop_total <- 100000
    
    set.seed(12345)
    
    # print(str_glue("policy_start_times = {policy_start_times}"))
    
    # k_matrix_basic <- data_save$k_matrix * data_save$k_scale_factor * (n_pop_total / data_save$k_matrix_pop)
    k_matrix_basic <- data_save$k_matrix * (n_pop_total / data_save$k_matrix_pop)
    
    
    
    # Other inputs
    n_initial_cases <- round(data_save$group_props * n_pop_total / 5000) # 5000th of the pop is infected at the model start
    group_props <- c(
      round(data_save$group_props[1:3] * n_pop_total) / n_pop_total,
      1 - sum(round(data_save$group_props[1:3] * n_pop_total) / n_pop_total)
    )
    
    
    k_mobility_final <- policy_vec_final %>% 
      map(~ list(k_matrix = k_matrix_basic * .x)) %>% 
      set_names(as.character(1:length(.)))

 
    # data_save$k_matrix_mobility <- k_mobility_final
    # 
    # 
    # save(data_save, file = "data/processed/data_save.RData")
    
    
    
    test_sim <- outbreak_sims_policy_change(
      n_sims = 30,
      n_iterations = 100000,
      keep_all_data = FALSE,
      print_detail = FALSE,
      constant_params = list(
        n_pop = n_pop_total, 
        hh_size_data = data_save$hh_data_bogota,
        n_initial_cases = n_initial_cases, # calculated within function if remains NULL
        group_props = group_props,     # ditto
        dt_approx = 1,
        recov_val = 10, # people recover 10 days after symptoms show (cuts off only ~ 1% of infections at the upper end of timing distribution)
        params_timing = data_save$params_timing,
        params_symptom_timing = data_save$params_symptom_timing,
        params_serial = data_save$params_serial,
        test_delay_data = data_save$test_delay_data,
        test_sensitivity_data = data_save$test_sensitivity_data, 
        ct_delay_data = data_save$ct_delay_data,
        probs_self_test_df = data_save$probs_self_test,
        probs_isolate_symptoms_df = data_save$probs_isolate_symptoms,
        probs_isolate_test_df = data_save$probs_isolate_test,
        probs_isolate_ct_df =   data_save$probs_isolate_ct,
        p_contact_if_isolated_home = rep(1, 4), 
        p_contact_traced = data_save$p_contact_traced, # TAKEN FROM ABOVE
        p_hh_quarantine = data_save$params_data$p_hh_quarantine,
        
        contact_dispersion = data_save$contact_dispersion,
        sar_out = data_save$params_data$sar_out_input,
        sar_home = data_save$params_data$sar_home_input, 
        infectiousness_by_symptoms = data_save$infectiouness_by_symptoms,
        alpha = c(0, 0, 0, 0)
      ),
      policy_start_times = policy_start_times_final,
      time_varying_params = k_mobility_final
    )    
    
    
    policy_start_times_final
    policy_vec_final

    
    
    
    
    
# PLOTS to check ----------------------------------------------------------
    
    sim_to_plot <- test_sim
    
    test_sim_time_series <- test_sim$time_series
    save(test_sim_time_series, file = "data/temp/test_sim.RData")
    
    report_confirmed_ratio(test_sim$time_series) # about 9.5% are detected (eventually)
    
    
    lower_bound_date <- ymd("2020-06-01")
    roll_smooth <- 14
    # lower_bound_t_plot <- updated_params$lower_bound_t
    
    
    # # 1. Plot mobility adjustments
    # policy_vec_tweaks <- tweaks_df_slim %>% 
    #   rowwise() %>% 
    #   mutate(diff_times = list(lead(policy_start_times) - policy_start_times),
    #          diff_times = list(if_else(is.na(diff_times), 500, diff_times)),
    #          policy_vec = list(rep(mobility_factors, times = diff_times)),
    #          t = list(0:(length(policy_vec) -  1))) %>% 
    #   # filter(iteration %in% c(1, 5, 10, 15, 19)) %>%
    #   filter(iteration %in% c(0, 10, 15, 16, 17)) %>%
    #   unnest(c(policy_vec, t))
    # 
    # 
    # policy_vec_tweaks %>% 
    #   ggplot(aes(x = t, y = policy_vec, colour = factor(iteration))) + 
    #   geom_line() + 
    #   coord_cartesian(xlim = c(0, 250)) + 
    #   scale_y_continuous(breaks = seq(0, 3, 0.5), minor_breaks = seq(0, 3, 0.1))
    # 
    
    
    

    
    manual_adjustment_total_cases <- sim_to_plot$time_series %>% 
      group_by(sim_id, t, policy) %>% 
      # sum up across i_groups
      summarise(across(c(n_new_cases, n_confirmed_cases), sum)) %>% 
      group_by(sim_id) %>% 
      mutate(
        new_cases_actual = n_new_cases,
        new_cases_detected =  n_confirmed_cases  - lag(n_confirmed_cases)
      ) %>% 
      mutate(
        across(c(new_cases_actual, new_cases_detected), list(log_pc = ~ log(. / n_pop_total))),
      )
    
    # Calculate t_shift by matching values at lower bound date
    overall_prev %>% filter(date_results == lower_bound_date)
    
    # Get the rolling average pc in real data
    real_data <- overall_prev %>%
      filter(new_cases != 0) %>% 
      mutate(real_pc = new_cases / monthly_positivity$n_pop_total[[1]]) %>%
      select(date_results, real_pc) %>% 
      mutate(across(c(real_pc), list(roll = ~ zoo::rollmean(.x, k = roll_smooth, na.pad = TRUE, align = "center"))))
    
    # What's the value of pc_roll on lower bound date
    lower_bound_date_value <- real_data %>% filter(date_results == lower_bound_date) %>% .$real_pc_roll
    
    model_data <- manual_adjustment_total_cases %>% 
      mutate(model_pc = new_cases_detected / n_pop_total) %>% 
      mutate(across(c(model_pc), list(roll = ~ zoo::rollmean(.x, k = roll_smooth, na.pad = TRUE, align = "center")))) %>% 
      select(sim_id, t, model_pc, model_pc_roll) %>% 
      group_by(t) %>% 
      quantile_summarise(model_pc_roll, conf_level = 0.9)
    # select(-model_pc_roll_upper, -model_pc_roll_lower)
    
    
    # lower bound date is equivalent to which t?
    lower_bound_t <- model_data %>% filter(model_pc_roll_median >= lower_bound_date_value) %>% .$t %>% first()
    
    model_data_with_date <- model_data %>% 
      mutate(date_model = days(t) + lower_bound_date - days(lower_bound_t))
    
    
    # MERGE REAL AND MODEL
    match_model <- real_data %>% 
      left_join(model_data_with_date, by = c("date_results" = "date_model"))
    
    ggplot(match_model, aes(x = date_results)) +
      geom_line(aes(y = real_pc_roll), size = 1.5, colour = "skyblue") +
      geom_ribbon(aes(ymin = model_pc_roll_lower, ymax = model_pc_roll_upper), fill = "indianred", alpha = 0.2) +
      geom_line(aes(y = model_pc_roll_median), size = 1.5, colour = "grey") +
      geom_point(aes(y = model_pc_roll_median)) +
      # geom_vline(xintercept = model_deviations$date_results[model_deviations$t == t_deviate]) +
      theme_custom() +
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    
    
    
    manual_by_group <- sim_to_plot$time_series %>% 
      select(sim_id, t, i_group, policy, n_pop, n_confirmed_cases) %>% 
      arrange(sim_id, i_group, t) %>% 
      group_by(sim_id, i_group) %>% 
      mutate(
        model_new_confirmed = n_confirmed_cases - lag(n_confirmed_cases),
        model_new_confirmed_week_roll = zoo::rollsum(model_new_confirmed, k = 20, fill = NA, align = "right") / (20/7),
        model_new_confirmed_week_roll_pc = model_new_confirmed_week_roll / n_pop,
        model_cum_confirmed = n_confirmed_cases,
        model_cum_confirmed_pc = n_confirmed_cases / n_pop
        # new_cases_per_cap = (n_new_cases_week_roll / n_pop)
      ) %>% 
      select(-n_confirmed_cases) %>% 
      mutate(date_model = days(t) + lower_bound_date - days(lower_bound_t))
    
    
    manual_by_group_with_data <- full_join(
      confirmed_cases_actual %>% rename(data_new_confirmed_pc = new_cases_per_cap,
                                        data_cum_confirmed_pc = n_confirmed_cum,
                                        data_cum_confirmed = n_confirmed_cum_abs),
      manual_by_group,
      by = c("date_results" = "date_model", "i_group")
    ) %>% 
      rename(date = date_results) %>% 
      mutate(i_group = recode_i_group(i_group))
    
    
    # CUMULATIVE
    manual_by_group_with_data %>% 
      group_by(t, date, i_group, data_cum_confirmed_pc) %>% 
      quantile_summarise(c(model_cum_confirmed_pc), conf_level = 0.9) %>% 
      # filter(date <= ymd("2020-07-01")) %>% 
      ggplot(aes(x = date, colour = i_group)) + 
      geom_line(aes(y = model_cum_confirmed_pc_median), size = 1.5) + 
      geom_ribbon(aes(ymin = model_cum_confirmed_pc_lower,
                      ymax = model_cum_confirmed_pc_upper,
                      fill = i_group),
                  alpha = 0.1, size = 0.3) +
      geom_line(aes(y = data_cum_confirmed_pc), linetype = "dashed", size = 1) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE) + 
      theme_custom() + 
      facet_wrap(~ i_group) + 
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    # CUMULATIVE ALL GROUPS
    cum_all_groups <- manual_by_group_with_data %>%
      group_by(sim_id, t, date) %>% 
      print_names %>% 
      # filter(date <= ymd("2020-07-01")) %>% 
      summarise(across(c(n_pop, data_cum_confirmed, model_cum_confirmed), sum)) %>% 
      ungroup %>% 
      mutate(model_cum_confirmed_pc = model_cum_confirmed / n_pop,
             data_cum_confirmed_pc = data_cum_confirmed /  monthly_positivity$n_pop_total[[1]]) %>% 
      
      group_by(sim_id) %>%
      mutate(final_cum = max(model_cum_confirmed_pc)) %>%
      ungroup %>%
      mutate(median_model = final_cum == median(final_cum, na.rm = TRUE))
    
    
    ggplot(cum_all_groups, aes(x = date)) + 
      geom_line(aes(y = model_cum_confirmed_pc, group = factor(sim_id)), size = 0.4) + 
      # geom_line(data = cum_all_groups %>% filter(median_model), aes(y = model_cum_confirmed_pc, group = factor(sim_id)), colour = "skyblue", size = 1) +
      geom_line(aes(y = data_cum_confirmed_pc), linetype = "dashed", size = 1) + 
      theme_custom() + 
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    # NEW
    manual_by_group_with_data %>% 
      group_by(t, date, i_group, data_new_confirmed_pc) %>% 
      quantile_summarise(c(model_new_confirmed_week_roll_pc)) %>% 
      pivot_longer(c(model_new_confirmed_week_roll_pc_median, data_new_confirmed_pc)) %>% 
      # filter(date <= ymd("2020-07-01")) %>% 
      ggplot(aes(x = date, colour = i_group)) + 
      geom_line(aes(y = value), size = 1) + 
      facet_wrap(~ name) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      theme_custom()
    
    # NEW ALL GROUPS
    match_model_data_manual %>%
      mutate(across(c(median, upper, lower), exp)) %>% 
      filter(str_detect(measure, "detected")) %>% 
      arrange(measure, date_results) %>% group_by(measure) %>% 
      mutate(across(c(median, upper, lower), list(roll = ~ zoo::rollmean(.x, k = roll_smooth, na.pad = TRUE, align = "left")))) %>% 
      ggplot(aes(x = date_results, y = median_roll)) + 
      geom_line(aes(colour = measure), size = 1.5) + 
      geom_ribbon(aes(ymin = lower_roll, ymax = upper_roll, fill = measure), alpha = 0.2) + 
      theme_custom() + 
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    
    
    
    
    
    # FIND THE "MEDIAN MODEL"
    median_model <- manual_by_group_with_data %>%
      group_by(sim_id, t, date) %>% 
      # filter(date <= ymd("2020-07-01")) %>% 
      summarise(across(c(model_cum_confirmed_pc, data_cum_confirmed_pc), sum)) %>% 
      group_by(sim_id) %>% 
      mutate(final_cum = max(model_cum_confirmed_pc)) %>% 
      ungroup %>% 
      mutate(median_model = final_cum == median(final_cum, na.rm = TRUE)) %>% 
      filter(median_model) %>% 
      .$sim_id %>% 
      unique()
    
    # EXAMINE NEW CASES for the median model
    median_model_data <- manual_adjustment_total_cases %>% 
      filter(sim_id == median_model) %>% 
      mutate(model_pc = new_cases_detected / n_pop_total,
             model_cum_pc = n_confirmed_cases / n_pop_total) %>% 
      mutate(across(c(model_pc), list(roll = ~ zoo::rollmean(.x, k = roll_smooth, na.pad = TRUE, align = "center")))) %>%
      select(sim_id, t, model_pc, model_cum_pc, model_pc_roll) %>%
      mutate(date_model = days(t) + lower_bound_date - days(lower_bound_t))
    
    
    
    # manual_adjustment_total_cases %>% 
    # ungroup %>% 
    # view_n()
    
    # MERGE REAL AND MODEL
    real_data %>% 
      left_join(median_model_data, by = c("date_results" = "date_model")) %>% 
      
      ggplot(aes(x = date_results)) +
      # geom_line(aes(y = median_model_pc_roll - real_pc_roll )) +
      geom_point(aes(y = real_pc_roll), size = 1.5, colour = "skyblue") +
      # geom_line(aes(y = model_pc), size = 1.5, colour = "grey") +
      geom_point(aes(y = model_pc_roll)) +
      theme_custom() +
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    
    # ALL GROUPS
    confirmed_cases_all %>% 
      mutate(real_pc = n_confirmed_cum / monthly_positivity$n_pop_total[[1]]) %>% 
      left_join(median_model_data, by = c("date_results" = "date_model")) %>% 
      
      ggplot(aes(x = date_results)) + 
      geom_line(aes(y = real_pc), size = 1.5, colour = "skyblue") +
      geom_point(aes(y = model_cum_pc)) +
      theme_custom() +
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    # DIFF CUMULATIVE
    confirmed_cases_all %>% 
      mutate(real_pc = n_confirmed_cum / monthly_positivity$n_pop_total[[1]]) %>% 
      left_join(median_model_data, by = c("date_results" = "date_model")) %>% 
      
      ggplot(aes(x = date_results)) + 
      geom_line(aes(y = model_cum_pc - real_pc), size = 1.5, colour = "skyblue") +
      # geom_point(aes(y = model_cum_pc)) +
      theme_custom() +
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    # DIFF NEW
    real_data %>% 
      left_join(median_model_data, by = c("date_results" = "date_model")) %>% 
      
      ggplot(aes(x = date_results)) +
      # geom_line(aes(y = median_model_pc_roll - real_pc_roll )) +
      geom_point(aes(y = model_pc_roll - real_pc_roll), size = 1.5, colour = "skyblue") +
      # geom_line(aes(y = model_pc), size = 1.5, colour = "grey") +
      # geom_point(aes(y = model_pc_roll)) +
      theme_custom() +
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    
    
    manual_adjustment_total_cases %>% 
      mutate(date_model = days(t) + lower_bound_date - days(lower_bound_t)) %>% 
      filter(sim_id == median_model)
    
    
    
    
    median_model_data %>% 
      ungroup %>% 
      mutate(cum_check = cumsum(if_else(is.na(model_pc), 0, model_pc))) %>% 
      mutate(check_tf = abs(model_cum_pc -  cum_check) < 0.000001) %>% 
      print_all
    
    
    
    
    
    system("say R Studio has finished!")
    
    
    
    