# 
# # Set up ------------------------------------------------------------------
# 
#       
# 
# 
#     
#     library("viridis")
# 
# 
# 
# # ...... ------------------------------------------------------------------
# 
# 
# # BASELINE ----------------------------------------------------------------
# 
# 
#     # load("data/processed/model_baseline_final.RData")
#     
#     # load("data/processed/model_baseline_final_v2.RData")
#     
# # 1. Basic graph of main simulation ---------------------------------------------------------
#     
#     live_cases <- model_baseline_time_series %>% 
#       mutate(n_cases_per_cap = n_cases_live / n_pop) %>% 
#       group_by(t, i_group) %>% 
#       summarise_quantiles(n_cases_per_cap) %>% 
#       filter(q %in% c(0.05, 0.5, 0.95)) %>% 
#       mutate(q_label = case_when(q == 0.05 ~ "_lower",
#                                  q == 0.5   ~ "",
#                                  q == 0.95 ~ "_upper")) %>% 
#       select(-q) %>%
#       ungroup %>% 
#       pivot_wider(names_from = q_label,
#                   values_from = n_cases_per_cap,
#                   names_prefix = "n_cases_per_cap")
#     
#     live_cases %>% 
#       mutate(i_group = recode_i_group(i_group)) %>% 
#       ggplot(aes(x = t, y = n_cases_per_cap)) + 
#       geom_line(aes(colour = factor(i_group)), size = 1) + 
#       geom_ribbon(aes(ymax = n_cases_per_cap_upper, ymin = n_cases_per_cap_lower, fill = factor(i_group)), alpha = 0.15) + 
#       # geom_label(aes(label = factor(stratum))) + 
#       scale_colour_viridis(option = "viridis",
#                            begin = 0.3, 
#                            discrete = TRUE) + 
#       scale_y_continuous(labels = scales::percent_format(accuracy = 1)) + 
#       scale_fill_viridis(option = "viridis",
#                          begin = 0.3, 
#                          discrete = TRUE) + 
#       theme_custom() + 
#       theme(legend.position = c(0.12, 0.67)) + 
#       labs(x = "t", y = "Prevalence", fill = "SES Group",
#            colour = "SES Group") + # + 
#       geom_hline(yintercept = 0, colour = "darkgrey")
#     
#     ggsave("figures/live_cases.png", scale = 0.8)
#     
#     
#     
# 
# # 1b - Proportion infected ------------------------------------------------
# 
#     
#     prop_infected <- model_baseline_time_series %>% 
#       mutate(n_cases_per_cap = n_cases_cum / n_pop) %>% 
#       group_by(t, i_group) %>% 
#       summarise_quantiles(n_cases_per_cap) %>% 
#       filter(q %in% c(0.05, 0.5, 0.95)) %>% 
#       mutate(q_label = case_when(q == 0.05 ~ "_lower",
#                                  q == 0.5   ~ "",
#                                  q == 0.95 ~ "_upper")) %>% 
#       select(-q) %>%
#       ungroup %>% 
#       pivot_wider(names_from = q_label,
#                   values_from = n_cases_per_cap,
#                   names_prefix = "n_cases_per_cap")
#     
#     prop_infected %>% 
#       mutate(i_group = recode_i_group(i_group)) %>% 
#       ggplot(aes(x = t, y = n_cases_per_cap)) + 
#       geom_line(aes(colour = factor(i_group)), size = 1) + 
#       geom_ribbon(aes(ymax = n_cases_per_cap_upper, ymin = n_cases_per_cap_lower, fill = factor(i_group)), alpha = 0.15) + 
#       # geom_label(aes(label = factor(stratum))) + 
#       scale_colour_viridis(option = "viridis",
#                            begin = 0.3, 
#                            discrete = TRUE) + 
#       scale_y_continuous(labels = scales::percent_format(accuracy = 1)) + 
#       scale_fill_viridis(option = "viridis",
#                          begin = 0.3, 
#                          discrete = TRUE) + 
#       theme_custom() + 
#       theme(legend.position = c(0.12, 0.67)) + 
#       labs(x = "t", y = "Prop infected", fill = "SES Group",
#            colour = "SES Group") + # + 
#       geom_hline(yintercept = 0, colour = "darkgrey")
#     
#     # ggsave("figures/prop_infected.png", scale = 0.8)
#     
#     
#     
#     
# # 2. New confirmed cases (model) ------------------------------------------------
#     
#     
#     
#     
#     confirmed_cases_model <- model_baseline_time_series %>% 
#       select(sim_id, t, i_group, n_pop, n_confirmed_cases) %>% 
#       arrange(sim_id, i_group, t) %>% 
#       group_by(sim_id, i_group) %>% 
#       mutate(
#         new_confirmed_cases = n_confirmed_cases - lag(n_confirmed_cases),
#         n_new_cases_week_roll = zoo::rollsum(new_confirmed_cases, k = 20, fill = NA, align = "right") / (20/7),
#         n_confirmed_cum = n_confirmed_cases / n_pop,
#         new_cases_per_cap = (n_new_cases_week_roll / n_pop)
#       ) %>% 
#       group_by(i_group, t) %>% 
#       summarise_quantiles(c(new_cases_per_cap, n_confirmed_cum)) %>% 
#       filter(q %in% c(0.05, 0.5, 0.95)) %>% 
#       mutate(q_label = case_when(q == 0.05 ~ "_lower",
#                                  q == 0.5   ~ "",
#                                  q == 0.95 ~ "_upper")) %>% 
#       select(-q) %>%
#       ungroup %>% 
#       pivot_wider(names_from = q_label,
#                   values_from = c(new_cases_per_cap, n_confirmed_cum),
#                   names_sep = "")
#     
#     
#     ggplot(confirmed_cases_model, aes(x = t, y = new_cases_per_cap)) + 
#       geom_line(aes(colour = factor(i_group)), size = 1) + 
#       geom_ribbon(aes(ymax = new_cases_per_cap_upper, ymin = new_cases_per_cap_lower, fill = factor(i_group)), alpha = 0.1) + 
#       # geom_label(aes(label = factor(stratum))) + 
#       scale_colour_viridis(option = "viridis",
#                            begin = 0.3, 
#                            discrete = TRUE) + 
#       scale_fill_viridis(option = "viridis",
#                          begin = 0.3, 
#                          discrete = TRUE) + 
#       theme_custom() + 
#       theme(legend.position = c(0.12, 0.67)) + 
#       labs(x = "t", y = "Weekly new confirmed cases per capita in group [model]", fill = "SES Group",
#            colour = "SES Group") + # + 
#       geom_hline(yintercept = 0, colour = "darkgrey")
#     
#     
#     
#     
#     
# 
#     
#     
# 
# # ..... -------------------------------------------------------------------
# 
# 
# # MOBILITY CHANGE ---------------------------------------------------------
#     
#     load("data/processed/policy_change_time_series.RData")
# 
#     # FOR PLOTTING the policy change graphs
#     lockdown_rect_1 <- policy_change_time_series %>% 
#       summarise(xmin = min(t[policy == "1_severe_lockdown"], na.rm = TRUE), 
#                 xmax = max(t[policy == "1_severe_lockdown"], na.rm = TRUE))
#     
#     # lockdown_rect_2 <- policy_change_time_series %>% 
#     #   summarise(xmin = min(t[policy == "2_lighter_lockdown"], na.rm = TRUE), 
#     #             xmax = max(t[policy == "2_lighter_lockdown"], na.rm = TRUE))
#     
#     
#     policy_change_time_series %>% filter(i_group ==1) %>% 
#       print(n = 200)
#     
#     
# 
# # 1. Basic graph ----------------------------------------------------------
#     
#     
#     
#     # PLOT POLICY CHANGE GRAPH
#     policy_change_time_series %>% 
#       group_by(t, i_group, n_pop, policy) %>% 
#       mutate(prevalence_prop = n_cases_live / n_pop) %>% 
#       quantile_summarise(c(prevalence_prop), conf_level = 0.9) %>% 
#       mutate(i_group = recode_i_group(i_group)) %>% 
#       # ungroup %>% 
#       ggplot() + 
#       
#       # Shaded area
#       geom_rect(data = lockdown_rect_1,
#                 aes(xmin = xmin,
#                     xmax = xmax,
#                     ymin=0, ymax=Inf), alpha = 0.08, fill = "indianred") +
#       
#       # geom_rect(data = lockdown_rect_2,
#       #           aes(xmin = xmin,
#       #               xmax = xmax,
#       #               ymin=0, ymax=Inf), alpha = 0.08, fill = "skyblue") +
#       
#       # LINE
#       geom_line(aes(x = t, y = prevalence_prop_median, 
#                     colour = factor(i_group), group = factor(i_group)),
#                 show.legend = TRUE, size = 1) + 
#       geom_ribbon(
#         aes(
#           x = t, 
#           ymax = prevalence_prop_upper,
#           ymin = prevalence_prop_lower,
#           fill = factor(i_group),
#           # colour = factor(i_group)
#         ),
#         linetype = 2,
#         alpha = 0.1
#       ) +
#       # facet_wrap(~ parameter_set, labeller = as_labeller(counterfactual_labels)) + 
#       
#       # Formatting
#       theme_custom() + 
#       theme(legend.position = "right") + 
#       scale_alpha_continuous(guide = FALSE) + 
#       scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
#       labs(colour = "SES Group", fill = "SES Group", y = "% Infected at t") +
#       geom_hline(yintercept = 0, colour = "darkgrey", size = 0.4) + 
#       # coord_cartesian(xlim = c(0, 300)) +
#       scale_colour_viridis(option = "viridis",
#                            begin = 0.3, 
#                            discrete = TRUE) + 
#       scale_fill_viridis(option = "viridis",
#                          begin = 0.3, 
#                          discrete = TRUE) + 
#       # scale_x_continuous(minor_breaks = c(0, 25, 50, 75), breaks = c(0, 50, 100, 150, 200)) + 
#       geom_vline(aes(xintercept = min(t[policy == "lockdown"], na.rm = TRUE)), linetype = "dashed") +
#       geom_vline(aes(xintercept = max(t[policy == "lockdown"], na.rm = TRUE)), linetype = "dashed")
#     
#     
#     ggsave("figures/second_wave_example.png", width = 6, height = 4, scale = 0.85)    
#     
#     
# 
#     
# 
# # 2. Compare prop infected across both -------------------------------------------------------------
# 
#     
#     prop_infected_policy_change <- policy_change_time_series %>% 
#       mutate(n_cases_per_cap = n_cases_cum / n_pop) %>% 
#       group_by(t, i_group) %>% 
#       summarise_quantiles(n_cases_per_cap) %>% 
#       filter(q %in% c(0.05, 0.5, 0.95)) %>% 
#       mutate(q_label = case_when(q == 0.05 ~ "_lower",
#                                  q == 0.5   ~ "",
#                                  q == 0.95 ~ "_upper")) %>% 
#       select(-q) %>%
#       ungroup %>% 
#       pivot_wider(names_from = q_label,
#                   values_from = n_cases_per_cap,
#                   names_prefix = "n_cases_per_cap")
#     
#     
#     prop_infected_both <- bind_rows(
#       "baseline" = prop_infected,
#       "mobility_change" = prop_infected_policy_change,
#       .id = "model_type"
#     )
#     
#     
#     prop_infected_both %>% 
#       mutate(i_group = recode_i_group(i_group)) %>% 
#       ggplot(aes(x = t, y = n_cases_per_cap)) + 
#       geom_line(aes(colour = factor(i_group)), size = 1) + 
#       geom_ribbon(aes(ymax = n_cases_per_cap_upper, ymin = n_cases_per_cap_lower, fill = factor(i_group)), alpha = 0.15) + 
#       # geom_label(aes(label = factor(stratum))) + 
#       scale_colour_viridis(option = "viridis",
#                            begin = 0.3, 
#                            discrete = TRUE) + 
#       scale_y_continuous(labels = scales::percent_format(accuracy = 1)) + 
#       scale_fill_viridis(option = "viridis",
#                          begin = 0.3, 
#                          discrete = TRUE) + 
#       theme_custom() + 
#       theme(legend.position = c(0.12, 0.67)) + 
#       labs(x = "t", y = "Prop infected", fill = "SES Group",
#            colour = "SES Group") + # + 
#       geom_hline(yintercept = 0, colour = "darkgrey") + 
#       facet_wrap(~ model_type)
#   
#     
#     # CUMULATIVE - cases!!
#     policy_change_time_series %>% 
#       group_by(sim_id, t) %>% 
#       summarise(
#         n_confirmed_cases = sum(n_confirmed_cases),
#         n_cases_cum = sum(n_cases_cum),
#         n_pop = sum(n_pop)) %>% 
#       mutate(n_cases_per_cap = n_cases_cum / n_pop,
#              n_confirmed_cases_per_cap = n_confirmed_cases / n_pop) %>% 
#       ungroup %>% 
#       left_join(
#         confirmed_cases_actual %>% group_by(t) %>% summarise(n_confirmed_cum = sum(n_confirmed_cum_abs)),
#         by = "t"
#       ) %>% 
#       mutate(
#         actual_per_cap = n_confirmed_cum / 7600000
#       ) %>% 
#       ggplot(aes(x = t, y = n_cases_per_cap)) + 
#       geom_line(size = 1) + 
#       geom_line(aes(y = n_confirmed_cases_per_cap), colour = "indianred") + 
#       geom_line(aes(y = actual_per_cap), colour = "indianred", linetype = "dashed") +
#       theme_custom() + 
#       theme(legend.position = c(0.12, 0.67)) + 
#       labs(x = "t", y = "Prop infected", fill = "SES Group",
#            colour = "SES Group") + # + 
#       geom_hline(yintercept = 0, colour = "darkgrey")
#     
# 
# # 3. Confirmed cases in mobility change model -----------------------------
# 
#     confirmed_cases_model_mobility_change <- policy_change_time_series %>% 
#       select(sim_id, t, i_group, n_pop, n_confirmed_cases) %>% 
#       arrange(sim_id, i_group, t) %>% 
#       group_by(sim_id, i_group) %>% 
#       mutate(
#         new_confirmed_cases = n_confirmed_cases - lag(n_confirmed_cases),
#         n_new_cases_week_roll = zoo::rollsum(new_confirmed_cases, k = 20, fill = NA, align = "right") / (20/7),
#         n_confirmed_cum = n_confirmed_cases / n_pop,
#         new_cases_per_cap = (n_new_cases_week_roll / n_pop)
#       ) %>% 
#       group_by(i_group, t) %>% 
#       summarise_quantiles(c(new_cases_per_cap, n_confirmed_cum)) %>% 
#       filter(q %in% c(0.05, 0.5, 0.95)) %>% 
#       mutate(q_label = case_when(q == 0.05 ~ "_lower",
#                                  q == 0.5   ~ "",
#                                  q == 0.95 ~ "_upper")) %>% 
#       select(-q) %>%
#       ungroup %>% 
#       pivot_wider(names_from = q_label,
#                   values_from = c(new_cases_per_cap, n_confirmed_cum),
#                   names_sep = "")
#     
#     
#     
#     
# # 3. Real and model new confirmed cases in same graph ----------------------------------
#     
#     
#     # WHEN IS Start date on model - April 1st when there are 486 cases
#     start_cases <- sum(data_save$best_guess_initial_cases$n) 
#     start_cases_prop <- start_cases / sum(data_save$best_guess_initial_cases$stratum_pop)
#     format(start_cases_prop, scientific=F)   # 0.00006578947  of the population
#     
#     
#     # Calculate which t should align with April 1st
#     start_t <- model_baseline_time_series %>% 
#       group_by(sim_id, t) %>% # sum all i_groups
#       summarise(across(c(n_pop, n_confirmed_cases), sum)) %>% 
#       ungroup %>% 
#       mutate(n_confirmed_prop = n_confirmed_cases / n_pop,
#              over_start_thresh = n_confirmed_prop >= start_cases_prop) %>% 
#       
#       # Find first t that goes over starting threshold
#       group_by(sim_id) %>% 
#       summarise(start_t = first_non_na(t[over_start_thresh])) %>% 
#       
#       # Take rounded median of all as starting t
#       summarise(start_t = floor(median_na(start_t))) %>% 
#       .$start_t
#     
#     print(str_glue("Median starting time (April 1st) is t = {start_t}"))
#     
#     
# 
#     stratum_pops <- data_save$sds_case_data %>% 
#       mutate(stratum = as.integer(stratum)) %>% 
#       mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
#                                  stratum %in% c(3, 4) ~ stratum - 1L,
#                                  stratum %in% c(5, 6) ~ 4L)) %>% 
#       group_by(stratum, stratum_pop) %>% 
#       summarise() %>% 
#       filter(!is.na(stratum)) %>% 
#       summarise(stratum_pop = sum(stratum_pop))
#     
#     confirmed_cases_actual <- data_save$sds_case_data %>% 
#       mutate(stratum = as.integer(stratum)) %>% 
#       mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
#                                  stratum %in% c(3, 4) ~ stratum - 1L,
#                                  stratum %in% c(5, 6) ~ 4L)) %>% 
#       filter(!is.na(stratum)) %>% 
#       group_by(stratum, date_results) %>% 
#       summarise(n_cases_day = n()) %>% 
#       full_join(
#         crossing(stratum = 1:4, date_results = ymd("2020-03-01") + days(1:400)), by = c("stratum", "date_results")
#       ) %>% 
#       mutate(n_cases_day = if_else(is.na(n_cases_day), 0L, n_cases_day)) %>% 
#       left_join(
#         stratum_pops, by = "stratum"
#       ) %>% 
#       # Calculate model t in real data
#       mutate(t = interval_days(ymd("2020-04-01"), date_results) + start_t) %>% 
#       arrange(stratum, date_results) %>% 
#       group_by(stratum, stratum_pop) %>% 
#       mutate(n_new_cases_week_roll = zoo::rollsum(n_cases_day, k = 7, fill = NA, align = "right")) %>% 
#       mutate(new_cases_per_cap = (n_new_cases_week_roll / stratum_pop)) %>% 
#       mutate(n_confirmed_cum = cumsum(n_cases_day) / stratum_pop,
#              n_confirmed_cum_abs = cumsum(n_cases_day)) %>% 
#       ungroup %>% 
#       filter(
#         # date_results <= ymd("2020-11-01")
#         # date_results > ymd("2020-04-01")
#       ) %>% 
#       mutate(
#         new_cases_per_cap = ifelse(date_results >= ymd("2020-12-01"), NA, new_cases_per_cap),
#         n_confirmed_cum = ifelse(date_results >= ymd("2020-12-01"), NA, n_confirmed_cum)
#       ) %>% 
#       select(i_group = stratum, t, date_results, new_cases_per_cap, n_confirmed_cum, n_confirmed_cum_abs)
#       # mutate(source = "data")
#     
#     t_adj <- -15
#     
#     date_to_t <- confirmed_cases_actual %>% 
#       mutate(t = t - t_adj) %>% 
#       select(t, date_results) %>% dups_drop()
#     
#     
#     # combine both into one DF
#     confirmed_cases_combined <- bind_rows(
#       "data" = confirmed_cases_actual %>% select(-date_results) %>% mutate(t = t - t_adj),
#       "model_baseline" = confirmed_cases_model,
#       # "model_mobility_change" = confirmed_cases_model_mobility_change,
#       .id = "source"
#     ) %>% 
#       left_join(date_to_t, by = "t")
#     
#     
#     # PLOT - weekly new confirmed
#     confirmed_cases_combined %>% 
#       # filter(source != "model_mobility_change") %>% 
#       filter(t > 0) %>% 
#       ggplot(aes(x = date_results, y = new_cases_per_cap)) + 
#       geom_line(aes(colour = factor(i_group)), size = 1) + 
#       geom_ribbon(aes(ymax = new_cases_per_cap_upper, ymin = new_cases_per_cap_lower, fill = factor(i_group)), alpha = 0.2) +
#       # geom_label(aes(label = factor(stratum))) + 
#       scale_colour_viridis(option = "viridis",
#                            begin = 0.3, 
#                            discrete = TRUE) + 
#       scale_fill_viridis(option = "viridis",
#                          begin = 0.3, 
#                          discrete = TRUE) + 
#       theme_custom() + 
#       # theme(legend.position = c(0.12, 0.67)) + 
#       labs(x = "Date", y = "Weekly new confirmed cases per capita in group", fill = "SES Group",
#            colour = "SES Group") + # + 
#       geom_hline(yintercept = 0, colour = "darkgrey") + 
#       facet_wrap(~ source)
#     
#     
#     
#     
#     
#     # PLOT
#     confirmed_cases_combined %>% 
#       # mutate(n_confirmed_cum = if_else(source == "model_baseline", n_confirmed_cum / 2, n_confirmed_cum)) %>%
#       mutate(i_group = recode_i_group(i_group)) %>% 
#       filter(t > 0, t < 300) %>% 
#       ggplot(aes(x = date_results, y = n_confirmed_cum)) + 
#       geom_line(aes(colour = factor(i_group), linetype = source), size = 1) + 
#       geom_ribbon(
#         aes(
#           ymax = n_confirmed_cum_upper,
#           ymin = n_confirmed_cum_lower,
#           fill = factor(i_group),
#           colour = factor(i_group)
#         ),
#         linetype = 2,
#         alpha = 0.1
#       ) +
#       # geom_label(aes(label = factor(stratum))) + 
#       scale_colour_viridis(option = "viridis",
#                            begin = 0.3, 
#                            discrete = TRUE) + 
#       scale_fill_viridis(option = "viridis",
#                          begin = 0.3, 
#                          discrete = TRUE) + 
#       theme_custom() + 
#       # theme(legend.position = c(0.12, 0.67)) + 
#       labs(x = "Date", y = "Cumulative confirmed cases per capita\nin each group", fill = "SES Group",
#            colour = "SES Group") + # + 
#       geom_hline(yintercept = 0, colour = "darkgrey")
#       # facet_wrap(~ source, labeller = as_labeller(c("data" = "Data", "model_baseline" = "Model (no mobility change)", "model_mobility_change" = "Model (mobility change)")))
#     
#     
#     # ggsave("figures/data_vs_model_confirmed_cum.png", scale = 0.7)
#     
#     
#     
#     
#     
#     
# 
# # ..... -------------------------------------------------------------------


# COUNTERFACTUALs ---------------------------------------------------------

    # load("data/temp/group_diff_mobility_manual_v2.RData")
    # load("data/temp/group_diff_mobility_11thFeb.RData")
    load("data/temp/group_diff_mobility_11thFeb_split.RData", verbose = TRUE)
    
    # Prepare plot DF
    group_diff_at_t <- group_diff_slim_combine %>% # note that combine keeps the extras
      group_by(parameter_set, t, i_group, n_pop) %>% 
      quantile_summarise(c(n_cases_live), conf_level = 0) %>% 
      mutate(prevalence_prop = n_cases_live_median / n_pop)
    
    # Labels for each counterfacutal type
    counterfactual_labels <- c(
      "baseline" = "Baseline",
      "out_contacts" = "Out of home",
      "home_contacts" = "Within home",
      "isolation_behaviour" = "Isolation behaviour",
      "testing_tracing" = "Testing & Tracing",
      "all" = "All", 
      "sar_home" = "SAR Home",
      "hh_size" = "HH Size"
    )
    
    
# 1. Counterfactual epidemic curve -----------------------------------------------------------
    
  
    
    # PLOT epidemic curves
    included_curves <-
      c(
        "baseline",
        "out_contacts",
        "home_contacts",
        "isolation_behaviour",
        "testing_tracing",
        "all",
        "hh_size",
        "sar_home"
      )
    group_diff_at_t %>% ungroup %>% count_prop(parameter_set)
    

    group_diff_at_t %>% 
      mutate(i_group = recode_i_group(i_group)) %>% 
      mutate(alpha = if_else(parameter_set %in% included_curves, 1, 0)) %>% 
      ggplot(aes(x = t, y = prevalence_prop, 
                 colour = factor(i_group), group = factor(i_group)
                 # alpha = 1
      )) + 
      geom_line(show.legend = TRUE) + 
      facet_wrap(~ parameter_set, labeller = as_labeller(counterfactual_labels)) + 
      
      # Formatting
      theme_custom() + 
      theme(legend.position = "right") + 
      scale_alpha_continuous(guide = FALSE) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
      labs(colour = "SES Group", fill = "SES Group", y = "% Infected at t") +
      geom_hline(yintercept = 0, colour = "darkgrey", size = 0.4) + 
      coord_cartesian(xlim = c(0, 500)) +
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE)
      # scale_x_continuous(minor_breaks = c(0, 25, 50, 75), breaks = c(0, 50, 100))
    
    
    ggsave("figures/epidemic_curve.png", width = 8, height = 4.5, scale = 0.8)
    # ggsave("epidemic_curve_2.png", width = 8, height = 4.5, scale = 0.8)
    # ggsave("epidemic_curve_3.png", width = 8, height = 4.5, scale = 0.8)
    
    
    
    
    
    

# 2. Counterfactual - summary results -------------------------------------

    
  
    # SUMMARISE ALL INFO
    group_diff_all_summ <- group_diff_slim_combine %>% 
      
      # (1) Calculate total cases
      group_by(parameter_set, i_group, sim_id, n_pop) %>% 
      summarise(n_cases = max(n_cases_cum)) %>% 
      
      # Calculate proportion infected, and gaps with group 5
      group_by(parameter_set, sim_id) %>% arrange(sim_id) %>% 
      mutate(prop_infected = n_cases / n_pop) %>% 
      mutate(diff_prop_infected = prop_infected - prop_infected[i_group == 4],
             diff_n_cases = n_cases - n_cases[i_group == 4]) %>% 
      
      
      # Calculate "effect" relative to baseline
      group_by(sim_id, i_group) %>% 
      mutate(across(-c(parameter_set), list(effect = ~ .x - .x[parameter_set == "baseline"]))) %>% 
      # Calculte implied contribution for each group, for each sim
      mutate(contribution = diff_prop_infected_effect / diff_prop_infected_effect[parameter_set == "all"]) %>% 
      group_by(parameter_set, i_group) %>% 
      arrange(parameter_set, i_group)
    # summarise_quantiles(-c(sim_id)) %>% print_all
    
    
    
    # Make into function
    plot_group_diffs <- function(.data, y, ylab = "Y") {
      
      # Labels for each counterfacutal type
      counterfactual_labels <- c(
        "baseline" = "Baseline",
        "out_contacts" = "Out of home",
        "home_contacts" = "Within home",
        "isolation_behaviour" = "Isolation behaviour",
        "testing_tracing" = "Testing & Tracing",
        "all" = "All", 
        "sar_home" = "SAR Home",
        "hh_size" = "HH Size"
      )
      
      .data %>% 
        mutate(i_group = recode_i_group(i_group)) %>% 
        summarise_quantiles({{y}}) %>% 
        select(parameter_set, i_group, q, {{y}}) %>% 
        filter(q %in% c(0.025, 0.5, 0.975)) %>% 
        pivot_wider(names_from = q, names_prefix = "y_", values_from = {{y}}) %>% 
        ggplot(aes(x = i_group, fill = factor(i_group))) + 
        geom_col(aes(y = y_0.5)) + 
        geom_errorbar(aes(ymin = y_0.025, ymax = y_0.975), width = 0.2, size = 0.5, colour = "#374561") + 
        facet_wrap(~ parameter_set, labeller = as_labeller(counterfactual_labels)) + 
        labs(y = ylab, x = "SES Group", fill = "SES Group") + 
        theme_custom() + 
        theme(legend.position = "right", panel.grid.minor = element_blank(), panel.grid.major.x = element_blank()) + 
        geom_hline(yintercept = 0, colour = "darkgrey", size = 0.4) + 
        scale_fill_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE)
      # scale_x_continuous(breaks = 1:5)
      
    }
    
    
    # PLOT
    # Prop infected in each scenario
    plot_group_diffs(group_diff_all_summ, y = prop_infected, "Total Proportion Infected")
    ggsave("figures/prop_infected.png", width = 8, height = 4.5, scale = 0.8)
    
    # Gap (relative to group 6) in each scenario
    plot_group_diffs(group_diff_all_summ, y = diff_prop_infected, "Gap relative to group 6")
    ggsave("figures/inequality.png", width = 8, height = 4.5, scale = 0.8)
    
    
    
    # TO DO !!!! SHOULD CALCULATE THE QUANTILES AFTER CALCULATING DESIRED QUANTITY
    
    # CHANGE RELATIVE TO BASELINE of prop infected
    # group_diff_all_summ %>% 
    #   group_by(i_group, q) %>% 
    #   mutate(across(-c(parameter_set), ~ . - .[parameter_set == "baseline"])) %>% 
    #   ungroup %>% 
    #   
    #   plot_group_diffs(
    #     y = prop_infected,
    #     ylab = "Change in Total Proportion Infected relative to Baseline"
    #   )
    
    # CHANGE RELATIVE TO BASELINE of group 1 gap (inequality)
    # group_diff_all_summ %>% 
    #   group_by(i_group, q) %>% 
    #   mutate(across(-c(parameter_set), ~ . - .[parameter_set == "baseline"])) %>% 
    #   ungroup %>% 
    #   
    #   plot_group_diffs(
    #     y = diff_prop_infected,
    #     ylab = "Change relative to baseline case in inequality relative to group 6"
    #   )
    
    

# 3. Decomposition (v1) ----------------------------------------------------


    
    # colours <- c(
    #   "darkgrey", "#E87D72", "#55BA70", "#4FB7DF", "#D378EF" 
    # )
    
    
    # PLOT implied "proportion" contribution of each parameter group
    # group_diff_all_summ %>% 
    #   group_by(i_group, q) %>% 
    #   mutate(across(-c(parameter_set), ~ . - .[parameter_set == "baseline"])) %>% 
    #   ungroup %>% 
    #   filter(q == 0.5) %>% 
    #   filter(parameter_set != "baseline") %>% 
    #   group_by(i_group) %>% 
    #   filter(i_group != 4) %>% 
    #   arrange(i_group) %>% 
    #   mutate(diff_prop_infected = diff_prop_infected / diff_prop_infected[parameter_set == "all"]) %>% 
    #   select(parameter_set, i_group, diff_prop_infected) %>% 
    #   mutate(parameter_set = as.character(parameter_set)) %>%
    #   mutate(parameter_set = if_else(parameter_set == "all", "Interaction", parameter_set)) %>%
    #   mutate(parameter_set = factor(parameter_set)) %>%
    #   group_by(i_group) %>%
    #   mutate(diff_prop_infected = if_else(parameter_set == "Interaction",
    #                                       1 - sum(diff_prop_infected[parameter_set != "Interaction"]),
    #                                       diff_prop_infected)) %>%
    #   # filter(!(parameter_set == "Interaction" & diff_prop_infected < 0)) %>% 
    #   mutate(parameter_set = forcats::fct_relevel(parameter_set, "Interaction"),
    #          parameter_set = fct_relevel(parameter_set, "home_contacts", after = 6)) %>% 
    #   
    #   ggplot(aes(x = fct_rev(factor(i_group)), y = diff_prop_infected)) + 
    #   # ggpattern::geom_col_pattern(
    #   #   aes(fill = parameter_set, pattern = parameter_set, pattern_angle = class), 
    #   #   colour = "white"
    #   # ) + 
    #   geom_col(aes(fill = parameter_set), colour = "white", width = 0.4) + 
    #   # geom_label_repel(aes(label = parameter_set), size = 0.
    #   #                  position = position_stack(vjust = .5)) + 
    #   scale_fill_manual(values = colours, labels = counterfactual_labels, name = element_blank()) + 
    #   theme_custom() + 
    #   geom_hline(yintercept = 1, size = 0.3, linetype = "longdash") + 
    #   geom_hline(yintercept = 0, size = 0.3, linetype = "longdash") + 
    #   geom_label(data = . %>% mutate(label = if_else(diff_prop_infected > 0.1, 
    #                                                  paste0(round(diff_prop_infected * 100), "%"),
    #                                                  NA_character_)),
    #              aes(label = label, group = parameter_set),
    #              position = position_stack(vjust = 0.5),
    #              alpha = 0.5,
    #              size = 2) + 
    #   coord_flip() + 
    #   scale_y_continuous(labels = scales::percent_format(accuracy = 1), breaks = 0:5 / 5) + 
    #   # scale_fill_wsj() + 
    #   labs(x = "SES Group", y = "Contribution to reduction in inequality")
    
    
    
    # ggsave("inequality_decomposition.png",  width = 6, height = 4.5, scale = 0.8)
    
    
    
    
    

# 4. Decoposition (v2) ----------------------------------------------------


    
    
    # V2 - no pie chart, just bars
    # Relative to total inequality, how much does each parameter change reduce
    
    
    contributions_df <- group_diff_all_summ %>% 
      # group_by(sim_id, parameter_set,  i_group) %>% 
      arrange(sim_id, parameter_set,  i_group) %>% 
      select(sim_id, parameter_set,  i_group, diff_n_cases) %>% 
      
      # For each sim_id, i_group, what's the prop reduction
      group_by(sim_id, i_group) %>% 
      filter(i_group != 4) %>%  # remove 4 because we're discussing related to top group
      mutate(prop_reduction = (diff_n_cases[parameter_set == "baseline"] - diff_n_cases) / diff_n_cases[parameter_set == "baseline"]) %>% 
      
      # Calculate quantiles across sim_ids
      group_by(i_group, parameter_set) %>% 
      summarise_quantiles(prop_reduction) %>% 
      filter(q %in% c(0.05, 0.5, 0.95)) %>% 
      mutate(q_label = case_when(q == 0.05 ~ "_lower",
                                 q == 0.5   ~ "",
                                 q == 0.95 ~ "_upper")) %>% 
      select(-q) %>%
      ungroup %>% 
      pivot_wider(names_from = q_label,
                  values_from = prop_reduction,
                  names_prefix = "prop_reduction")
    
    # Plot
    contributions_df %>% 
      mutate(i_group = recode_i_group(i_group)) %>% 
      ggplot(aes(x = parameter_set, y = prop_reduction, fill = i_group)) + 
      geom_col(position = "dodge", width = 0.7) + 
      geom_errorbar(aes(ymin = prop_reduction_lower, ymax = prop_reduction_upper), position = position_dodge(0.7), width = 0.2, size = 0.5, colour = "#374561") + 
      labs(x = "Scenario", y = "% reduction in inequality\nrelative to group 5&6") + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1)) + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         end = 0.766666667,
                         discrete = TRUE,
                         name = "SES Group") + 
      scale_x_discrete(labels = counterfactual_labels) + 
      theme_custom() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),
            panel.grid.minor = element_blank(),
            panel.grid.major.x = element_blank()) + 
      coord_cartesian(ylim = c(-0.1, 1)) + 
      geom_hline(yintercept = 0)
    
    
    ggsave("figures/inequality_decomposition.png",  width = 6, height = 4.5, scale = 0.8)
    
# Output tables ------------------------------------------------------------------
    
    # Column 0 - N infected in each one
    # Column 1 - what proportion of population in each group are infected in each one
    # Column 2 - implied effect relative to baseline on inequality
    # Column 3 - implied contribution of effect on inequality
    
    # Should report the median, the 95th centiles
    # 
    
    
    # group_diff_table <- group_diff_all_summ %>% 
    #   pivot_longer(-c(q, n_pop, parameter_set, i_group), names_to = "outcome_name", values_to = "outcome_val") %>% 
    #   filter(q %in% c(0.01, 0.5, 0.99)) %>% 
    #   
    #   # Combine confidence intervals
    #   pivot_wider(names_from = q, values_from = outcome_val) %>% 
    #   rename(lower =  `0.01`, upper = `0.99`, median = `0.5`) %>% 
    #   
    #   # Keep only outcomes we want in the table
    #   filter(outcome_name %in% c("prop_infected", "diff_prop_infected_effect", "contribution")) %>% 
    #   
    #   # Clean up vars
    #   mutate(
    #     across(c(lower, upper), ~ replace_with_na(.x, c(0, 1))),
    #     across(c(lower, upper), ~ replace_with_na(.x, c(0))),
    #     across(c(lower, median, upper), ~ round(.x, 2)),  # Round all to 3 d.p.
    #     across(c(lower, upper), ~ format(.x, digits = 2, nsmall = 2, trim = TRUE)), 
    #     median = format(median, digits = 2, nsmall = 2),
    #     across(c(median), ~ if_else(str_detect(.x, "NA"), "", .x))
    #   ) %>% # remove 0s/1s
    #   
    #   # Combine lower / upper
    #   mutate(conf = if_else(str_detect(lower, "NA"), "", as.character(str_glue("[{lower}, {upper}]")))) %>% 
    #   mutate(output = str_glue("{median} {conf}")) %>% 
    #   select(-lower, -upper, -median, -conf) %>%
    #   select(-n_pop) %>% 
    #   
    #   # Get each variable in its own column 
    #   pivot_wider(names_from = outcome_name, values_from = output) %>% 
    #   mutate(
    #     parameter_set = fct_recode(parameter_set,
    #                                "Baseline" = "baseline",
    #                                "Interactions (Out)" = "out_contacts",
    #                                "Interactions (Home)" = "home_contacts",
    #                                "Isolation" = "isolation_behaviour",
    #                                "Testing & Tracing" = "testing_tracing",
    #                                "All" = "all"
    #     )
    #   ) %>% 
    #   
    #   # Only write parameter set once each time
    #   mutate(parameter_set = as.character(parameter_set)) %>% 
    #   group_by(parameter_set) %>% 
    #   mutate(parameter_set = if_else(parameter_set == lag(parameter_set) & !is.na(lag(parameter_set)), "", parameter_set)) %>% 
    #   
    #   # Rename columns
    #   set_names(
    #     c("Parameter Set", "SES Group", "Proportion Infected", "Effect on group 5 gap", "Contribution")
    #   ) %>% 
    #   
    #   print_all
    # 
    # library("xtable")
    # 
    # print.xtable(
    #   xtable(group_diff_table, caption = "Main Output"),
    #   # type = "html",
    #   caption.placement = "top",
    #   table.placement = "!htbp",
    #   file = "group_diffs.tex",
    #   include.rownames = FALSE,
    #   hline.after = 0:5 * 5
    # )
    # 
    # 
    # 
    # 
    # 
    # ?as.character
    # 
    # format_dbl <- function(x, n_digits) {
    #   as.character(format(round(x, n_digits), nsmall = n_digits))
    # }
    # 
    # format_chr <- function(x) {
    #   str_replace_all(x, "_", " ") %>% 
    #     str_to_title(locale = "en")
    # }
    # 
    # 
    # 
    # out_table <- sds_means %>% 
    #   ungroup %>% 
    #   mutate(p.value = sds_mean_diffs$p.value) %>% 
    #   select(-conf.low, -conf.high) %>% 
    #   mutate(
    #     stratum = as.integer(stratum),
    #     p.value = format_dbl(p.value, 3),
    #     p.value = if_else(stratum == 1, "-", p.value),
    #     std.error = format_dbl(std.error, 2),
    #     estimate = format_dbl(estimate, 2),
    #     delay_var = format_chr(delay_var)
    #   ) %>% 
    #   mutate(mean_se = str_glue("{estimate} ({std.error})")) %>% 
    #   mutate(delay_var = if_else(delay_var == lag(delay_var) & !is.na(lag(delay_var)), "", delay_var)) %>% 
    #   select("Delay Type" = delay_var, 
    #          "SES stratum" = stratum, 
    #          "Mean (SE)" = mean_se,
    #          "p val diff (to stratum 1)" = p.value,
    #          "N" = N)
    # 
    # 
    # 
    # 
    # print.xtable(
    #   xtable(out_table, caption = "Testing Delay Means"),
    #   # type = "html",
    #   caption.placement = "top",
    #   table.placement = "!htbp",
    #   file = "test_delay_means.tex",
    #   include.rownames = FALSE
    # )
    
    

# 5. Share of detected-------------------------------------------------------
    
    

    # 2 options:
    # (1) What share of people who are infected are detected at at least one time during their infection?
    # (2) What's the average proportion of infected people at a given t who are detected [weighted by # infected at that t?]
    
    # Number 2 I can already calculate:
    
    # share_detected_instantaneous <- group_diff_slim %>% 
    #   filter(parameter_set != "out_plus_home") %>% 
    #   filter(parameter_set %in% c("baseline", "testing_tracing", "all")) %>%
    #   
    #   mutate(share_detected_inst = n_detected / n_cases_live) %>% 
    #   group_by(parameter_set, sim_id, i_group) %>% 
    #   select(t, share_detected_inst, n_cases_live) %>% 
    #   summarise(share_detected_w = weighted.mean(x = share_detected_inst, w = n_cases_live)) %>% 
    #   group_by(parameter_set, i_group) %>% 
    #   summarise(
    #     q = c(0.025, 0.25, 0.5, 0.75, 0.975),
    #     across(c(share_detected_w),
    #            ~ quantile(.x, q = c(0.025, 0.25, 0.5, 0.75, 0.975)))
    #     # quibble
    #     # quibble(diff_prop_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9)),
    #     # quibble(diff_tot_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9))
    #   ) %>% 
    #   mutate(
    #     parameter_set = factor(parameter_set, levels = unique(group_diff_slim$parameter_set))
    #   )
    # 
    # share_detected_instantaneous %>% plot_group_diffs(y = share_detected_w, 
    #                                                   # ylab = "Average share of infected who have tested positive"
    #                                                   ylab = "Avg. share detected"
    # )
    # 
    # 
    # # ggsave("share_detected.png",width = 8, height = 4.5, scale = 0.8)
    # ggsave("share_detected_testing_tracing.png", width = 8, height = 2.5, scale = 0.8)
    
    
    
    
    
    
    # V2 - ratio of confirmed cases / total cases
    
    share_confirmed <- group_diff_slim %>% 
      filter(parameter_set != "out_plus_home") %>% 
      filter(parameter_set %in% c("baseline", "testing_tracing", "all")) %>%
      
      group_by(parameter_set, sim_id, i_group) %>% 
      summarise(n_confirmed_cases = max(n_confirmed_cases),
                n_cases_cum = max(n_cases_cum)) %>% 
      mutate(share_confirmed = n_confirmed_cases / n_cases_cum) %>% 
      
      group_by(parameter_set, i_group) %>% 
      
      summarise(
        q = c(0.025, 0.25, 0.5, 0.75, 0.975),
        share_confirmed = quantile(share_confirmed, q = c(0.025, 0.25, 0.5, 0.75, 0.975))
      ) %>% 
      mutate(
        parameter_set = factor(parameter_set, levels = unique(group_diff_slim$parameter_set))
      )
    
    
    share_confirmed %>% plot_group_diffs(y = share_confirmed, 
                                         # ylab = "Average share of infected who have tested positive"
                                         ylab = "Avg. share detected")
    
    
    ggsave("figures/share_detected_testing_tracing.png", width = 8, height = 2.5, scale = 0.8)
    
    
# 6. Share isolated ----------------------------------------------------------
    
    
    
    
    share_isolated_instantaneous <- group_diff_slim %>% 
      filter(parameter_set != "out_plus_home") %>% 
      filter(parameter_set %in% c("baseline", "testing_tracing", "all")) %>%
      
      # filter(sim_id == 1, i_group == 1) %>% 
      # filter(n_cases_live > 200) %>% 
      # print(n = 200) %>% 
      # ggplot(aes(x = t, y = n_isolators / n_cases_live, colour = factor(parameter_set))) + 
      # geom_line()
      mutate(isolation_ratio_inst = n_isolators / n_cases_live) %>% 
      group_by(parameter_set, sim_id, i_group) %>% 
      select(t, isolation_ratio_inst, n_cases_live) %>% 
      summarise(isolation_ratio_w = weighted.mean(x = isolation_ratio_inst, w = n_cases_live)) %>% 
      group_by(parameter_set, i_group) %>% 
      summarise(
        q = c(0.025, 0.25, 0.5, 0.75, 0.975),
        across(c(isolation_ratio_w),
               ~ quantile(.x, q = c(0.025, 0.25, 0.5, 0.75, 0.975)))
        # quibble
        # quibble(diff_prop_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9)),
        # quibble(diff_tot_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9))
      ) %>% 
      mutate(
        parameter_set = factor(parameter_set, levels = unique(group_diff_slim$parameter_set))
      )
    
    share_isolated_instantaneous %>% plot_group_diffs(y = "isolation_ratio_w", ylab = "Avg. # Isolating / # Infected")
    
    
    # ggsave("share_isolated.png",width = 8, height = 4.5, scale = 0.8)
    ggsave("figures/share_isolated_testing_tracing.png", width = 8, height = 2.5, scale = 0.8)
    
    
    
    

# .... --------------------------------------------------------------------


