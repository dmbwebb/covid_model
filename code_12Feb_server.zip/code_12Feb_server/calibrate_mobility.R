
# (0) ACTUAL CASES DATA ---------------------------------------------------

# Import actual case data -------------------------------------------------


    stratum_pops <- data_save$sds_case_data %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>% 
      group_by(stratum, stratum_pop) %>% 
      summarise() %>% 
      filter(!is.na(stratum)) %>% 
      summarise(stratum_pop = sum(stratum_pop))



    confirmed_cases_actual <- data_save$sds_case_data %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>% 
      filter(!is.na(stratum)) %>% 
      group_by(stratum, date_results) %>% 
      summarise(n_cases_day = n()) %>% 
      full_join(
        crossing(stratum = 1:4, date_results = ymd("2020-03-01") + days(1:400)), by = c("stratum", "date_results")
      ) %>% 
      mutate(n_cases_day = if_else(is.na(n_cases_day), 0L, n_cases_day)) %>% 
      left_join(
        stratum_pops, by = "stratum"
      ) %>% 
      # Calculate model t in real data
      # mutate(t = interval_days(ymd("2020-04-01"), date_results) + start_t) %>% 
      arrange(stratum, date_results) %>% 
      group_by(stratum, stratum_pop) %>% 
      mutate(n_new_cases_week_roll = zoo::rollsum(n_cases_day, k = 7, fill = NA, align = "right")) %>% 
      mutate(new_cases_per_cap = (n_new_cases_week_roll / stratum_pop)) %>% 
      mutate(n_confirmed_cum = cumsum(n_cases_day) / stratum_pop,
             n_confirmed_cum_abs = cumsum(n_cases_day)) %>% 
      ungroup %>% 
      filter(
        # date_results <= ymd("2020-11-01")
        # date_results > ymd("2020-04-01")
      ) %>% 
      mutate(
        new_cases_per_cap = ifelse(date_results >= ymd("2020-12-01"), NA, new_cases_per_cap),
        n_confirmed_cum = ifelse(date_results >= ymd("2020-12-01"), NA, n_confirmed_cum)
      ) %>% 
      select(i_group = stratum, date_results, new_cases_per_cap, n_confirmed_cum, n_confirmed_cum_abs)
    # mutate(source = "data")

    
    
    overall_prev <- data_save$sds_case_data %>% 
      select(case_id, date_results) %>% 
      group_by(date_results) %>% 
      summarise(new_cases = n()) %>% 
      full_join(tibble(date_results = ymd("2020-03-01") + days(0:300))) %>% 
      arrange(date_results) %>% 
      mutate(new_cases = if_else(is.na(new_cases), 0L, new_cases)) %>% print(n = 500) %>% 
      mutate(days_since_march_1 = interval_days("2020-03-01", date_results)) %>% 
      mutate(ln_new_cases = log(new_cases))


    
    

# Positivity data ---------------------------------------------------------


    
    monthly_positivity <- readxl::read_excel("data/positivity_rates.xlsx") %>% 
      left_join(
        tibble(day = ymd("2020-06-01") + days(1:200),
               month = month(day)),
        by = "month"
      ) %>% 
      print_all
    
    

    

    

# .... --------------------------------------------------------------------

    
# (1) MANUAL MATCHING -------------------------------------------------
    
    


# Run sim -----------------------------------------------------------------

    data_save$params_data$days_of_work
    data_save$params_data$outside_non_work
    
    
    
    outside_work_factor <- 1.4    # Note: this scales contact_means linearly
    
    contacts_outside_home <- data_save$params_data$outside_non_work + (data_save$params_data$days_of_work * outside_work_factor)
    
    data_save$contacts_outside_home <- contacts_outside_home
    
    ind_mean_hh_size <- data_save$hh_data_bogota %>% 
      group_by(i_group) %>% 
      summarise(ind_mean_hh_size = mean(hh_size, na.rm = TRUE)) %>% 
      .$ind_mean_hh_size
    
    total_contacts <- contacts_outside_home + (ind_mean_hh_size - 1)
    
    p_contact_traced <- data_save$params_data$contacts_traced / total_contacts
    
    
    data_save$p_contact_traced <- p_contact_traced
    
    save(data_save, file = "data/processed/data_save.RData")
    
    
    
    
    # THEN NEED TO RERUN CONTACT MATRIX CALCULATION BASED ON THIS ****
    source("code/calc_contact_matrix_4groups.R")
    
    
    # print(str_glue("Assuming k_scale_factor of {k_scale_factor}"))
    # data_save$k_scale_factor <- k_scale_factor

    
    
    # 
    # load("data/processed/data_save.RData")
    
    n_pop_total <- 100000
    
    set.seed(12345)
  
    # print(str_glue("policy_start_times = {policy_start_times}"))
    
    # k_matrix_basic <- data_save$k_matrix * data_save$k_scale_factor * (n_pop_total / data_save$k_matrix_pop)
    k_matrix_basic <- data_save$k_matrix * (n_pop_total / data_save$k_matrix_pop)


    
    # OTHER VARIABLE IS WHAT PROP OF THE POP IS INFECTED AT THE START...
    
    # policy_start_manual <- c(0, 135, 175) # PREVIOUS VALUE
    
    # policy_start_manual <- c(0, 85, 175 + 30)
    
    
    # policy_start_manual <- c(0, 25 + mobility_increase_factor$delay[-1])
    policy_start_manual <- c(0, 35 + mobility_increase_factor$delay[-1])
    
    
    
    data_save$policy_start_manual <- policy_start_manual
    
    
    # mobility_factors <- c(1, 0.7, 1.1) # original manual
    # mobility_factors <- mobility_increase_factor$factor # original
    mobility_factors <- (mobility_increase_factor$factor - 1) * 0.4 + 1
    
    # MANUAL 
    # mobility_factors <- c(1, 1.23, 0.9, 1.3, 1.6)
    mobility_factors <- c(1, 1.25, 0.95, 1.4, 1.6)
    
    # mobility_factors <- c(1, 1, 1)
    
    k_manual <- mobility_factors %>% 
      map(~ list(k_matrix = k_matrix_basic * .x)) %>% 
      set_names(as.character(1:length(.)))
    
    data_save$mobility_factors <- mobility_factors
    
    
    # Other inputs
    n_initial_cases <- round(data_save$group_props * n_pop_total / 5000) # 5000th of the pop is infected at the model start
    group_props <- c(
      round(data_save$group_props[1:3] * n_pop_total) / n_pop_total,
      1 - sum(round(data_save$group_props[1:3] * n_pop_total) / n_pop_total)
    )

    
    
    # RUN MODEL WITH MOBILITY CHANGE
    set.seed(12345)
    manual_adjustment_test <- outbreak_sims_policy_change(
      n_sims = 3,
      n_iterations = 300,
      keep_all_data = FALSE,
      print_detail = TRUE,
      constant_params = list(
        n_pop = n_pop_total, 
        hh_size_data = data_save$hh_data_bogota,
        n_initial_cases = n_initial_cases, # calculated within function if remains NULL
        group_props = group_props,     # ditto
        dt_approx = 1,
        recov_val = 10, # people recover 10 days after symptoms show (cuts off only ~ 1% of infections at the upper end of timing distribution)
        params_timing = data_save$params_timing,
        params_symptom_timing = data_save$params_symptom_timing,
        params_serial = data_save$params_serial,
        test_delay_data = data_save$test_delay_data,
        test_sensitivity_data = data_save$test_sensitivity_data, 
        ct_delay_data = data_save$ct_delay_data,
        probs_self_test_df = data_save$probs_self_test,
        probs_isolate_symptoms_df = data_save$probs_isolate_symptoms,
        probs_isolate_test_df = data_save$probs_isolate_test,
        probs_isolate_ct_df =   data_save$probs_isolate_ct,
        p_contact_if_isolated_home = rep(1, 4), 
        p_contact_traced = data_save$p_contact_traced, # TAKEN FROM ABOVE
        p_hh_quarantine = data_save$params_data$p_hh_quarantine,
        
        contact_dispersion = data_save$contact_dispersion,
        sar_out = data_save$params_data$sar_out_input,
        sar_home = data_save$params_data$sar_home_input, 
        infectiousness_by_symptoms = data_save$infectiouness_by_symptoms,
        alpha = c(0, 0, 0, 0)
      ),
      policy_start_times = policy_start_manual,
      time_varying_params = k_manual
    )
    
    # time_series_1 <- manual_adjustment_test$time_series
    # time_series_2 <- 
    
    # time_series_3 <- manual_adjustment_test$time_series
    # save(time_series_3, file = "data/temp/mobility_calibrate_time_series")
    
    # DF with total cases:
    manual_adjustment_total_cases <- manual_adjustment_test$time_series %>% 
      group_by(sim_id, t, policy) %>% 
      # sum up across i_groups
      summarise(across(c(n_new_cases, n_confirmed_cases), sum)) %>% 
      group_by(sim_id) %>% 
      mutate(
        new_cases_actual = n_new_cases,
        new_cases_detected =  n_confirmed_cases  - lag(n_confirmed_cases)
      ) %>% 
      mutate(
        across(c(new_cases_actual, new_cases_detected), list(log_pc = ~ log(. / n_pop_total))),
      )
    
    
    
    
    # load("data/temp/mobility_calibrate_time_series", verbose = TRUE)
    
    # data <- time_series_3
    
    
    report_confirmed_ratio(manual_adjustment_test$time_series) 
    # about 10% of cases are confirmed
    
    

    
    
  
      
    

# Check R0 slope at start -------------------------------------------------------

    min_t <- 10; max_t <- 75
    
    # REGRESSION (1) ACTUAL CASES
    manual_adjustment_total_cases %>% 
      group_by(sim_id) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(reg_model = 
               list(lm(new_cases_actual_log_pc ~ t, 
                  data = data, 
                  subset = t <= max_t & t >= min_t & !is.infinite(new_cases_actual_log_pc))),
             r = reg_model$coefficients[[2]])
    
    
    reg_model <- lm(new_cases_actual_log_pc ~ t, 
                    data = manual_adjustment_total_cases, 
                    subset = t <= max_t & t >= min_t & !is.infinite(new_cases_actual_log_pc))
    
    # Coefficients
    r <- reg_model$coefficients[[2]]
    r_conf <- confint(reg_model)[2, ]
    (r_lab <- str_glue("r = {round(r, 3)}\n[{round(r_conf[[1]], 3)}, {round(r_conf[[2]], 3)}]"))
    
    # PLOT
    manual_adjustment_total_cases %>% 
      ggplot(aes(x = t, y = new_cases_actual_log_pc))  + 
      geom_point(alpha = 0.2) + 
      geom_smooth(aes(group = sim_id), data = manual_adjustment_total_cases %>% filter(t <= max_t & t >= min_t), method = "lm",) +
      theme_custom(panel.grid = element_blank()) + 
      labs(x = "t", y = "ln(Daily New Cases)") + 
      annotate(geom = "text", x = 0, y = -5, label = r_lab, vjust = "inward", hjust = "inward") +  
      geom_text(label = r_lab) %>% 
      print()
    
    
    # CALCULATE R0
    # Import generation interval dist
    dens <- density(gen_data_clean$secondary_timing)
    gen_int <- tibble(x = dens$x, y = dens$y) %>% 
      filter(x > 0) 
    
    # Combine with exponential 
    integrand_df <- gen_int %>% 
      rename(t = x, g_x = y) %>% 
      mutate(exp_term = exp(-r * t),
             integrand = exp_term * g_x)
    
    # Numerically integrate
    # Create a trapezoid function that approximates the integrand
    integrand_trapezoid <- approxfun(integrand_df$t,
                                     integrand_df$integrand)
  
    r0_inv <- integrate(integrand_trapezoid, min(integrand_df$t), max(integrand_df$t))$value
    r0 <- 1 / r0_inv
    print(str_glue("R0 is estimated to be {round(r0, 2)}"))
    
    
    
    
    

# Plot relative to real [logs, overall] ----------------------------------------------

    t_shift <- 5
    
    manual_adj_cases_with_t <- manual_adjustment_total_cases %>% 
      mutate(date_model = ymd("2020-03-01") + days(t_shift) + t)
    
    
    match_model_data_manual <- overall_prev %>%
      filter(new_cases != 0) %>% 
      left_join(manual_adj_cases_with_t, by = c("date_results" = "date_model")) %>%
      mutate(n_new_cases_pc = new_cases_detected / n_pop_total,
             n_confirmed_pc = new_cases_actual / n_pop_total,
             new_cases_pc = new_cases / monthly_positivity$n_pop_total[[1]]) %>%
      mutate(
        # real_positivity_log_pc = log(daily_cases_pc),
        real_detected_log_pc = log(new_cases_pc),
        model_detected_log_pc = log(n_new_cases_pc),
        model_log_pc = log(n_confirmed_pc)
      ) %>%
      full_join(monthly_positivity, by = c("date_results" = "day")) %>% 
      mutate(real_positivity_log_pc = log(daily_cases_pc)) %>% 
      select(t, sim_id, date_results, 
             real_positivity_log_pc,
             real_detected_log_pc, model_detected_log_pc, model_log_pc) %>%
      group_by(date_results, t) %>% 
      quantile_summarise(-sim_id, conf_level = 0.9) %>% 
      pivot_longer(-c(t, date_results), names_to = c("measure", ".value"), names_pattern = "^(.*)_log_pc_(median|upper|lower)$") %>% 
      print
    
    
    # PLOT
    ggplot(match_model_data_manual, aes(x = date_results, y = upper, colour = measure)) +
      geom_point(alpha = 0.5) + 
      geom_vline(xintercept = ymd("2020-03-01") + days(t_shift) + days(policy_start_manual)) + 
      scale_x_date(breaks = "months", date_labels = "%b %d")
    

    
    # data_save$probs_self_test
    
    
    
    

# Plot by group -----------------------------------------------------------

    
    
    manual_by_group <- manual_adjustment_test$time_series %>% 
      select(sim_id, t, i_group, policy, n_pop, n_confirmed_cases) %>% 
      arrange(sim_id, i_group, t) %>% 
      group_by(sim_id, i_group) %>% 
      mutate(
        model_new_confirmed = n_confirmed_cases - lag(n_confirmed_cases),
        model_new_confirmed_week_roll = zoo::rollsum(model_new_confirmed, k = 20, fill = NA, align = "right") / (20/7),
        model_new_confirmed_week_roll_pc = model_new_confirmed_week_roll / n_pop,
        model_cum_confirmed = n_confirmed_cases,
        model_cum_confirmed_pc = n_confirmed_cases / n_pop
        # new_cases_per_cap = (n_new_cases_week_roll / n_pop)
      ) %>% 
      select(-n_confirmed_cases) %>% 
      mutate(date_model = ymd("2020-03-01") + days(t_shift) + t)
    
    
    manual_by_group_with_data <- full_join(
      confirmed_cases_actual %>% rename(data_new_confirmed_pc = new_cases_per_cap,
                                                                          data_cum_confirmed_pc = n_confirmed_cum,
                                                                          data_cum_confirmed = n_confirmed_cum_abs),
      manual_by_group,
      by = c("date_results" = "date_model", "i_group")
    ) %>% 
      rename(date = date_results) %>% 
      mutate(i_group = recode_i_group(i_group))
    
    
    # CUMULATIVE
    manual_by_group_with_data %>% 
      group_by(t, date, i_group, data_cum_confirmed_pc) %>% 
      quantile_summarise(c(model_cum_confirmed_pc), conf_level = 0.9) %>% 
      # filter(date <= ymd("2020-07-01")) %>% 
      ggplot(aes(x = date, colour = i_group)) + 
      geom_line(aes(y = model_cum_confirmed_pc_median), size = 1.5) + 
      geom_ribbon(aes(ymin = model_cum_confirmed_pc_lower,
                      ymax = model_cum_confirmed_pc_upper,
                      fill = i_group),
                  alpha = 0.1, size = 0.3) +
      geom_line(aes(y = data_cum_confirmed_pc), linetype = "dashed", size = 1) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      scale_fill_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      theme_custom() + 
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    # CUMULATIVE ALL GROUPS
    manual_by_group_with_data %>%
      group_by(sim_id, t, date) %>% 
      # filter(date <= ymd("2020-07-01")) %>% 
      summarise(across(c(model_cum_confirmed_pc, data_cum_confirmed_pc), sum)) %>% 
      ggplot(aes(x = date)) + 
      geom_line(aes(y = model_cum_confirmed_pc, group = factor(sim_id)), size = 0.3) + 
      geom_line(aes(y = data_cum_confirmed_pc), linetype = "dashed", size = 1) + 
      theme_custom() + 
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    # NEW
    manual_by_group_with_data %>% 
      group_by(t, date, i_group, data_new_confirmed_pc) %>% 
      quantile_summarise(c(model_new_confirmed_week_roll_pc)) %>% 
      pivot_longer(c(model_new_confirmed_week_roll_pc_median, data_new_confirmed_pc)) %>% 
      # filter(date <= ymd("2020-07-01")) %>% 
      ggplot(aes(x = date, colour = i_group)) + 
      geom_line(aes(y = value), size = 1) + 
      facet_wrap(~ name) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      theme_custom()
    
    # NEW ALL GROUPS
    match_model_data_manual %>%
      mutate(across(c(median, upper, lower), exp)) %>% 
      filter(str_detect(measure, "detected")) %>% 
      arrange(measure, date_results) %>% group_by(measure) %>% 
      mutate(across(c(median, upper, lower), list(roll = ~ zoo::rollmean(.x, k = 7, na.pad = TRUE, align = "left")))) %>% 
      ggplot(aes(x = date_results, y = median_roll)) + 
      geom_line(aes(colour = measure), size = 1.5) + 
      geom_ribbon(aes(ymin = lower_roll, ymax = upper_roll, fill = measure), alpha = 0.2) + 
      theme_custom() + 
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
      
    
    
    
    
    confirmed_cases_actual %>% 
      select(-t) %>% rename(data_new_confirmed_pc = new_cases_per_cap,
                            data_cum_confirmed_pc = n_confirmed_cum,
                            data_cum_confirmed = n_confirmed_cum_abs) %>% 
      group_by(date_results) %>% 
      summarise(data_cum_confirmed = sum(data_cum_confirmed)) %>% 
      mutate(n_pop_actual = monthly_positivity$n_pop_total[[1]],
             data_cum_confirmed_pc = data_cum_confirmed / n_pop_actual) %>% 
      mutate(guesstimate_total = lead(10 * data_cum_confirmed_pc, 14),
             guesstimate_frac = round(1/guesstimate_total)) %>% 
      print(n = 100)
    
    

# ........... -------------------------------------------------------------


# OLD ---------------------------------------------------------------------


# Calculate implied exponential ----------------------------------------------------
    
    
    # Plot to check time window
    plot(sim_for_r0)
    # plot_by_i_group(sim_for_r0, prop = TRUE)
    plot_detected_by_i_group(sim_for_r0)
    plot_detected(sim_for_r0)
    
    
    
   
    
    
    min_t <- 1
    max_t <- 75
    
    
    
    
    
    # REGRESSION (1) ACTUAL CASES
    reg <- lm(new_cases_actual_log_pc ~ t, data = new_cases, 
              subset = t <= max_t & t >= min_t & !is.infinite(new_cases_actual_log_pc))
    
    # Coefficients
    r <- reg$coefficients[[2]]
    r_conf <- confint(reg)[2, ]
    
    (r_lab <- str_glue("r = {round(r, 3)}\n[{round(r_conf[[1]], 3)}, {round(r_conf[[2]], 3)}]"))
    
    # PLOT
    new_cases %>% 
      # filter(date_results >= ymd("2020-03-14")) %>% 
      # filter(new_cases != 0) %>% 
      
      ggplot(aes(x = t, y = new_cases_actual_log_pc))  + 
      geom_point(alpha = 0.2) + 
      geom_smooth(data = new_cases %>% filter(t <= max_t & t >= min_t), method = "lm") +
      theme_custom(panel.grid = element_blank()) + 
      labs(x = "t", y = "ln(Daily New Cases)") + 
      annotate(geom = "text", x = 0, y = -5, label = r_lab, vjust = "inward", hjust = "inward") +  
      geom_text(label = r_lab) %>% 
      print()
    
    
    # REGRESSION (2) - DETECTED cases
    # reg <- lm(new_cases_detected_log_pc ~ t, data = new_cases, 
    #           subset = t <= max_t & t >= min_t & !is.na(new_cases_detected_log_pc) & !is.infinite(new_cases_detected_log_pc))
    # 
    # 
    # 
    # 
    # # Coefficients
    # r <- reg$coefficients[[2]]
    # r_conf <- confint(reg)[2, ]
    # 
    # (r_lab <- str_glue("r = {round(r, 3)}\n[{round(r_conf[[1]], 3)}, {round(r_conf[[2]], 3)}]"))
    # 
    # # PLOT
    # new_cases %>% 
    #   # filter(date_results >= ymd("2020-03-14")) %>% 
    #   # filter(new_cases != 0) %>% 
    #   
    #   ggplot(aes(x = t, y = new_cases_detected_log_pc))  + 
    #   geom_point(alpha = 0.2) + 
    #   geom_smooth(data = new_cases %>% filter(t <= max_t & t >= min_t), method = "lm") +
    #   theme_custom(panel.grid = element_blank()) + 
    #   labs(x = "t", y = "ln(Daily New Cases)") + 
    #   annotate(geom = "text", x = 0, y = -5, label = r_lab, vjust = "inward", hjust = "inward") +  
    #   geom_text(label = r_lab) %>% 
    #   print()
    
    
    

    
    
    geom_smooth(data = match_model_data %>% filter(date_results <= max_date & date_results >= min_date), method = "lm") +
      theme_custom(panel.grid = element_blank()) +
      labs(x = "t", y = "ln(Daily Confirmed New Cases)")
    # 
    

    
    
    
    
    
# ....... -----------------------------------------------------------------
    
    
# (1) MOBILITY MATCHING -------------------------------------------------------
    
    
    
    
    
    
# Mobility factors -----------------------------------------------------------
    
    # Import
    mobility_data <- read_csv("data/bogota_mobility_report.csv") %>% 
      select(date:residential_percent_change_from_baseline) %>% 
      mutate(date = dmy(date)) %>% 
      pivot_longer(-date, names_to = "category", values_to = "perc_change") %>% 
      mutate(category = str_replace_all(category, "_percent_change_from_baseline", ""))
    
    
    # Quick plot
    mobility_data %>% 
      arrange(category, date) %>% 
      group_by(category) %>% 
      mutate(perc_change = if_else(category == "residential", -perc_change, perc_change)) %>% 
      mutate(perc_change_roll = zoo::rollmean(perc_change, k = 7, na.pad = TRUE, align = "left")) %>% 
      ggplot(aes(x = date, y = perc_change_roll, colour = category)) + 
      scale_x_date(minor_breaks = "months") + 
      geom_line() + 
      facet_wrap(~ category)
    
    
    # INVERSE OF RESIDENTIAL??
    mobility_data %>% 
      filter(category == "residential") %>% 
      arrange(category, date) %>% 
      group_by(category) %>% 
      mutate(perc_change_roll = zoo::rollmean(perc_change, k = 7, na.pad = TRUE, align = "left"),
             perc_change_roll_inv = -perc_change_roll) %>% 
      ggplot(aes(x = date, y = perc_change_roll_inv, colour = category)) + 
      scale_x_date(minor_breaks = "months") + 
      geom_line() + 
      facet_wrap(~ category)
    
    
    
    
    phase_dates <- tibble(
      phase_date = ymd(
        c("2020-04-01", "2020-06-01", "2020-07-10", "2020-08-20", "2020-10-01", "2030-01-01")
      )
    ) %>% mutate(phase = row_number())
    
    
    
    # Take the rolling average (only workplaces)
    mobility_summ <- mobility_data %>% 
      # mutate(perc_change = if_else(category == "residential", -perc_change, perc_change)) %>% 
      filter(category == "transit_stations") %>%
      mutate(perc_change_roll = zoo::rollmean(perc_change, k = 7, na.pad = TRUE, align = "left")) %>% 
      mutate(
        phase_dates = list(phase_dates$phase_date)
      ) %>% 
      rowwise() %>% 
      mutate(
        phase_date = last_non_na(phase_dates[date >= phase_dates])
      ) %>% 
      filter(!is.na(phase_date)) %>%
      left_join(phase_dates, by = "phase_date") %>% 
      # mutate(phase = case_when(
      #   date >= ymd("2020-04-01") & date < ymd("2020-06-01") ~ "1_severe_lockdown",
      #   date >= ymd("2020-06-01")        & date < ymd("2020-10-01")   ~ "2_lighter_lockdown",
      #   date >= ymd("2020-10-01")                              ~ "3_loose"
      # )) %>% 
      mutate(month = month(date)) %>% 
      group_by(phase, phase_date) %>% 
      summarise(phase_average = mean(perc_change))
                # date = first_non_na(date),
                # yday = yday(date)
                # ) %>% 
      # filter(!is.na(month))
    
    # Assume that in early april it's 
    
    
    


    mobility_data %>% 
      filter(category == "transit_stations") %>% 
      mutate(perc_change_roll = zoo::rollmean(perc_change, k = 7, na.pad = TRUE, align = "left"),
             perc_change_roll_inv = perc_change_roll) %>% 
      mutate(
        phase_dates = list(phase_dates$phase_date)
      ) %>% 
      rowwise() %>% 
      mutate(
        phase_date = last_non_na(phase_dates[date >= phase_dates])
      ) %>% 
      left_join(phase_dates, by = "phase_date") %>% 
      # mutate(phase = case_when(
      #   # date >= ymd("2020-04-01") & date < ymd("2020-06-01") ~ "1_severe_lockdown",
      #   # date >= ymd("2020-06-01")        & date < ymd("2020-10-01")   ~ "2_lighter_lockdown",
      #   # date >= ymd("2020-10-01")                              ~ "3_loose"
      #   date >= ymd("2020-04-01") & date < ymd("2020-06-01") ~ "1_severe_lockdown",
      #   date >= ymd("2020-06-01")        & date < ymd("2020-07-10")   ~ "2_lighter_lockdown",
      #   date >= ymd("2020-07-10")        & date < ymd("2020-08-20")   ~ "2.5_august_dip",
      #   date >= ymd("2020-08-20")        & date < ymd("2020-08-20")   ~ "2.5_august_dip",
      #   date >= ymd("2020-10-01")                              ~ "3_loose"
      # )) %>% 
      mutate(month = month(date)) %>% 
      group_by(phase) %>% 
      mutate(phase_average = mean(perc_change)) %>% 
      ggplot(aes(x = date, y = perc_change_roll_inv, colour = category)) + 
      scale_x_date(minor_breaks = "months") + 
      geom_line() + 
      geom_line(aes(y = phase_average), colour = "skyblue") + 
      facet_wrap(~ category)
    
    
    mobility_increase_factor <- mobility_summ %>% select(phase, phase_date, phase_average) %>% 
      mutate(pp = 1 + (phase_average / 100)) %>% 
      ungroup %>% 
      # filter(!is.na(phase)) %>% 
      mutate(factor = pp /  pp[phase == first(phase)]) %>% 
      mutate(delay = interval_days(ymd("2020-04-01"), phase_date))
    
    
    
    
# Test  -------------------------------------------------------------------
    
    k_scale_factor <- 1    # Note: this scales contact_means linearly
    
    print(str_glue("Assuming k_scale_factor of {k_scale_factor}"))
    data_save$k_scale_factor <- k_scale_factor
    # save(data_save, file = "data/processed/data_save.RData")
    
    
    n_pop_total <- 100000
    
    set.seed(12345)
    
    
    # time_delay <- -10
    
    t_start_yday <- 80  # cannot be below 46
    
    mobility_periods <- mobility_increase_factor %>% 
      filter(yday > t_start_yday | yday == last(yday[yday <= t_start_yday])) %>% 
      mutate(delay = yday - t_start_yday)
    
    policy_start_times <- c(
      0, mobility_periods$delay[-c(1)]
    ) %>% 
      print()
    
    # print(str_glue("policy_start_times = {policy_start_times}"))
    
    k_matrix_basic <- data_save$k_matrix * data_save$k_scale_factor * (n_pop_total / data_save$k_matrix_pop)
    
    mobility_adjusted_k <- mobility_periods$factor %>% 
      map(~ list(k_matrix = k_matrix_basic * .x)) %>% 
      set_names(mobility_periods$month)
    
    
    
    # OTHER VARIABLE IS WHAT PROP OF THE POP IS INFECTED AT THE START...
    
    
    # Other inputs
    n_initial_cases <- round(data_save$group_props * n_pop / 5000) # 5000th of the pop is infected at the model start
    group_props <- c(
      round(data_save$group_props[1:3] * n_pop) / n_pop,
      1 - sum(round(data_save$group_props[1:3] * n_pop) / n_pop)
    )
    
    
    # RUN MODEL WITH MOBILITY CHANGE
    set.seed(12345)
    mobility_change_test <- outbreak_sims_policy_change(
      n_sims = 1,
      n_iterations = 365,
      keep_all_data = FALSE,
      print_detail = TRUE,
      constant_params = list(
        n_pop = n_pop, 
        hh_size_data = data_save$hh_data_bogota,
        n_initial_cases = n_initial_cases, # calculated within function if remains NULL
        group_props = group_props,     # ditto
        dt_approx = 1,
        recov_val = 10, # people recover 10 days after symptoms show (cuts off only ~ 1% of infections at the upper end of timing distribution)
        params_timing = data_save$params_timing,
        params_symptom_timing = data_save$params_symptom_timing,
        params_serial = data_save$params_serial,
        test_delay_data = data_save$test_delay_data,
        test_sensitivity_data = data_save$test_sensitivity_data, 
        ct_delay_data = data_save$ct_delay_data,
        probs_self_test_df = data_save$probs_self_test,
        probs_isolate_symptoms_df = data_save$probs_isolate_symptoms,
        probs_isolate_test_df = data_save$probs_isolate_test,
        probs_isolate_ct_df =   data_save$probs_isolate_ct,
        p_contact_if_isolated_home = rep(1, 4), 
        p_contact_traced = data_save$params_data$p_contact_traced,
        p_hh_quarantine = data_save$params_data$p_hh_quarantine,
        
        contact_dispersion = data_save$contact_dispersion,
        sar_out = data_save$params_data$sar_out_input,
        sar_home = data_save$params_data$sar_home_input, 
        infectiousness_by_symptoms = data_save$infectiouness_by_symptoms,
        alpha = c(0, 0, 0, 0)
      ),
      policy_start_times = policy_start_times,
      time_varying_params = mobility_adjusted_k
    )
    
    
    new_cases <- mobility_change_test$time_series %>% 
      group_by(sim_id, t, policy) %>% 
      # sum up across i_groups
      summarise(across(c(n_new_cases, n_confirmed_cases), sum)) %>% 
      group_by(sim_id) %>% 
      mutate(
        new_cases_actual = n_new_cases,
        new_cases_detected =  n_confirmed_cases  - lag(n_confirmed_cases)
      ) %>% 
      mutate(
        across(c(new_cases_actual, new_cases_detected), list(log_pc = ~ log(. / n_pop_total))),
      ) %>% 
      mutate(
        date_model = ymd("2020-05-01") + days(t - first(t[policy == "5"]))
      )
    
    
    
    
    
    
    
    
    match_model_data <- overall_prev %>%
      # filter(date_results >= ymd("2020-03-14")) %>%
      # mutate(t = days_since_march_1 + 30 - time_delay) %>%
      filter(new_cases != 0) %>%
      left_join(new_cases, by = c("date_results" = "date_model")) %>%
      mutate(n_new_cases_pc = new_cases_detected / n_pop_total,
             n_confirmed_pc = new_cases_actual / n_pop_total,
             new_cases_pc = new_cases / monthly_positivity$n_pop_total[[1]]) %>%
      mutate(
        # real_positivity_log_pc = log(daily_cases_pc),
        real_detected_log_pc = log(new_cases_pc),
        model_detected_log_pc = log(n_new_cases_pc),
        model_log_pc = log(n_confirmed_pc)
      ) %>%
      full_join(monthly_positivity, by = c("date_results" = "day")) %>% 
      mutate(real_positivity_log_pc = log(daily_cases_pc)) %>% 
      select(t, date_results, 
             real_positivity_log_pc,
             real_detected_log_pc, model_detected_log_pc, model_log_pc) %>%
      pivot_longer(-c(t, date_results))
    
    
    # PLOT
    ggplot(match_model_data, aes(x = date_results, y = value, colour = name)) +
      geom_point(alpha = 0.5) + 
      scale_x_date(breaks = "months", date_labels = "%b %d")
    
    
    
    
    
    
    
    # Second plot (by stratum total cases) ------------------------------------
    
    confirmed_cases_by_igroup <- mobility_change_test$time_series %>% 
      select(sim_id, t, i_group, policy, n_pop, n_confirmed_cases) %>% 
      arrange(sim_id, i_group, t) %>% 
      group_by(sim_id, i_group) %>% 
      mutate(
        model_new_confirmed = n_confirmed_cases - lag(n_confirmed_cases),
        model_new_confirmed_week_roll = zoo::rollsum(model_new_confirmed, k = 20, fill = NA, align = "right") / (20/7),
        model_cum_confirmed = n_confirmed_cases,
        model_cum_confirmed_pc = n_confirmed_cases / n_pop
        # new_cases_per_cap = (n_new_cases_week_roll / n_pop)
      ) %>% 
      select(-n_confirmed_cases) %>% 
      mutate(
        date_model = ymd("2020-05-01") + days(t - first(t[policy == "5"]))
      )
    
    
    cases_model_data <- full_join(
      confirmed_cases_actual %>% print(n = 100) %>% select(-t) %>% rename(data_new_confirmed_pc = new_cases_per_cap,
                                                                          data_cum_confirmed_pc = n_confirmed_cum,
                                                                          data_cum_confirmed = n_confirmed_cum_abs),
      confirmed_cases_by_igroup,
      by = c("date_results" = "date_model", "i_group")
    ) %>% 
      rename(date = date_results) %>% 
      mutate(i_group = recode_i_group(i_group))
    
    
    cases_model_data %>% 
      ggplot(aes(x = date, colour = i_group)) + 
      geom_line(aes(y = model_cum_confirmed_pc), size = 1) + 
      geom_line(aes(y = data_cum_confirmed_pc), linetype = "dashed", size = 1) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      theme_custom()
    
    
    
    
    
    confirmed_cases_actual %>% 
      select(-t) %>% rename(data_new_confirmed_pc = new_cases_per_cap,
                            data_cum_confirmed_pc = n_confirmed_cum,
                            data_cum_confirmed = n_confirmed_cum_abs) %>% 
      group_by(date_results) %>% 
      summarise(data_cum_confirmed = sum(data_cum_confirmed)) %>% 
      mutate(n_pop_actual = monthly_positivity$n_pop_total[[1]],
             data_cum_confirmed_pc = data_cum_confirmed / n_pop_actual) %>% 
      mutate(guesstimate_total = lead(10 * data_cum_confirmed_pc, 14),
             guesstimate_frac = round(1/guesstimate_total)) %>% 
      print(n = 100)
    
    