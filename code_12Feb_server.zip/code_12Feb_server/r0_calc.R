
    library("haven")
    library("lubridate")
    
    load("data/processed/data_save.RData")
    load("data/processed/gen_data_clean_timings.RData")
    
# Exponential growth calc -------------------------------------------------

    overall_prev <- data_save$sds_case_data %>% 
      select(case_id, date_results) %>% 
      group_by(date_results) %>% 
      summarise(new_cases = n()) %>% 
      full_join(tibble(date_results = ymd("2020-03-01") + days(0:300))) %>% 
      arrange(date_results) %>% 
      mutate(new_cases = if_else(is.na(new_cases), 0L, new_cases)) %>% print(n = 500) %>% 
      mutate(days_since_march_1 = interval_days("2020-03-01", date_results)) %>% 
      mutate(ln_new_cases = log(new_cases))
    
    
    # min_date <- ymd("2020-03-01") + days(30)
    min_date <- ymd("2020-04-01")
    max_date <- ymd("2020-04-01") + 60
      days(interval_days(data_save$start_date, data_save$lockdown_end_date[[1]]))
    
   
    
    
    # REGRESSION
    reg <- lm(ln_new_cases ~ days_since_march_1, data = overall_prev, 
              subset = date_results <= max_date & date_results >= min_date)
    
    # Coefficients
    r <- reg$coefficients[[2]]
    r_conf <- confint(reg)[2, ]
    
    (r_lab <- str_glue("r = {round(r, 3)}\n[{round(r_conf[[1]], 3)}, {round(r_conf[[2]], 3)}]"))
    
    # PLOT
    overall_prev %>% 
      filter(date_results >= ymd("2020-03-14")) %>% 
      filter(new_cases != 0) %>% 
      
      ggplot(aes(x = date_results, y = ln_new_cases))  + 
      geom_point(alpha = 0.2) + 
      geom_smooth(data = overall_prev %>% filter(date_results <= max_date & date_results >= min_date), method = "lm") + 
      # theme_custom(panel.grid = element_blank()) + 
      scale_x_date(minor_breaks = "months") + 
      labs(x = "Days since 1st March 2020", y = "ln(Daily Confirmed New Cases)")
      # annotate(geom = "text", x = 0, y = 7.5, label = r_lab, vjust = "inward", hjust = "inward")
      # geom_text(label = r_lab)
    
    
    
    
    

# Import generation interval dist -----------------------------------------

    
    
    ggplot(gen_data_clean, aes(x = secondary_timing)) + 
      geom_density(colour = "seagreen4", fill = "seagreen4", alpha = 0.5) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
      labs(y = "Density", x = "Generation Interval (days)") + 
      coord_cartesian(xlim = c(0, 20)) +
      theme_classic()
    
    
    
    gen_data_clean$secondary_timing
    
    
    dens <- density(gen_data_clean$secondary_timing)
    
    
    gen_int <- tibble(x = dens$x, y = dens$y) %>% 
      filter(x > 0) 
    
  
    ggplot(gen_int, aes(x = x, y = y)) + geom_line()
    

    
    
    

# Combine with exponential -----------------------------------------------

    
    r <- reg$coefficients[[2]]
    # r <- confint(reg)[2, ][[1]]
    
    integrand_df <- gen_int %>% 
      rename(t = x, g_x = y) %>% 
      mutate(exp_term = exp(-r * t),
             integrand = exp_term * g_x)
    
    
    
    
    

# Numerically integrate ---------------------------------------------------

    # Create a trapezoid function that approximates the integrand
    integrand_trapezoid <- approxfun(integrand_df$t,
                                     integrand_df$integrand)
    
    
    r0_inv <- integrate(integrand_trapezoid, min(integrand_df$t), max(integrand_df$t))$value

    r0 <- 1 / r0_inv
    
    print(str_glue("R0 estimate from data is {round(r0, 3)}"))
    
    data_save$initial_r0 <- r0
    

    