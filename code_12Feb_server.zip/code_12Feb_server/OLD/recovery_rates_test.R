idr_system <- function(time, variables, parameters) {
  with(as.list(c(variables, parameters)), {
    dI <- - pi * I - gamma * I
    dD <- + pi * I - gamma * D
    dR <- gamma * I + gamma * D
    return(list(c(dI, dD, dR)))
  })
} 

# HYPOTHESIS: R curve should be UNCHANGED WHEN WE CHANGE pi - i.e. because recovery rates are unchanged




initial_values <- c(
  I = 1,
  D = 0,
  R = 0
)

idr_by_params <- function(pi, gamma) {
  
  # parms <- c(
  #   pi = 1/50,
  #   gamma = 1/10
  # )
  
  parms <- c(
    pi = pi,
    gamma = gamma
  )
  
  require(deSolve)
  
  results <- ode(
    y = initial_values,
    times = seq(0, 100, 0.1),
    func = idr_system,
    parms = parms 
  )
  
  results <- results %>% as.data.frame() %>% as_tibble()
  # if (tau - kappa * lambda < 0) warning("tau - kappa * lambda < 0")
  
  results
  
}

results_by_pi <- crossing(
  pi = seq(0, 1, 0.1),
  gamma = c(1/10, 1/20, 0.5)
) %>% 
  mutate(results = pmap(., idr_by_params)) %>% 
  unnest(results)

results_by_pi %>%
  ggplot(aes(x = time, y = R, colour = factor(pi))) + 
  geom_line() + 
  facet_wrap(~ paste0("gamma = ", gamma))














