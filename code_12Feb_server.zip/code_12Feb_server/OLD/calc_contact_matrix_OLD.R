# Beta / K matrices -------------------------------------------------------

    
    
    k_matrix_trial_6 <- Matrix::forceSymmetric(
      matrix(
        c(4, 1, 1, 1, 1, 1,
          4,  6, 1, 1, 1, 1,
          3,  4, 7, 1, 1, 1,
          1,  3, 3, 4, 1, 1,
          1,  1, 2, 2, 3, 1, 
          0,  0, 1, 1, 2, 3),
        nrow = 6
      )
    ) %>% as.matrix()
    
  

# Functions ----------------------------------------------------------------

    
    # Takes k_vec and mu as inputs, and outputs the full k_matrix
    k_vec_to_matrix_OLD_6 <- function(k_vec, mu) {
      
      # k_vec_example <- c( c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
      #                     c(2, 0.5, 0.3, 0.3),
      #                     c(2, 0.5, 0.3),
      #                     c(2, 0.5),
      #                     c(2))
      
      if (length(k_vec) != 15) {
        print(length(k_vec))
        stop("wrong length of k_vec")
      }
      
      k_1_almost <- k_vec[1:5]
      k_2_almost <- k_vec[6:9]
      k_3_almost <- k_vec[10:12]
      k_4_almost <- k_vec[13:14]
      k_5_almost <- k_vec[15]
      # k_6 is pinned down by the mu
      
      k_1 <- append(k_1_almost, mu_vec[[1]] - sum(k_1_almost))
      k_2 <- c(k_1[[2]], k_2_almost) %>% append(mu_vec[[2]] - sum(.))
      k_3 <- c(k_1[[3]], k_2[[3]], k_3_almost) %>% append(mu_vec[[3]] - sum(.))
      k_4 <- c(k_1[[4]], k_2[[4]], k_3[[4]], k_4_almost) %>% append(mu_vec[[4]] - sum(.))
      k_5 <- c(k_1[[5]], k_2[[5]], k_3[[5]], k_4[[5]], k_5_almost) %>% append(mu_vec[[5]] - sum(.))
      k_6 <- c(k_1[[6]], k_2[[6]], k_3[[6]], k_4[[6]], k_5[[6]]) %>% append(mu_vec[[6]] - sum(.))
      
      # Make the k matrix for clarity
      k_matrix <- matrix(
        c(
          k_1, k_2, k_3, k_4, k_5, k_6
        ),
        nrow = 6, 
        byrow = TRUE
      )
      
      return(k_matrix)
      
    }
    
    k_matrix_to_vec_OLD_6 <- function(k_matrix) {
      
      i_row <- c(rep(1, 5), rep(2, 4), rep(3, 3), rep(4, 2), rep(5, 1))
      i_col <- c(1:5, 2:5, 3:5, 4:5, 5)
      
      k_vec <- list()
      for (i in seq_along(i_row)) {
        k_vec[[i]] <- as.vector(k_matrix[ i_row[[i]], i_col[[i]] ])
      }
      
      return(flatten_dbl(k_vec))
      
    }
    
    
    
    # Takes k_vec and mu_vec as inputs, and outputs the full k_matrix
    k_vec_to_matrix <- function(k_vec, mu_vec) {
      
      # k_vec_example <- c( c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
      #                     c(2, 0.5, 0.3, 0.3),
      #                     c(2, 0.5, 0.3),
      #                     c(2, 0.5),
      #                     c(2))
      
      if (length(k_vec) != 10) {
        print(length(k_vec))
        stop("wrong length of k_vec")
      }
      
      k_1_almost <- k_vec[1:4]
      k_2_almost <- k_vec[5:7]
      k_3_almost <- k_vec[8:9]
      k_4_almost <- k_vec[10]
      # k_5 is pinned down by the mu
      
      k_1 <- append(k_1_almost, mu_vec[[1]] - sum(k_1_almost))
      k_2 <- c(k_1[[2]], k_2_almost) %>% append(mu_vec[[2]] - sum(.))
      k_3 <- c(k_1[[3]], k_2[[3]], k_3_almost) %>% append(mu_vec[[3]] - sum(.))
      k_4 <- c(k_1[[4]], k_2[[4]], k_3[[4]], k_4_almost) %>% append(mu_vec[[4]] - sum(.))
      k_5 <- c(k_1[[5]], k_2[[5]], k_3[[5]], k_4[[5]]) %>% append(mu_vec[[5]] - sum(.))
      
      # Make the k matrix for clarity
      k_matrix <- matrix(
        c(
          k_1, k_2, k_3, k_4, k_5
        ),
        nrow = 5, 
        byrow = TRUE
      )
      
      return(k_matrix)
      
    }
    
    
    k_matrix_to_vec <- function(k_matrix) {
      
      i_row <- c(rep(1, 4), rep(2, 3), rep(3, 2), rep(4, 1))
      i_col <- c(1:4, 2:4, 3:4, 4)
      
      k_vec <- list()
      for (i in seq_along(i_row)) {
        k_vec[[i]] <- as.vector(k_matrix[ i_row[[i]], i_col[[i]] ])
      }
      
      return(flatten_dbl(k_vec))
      
    }
    
    
    
    
    # Takes the parameter vector as an input, and outputs all the implied parameters
    # e.g. the k_matrix, the q_matrix, etc.
    read_params_OLD_6 <- function(params) {
      
      mu <- params[1:6]
      size <- params[[7]]
      k_vec <- params[8:22]
      
      k_matrix <- k_vec_to_matrix(k_vec = k_vec, mu_vec = mu)
      
      # Check there's no negative values
      # if (any(k_matrix < 0, na.rm = TRUE) | any(is.na(k_matrix))) {
      #   # print("Negative or missing values in k")
      #   # return(Inf)
      #   # WILL NEED TO RETURN INFINITY HERE
      # }
      
      mu_matrix <- matrix(
        rep(mu, each = 6), nrow = 6,
        byrow = FALSE
      )
      
      q_matrix <- k_matrix / mu_matrix     # columns sum to 1
      
      # Convert q_matrix into form that can be joined onto tibble
      q_tibble <- q_matrix %>% as_tibble() %>% 
        set_names(paste0("primary", 1:6)) %>% 
        mutate(secondary_i_group = row_number()) %>% 
        pivot_longer(-secondary_i_group, names_to = "i_group", names_prefix = "primary", values_to = "q_estimate") %>% 
        mutate(i_group = as.integer(i_group))
      
      
      out <- list(
        mu = mu,
        size = size,
        k_vec = k_vec,
        k_matrix = k_matrix,
        mu_matrix = mu_matrix,
        q_matrix = q_matrix,
        q_tibble = q_tibble
      )
      
      return(out)
      
    }
    
    
    
    
    
    
    # Calculate the log likelihood of observing data given parameters
    contact_maxlik <- function(param_vec, data) {
      
      # INPUTS FOR TESTING
      # param_vec <- c(
      #   c(5, 5, 5, 5, 5, 10),       # mu
      #   0.5,                       # size
      #   c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
      #        c(2, 0.5, 0.3, 0.3),
      #             c(2, 0.5, 0.3),
      #                  c(2, 0.5),
      #                       c(2)
      # )
      # 
      # data <- tibble(
      #   id = 1:10000,
      #   i_group = sample(c(1:6), size = 10000, replace = TRUE)
      # ) %>%
      #   left_join(tibble(i_group = 1:6, mu_actual = c(5, 6, 5, 5, 5, 10))) %>%
      #   mutate(
      #     contacts_total = rnbinom(n = 10000, size = 0.4, mu = mu_actual)
      #   ) %>%
      #   rowwise() %>%
      #   mutate(contacts_id = if_else(contacts_total > 0, list(1:contacts_total), list(NA_integer_))) %>%
      #   unnest(contacts_id) %>%
      #   mutate(secondary_i_group = if_else(contacts_total > 0,
      #                                      sample(x = 1:6, size = nrow(.), replace = TRUE, prob = c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1)),
      #                                      NA_integer_)) %>%
      #   select(-mu_actual, -contacts_id)
      # ---
      
      params <- read_params(param_vec)

      
      # Check there's no negative / missing values
      if (any(params$k_matrix < -0.001, na.rm = TRUE) | any(is.na(params$k_matrix))) {
        print("Negative or missing values in k")
        # print(params$k_matrix)
        # return(Inf)
      }
      
      # Check symmetric
      if (!isSymmetric(params$k_matrix)) {
        print(params$k_matrix)
        stop("matrix is not symmetric")
      }
      
      # Add on p_estimate for number of contacts
      data_p <- data %>% dups_drop(id, warn = FALSE) %>% 
        left_join(tibble(i_group = 1:6, mu = params$mu), by = "i_group") %>% 
        mutate(
          p_estimate = dnbinom(x = contacts_total, size = params$size, mu = mu)
        )
      
      # And q_estimate on group of contact from q_matrix
      data_q <- data  %>% 
        left_join(q_tibble, by = c("i_group", "secondary_i_group")) %>% 
        mutate(q_estimate = replace_na(q_estimate, 1))
      
      # Negative log likelihood (to be minimised)
      neg_ll <- -(sum(log(data_q$q_estimate)) + sum(log(data_p$p_estimate)))
      
      return(neg_ll)
      
    }
    
    
    
    
    
    
    

# ...... ------------------------------------------------------------------


# TESTING -----------------------------------------------------------------

    # Function that MAKES A DATA EXAMPLE THAT FOLLOWS THE assumed data-generating process
    gen_example_data <- function(mu, size, k_vec, N = 1000) {
      
      # mu_example <- c(4, 7, 5, 5, 4, 7)
      # size_example <- 0.5
      # 
      # k_vec_example <- c( c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
      #                     c(2, 1, 0.3, 0.3),
      #                     c(2, 0.5, 0.3),
      #                     c(2, 0.5),
      #                     c(2))
      
      (k_matrix <- k_vec_to_matrix(k_vec, mu))
      
      mu_matrix <- matrix(
        rep(mu, each = 6), nrow = 6,
        byrow = FALSE
      )
      
      q_matrix <- k_matrix / mu_matrix     # columns sum to 1
      # [i, j] = [to, from]
      
      # Convert q_matrix into form that can be joined onto tibble
      q_tibble <- q_matrix %>% as_tibble() %>% 
        set_names(paste0("primary", 1:6)) %>% 
        mutate(secondary_i_group = row_number()) %>% 
        pivot_longer(-secondary_i_group, names_to = "i_group", names_prefix = "primary", values_to = "q_estimate") %>% 
        mutate(i_group = as.integer(i_group))
      
      
      data_example_split <- tibble(
        id = 1:N,
        i_group = sample(c(1:6), size = N, replace = TRUE)
      ) %>% 
        left_join(tibble(i_group = 1:6, mu_actual = mu), by = "i_group") %>% 
        mutate(
          contacts_total = rnbinom(n = N, size = size, mu = mu_actual)
        ) %>% 
        rowwise() %>% 
        mutate(contacts_id = if_else(contacts_total > 0, list(1:contacts_total), list(NA_integer_))) %>% 
        unnest(contacts_id) %>% 
        group_by(i_group) %>% 
        group_split() 
      
      q_list <- as.list(as.data.frame(q_matrix))
      
      data_example_bind <- map2(.x = data_example_split, .y = q_list, .f = ~ {
        .x %>% mutate(secondary_i_group = if_else(contacts_total > 0, 
                                                  sample(x = 1:6, size = nrow(.), replace = TRUE, 
                                                         prob = .y),
                                                  NA_integer_))
      }) %>% 
        bind_rows() %>% 
        arrange(id)
      
      
      return(data_example_bind)
    }
    
    
# Test the maxlik function (basic test) -------------------------------------------------------

    contact_maxlik(
      params = c(
        c(5, 5, 5, 5, 5, 10),       # mu
        0.5,                       # size
        c(2, 0.5, 0.8, 0.3, 0.1),   # k_1
        c(2, 0.5, 0.3, 0.3),
        c(2, 0.5, 0.3),
        c(2, 0.5),
        c(2)
      ),
      
      data = tibble(
        id = 1:10000,
        i_group = sample(c(1:6), size = 10000, replace = TRUE)
      ) %>% 
        left_join(tibble(i_group = 1:6, mu_actual = c(5, 6, 5, 5, 5, 10)), by = "i_group") %>% 
        mutate(
          contacts_total = rnbinom(n = 10000, size = 0.4, mu = mu_actual)
        ) %>% 
        rowwise() %>% 
        mutate(contacts_id = if_else(contacts_total > 0, list(1:contacts_total), list(NA_integer_))) %>% 
        unnest(contacts_id) %>% 
        mutate(secondary_i_group = if_else(contacts_total > 0, 
                                           sample(x = 1:6, size = nrow(.), replace = TRUE, prob = c(0.1, 0.2, 0.3, 0.2, 0.1, 0.1)),
                                           NA_integer_)) %>% 
        select(-mu_actual, -contacts_id)
    )
    
    

# Test with an example ----------------------------------------------------



    
    
    data_example <- gen_example_data(mu = c(4, 7, 5, 5, 4, 7),
                                     size = 0.5,
                                     k_vec = c( c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
                                                c(2, 1, 0.3, 0.3),
                                                c(2, 0.5, 0.3),
                                                c(2, 0.5),
                                                c(2)),
                                     N = 10000)
    
    
    k_constraint <- function(params, data) {

      k_vals <- read_params(params)$k_matrix %>% as.vector()

      return(-k_vals)

    }
    
    
    # CALCULATE NAIVE STARTING PARAMS
    mu_start <- data_example %>% select(id, i_group, contacts_total) %>% dups_drop(warn = FALSE) %>% 
      group_by(i_group) %>% summarise(contacts_total = mean(contacts_total)) %>% 
      .$contacts_total
    
    size_start <- 0.2
    
    k_vec_start <- data_example %>% 
      group_by(i_group, secondary_i_group) %>% 
      filter(!is.na(secondary_i_group)) %>% 
      summarise(n_contacts = n()) %>% 
      mutate(q = n_contacts / sum(n_contacts)) %>% 
      left_join(tibble(i_group = 1:6, mu = mu_start)) %>% 
      mutate(k_val = q * mu) %>% 
      .$k_val %>% 
      matrix(nrow = 6, ncol = 6) %>%  # this isn't symmetrical because it hasn't been harmonised properly
      k_matrix_to_vec()             # infer the k_vec parameters from the matrix
    
    # NOTE: might want to adjust this so that k_matrix is forced to be symmetric (take average of k_ij and k_ji)
    # for the real data whcih will likely be less symmetrical
    
    # Test whether ML process gets the right answer
    library("nloptr")
    opt_results <- nloptr(
      x0 = c(mu_start, size_start, k_vec_start), 
      eval_f = contact_maxlik, 
      eval_g_ineq = k_constraint,
      lb = rep(0, 22), 
      # ub = c(rep(50, 6), 30, rep(50, 15)),
      opts = list(
        "algorithm" = "NLOPT_LN_COBYLA",
        "xtol_abs"=1.0e-6,
        "maxeval" = 1000,
        "print_level" = 1
      ),
      data = data_example
    )
    
    
    params_solution <- read_params(opt_results$solution)
    
    
    
    # CHECK DIFFS between the solution and true values
    mu_example
    params_solution$mu
    
    size_example
    params_solution$size
    
    
    round(q_matrix, 2)
    round(params_solution$q_matrix, 2)
    
    round(k_matrix, 2)
    round(params_solution$k_matrix, 1)
    
    
    
# Plot distributions ------------------------------------------------------
    
    
    # COMPARE DISTRIBUTIONS graphically
    comparison_data <- list(
      actual = data_example,
      inferred = gen_example_data(
        mu = params_solution$mu,
        size = params_solution$size,
        k_vec = params_solution$k_vec,
        N = 10000
      )
    ) %>% 
      bind_rows(.id = "data_type")
    
    comparison_data_grouped <- comparison_data %>% 
      mutate(id = paste0(data_type, "_", id)) %>% 
      tidyr::complete(id, secondary_i_group) %>% 
      arrange(id, secondary_i_group) %>% 
      group_by(data_type, id, secondary_i_group) %>% 
      summarise(n_in_secondary = sum(!is.na(contacts_id))) %>% 
      filter(!is.na(data_type), !is.na(secondary_i_group))
    
    
    ggplot(comparison_data_grouped) + 
      geom_density(aes(x = log(n_in_secondary + 1), colour = data_type), adjust = 2) + 
      facet_wrap(~ factor(secondary_i_group))
    
    
    
    
    
    
# CHeck probabilities work as expected ------------------------------------
    
    actual_data_probs <- comparison_data %>% filter(data_type == "actual") %>% 
      filter(!is.na(contacts_id)) %>% 
      group_by(i_group, secondary_i_group) %>% 
      summarise(n = n()) %>% 
      tidyr::complete(i_group, secondary_i_group) %>% 
      mutate(prop = round(n / sum(n), 2)) %>% 
      print_all
    
    data_q <- matrix(actual_data_probs$prop, nrow = 6)
    solution_q <- round(params_solution$q_matrix, 2)
    data_q - solution_q # magnitude of the error
    
    data_k <- matrix(actual_data_probs$n, nrow = 6) %>% print # check this is roughly symmetric. YES
    
    
    
    
    
    
    
    
    
    
    
    
    

# .... --------------------------------------------------------------------


# V2 - two-step approach -------------------------------------------------

    
    # THIS VERSION - we get mu and size beforehand using a different process, and then calculate the K's and Q's 
    # from the contact matrix data

    
    # Takes the parameter vector as an input, and outputs all the implied parameters
    # e.g. the k_matrix, the q_matrix, etc.
    read_params <- function(params) {
      
      mu <- params[1:5]
      k_vec <- params[6:15]
      
      k_matrix <- k_vec_to_matrix(k_vec = k_vec, mu_vec = mu)
      
      # Check there's no negative values
      # if (any(k_matrix < 0, na.rm = TRUE) | any(is.na(k_matrix))) {
      #   # print("Negative or missing values in k")
      #   # return(Inf)
      #   # WILL NEED TO RETURN INFINITY HERE
      # }
      
      mu_matrix <- matrix(
        rep(mu, each = 5), nrow = 5,
        byrow = FALSE
      )
      
      q_matrix <- k_matrix / mu_matrix     # columns sum to 1
      
      # Convert q_matrix into form that can be joined onto tibble
      q_tibble <- q_matrix %>% as_tibble() %>% 
        set_names(paste0("primary", 1:5)) %>% 
        mutate(secondary_i_group = row_number()) %>% 
        pivot_longer(-secondary_i_group, names_to = "i_group", names_prefix = "primary", values_to = "q_estimate") %>% 
        mutate(i_group = as.integer(i_group))
      
      
      out <- list(
        mu = mu,
        k_vec = k_vec,
        k_matrix = k_matrix,
        mu_matrix = mu_matrix,
        q_matrix = q_matrix,
        q_tibble = q_tibble
      )
      
      return(out)
      
    }
    
    
    
    # Calculate the log likelihood of observing data given parameters
    contact_maxlik_k_only <- function(k_vec, mu, data) {
      
      
      # INPUTS FOR TESTING
      # mu <- c(4, 7, 5, 5, 4, 7)
      # size <- 0.5
      # k_vec <- c( c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
      #             c(2, 1, 0.3, 0.3),
      #             c(2, 0.5, 0.3),
      #             c(2, 0.5),
      #             c(2))
      # data <- gen_example_data(mu = mu, size = size, k_vec = k_vec, N = 1000)
      
      params <- read_params(c(mu, k_vec))
      
      # Check there's no negative / missing values
      if (any(params$k_matrix < -0.001, na.rm = TRUE) | any(is.na(params$k_matrix))) {
        print("Negative or missing values in k")
        
        # if (any(is.nan(params$k_matrix))) browser()
        # print(params$k_matrix)
        return(Inf)
      }
      
      # Check symmetric
      if (!isSymmetric(params$k_matrix)) {
        print(params$k_matrix)
        stop("matrix is not symmetric")
      }
      
      # Add on p_estimate for number of contacts
      # data_p <- data %>% dups_drop(id, warn = FALSE) %>% 
      #   left_join(tibble(i_group = 1:6, mu = params$mu), by = "i_group") %>% 
      #   mutate(
      #     p_estimate = dnbinom(x = contacts_total, size = params$size, mu = mu)
      #   )
      
      # And q_estimate on group of contact from q_matrix
      data_q <- data  %>% 
        left_join(params$q_tibble, by = c("i_group", "secondary_i_group")) %>% 
        mutate(q_estimate = replace_na(q_estimate, 1))
      
      # Negative log likelihood (to be minimised)
      neg_ll <- -sum(log(data_q$q_estimate))
      
      return(neg_ll)
      
    }
    
    
    
    
    
    # CURRENTLY THIS IS A BIT ROUGH BECUASE IT DOESN'T ACCOUNT FOR THE 
    # DIFFERENT SAMPLE SIZES IN EACH "CELL" OF THE MATRIX
    # THIS IS WHY THE MAX LIKELIHOOD IS USEFUL
    symmetric_mean <- function(matrix) {
      
      for (i in 1:nrow(matrix)) {
        for (j in 1:ncol(matrix)) {
          mean_val <- (matrix[i, j]  + matrix[j, i]) / 2
          matrix[i, j] <- mean_val
          matrix[j, i] <- mean_val
        }
      }
      
      return(matrix)
    }
    
    

    k_vec_data <- k_matrix_to_vec(symmetric_mean(k_data))
    
    
    k_vec_to_matrix(k_vec_data, mu_vec = mu_guess)
    
    data_example <- gen_example_data(mu = mu_guess,
                                     size = 0.5,
                                     k_vec = k_vec_data,
                                     N = 100)
    
    
    
    
    shitty_data_example <- tibble(
      
    )
    
    

    
    k_vec_start <- data_example %>% 
      group_by(i_group, secondary_i_group) %>% 
      filter(!is.na(secondary_i_group)) %>% 
      summarise(n_contacts = n()) %>% 
      mutate(q = n_contacts / sum(n_contacts)) %>% 
      left_join(tibble(i_group = 1:6, mu = c(5, 6, 5, 5, 4.3, 7))) %>% 
      mutate(k_val = q * mu) %>% 
      .$k_val %>% 
      matrix(nrow = 6, ncol = 6) %>%  # this isn't symmetrical because it hasn't been harmonised properly
      k_matrix_to_vec()             # infer the k_vec parameters from the matrix
    
    # NOTE: might want to adjust this so that k_matrix is forced to be symmetric (take average of k_ij and k_ji)
    # for the real data whcih will likely be less symmetrical
    
    
    
    # Constraint function to prevent negative values in K matrix
    k_constraint <- function(k_vec, mu, data) {
      k_vals <- read_params(c(mu, k_vec))$k_matrix %>% as.vector()
      return(-k_vals)
    }

  
    # Test whether ML process gets the right answer
    library("nloptr")
    opt_results <- nloptr(
      x0 = k_vec_start, 
      eval_f = contact_maxlik_k_only, 
      eval_g_ineq = k_constraint,
      lb = rep(0, 15), 
      # ub = c(rep(50, 6), 30, rep(50, 15)),
      opts = list(
        "algorithm" = "NLOPT_LN_COBYLA",
        "xtol_abs"=1.0e-6,
        "maxeval" = 1000,
        "print_level" = 1
      ),
      mu = c(5, 6, 5, 5, 4.3, 7),
      data = data_example
    )
    
    
    
    
    
    
    
    

# Test with a shitty data example -----------------------------------------

    q_data <- matrix(
      c(2, 4, 4, 2, 0, 
        3, 36, 22, 4, 0,
        3, 27, 81, 12, 2,
        0, 2, 7, 9, 0,
        0, 3, 0, 0, 2),
      nrow = 5,
      byrow = TRUE
    ) %>% 
      {. / rowSums(.)}
    
    q_tibble <- q_data %>% as_tibble() %>% 
      set_names(paste0("primary", 1:5)) %>% 
      mutate(secondary_i_group = row_number()) %>% 
      pivot_longer(-secondary_i_group, names_to = "i_group", names_prefix = "primary", values_to = "q_estimate") %>% 
      mutate(i_group = as.integer(i_group))
    
    # CREATE example data using those probabilities
    shitty_data_example <- tibble(
      i_group = sample(1:5, size = 300, replace = TRUE, prob = data_save$group_props[1:5])
    ) %>% 
      group_by(i_group) %>% 
      group_split() %>% 
      map2(.y = q_tibble %>% group_by(i_group) %>% group_split() %>% map("q_estimate"),
           .f = ~ {
             .x %>% mutate(secondary_i_group = sample(1:5, size = nrow(.), replace = TRUE, prob = .y))
           }) %>% 
      bind_rows()
    
    
    k_vec_to_matrix(k_vec = rep(1, 10), mu = rep(6, 5))
  
    
    contact_maxlik_k_only(k_vec = rep(1, 10),
                          mu = rep(6, 5),
                          data = shitty_data_example)
    
    
    opt_results <- nloptr(
      x0 = rep(1, 10), 
      eval_f = contact_maxlik_k_only, 
      eval_g_ineq = k_constraint,
      lb = rep(0, 10), 
      # ub = c(rep(50, 6), 30, rep(50, 15)),
      opts = list(
        "algorithm" = "NLOPT_LN_COBYLA",
        "xtol_abs"=1.0e-6,
        "maxeval" = 10000,
        "print_level" = 1
      ),
      mu = rep(6, 5),
      data = shitty_data_example
    )
    
    k_solution <- k_vec_to_matrix(opt_results$solution, mu_vec = rep(6, 5)) %>% round(3)
    rowSums(k_solution)
    
    
    
    
    
    

# .............. ----------------------------------------------------------

# V3 - K with population size adjustment ----------------------------------

    # Takes k_vec and mu_vec as inputs, and outputs the full k_matrix
    k_vec_to_matrix <- function(k_vec, mu, pops) {
      
      # k_vec <- c(c(10, 5, 2, 2),   # k_1
      #            c(50, 15, 5),
      #            c(30, 5),
      #            c(5)) * 1000
      # mu <- 10:6 - 1/3
      # group_props <- data_save$group_props[1:5]
      # group_props[[5]] <- group_props[[5]] + data_save$group_props[[6]]
      # n_pop <- 23000
      
      if (length(k_vec) != 10) {
        print(length(k_vec))
        stop("wrong length of k_vec")
      }
      
      # Total contacts in each group
      total_contacts <- as.integer(round(mu * pops))
      
      k_1_almost <- k_vec[1:4]
      k_2_almost <- k_vec[5:7]
      k_3_almost <- k_vec[8:9]
      k_4_almost <- k_vec[10]
      # k_5 is pinned down by the mu
      
      k_1 <- append(k_1_almost, total_contacts[[1]] - sum(k_1_almost))
      k_2 <- c(k_1[[2]], k_2_almost) %>% append(total_contacts[[2]] - sum(.))
      k_3 <- c(k_1[[3]], k_2[[3]], k_3_almost) %>% append(total_contacts[[3]] - sum(.))
      k_4 <- c(k_1[[4]], k_2[[4]], k_3[[4]], k_4_almost) %>% append(total_contacts[[4]] - sum(.))
      k_5 <- c(k_1[[5]], k_2[[5]], k_3[[5]], k_4[[5]]) %>% append(total_contacts[[5]] - sum(.))
      
      # Make the k matrix for clarity
      k_matrix <- matrix(
        c(
          k_1, k_2, k_3, k_4, k_5
        ),
        nrow = 5, 
        byrow = TRUE
      )
      
      return(k_matrix)
      
    }
    
    
    k_matrix_to_vec <- function(k_matrix) {
      
      i_row <- c(rep(1, 4), rep(2, 3), rep(3, 2), rep(4, 1))
      i_col <- c(1:4, 2:4, 3:4, 4)
      
      k_vec <- list()
      for (i in seq_along(i_row)) {
        k_vec[[i]] <- as.vector(k_matrix[ i_row[[i]], i_col[[i]] ])
      }
      
      return(flatten_dbl(k_vec))
      
    }
    
    
 
    
    
    
    # Takes the parameter vector as an input, and outputs all the implied parameters
    # e.g. the k_matrix, the q_matrix, etc.
    read_params <- function(k_vec, mu, group_props, n_pop) {
      
      
      # k_vec <-  c(c(10, 5, 2, 2),   # k_1
      #             c(50, 15, 5),
      #             c(30, 5),
      #             c(5)) * 1000
      # mu <- rep(10, 5)
      # group_props <- data_save$group_props[1:5]
      # n_pop <- 23000
      
      # Calculate population size
      pops <- calc_pops(group_props, n_pop)
      
      
      k_matrix <- k_vec_to_matrix(k_vec = k_vec, mu = mu, pops = pops)
      
      # Check there's no negative values
      # if (any(k_matrix < 0, na.rm = TRUE) | any(is.na(k_matrix))) {
      #   # print("Negative or missing values in k")
      #   # return(Inf)
      #   # WILL NEED TO RETURN INFINITY HERE
      # }
    
      
      # mu_matrix <- matrix(
      #   rep(mu, each = 5), nrow = 5,
      #   byrow = FALSE
      # )
      
      
      q_matrix <- k_matrix / rowSums(k_matrix)     # rows sum to 1
    
      # Convert q_matrix into form that can be joined onto tibble
      q_tibble <- q_matrix %>% as_tibble() %>% 
        set_names(paste0("primary", 1:5)) %>% 
        mutate(secondary_i_group = row_number()) %>% 
        pivot_longer(-secondary_i_group, names_to = "i_group", names_prefix = "primary", values_to = "q_estimate") %>% 
        mutate(i_group = as.integer(i_group))
      
      
      # Calculate beta_matrix
      pop_matrix <- pops %*% t(pops)
      beta_matrix <- k_matrix / pop_matrix #* (n_pop^2)
      
      
      out <- list(
        mu = mu,
        k_vec = k_vec,
        k_matrix = k_matrix,
        # mu_matrix = mu_matrix,
        q_matrix = q_matrix,
        q_tibble = q_tibble,
        beta_matrix = beta_matrix,
        pops = pops
      )
      
      return(out)
      
    }
    
    
    
    
    
    
    # Calculate the log likelihood of observing data given parameters
    contact_maxlik_k_only <- function(k_vec, mu, group_props, n_pop, data) {
      
      
      # INPUTS FOR TESTING
      # k_vec <-  c(c(10, 5, 2, 2),   # k_1
      #             c(50, 15, 5),
      #             c(30, 5),
      #             c(5)) * 1000
      # mu <- rep(10, 5)
      # group_props <- data_save$group_props[1:5]
      # n_pop <- 23000
      # data <- shitty_data_example
      
      params <- read_params(k_vec = k_vec, mu = mu, group_props = group_props, n_pop = n_pop)
      print(round(params$k_matrix))
      # Check there's no negative / missing values
      if (any(params$k_matrix < -5, na.rm = TRUE) | any(is.na(params$k_matrix))) {
        print("Negative or missing values in k")
        
        # if (any(is.nan(params$k_matrix))) browser()
        # print(params$k_matrix)
        return(Inf)
      }
      
      # Check symmetric
      if (!isSymmetric(params$k_matrix)) {
        print(params$k_matrix)
        stop("matrix is not symmetric")
      }
      
      # Add on p_estimate for number of contacts
      # data_p <- data %>% dups_drop(id, warn = FALSE) %>% 
      #   left_join(tibble(i_group = 1:6, mu = params$mu), by = "i_group") %>% 
      #   mutate(
      #     p_estimate = dnbinom(x = contacts_total, size = params$size, mu = mu)
      #   )
      
      

      
      # And q_estimate on group of contact from q_matrix
      data_q <- data  %>% 
        left_join(params$q_tibble, by = c("i_group", "secondary_i_group")) %>% 
        mutate(q_estimate = replace_na(q_estimate, 1))
      
      # Negative log likelihood (to be minimised)
      neg_ll <- -sum(log(data_q$q_estimate))
      
      return(neg_ll)
      
    }
    
    
    # Constraint function to prevent negative values in K matrix
    k_constraint <- function(k_vec, mu, group_props, n_pop, data) {
      k_vals <- read_params(k_vec, mu, group_props, n_pop)$k_matrix %>% as.vector()
      return(-k_vals)
    }

    
    pops <- calc_pops(group_props = data_save$group_props[1:5], n_pop = 10000)
    
    pop_matrix <- pops %>% 
      {. %*% t(.)} %>%print
    
    beta_val <- pop_matrix %>% {10 * pops / rowSums(.)}
    
    k_start <- pop_matrix * beta_val[[1]]
    
    # TRY MAX LIKELIHOOD AGAIN
    opt_results <- nloptr::nloptr(
      x0 =  k_matrix_to_vec(k_start),
      eval_f = contact_maxlik_k_only, 
      eval_g_ineq = k_constraint,
      lb = rep(0, 10), 
      # ub = c(rep(50, 6), 30, rep(50, 15)),
      opts = list(
        "algorithm" = "NLOPT_LN_COBYLA",
        "xtol_abs"=1.0e-6,
        "maxeval" = 10000,
        "print_level" = 1
      ),
      mu = 10:6,
      group_props = data_save$group_props,
      n_pop = 10000,
      data = shitty_data_example
    )
    
    
    solution <- read_params(
      k_vec = opt_results$solution,
      mu = 10:6,
      group_props = data_save$group_props,
      n_pop = 10000
    )
    
    
    data_save$k_matrix_5 <- round(solution$k_matrix)
    
    
    
    
    # round(solution$k_matrix / (23000^2) * (10000^2))  # divide by original pop squared, then multiply by new pop squared
    
    # round(solution$k_matrix / calc_pops(group_props = data_save$group_props[1:5],
                                  # n_pop = 23000), 2)
    
    # solution$q_matrix %>% round(2)
    