x <- rnorm(1000)

y <- 0.5 * x




ggplot(tibble(x = x, y = y, )) + 
  geom_density(aes(x = x)) + 
  geom_density(aes(x = y), colour = "red") + 
  geom_line(data = tibble(x = seq(-2, 2, 0.1),
                          z = (1/0.5) * dnorm(x/0.5, mean = 0, sd = 1)),
            aes(x = x, y = z),
            colour = "blue")

hist(x)



# SUPPOSE we have 
r_1 = 1; r_2 = 0.05
r_tot = r_1 + r_2
mu <- 3
# >> 
(p <- r_tot / (r_tot + mu))

# r is directly proportional to the mean - higher r >> higher mean


tibble(
  x = rnbinom(n = 10000, size = r_1, p = p),
  y = rnbinom(n = 10000, size = r_2, p = p),
  z1 = x + y,
  z = rnbinom(n = 10000, size = r_tot, mu = mu)
) %>% 
  ggplot() + 
  geom_density(aes(x = z1)) +
  geom_density(aes(x = z), colour = "red") +
  geom_density(aes(x = y), colour = "darkgreen", alpha = 0) + 
  geom_density(aes(x = x), colour = "lightblue", alpha = 0)
  # coord_cartesian(xlim = c(20, 50), ylim = c(0, 3))


# WE WANT TO FIND THE PARAMETERS R_1 and R_2 that sum to r_tot



# Example likelihood ------------------------------------------------------

# SET PARAMETERS
r_11 <- 0.5
r_12 <- 0.1
r_22 <- 0.2

mu_1 <- 5
mu_2 <- 10


# DATA
d <- tibble(
  group_i = sample(1:2, size = 100, replace = TRUE),
  group_j = sample(1:2, size = 100, replace = TRUE),
  r_param = case_when(group_i == 1 & group_j == 1 ~ r_11,
                      group_i == 2 & group_j == 2 ~ r_22,
                      group_i == 1 & group_j == 2 ~ r_12,
                      group_i == 2 & group_j == 1 ~ r_12),
  mu_param = case_when(group_i == 1 ~ mu_1,
                       group_i == 2 ~ mu_2),
  y_ij = sample(0:50, size = 100, replace = TRUE)
)


# CALCULATE Ps
r_tot_1 <- r_11 + r_12
r_tot_2 <- r_12 + r_22

(p_1 <- r_tot_1 / (r_tot_1 + mu_1))
(p_2 <- r_tot_2 / (r_tot_2 + mu_2))

d %>% 
  left_join(tibble(group_i = c(1, 2),
                   p_param = c(p_1, p_2))) %>% 
  mutate(
    prob_val = dnbinom(x = y_ij, size = r_param, prob = p_param)
  ) %>% 
  pull(prob_val) %>% 
  log() %>% 
  sum()




# FUnction version --------------------------------------------------------


    ll_nbinom <- function(params, data) {
      
      # data <- tibble(
      #   group_i = sample(1:2, size = 100, replace = TRUE),
      #   group_j = sample(1:2, size = 100, replace = TRUE),
      #   y_ij = sample(0:50, size = 100, replace = TRUE)
      # )

      # params <- c(0.5, 0.1, 0.2, 5, 10)
      
      
      # SET PARAMETERS
      r_11 <- params[[1]]
      r_12 <- params[[2]]
      r_22 <- params[[3]]
      
      mu_1 <- params[[4]]
      mu_2 <- params[[5]]
      
      # CALCULATE Ps
      r_tot_1 <- r_11 + r_12
      r_tot_2 <- r_12 + r_22
      
      (p_1 <- r_tot_1 / (r_tot_1 + mu_1))
      (p_2 <- r_tot_2 / (r_tot_2 + mu_2))
      
      # DATA
      data_params <- data %>% 
        mutate(r_param = case_when(group_i == 1 & group_j == 1 ~ r_11,
                            group_i == 2 & group_j == 2 ~ r_22,
                            group_i == 1 & group_j == 2 ~ r_12,
                            group_i == 2 & group_j == 1 ~ r_12)) %>% 
        left_join(tibble(group_i = c(1, 2),
                         p_param = c(p_1, p_2)),
                  by = "group_i")
      
      # Calculate likelihood using negative binomial function
      ll <- data_params %>% 
        mutate(
          prob_val = dnbinom(x = y_ij, size = r_param, prob = p_param)
        ) %>% 
        pull(prob_val)
      
      return(-sum(log(ll)))
      
    }


    ll_nbinom(
      data = tibble(
        group_i = sample(1:2, size = 100, replace = TRUE),
        group_j = sample(1:2, size = 100, replace = TRUE),
        y_ij = sample(0:50, size = 100, replace = TRUE)
      ),
      params = c(0.5, 0.1, 0.2, 10, 100)
    )

    
    
    

# Optimise the function ---------------------------------------------------
    
    
    
    # EXAMPLE DATA TO SEE IF LIKELIHOOD FUNCTION WORKS
    params_example <- c(0.5, 0.1, 0.2, 10, 20)
    
    # CALCULATE Ps
    r_tot_1 <- params_example[[1]] + params_example[[2]]
    r_tot_2 <- params_example[[2]] + params_example[[3]]
    
    (p_1 <- r_tot_1 / (r_tot_1 + params_example[[4]]))
    (p_2 <- r_tot_2 / (r_tot_2 + params_example[[5]]))
    
    data_example <- tibble(
      group_i = rep(c(1, 2), times = 10000),
      group_j = rep(c(1, 1, 2, 2), times = 5000),
      r_example = rep(c(params_example[[1]], params_example[[2]], params_example[[2]], params_example[[3]]),
                      times = 5000),
      p_example = rep(c(p_1, p_2), times = 10000)
    ) %>% 
      mutate(
        y_ij = rnbinom(n = nrow(.), size = r_example, prob = p_example)
      ) %>% 
      select(-r_example, p_example)
   
    
    
    
    

    library("nloptr")
    nlbinom_optr <- nloptr(x0 = c(0.5, 0.1, 0.2, 10, 100), 
                           eval_f = ll_nbinom, 
                           lb = c(0, 0, 0, 0, 0),
                           opts = list(
                             "algorithm" = "NLOPT_LN_SBPLX",
                             "xtol_abs"=1.0e-10,
                             "maxeval" = 200,
                             "print_level" = 3
                           ),
                           data = data_example)

    (params_solution <- nlbinom_optr$solution)
    
    
    # CALCULATE Ps
    r_tot_1 <- params_solution[[1]] + params_solution[[2]]
    r_tot_2 <- params_solution[[2]] + params_solution[[3]]
    
    (p_1 <- r_tot_1 / (r_tot_1 + params[[4]]))
    (p_2 <- r_tot_2 / (r_tot_2 + params[[5]]))
    
    
    dist_solution <- tibble(id = 1:(10000),
                              group_i = sample(c(1, 2), size = 10000, replace = TRUE),
                              group_j = sample(c(1, 2), size = 10000, replace = TRUE)) %>%
      mutate(
        r_param = case_when(
          group_i == 1 & group_j == 1 ~ params_solution[[1]],
          group_i == 2 &
            group_j == 2 ~ params_solution[[3]],
          group_i == 1 &
            group_j == 2 ~ params_solution[[2]],
          group_i == 2 &
            group_j == 1 ~ params_solution[[2]]
        )
      ) %>%
      left_join(tibble(group_i = c(1, 2),
                       p_param = c(p_1, p_2)),
                by = "group_i") %>% 
      mutate(y = rnbinom(n = nrow(.), size = r_param, prob = p_param)) %>% 
      mutate(group_ij = paste0(group_i, "_", group_j))
    
    
    
    
    data_example %>% mutate(group_ij = paste0(group_i, "_", group_j)) %>% 
      ggplot(aes(group = group_ij)) + 
      geom_density(aes(x = log(y_ij + 1), fill = group_ij)) + 
      geom_density(data = dist_solution, aes(x = log(y + 1)), alpha = 0, colour = "red", linetype = "dashed") + 
      facet_wrap(~ group_ij)
    
    
    # ASSUMES THAT for a given person i
    # the number of contacts they have with group 1 is uncorrelated with number of contacts they have with group 5 (for example)

    
    dist_solution %>% 
      ggplot(aes(x = log(y + 1))) + 
      geom_density(aes(colour = group_ij))
    
    
    
    
    
    
    
    

# TRY TOTAL then proportions [for one group] ----------------------------------------------

    
    # EMPIRICAL DISTRIBUTIONS GIVEN PARAMETERS [ to calc likelihoods ]
    
    mu <- 3
    size <- 0.5
    
    k_almost <- c(1, 0.5, 0.3, 0.3, 0.1)
    k_complete <- append(k_almost, mu - sum(k_almost)) # enforces that last one has to complete to one
    
    probs <- k_complete / mu
    
    # Draw totals of contacts
    d <- tibble(
      id = 1:10000,
      contacts_total = rnbinom(n = 10000, size = size, mu = mu)
    ) %>% 
      rowwise() %>% 
      mutate(contacts_id = if_else(contacts_total > 0, list(1:contacts_total), list(NA_integer_))) %>% 
      unnest(contacts_id)
    
    # Probability from each group
    # probs <- c(0.4, 0.2, 0.1, 0.3)
    
    
    # NEED TO ENFORCE that final probability is just 1 - the rest...
    
    # Which one is from each group
    d_groups <- d %>% 
      # filter(contacts_total != 0) %>% 
      mutate(secondary_i_group = if_else(contacts_total > 0, 
                                         sample(x = 1:6, size = nrow(.), replace = TRUE, prob = probs),
                                         NA_integer_))
    
    d_n_secondary_groups <- d_groups %>%
      tidyr::complete(id, secondary_i_group) %>% 
      arrange(id, secondary_i_group) %>% 
      group_by(id, secondary_i_group) %>% 
      filter(!is.na(secondary_i_group)) %>% 
      summarise(n = sum(!is.na(contacts_id))) #%>% 
      # mutate(p = n / sum(n))
    
    d_n_secondary_groups %>% 
      ggplot() + 
      geom_histogram(aes(x = n, fill = factor(secondary_i_group)), binwidth = 1, boundary = -0.25, colour = "white") + 
      facet_wrap(~ factor(secondary_i_group))
    
    
    
    
    # NEXT: plot the realised probabilities (not n) for each group
    d_n_secondary_groups %>% 
      filter(sum(n) != 0) %>% 
      ggplot() + 
      geom_histogram(aes(x = p, fill = factor(secondary_i_group)), binwidth = 0.1, boundary = 0, colour = "white") + 
      facet_wrap(~ factor(secondary_i_group))
    
    
    # NEW TACTIC
    # p is probability of observing that many contacts in total
    # q is the probability for each obs being that type
    
    calc_d_groups <- d_groups %>%
      mutate(
        p_estimate = dnbinom(x = contacts_total, size = size, mu = mu)
      ) %>% 
      left_join(
        tibble(secondary_i_group = 1:6,
               q_estimate = probs)
      ) %>% 
      group_by(id, p_estimate) %>% 
      # print(n = 100)
      summarise(q_estimate_total = prod(q_estimate)) %>% 
      mutate(q_estimate_total = replace_na(q_estimate_total, 1)) %>%  # fill in NAs with 1s so they can be multiplied with the p's
      mutate(total_prob = p_estimate * q_estimate_total)
    
    
    
    -sum(log(calc_d_groups$total_prob))
    
    
    
    
    # Make sure it's not correlated to total N?
    
    # Then this is the empirical distribution we can use to calculate the likelihood of the secondary probabilities...

  
    
    
    
    # Test with some "data" ...
    # "DATA"
    # Make into a likelihood function
    # See whether a MaxLi estimate gets to the correct parameter values
    
    
    
    
    
    
    


    
    


    
    
    



    
    
    
    
    
    

    
    

# Beta / K matrices -------------------------------------------------------

    
    
    k_matrix_trial <- Matrix::forceSymmetric(
      matrix(
        c(4, 1, 1, 1, 1, 1,
          4,  6, 1, 1, 1, 1,
          3,  4, 7, 1, 1, 1,
          1,  3, 3, 4, 1, 1,
          1,  1, 2, 2, 3, 1, 
          0,  0, 1, 1, 2, 3),
        nrow = 6
      )
    ) %>% as.matrix()
    
    # beta_matrix <- k_matrix_trial %>%
    #   as.vector() %>%
    #   {mutate(crossing(to = 1:6, from = 1:6), k_val = .)} %>%
    #   left_join(
    #     tibble(to = 1:6, group_props = data_save$group_props), by = "to"
    #   ) %>%
    #   arrange(from) %>% select(from, to, everything()) %>%
    #   mutate(beta_val = k_val / group_props) %>%
    #   select(to, from, beta_val)
    # 
    
    
    
    
    
    

# ...... ------------------------------------------------------------------

# Functions ----------------------------------------------------------------

    
    # Takes k_vec and mu_vec as inputs, and outputs the full k_matrix
    k_vec_to_matrix <- function(k_vec, mu_vec) {
      
      # k_vec_example <- c( c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
      #                     c(2, 0.5, 0.3, 0.3),
      #                     c(2, 0.5, 0.3),
      #                     c(2, 0.5),
      #                     c(2))
      
      if (length(k_vec) != 15) {
        print(length(k_vec))
        stop("wrong length of k_vec")
      }
      
      k_1_almost <- k_vec[1:5]
      k_2_almost <- k_vec[6:9]
      k_3_almost <- k_vec[10:12]
      k_4_almost <- k_vec[13:14]
      k_5_almost <- k_vec[15]
      # k_6 is pinned down by the mus
      
      k_1 <- append(k_1_almost, mu_vec[[1]] - sum(k_1_almost))
      k_2 <- c(k_1[[2]], k_2_almost) %>% append(mu_vec[[2]] - sum(.))
      k_3 <- c(k_1[[3]], k_2[[3]], k_3_almost) %>% append(mu_vec[[3]] - sum(.))
      k_4 <- c(k_1[[4]], k_2[[4]], k_3[[4]], k_4_almost) %>% append(mu_vec[[4]] - sum(.))
      k_5 <- c(k_1[[5]], k_2[[5]], k_3[[5]], k_4[[5]], k_5_almost) %>% append(mu_vec[[5]] - sum(.))
      k_6 <- c(k_1[[6]], k_2[[6]], k_3[[6]], k_4[[6]], k_5[[6]]) %>% append(mu_vec[[6]] - sum(.))
      
      # Make the k matrix for clarity
      k_matrix <- matrix(
        c(
          k_1, k_2, k_3, k_4, k_5, k_6
        ),
        nrow = 6, 
        byrow = TRUE
      )
      
      return(k_matrix)
      
    }
    
    k_matrix_to_vec <- function(k_matrix) {
      
      i_row <- c(rep(1, 5), rep(2, 4), rep(3, 3), rep(4, 2), rep(5, 1))
      i_col <- c(1:5, 2:5, 3:5, 4:5, 5)
      
      k_vec <- list()
      for (i in seq_along(i_row)) {
        k_vec[[i]] <- as.vector(k_matrix[ i_row[[i]], i_col[[i]] ])
      }
      
      return(flatten_dbl(k_vec))
      
    }
    
    
    
    
    # Takes the parameter vector as an input, and outputs all the implied parameters
    # e.g. the k_matrix, the q_matrix, etc.
    read_params <- function(params) {
      
      mus <- params[1:6]
      size <- params[[7]]
      k_vec <- params[8:22]
      
      k_matrix <- k_vec_to_matrix(k_vec = k_vec, mu_vec = mus)
      
      # Check there's no negative values
      # if (any(k_matrix < 0, na.rm = TRUE) | any(is.na(k_matrix))) {
      #   # print("Negative or missing values in k")
      #   # return(Inf)
      #   # WILL NEED TO RETURN INFINITY HERE
      # }
      
      mu_matrix <- matrix(
        rep(mus, each = 6), nrow = 6,
        byrow = FALSE
      )
      
      q_matrix <- k_matrix / mu_matrix     # columns sum to 1
      
      # Convert q_matrix into form that can be joined onto tibble
      q_tibble <- q_matrix %>% as_tibble() %>% 
        set_names(paste0("primary", 1:6)) %>% 
        mutate(secondary_i_group = row_number()) %>% 
        pivot_longer(-secondary_i_group, names_to = "i_group", names_prefix = "primary", values_to = "q_estimate") %>% 
        mutate(i_group = as.integer(i_group))
      
      
      out <- list(
        mus = mus,
        size = size,
        k_vec = k_vec,
        k_matrix = k_matrix,
        mu_matrix = mu_matrix,
        q_matrix = q_matrix,
        q_tibble = q_tibble
      )
      
      return(out)
      
    }
    
    
    
    
    
    
    # Calculate the log likelihood of observing data given parameters
    contact_maxlik <- function(param_vec, data) {
      
      # INPUTS FOR TESTING
      # param_vec <- c(
      #   c(5, 5, 5, 5, 5, 10),       # mus
      #   0.5,                       # size
      #   c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
      #        c(2, 0.5, 0.3, 0.3),
      #             c(2, 0.5, 0.3),
      #                  c(2, 0.5),
      #                       c(2)
      # )
      # 
      # data <- tibble(
      #   id = 1:10000,
      #   i_group = sample(c(1:6), size = 10000, replace = TRUE)
      # ) %>%
      #   left_join(tibble(i_group = 1:6, mu_actual = c(5, 6, 5, 5, 5, 10))) %>%
      #   mutate(
      #     contacts_total = rnbinom(n = 10000, size = 0.4, mu = mu_actual)
      #   ) %>%
      #   rowwise() %>%
      #   mutate(contacts_id = if_else(contacts_total > 0, list(1:contacts_total), list(NA_integer_))) %>%
      #   unnest(contacts_id) %>%
      #   mutate(secondary_i_group = if_else(contacts_total > 0,
      #                                      sample(x = 1:6, size = nrow(.), replace = TRUE, prob = c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1)),
      #                                      NA_integer_)) %>%
      #   select(-mu_actual, -contacts_id)
      # ---
      
      params <- read_params(param_vec)

      
      # Check there's no negative / missing values
      if (any(params$k_matrix < -0.001, na.rm = TRUE) | any(is.na(params$k_matrix))) {
        print("Negative or missing values in k")
        # print(params$k_matrix)
        # return(Inf)
      }
      
      # Check symmetric
      if (!isSymmetric(params$k_matrix)) {
        print(params$k_matrix)
        stop("matrix is not symmetric")
      }
      
      # Add on p_estimate for number of contacts
      data_p <- data %>% dups_drop(id, warn = FALSE) %>% 
        left_join(tibble(i_group = 1:6, mu = params$mus), by = "i_group") %>% 
        mutate(
          p_estimate = dnbinom(x = contacts_total, size = params$size, mu = mu)
        )
      
      # And q_estimate on group of contact from q_matrix
      data_q <- data  %>% 
        left_join(q_tibble, by = c("i_group", "secondary_i_group")) %>% 
        mutate(q_estimate = replace_na(q_estimate, 1))
      
      # Negative log likelihood (to be minimised)
      neg_ll <- -(sum(log(data_q$q_estimate)) + sum(log(data_p$p_estimate)))
      
      return(neg_ll)
      
    }
    
    
    # Function that MAKES A DATA EXAMPLE THAT FOLLOWS THE assumed data-generating process
    gen_example_data <- function(mu, size, k_vec, N = 1000) {
      
      # mu_example <- c(4, 7, 5, 5, 4, 7)
      # size_example <- 0.5
      # 
      # k_vec_example <- c( c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
      #                     c(2, 1, 0.3, 0.3),
      #                     c(2, 0.5, 0.3),
      #                     c(2, 0.5),
      #                     c(2))
      
      (k_matrix <- k_vec_to_matrix(k_vec, mu))
      
      mu_matrix <- matrix(
        rep(mu, each = 6), nrow = 6,
        byrow = FALSE
      )
      
      q_matrix <- k_matrix / mu_matrix     # columns sum to 1
      # [i, j] = [to, from]
      
      # Convert q_matrix into form that can be joined onto tibble
      q_tibble <- q_matrix %>% as_tibble() %>% 
        set_names(paste0("primary", 1:6)) %>% 
        mutate(secondary_i_group = row_number()) %>% 
        pivot_longer(-secondary_i_group, names_to = "i_group", names_prefix = "primary", values_to = "q_estimate") %>% 
        mutate(i_group = as.integer(i_group))
      
      
      data_example_split <- tibble(
        id = 1:N,
        i_group = sample(c(1:6), size = N, replace = TRUE)
      ) %>% 
        left_join(tibble(i_group = 1:6, mu_actual = mu), by = "i_group") %>% 
        mutate(
          contacts_total = rnbinom(n = N, size = size, mu = mu_actual)
        ) %>% 
        rowwise() %>% 
        mutate(contacts_id = if_else(contacts_total > 0, list(1:contacts_total), list(NA_integer_))) %>% 
        unnest(contacts_id) %>% 
        group_by(i_group) %>% 
        group_split() 
      
      q_list <- as.list(as.data.frame(q_matrix))
      
      data_example_bind <- map2(.x = data_example_split, .y = q_list, .f = ~ {
        .x %>% mutate(secondary_i_group = if_else(contacts_total > 0, 
                                                  sample(x = 1:6, size = nrow(.), replace = TRUE, 
                                                         prob = .y),
                                                  NA_integer_))
      }) %>% 
        bind_rows() %>% 
        arrange(id)
      
      
      return(data_example_bind)
    }
    
    
    
    

# ...... ------------------------------------------------------------------


# TESTING -----------------------------------------------------------------

    
# Test the maxlik function (basic test) -------------------------------------------------------

    contact_maxlik(
      params = c(
        c(5, 5, 5, 5, 5, 10),       # mus
        0.5,                       # size
        c(2, 0.5, 0.8, 0.3, 0.1),   # k_1
        c(2, 0.5, 0.3, 0.3),
        c(2, 0.5, 0.3),
        c(2, 0.5),
        c(2)
      ),
      
      data = tibble(
        id = 1:10000,
        i_group = sample(c(1:6), size = 10000, replace = TRUE)
      ) %>% 
        left_join(tibble(i_group = 1:6, mu_actual = c(5, 6, 5, 5, 5, 10)), by = "i_group") %>% 
        mutate(
          contacts_total = rnbinom(n = 10000, size = 0.4, mu = mu_actual)
        ) %>% 
        rowwise() %>% 
        mutate(contacts_id = if_else(contacts_total > 0, list(1:contacts_total), list(NA_integer_))) %>% 
        unnest(contacts_id) %>% 
        mutate(secondary_i_group = if_else(contacts_total > 0, 
                                           sample(x = 1:6, size = nrow(.), replace = TRUE, prob = c(0.1, 0.2, 0.3, 0.2, 0.1, 0.1)),
                                           NA_integer_)) %>% 
        select(-mu_actual, -contacts_id)
    )
    
    

# Test with an example ----------------------------------------------------


    
    data_example <- gen_example_data(mu = c(4, 7, 5, 5, 4, 7),
                                     size = 0.5,
                                     k_vec = c( c(2, 0.5, 0.3, 0.3, 0.1),   # k_1
                                                c(2, 1, 0.3, 0.3),
                                                c(2, 0.5, 0.3),
                                                c(2, 0.5),
                                                c(2)),
                                     N = 10000)
    
    
    k_constraint <- function(params, data) {
      
      k_vals <- read_params(params)$k_matrix %>% as.vector()
      
      return(-k_vals)  
      
    }
    
    
    # CALCULATE NAIVE STARTING PARAMS
    mu_start <- data_example %>% select(id, i_group, contacts_total) %>% dups_drop(warn = FALSE) %>% 
      group_by(i_group) %>% summarise(contacts_total = mean(contacts_total)) %>% 
      .$contacts_total
    
    size_start <- 0.2
    
    k_vec_start <- data_example %>% 
      group_by(i_group, secondary_i_group) %>% 
      filter(!is.na(secondary_i_group)) %>% 
      summarise(n_contacts = n()) %>% 
      mutate(q = n_contacts / sum(n_contacts)) %>% 
      left_join(tibble(i_group = 1:6, mu = mu_start)) %>% 
      mutate(k_val = q * mu) %>% 
      .$k_val %>% 
      matrix(nrow = 6, ncol = 6) %>%  # this isn't symmetrical because it hasn't been harmonised properly
      k_matrix_to_vec()             # infer the k_vec parameters from the matrix
    
    # NOTE: might want to adjust this so that k_matrix is forced to be symmetric (take average of k_ij and k_ji)
    # for the real data whcih will likely be less symmetrical
    
    # Test whether ML process gets the right answer
    library("nloptr")
    opt_results <- nloptr(
      x0 = c(mu_start, size_start, k_vec_start), 
      eval_f = contact_maxlik, 
      eval_g_ineq = k_constraint,
      lb = rep(0, 22), 
      # ub = c(rep(50, 6), 30, rep(50, 15)),
      opts = list(
        "algorithm" = "NLOPT_LN_COBYLA",
        "xtol_abs"=1.0e-6,
        "maxeval" = 1000,
        "print_level" = 1
      ),
      data = data_example
    )
    
    
    params_solution <- read_params(opt_results$solution)
    
    
    
    # CHECK DIFFS between the solution and true values
    mu_example
    params_solution$mus
    
    size_example
    params_solution$size
    
    
    round(q_matrix, 2)
    round(params_solution$q_matrix, 2)
    
    round(k_matrix, 2)
    round(params_solution$k_matrix, 1)
    
    
    
# Plot distributions ------------------------------------------------------
    
    
    # COMPARE DISTRIBUTIONS graphically
    comparison_data <- list(
      actual = data_example,
      inferred = gen_example_data(
        mu = params_solution$mus,
        size = params_solution$size,
        k_vec = params_solution$k_vec,
        N = 10000
      )
    ) %>% 
      bind_rows(.id = "data_type")
    
    comparison_data_grouped <- comparison_data %>% 
      mutate(id = paste0(data_type, "_", id)) %>% 
      tidyr::complete(id, secondary_i_group) %>% 
      arrange(id, secondary_i_group) %>% 
      group_by(data_type, id, secondary_i_group) %>% 
      summarise(n_in_secondary = sum(!is.na(contacts_id))) %>% 
      filter(!is.na(data_type), !is.na(secondary_i_group))
    
    
    ggplot(comparison_data_grouped) + 
      geom_density(aes(x = log(n_in_secondary + 1), colour = data_type), adjust = 2) + 
      facet_wrap(~ factor(secondary_i_group))
    
    
    
    
    
    
# CHeck probabilities work as expected ------------------------------------
    
    actual_data_probs <- comparison_data %>% filter(data_type == "actual") %>% 
      filter(!is.na(contacts_id)) %>% 
      group_by(i_group, secondary_i_group) %>% 
      summarise(n = n()) %>% 
      tidyr::complete(i_group, secondary_i_group) %>% 
      mutate(prop = round(n / sum(n), 2)) %>% 
      print_all
    
    data_q <- matrix(actual_data_probs$prop, nrow = 6)
    solution_q <- round(params_solution$q_matrix, 2)
    data_q - solution_q # magnitude of the error
    
    data_k <- matrix(actual_data_probs$n, nrow = 6) %>% print # check this is roughly symmetric. YES
    
    
    