zeros_and_ones <- c(183, 2202)

d <- tibble(
  y = c(rep(FALSE, zeros_and_ones[[1]]), rep(TRUE, zeros_and_ones[[2]]))
)

summary(lm(y ~ 1, data = d))$coefficients %>% round(4)
