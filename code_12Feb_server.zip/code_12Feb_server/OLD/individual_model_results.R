


# .................... ---------------------------------------------------------------------
# MAIN RESULTS - GROUP DIFFS - 5+ groups --------------------------------------------------
  


# Group diff default function ---------------------------------------------


    
    group_diff_default <- function(n_sims = 1,
                                   n_iterations = 1000,
                                   keep_all_data = FALSE,
                                   print_detail = TRUE,
                                   n_pop = 10000, 
                                   hh_size_data = data_save$hh_data_bogota,
                                   n_initial_cases = NULL, # calculated within function if remains NULL
                                   group_props = NULL,     # ditto
                                   dt_approx = 1,
                                   recov_val = 10, # people recover 10 days after symptoms show (cuts off only ~ 1% of infections at the upper end of timing distribution)
                                   params_timing = data_save$params_timing,
                                   params_symptom_timing = data_save$params_symptom_timing,
                                   params_serial = data_save$params_serial,
                                   test_delay_data = data_save$test_delay_data,
                                   # test_choice_delay_data = data_save$test_choice_delay_data,
                                   # test_results_delay_data = data_save$test_results_delay_data, 
                                   test_sensitivity_data = data_save$test_sensitivity_data, 
                                   ct_delay_data = data_save$ct_delay_data,
                                   probs_self_test_df = data_save$probs_self_test %>% mutate(prob = prob * self_test_scale_factor),
                                   probs_isolate_symptoms_df = data_save$probs_isolate_symptoms,
                                   probs_isolate_test_df = data_save$probs_isolate_test,
                                   probs_isolate_ct_df =   data_save$probs_isolate_ct,
                                   p_contact_if_isolated_home = rep(0, 4), 
                                   p_contact_traced = data_save$params_data$p_contact_traced,
                                   p_hh_quarantine = data_save$params_data$p_hh_quarantine,
                                   k_matrix = data_save$k_matrix * data_save$k_scale_factor, # multiply by new n_pop here,
                                   contact_dispersion = data_save$contact_dispersion,
                                   # beta_matrix = beta_matrix_6,
                                   # r0_group_1 = 5, 
                                   # contacts_mean = contacts_mean_6,
                                   sar_out = data_save$params_data$sar_out_input,
                                   sar_home = data_save$params_data$sar_home_input, 
                                   infectiousness_by_symptoms = c(0.7, 1),
                                   alpha = c(0, 0, 0, 0)) {
      
      # Calculate number of initial cases and group proportions
      if (is.null(n_initial_cases)) {
        n_initial_cases <- round(data_save$group_props * n_pop / 1000) # 1000th of the pop is infected at the model start
      }
      
      group_props <- c(
        round(data_save$group_props[1:3] * n_pop) / n_pop,
        1 - sum(round(data_save$group_props[1:3] * n_pop) / n_pop)
      )
      
      
      n_pop_scale <- n_pop / data_save$k_matrix_pop
      
      
      
      outbreak_sims(keep_all_data = keep_all_data,
                    print_detail = print_detail,
                    n_sims = n_sims, 
                    n_iterations = n_iterations,
                    n_pop = n_pop, 
                    n_initial_cases = n_initial_cases,
                    group_props = group_props,
                    dt_approx = dt_approx,
                    recov_val = recov_val,
                    params_timing = params_timing,
                    params_symptom_timing = params_symptom_timing,
                    params_serial = params_serial,
                    test_delay_data = test_delay_data,
                    # test_choice_delay_data = test_choice_delay_data,
                    # test_results_delay_data = test_results_delay_data,
                    test_sensitivity_data = test_sensitivity_data,
                    ct_delay_data = ct_delay_data,
                    probs_self_test_df = probs_self_test_df, 
                    probs_isolate_symptoms_df = probs_isolate_symptoms_df, 
                    probs_isolate_test_df = probs_isolate_test_df, 
                    probs_isolate_ct_df = probs_isolate_ct_df,
                    p_contact_if_isolated_home = p_contact_if_isolated_home, p_contact_traced = p_contact_traced, 
                    p_hh_quarantine = p_hh_quarantine,
                    k_matrix = k_matrix * n_pop_scale,
                    contact_dispersion = contact_dispersion,
                    hh_size_data = hh_size_data, 
                    alpha = alpha, 
                    sar_home = sar_home, sar_out = sar_out,
                    infectiousness_by_symptoms = infectiousness_by_symptoms
      )
    }
    
    test_group_diff <- group_diff_default(n_iterations = 2)
  
    test_group_diff$params$next_gen_matrix
    test_group_diff$params$contact_means
    
    
    
    

# Run baseline in detail --------------------------------------------------

    
    
    model_baseline <- group_diff_default(n_pop = 1e7, n_sims = 1, n_initial_cases = c(100, 100, 100, 100))
    
    model_basline_time_series <- model_baseline$time_series
    
    # save(model_basline_time_series, file = "model_baseline_100kpop.RData")
    # save(model_basline_time_series, file = "model_baseline_100kpop_2xtest.RData")
    # save(model_baseline, file = "model_baseline_7.6pop.RData")
    save(model_basline_time_series, file = "model_baseline_1m.RData")
           
    # load("model_baseline_100kpop.RData")
    
    load("model_baseline_1m.RData", verbose = TRUE)
  
    sum(best_guess_initial_cases$n)
    # 1000 people = 0.
    format(500 / 7600000, scientific=F)   # 0.00006578947  of the population
    
    
    round(best_guess_initial_cases$n * (1e5L / 7.6e6))
    
    # 1000 people actually detected
    
    
    
    
    

# Plot main graph ---------------------------------------------------------

    live_cases <- model_basline_time_series %>% 
      mutate(n_cases_per_cap = n_cases_live / n_pop) %>% 
      group_by(t, i_group) %>% 
      summarise_quantiles(n_cases_per_cap) %>% 
      filter(q %in% c(0.025, 0.5, 0.975)) %>% 
      mutate(q_label = case_when(q == 0.025 ~ "_lower",
                                 q == 0.5   ~ "",
                                 q == 0.975 ~ "_upper")) %>% 
      select(-q) %>%
      ungroup %>% 
      pivot_wider(names_from = q_label,
                  values_from = n_cases_per_cap,
                  names_prefix = "n_cases_per_cap")
 
    live_cases %>% 
      mutate(i_group = recode_i_group(i_group)) %>% 
      ggplot(aes(x = t, y = n_cases_per_cap)) + 
      geom_line(aes(colour = factor(i_group)), size = 1) + 
      geom_ribbon(aes(ymax = n_cases_per_cap_upper, ymin = n_cases_per_cap_lower, fill = factor(i_group)), alpha = 0.2) + 
      # geom_label(aes(label = factor(stratum))) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1)) + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE) + 
      theme_custom() + 
      theme(legend.position = c(0.12, 0.67)) + 
      labs(x = "t", y = "Prevalence", fill = "SES Group",
           colour = "SES Group") + # + 
      geom_hline(yintercept = 0, colour = "darkgrey")
    
    ggsave("live_cases.png", scale = 0.8)
    

# Plot new confirmed cases ------------------------------------------------

    
    
    
    confirmed_cases_model <- model_basline_time_series %>% 
      select(sim_id, t, i_group, n_pop, n_confirmed_cases) %>% 
      arrange(sim_id, i_group, t) %>% 
      group_by(sim_id, i_group) %>% 
      mutate(
        new_confirmed_cases = n_confirmed_cases - lag(n_confirmed_cases),
        n_new_cases_week_roll = zoo::rollsum(new_confirmed_cases, k = 20, fill = NA, align = "right") / (20/7),
        n_confirmed_cum = n_confirmed_cases / n_pop,
        new_cases_per_cap = (n_new_cases_week_roll / n_pop)
      ) %>% 
      group_by(i_group, t) %>% 
      summarise_quantiles(c(new_cases_per_cap, n_confirmed_cum)) %>% 
      filter(q %in% c(0.025, 0.5, 0.975)) %>% 
      mutate(q_label = case_when(q == 0.025 ~ "_lower",
                                 q == 0.5   ~ "",
                                 q == 0.975 ~ "_upper")) %>% 
      select(-q) %>%
      ungroup %>% 
      pivot_wider(names_from = q_label,
                  values_from = c(new_cases_per_cap, n_confirmed_cum),
                  names_sep = "")
  
    
    ggplot(confirmed_cases_model, aes(x = t, y = new_cases_per_cap)) + 
      geom_line(aes(colour = factor(i_group)), size = 1) + 
      geom_ribbon(aes(ymax = new_cases_per_cap_upper, ymin = new_cases_per_cap_lower, fill = factor(i_group)), alpha = 0.2) + 
      # geom_label(aes(label = factor(stratum))) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE) + 
      theme_custom() + 
      theme(legend.position = c(0.12, 0.67)) + 
      labs(x = "t", y = "Weekly new confirmed cases per capita in group [model]", fill = "SES Group",
           colour = "SES Group") + # + 
      geom_hline(yintercept = 0, colour = "darkgrey")
    
    
    
    

# Plot both real and model in same graph ----------------------------------

    
    # WHEN IS Start date on model - April 1st when there are 486 cases
    start_cases <- sum(best_guess_initial_cases$n) 
    start_cases_prop <- start_cases / 7600000
    format(start_cases_prop, scientific=F)   # 0.00006578947  of the population
    
    
    # Calculate which t should align with April 1st
    start_t <- model_basline_time_series %>% 
      group_by(sim_id, t) %>% # sum all i_groups
      summarise(across(c(n_pop, n_confirmed_cases), sum)) %>% 
      ungroup %>% 
      mutate(n_confirmed_prop = n_confirmed_cases / n_pop,
             over_start_thresh = n_confirmed_prop >= start_cases_prop) %>% 
      
      # Find first t that goes over starting threshold
      group_by(sim_id) %>% 
      summarise(start_t = first_non_na(t[over_start_thresh])) %>% 
      
      # Take rounded median of all as starting t
      summarise(start_t = floor(median_na(start_t))) %>% 
      .$start_t
      
    
    
    confirmed_cases_actual <- sds_jobs_clean %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>% 
      filter(!is.na(stratum)) %>% 
      group_by(stratum, date_results) %>% 
      summarise(n_cases_day = n()) %>% 
      full_join(
        crossing(stratum = 1:4, date_results = ymd("2020-03-01") + days(1:400)), by = c("stratum", "date_results")
      ) %>% 
      left_join(
        stratum_pops, by = c("stratum")
      ) %>% 
      mutate(n_cases_day = if_else(is.na(n_cases_day), 0L, n_cases_day)) %>% 
      
      # Calculate model t in real data
      mutate(t = interval_days(ymd("2020-04-01"), date_results) + start_t) %>% 
      arrange(stratum, date_results) %>% 
      group_by(stratum, stratum_pop) %>% 
      mutate(n_new_cases_week_roll = zoo::rollsum(n_cases_day, k = 7, fill = NA, align = "right")) %>% 
      mutate(new_cases_per_cap = (n_new_cases_week_roll / stratum_pop)) %>% 
      mutate(n_confirmed_cum = cumsum(n_cases_day) / stratum_pop) %>% 
      ungroup %>% 
      filter(
        # date_results <= ymd("2020-11-01")
        # date_results > ymd("2020-04-01")
      ) %>% 
      select(i_group = stratum, t, date_results, new_cases_per_cap, n_confirmed_cum) %>% 
      mutate(source = "data")
    
    date_to_t <- confirmed_cases_actual %>% 
      select(t, date_results) %>% dups_drop()
      
    
    # combine both into one DF
    confirmed_cases_combined <- bind_rows(
      confirmed_cases_actual %>% select(-date_results),
      confirmed_cases_model %>% mutate(source = "model")
    ) %>% 
      left_join(date_to_t, by = "t")
    
    
    # PLOT - weekly new confirmed
    confirmed_cases_combined %>% 
      filter(t > 0) %>% 
      ggplot(aes(x = date_results, y = new_cases_per_cap)) + 
      geom_line(aes(colour = factor(i_group)), size = 1) + 
      geom_ribbon(aes(ymax = new_cases_per_cap_upper, ymin = new_cases_per_cap_lower, fill = factor(i_group)), alpha = 0.2) + 
      # geom_label(aes(label = factor(stratum))) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE) + 
      theme_custom() + 
      # theme(legend.position = c(0.12, 0.67)) + 
      labs(x = "Date", y = "Weekly new confirmed cases per capita in group", fill = "SES Group",
           colour = "SES Group") + # + 
      geom_hline(yintercept = 0, colour = "darkgrey") + 
      facet_wrap(~ source)
    
    
    
    
    recode_i_group <- function(x) {
      fct_recode(factor(x), "1+2" = "1", "3" = "2", "4" = "3", "5+6" = "4")
    }
    
    
    # PLOT
    confirmed_cases_combined %>% 
      mutate(i_group = recode_i_group(i_group)) %>% 
      filter(t > 0, t < 500) %>% 
      ggplot(aes(x = date_results, y = n_confirmed_cum)) + 
      geom_line(aes(colour = factor(i_group)), size = 1) + 
      geom_ribbon(aes(ymax = n_confirmed_cum_upper, ymin = n_confirmed_cum_lower, fill = factor(i_group)), alpha = 0.2) + 
      # geom_label(aes(label = factor(stratum))) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE) + 
      theme_custom() + 
      # theme(legend.position = c(0.12, 0.67)) + 
      labs(x = "Date", y = "Cumulative confirmed cases per capita\nin each group", fill = "SES Group",
           colour = "SES Group") + # + 
      geom_hline(yintercept = 0, colour = "darkgrey") + 
      facet_wrap(~ source)
    
    
    ggsave("data_vs_model_confirmed_cum.png", scale = 0.7)
    

    
    
    
    
    
    

# ....... -----------------------------------------------------------------



# COUNTERFACTUALS ---------------------------------------------------------

    
    

# Run counterfactuals using function to equalise params --------------------

    
    
    # BASELINE PARAMETERS
    params_baseline <- list(
      group_props = data_save$group_props,
      n_pop = 10000,
      
      ct_delay_data             = data_save$ct_delay_data,
      probs_self_test_df        = data_save$probs_self_test,
      probs_isolate_symptoms_df = data_save$probs_isolate_symptoms,
      probs_isolate_test_df     = data_save$probs_isolate_test,
      probs_isolate_ct_df       = data_save$probs_isolate_ct,
      p_contact_if_isolated_home= rep(0, 4),
      p_contact_traced          = data_save$params_data$p_contact_traced,
      p_hh_quarantine           = data_save$params_data$p_hh_quarantine,
      hh_size_data              = data_save$hh_data_bogota,
      test_delay_data           = data_save$test_delay_data,
      k_matrix                  = data_save$k_matrix * 1.5 * 10000 / 10000,
      sar_out                   = data_save$params_data$sar_out_input,
      sar_home                  = data_save$params_data$sar_home_input,
      alpha                     = rep(0, 4)
    )
    
    # EQUALISED PARAMETERS
    params_equalised <- equalise_params_to(params_baseline, equalise_to = 4)
    

    # Calculate new list of equalised parameters
    # params_to_equalise_list <- list(
    #   "baseline"             = c(),
    #   "out_contacts"         = c("k_matrix", "sar_out"),
    #   "home_contacts"        = c("p_contact_if_isolated_home", "sar_home", "hh_size_data"),
    #   "isolation_behaviour"  = c("probs_isolate_symptoms_df", "probs_isolate_test_df", "probs_isolate_ct_df", "p_hh_quarantine"),
    #   "testing_tracing"      = c("probs_self_test_df", "test_choice_delay_data", "test_results_delay_data", "ct_delay_data", "p_contact_traced")
    # )
    params_to_equalise_list <- list(
      "baseline"             = c(),
      "out_contacts"         = c("k_matrix"),
      "home_contacts"        = c("hh_size_data"),
      "isolation_behaviour"  = c("probs_isolate_symptoms_df", "probs_isolate_test_df", "probs_isolate_ct_df", "p_hh_quarantine"),
      "testing_tracing"      = c("probs_self_test_df", "test_choice_delay_data", "test_results_delay_data", "p_contact_traced")
    )
    
    params_to_equalise_list$all <- flatten_chr(params_to_equalise_list)
    
    # Combine params from old and new
    params_combined <- tibble(
      parameter_set = names(params_to_equalise_list),
      params_to_equalise = params_to_equalise_list
    ) %>% 
      mutate(
        baseline_to_use = map(params_to_equalise, ~ params_baseline[! names(params_baseline) %in% .x]),
        equalised_to_use = map(params_to_equalise, ~ params_equalised[names(params_equalised) %in% .x]),
        params_to_use = map2(baseline_to_use, equalised_to_use, ~ c(.x, .y))
      ) %>% 
      select(-baseline_to_use, equalised_to_use)
    
    
    # Convert to tibble to be pmapped
    params_combined_df <- bind_cols(
      tibble(parameter_set = params_combined$parameter_set,
             params_to_equalise = params_combined$params_to_equalise),
      params_combined$params_to_use %>% purrr::transpose() %>% as_tibble()
    )
    
    # RUN THE MODELS
    group_diffs <- params_combined_df %>% 
      mutate(model_output = pmap(select(., -parameter_set, -params_to_equalise),
                                 group_diff_default, 
                                 print_detail = FALSE,
                                 n_sims = 2, 
                                 n_iterations = 10000))
    
  
    # Slim the data to just time series to be used in graphs
    group_diff_slim <- group_diffs %>% 
      select(parameter_set, any_of("params_to_equalise"), model_output) %>% 
      mutate(time_series = map(model_output, "time_series")) %>% 
      select(-model_output) %>% 
      unnest(time_series) %>% 
      mutate(parameter_set = factor(parameter_set, levels = names(params_to_equalise_list)))


    save(group_diff_slim, file = "group_diff_slim.RData")
    load("group_diff_slim.RData")
    
    
    
    
# Output main graphs -----------------------------------------------------------

    
    library("viridis")
    
    # Prepare plot DF
    group_diff_at_t <- group_diff_slim %>% 
      group_by(parameter_set, t, i_group, n_pop) %>% 
      quantile_summarise(c(n_cases_live), conf_level = 0) %>% 
      mutate(prevalence_prop = n_cases_live_median / n_pop)
    
    # Labels for each counterfacutal type
    counterfactual_labels <- c(
      "baseline" = "Baseline",
      "out_contacts" = "Out of home",
      "home_contacts" = "Within home",
      "isolation_behaviour" = "Isolation behaviour",
      "testing_tracing" = "Testing & Tracing",
      "all" = "All"
    )
    

    # PLOT epidemic curves
    included_curves <- c("baseline", "out_contacts", "home_contacts", "isolation_behaviour", "testing_tracing", "all")
    # group_diff_at_t %>% ungroup %>% count_prop(parameter_set)
    group_diff_at_t %>% 
      mutate(i_group = recode_i_group(i_group)) %>% 
      mutate(alpha = if_else(parameter_set %in% included_curves, 1, 0)) %>% 
      ggplot(aes(x = t, y = prevalence_prop, 
                 colour = factor(i_group), group = factor(i_group)
                 # alpha = 1
                 )) + 
      geom_line(show.legend = TRUE) + 
      facet_wrap(~ parameter_set, labeller = as_labeller(counterfactual_labels)) + 
      
      # Formatting
      theme_custom() + 
      theme(legend.position = "right") + 
      scale_alpha_continuous(guide = FALSE) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
      labs(colour = "SES Group", fill = "SES Group", y = "% Infected at t") +
      geom_hline(yintercept = 0, colour = "darkgrey", size = 0.4) + 
      coord_cartesian(xlim = c(0, 150)) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      scale_x_continuous(minor_breaks = c(0, 25, 50, 75), breaks = c(0, 50, 100))
    
    
    ggsave("epidemic_curve.png", width = 8, height = 4.5, scale = 0.8)
    # ggsave("epidemic_curve_2.png", width = 8, height = 4.5, scale = 0.8)
    # ggsave("epidemic_curve_3.png", width = 8, height = 4.5, scale = 0.8)
    
    
    
    summarise_quantiles <- function(.data, ..., q = c(0.01, 0.025, 0.25, 0.5, 0.75, 0.975, 0.99)) {
      .data %>% 
        summarise(
          across(..., ~ quantile(.x, probs = q, na.rm = TRUE)),
          q = q
        ) %>% 
        relocate(q)
    }
    
    
    # SUMMARISE ALL INFO
    group_diff_all_summ <- group_diff_slim %>% 
      
      # (1) Calculate total cases
      group_by(parameter_set, i_group, sim_id, n_pop) %>% 
      summarise(n_cases = max(n_cases_cum)) %>% 
      
      # Calculate proportion infected, and gaps with group 5
      group_by(parameter_set, sim_id) %>% arrange(sim_id) %>% 
      mutate(prop_infected = n_cases / n_pop) %>% 
      mutate(diff_prop_infected = prop_infected - prop_infected[i_group == 4],
             diff_n_cases = n_cases - n_cases[i_group == 4]) %>% 
      
      
      # Calculate "effect" relative to baseline
      group_by(sim_id, i_group) %>% 
      mutate(across(-c(parameter_set), list(effect = ~ .x - .x[parameter_set == "baseline"]))) %>% 
      # Calculte implied contribution for each group, for each sim
      mutate(contribution = diff_prop_infected_effect / diff_prop_infected_effect[parameter_set == "all"]) %>% 
      group_by(parameter_set, i_group) %>% 
      arrange(parameter_set, i_group)
      # summarise_quantiles(-c(sim_id)) %>% print_all
    

    
    # Make into function
    plot_group_diffs <- function(.data, y, ylab = "Y") {
      
      # Labels for each counterfacutal type
      counterfactual_labels <- c(
        "baseline" = "Baseline",
        "out_contacts" = "Out of home",
        "home_contacts" = "Within home",
        "isolation_behaviour" = "Isolation behaviour",
        "testing_tracing" = "Testing & Tracing",
        "all" = "All"
      )
      
      .data %>% 
        mutate(i_group = recode_i_group(i_group)) %>% 
        summarise_quantiles({{y}}) %>% 
        select(parameter_set, i_group, q, {{y}}) %>% 
        filter(q %in% c(0.025, 0.5, 0.975)) %>% 
        pivot_wider(names_from = q, names_prefix = "y_", values_from = {{y}}) %>% 
        ggplot(aes(x = i_group, fill = factor(i_group))) + 
        geom_col(aes(y = y_0.5)) + 
        geom_errorbar(aes(ymin = y_0.025, ymax = y_0.975), width = 0.2, size = 0.5, colour = "#374561") + 
        facet_wrap(~ parameter_set, labeller = as_labeller(counterfactual_labels)) + 
        labs(y = ylab, x = "SES Group", fill = "SES Group") + 
        theme_custom() + 
        theme(legend.position = "right", panel.grid.minor = element_blank(), panel.grid.major.x = element_blank()) + 
        geom_hline(yintercept = 0, colour = "darkgrey", size = 0.4) + 
        scale_fill_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE)
        # scale_x_continuous(breaks = 1:5)
      
    }
    
    
    # PLOT
    # Prop infected in each scenario
    plot_group_diffs(group_diff_all_summ, y = prop_infected, "Total Proportion Infected")
    ggsave("prop_infected.png", width = 8, height = 4.5, scale = 0.8)
  
    # Gap (relative to group 6) in each scenario
    plot_group_diffs(group_diff_all_summ, y = diff_prop_infected, "Gap relative to group 6")
    ggsave("inequality.png", width = 8, height = 4.5, scale = 0.8)
    
    
    
    # TO DO !!!! SHOULD CALCULATE THE QUANTILES AFTER CALCULATING DESIRED QUANTITY
    
    # CHANGE RELATIVE TO BASELINE of prop infected
    group_diff_all_summ %>% 
      group_by(i_group, q) %>% 
      mutate(across(-c(parameter_set), ~ . - .[parameter_set == "baseline"])) %>% 
      ungroup %>% 
      
      plot_group_diffs(
        y = prop_infected,
        ylab = "Change in Total Proportion Infected relative to Baseline"
      )
    
    # CHANGE RELATIVE TO BASELINE of group 1 gap (inequality)
    group_diff_all_summ %>% 
      group_by(i_group, q) %>% 
      mutate(across(-c(parameter_set), ~ . - .[parameter_set == "baseline"])) %>% 
      ungroup %>% 
      
      plot_group_diffs(
        y = diff_prop_infected,
        ylab = "Change relative to baseline case in inequality relative to group 6"
      )
    
    
    colours <- c(
      "darkgrey", "#E87D72", "#55BA70", "#4FB7DF", "#D378EF" 
    )
    

    # PLOT implied "proportion" contribution of each parameter group
    group_diff_all_summ %>% 
      group_by(i_group, q) %>% 
      mutate(across(-c(parameter_set), ~ . - .[parameter_set == "baseline"])) %>% 
      ungroup %>% 
      filter(q == 0.5) %>% 
      filter(parameter_set != "baseline") %>% 
      group_by(i_group) %>% 
      filter(i_group != 4) %>% 
      arrange(i_group) %>% 
      mutate(diff_prop_infected = diff_prop_infected / diff_prop_infected[parameter_set == "all"]) %>% 
      select(parameter_set, i_group, diff_prop_infected) %>% 
      mutate(parameter_set = as.character(parameter_set)) %>%
      mutate(parameter_set = if_else(parameter_set == "all", "Interaction", parameter_set)) %>%
      mutate(parameter_set = factor(parameter_set)) %>%
      group_by(i_group) %>%
      mutate(diff_prop_infected = if_else(parameter_set == "Interaction",
                                          1 - sum(diff_prop_infected[parameter_set != "Interaction"]),
                                          diff_prop_infected)) %>%
      # filter(!(parameter_set == "Interaction" & diff_prop_infected < 0)) %>% 
      mutate(parameter_set = forcats::fct_relevel(parameter_set, "Interaction"),
             parameter_set = fct_relevel(parameter_set, "home_contacts", after = 6)) %>% 
      
      ggplot(aes(x = fct_rev(factor(i_group)), y = diff_prop_infected)) + 
      # ggpattern::geom_col_pattern(
      #   aes(fill = parameter_set, pattern = parameter_set, pattern_angle = class), 
      #   colour = "white"
      # ) + 
      geom_col(aes(fill = parameter_set), colour = "white", width = 0.4) + 
      # geom_label_repel(aes(label = parameter_set), size = 0.
      #                  position = position_stack(vjust = .5)) + 
      scale_fill_manual(values = colours, labels = counterfactual_labels, name = element_blank()) + 
      theme_custom() + 
      geom_hline(yintercept = 1, size = 0.3, linetype = "longdash") + 
      geom_hline(yintercept = 0, size = 0.3, linetype = "longdash") + 
      geom_label(data = . %>% mutate(label = if_else(diff_prop_infected > 0.1, 
                                                     paste0(round(diff_prop_infected * 100), "%"),
                                                     NA_character_)),
                aes(label = label, group = parameter_set),
                position = position_stack(vjust = 0.5),
                alpha = 0.5,
                size = 2) + 
      coord_flip() + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), breaks = 0:5 / 5) + 
      # scale_fill_wsj() + 
      labs(x = "SES Group", y = "Contribution to reduction in inequality")
    
    
    
    ggsave("inequality_decomposition.png",  width = 6, height = 4.5, scale = 0.8)
    
    
    

    
    
    # V2 - no pie chart, just bars
    # Relative to total inequality, how much does each parameter change reduce
    
    
    contributions_df <- group_diff_all_summ %>% 
      # group_by(sim_id, parameter_set,  i_group) %>% 
      arrange(sim_id, parameter_set,  i_group) %>% 
      select(sim_id, parameter_set,  i_group, diff_n_cases) %>% 
      
      # For each sim_id, i_group, what's the prop reduction
      group_by(sim_id, i_group) %>% 
      filter(i_group != 4) %>%  # remove 4 because we're discussing related to top group
      mutate(prop_reduction = (diff_n_cases[parameter_set == "baseline"] - diff_n_cases) / diff_n_cases[parameter_set == "baseline"]) %>% 
      
      # Calculate quantiles across sim_ids
      group_by(i_group, parameter_set) %>% 
      summarise_quantiles(prop_reduction) %>% 
      filter(q %in% c(0.025, 0.5, 0.975)) %>% 
      mutate(q_label = case_when(q == 0.025 ~ "_lower",
                                 q == 0.5   ~ "",
                                 q == 0.975 ~ "_upper")) %>% 
      select(-q) %>%
      ungroup %>% 
      pivot_wider(names_from = q_label,
                  values_from = prop_reduction,
                  names_prefix = "prop_reduction")
    
    # Plot
    contributions_df %>% 
      mutate(i_group = recode_i_group(i_group)) %>% 
      ggplot(aes(x = parameter_set, y = prop_reduction, fill = i_group)) + 
      geom_col(position = "dodge", width = 0.7) + 
      geom_errorbar(aes(ymin = prop_reduction_lower, ymax = prop_reduction_upper), position = position_dodge(0.7), width = 0.2, size = 0.5, colour = "#374561") + 
      labs(x = "Scenario", y = "% reduction in inequality\nrelative to group 5&6") + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1)) + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         end = 0.766666667,
                         discrete = TRUE,
                         name = "SES Group") + 
      scale_x_discrete(labels = counterfactual_labels) + 
      theme_custom() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1),
            panel.grid.minor = element_blank(),
            panel.grid.major.x = element_blank()) + 
      coord_cartesian(ylim = c(-0.2, 1)) + 
      geom_hline(yintercept = 0)
    
    
    

# Output tables ------------------------------------------------------------------

    # Column 0 - N infected in each one
    # Column 1 - what proportion of population in each group are infected in each one
    # Column 2 - implied effect relative to baseline on inequality
    # Column 3 - implied contribution of effect on inequality
    
    # Should report the median, the 95th centiles
    # 
    
    
    group_diff_table <-group_diff_all_summ %>% 
      pivot_longer(-c(q, n_pop, parameter_set, i_group), names_to = "outcome_name", values_to = "outcome_val") %>% 
      filter(q %in% c(0.01, 0.5, 0.99)) %>% 
      
      # Combine confidence intervals
      pivot_wider(names_from = q, values_from = outcome_val) %>% 
      rename(lower =  `0.01`, upper = `0.99`, median = `0.5`) %>% 
      
      # Keep only outcomes we want in the table
      filter(outcome_name %in% c("prop_infected", "diff_prop_infected_effect", "contribution")) %>% 
      
      # Clean up vars
      mutate(
        across(c(lower, upper), ~ replace_with_na(.x, c(0, 1))),
        across(c(lower, upper), ~ replace_with_na(.x, c(0))),
        across(c(lower, median, upper), ~ round(.x, 2)),  # Round all to 3 d.p.
        across(c(lower, upper), ~ format(.x, digits = 2, nsmall = 2, trim = TRUE)), 
        median = format(median, digits = 2, nsmall = 2),
        across(c(median), ~ if_else(str_detect(.x, "NA"), "", .x))
      ) %>% # remove 0s/1s
      
      # Combine lower / upper
      mutate(conf = if_else(str_detect(lower, "NA"), "", as.character(str_glue("[{lower}, {upper}]")))) %>% 
      mutate(output = str_glue("{median} {conf}")) %>% 
      select(-lower, -upper, -median, -conf) %>%
      select(-n_pop) %>% 
      
      # Get each variable in its own column 
      pivot_wider(names_from = outcome_name, values_from = output) %>% 
      mutate(
        parameter_set = fct_recode(parameter_set,
                                         "Baseline" = "baseline",
                                         "Interactions (Out)" = "out_contacts",
                                         "Interactions (Home)" = "home_contacts",
                                         "Isolation" = "isolation_behaviour",
                                         "Testing & Tracing" = "testing_tracing",
                                         "All" = "all"
        )
      ) %>% 
      
      # Only write parameter set once each time
      mutate(parameter_set = as.character(parameter_set)) %>% 
      group_by(parameter_set) %>% 
      mutate(parameter_set = if_else(parameter_set == lag(parameter_set) & !is.na(lag(parameter_set)), "", parameter_set)) %>% 
      
      # Rename columns
      set_names(
        c("Parameter Set", "SES Group", "Proportion Infected", "Effect on group 5 gap", "Contribution")
      ) %>% 
      
      print_all
    
    library("xtable")
    
    print.xtable(
      xtable(group_diff_table, caption = "Main Output"),
      # type = "html",
      caption.placement = "top",
      table.placement = "!htbp",
      file = "group_diffs.tex",
      include.rownames = FALSE,
      hline.after = 0:5 * 5
    )
      
      
    
    
    
    ?as.character
    
    format_dbl <- function(x, n_digits) {
      as.character(format(round(x, n_digits), nsmall = n_digits))
    }
    
    format_chr <- function(x) {
      str_replace_all(x, "_", " ") %>% 
        str_to_title(locale = "en")
    }
    
    
    
    out_table <- sds_means %>% 
      ungroup %>% 
      mutate(p.value = sds_mean_diffs$p.value) %>% 
      select(-conf.low, -conf.high) %>% 
      mutate(
        stratum = as.integer(stratum),
        p.value = format_dbl(p.value, 3),
        p.value = if_else(stratum == 1, "-", p.value),
        std.error = format_dbl(std.error, 2),
        estimate = format_dbl(estimate, 2),
        delay_var = format_chr(delay_var)
      ) %>% 
      mutate(mean_se = str_glue("{estimate} ({std.error})")) %>% 
      mutate(delay_var = if_else(delay_var == lag(delay_var) & !is.na(lag(delay_var)), "", delay_var)) %>% 
      select("Delay Type" = delay_var, 
             "SES stratum" = stratum, 
             "Mean (SE)" = mean_se,
             "p val diff (to stratum 1)" = p.value,
             "N" = N)
    
    
    
    
    print.xtable(
      xtable(out_table, caption = "Testing Delay Means"),
      # type = "html",
      caption.placement = "top",
      table.placement = "!htbp",
      file = "test_delay_means.tex",
      include.rownames = FALSE
    )
    
    
    
    


# ............. -----------------------------------------------------------


# Share of detected-------------------------------------------------------

    
    group_diff_df_6$baseline %>% plot_detected_by_i_group(prop = TRUE)
    
    # 2 options:
    # (1) What share of people who are infected are detected at at least one time during their infection?
    # (2) What's the average proportion of infected people at a given t who are detected [weighted by # infected at that t?]
    
    # Number 2 I can already calculate:
    
    share_detected_instantaneous <- group_diff_slim %>% 
      filter(parameter_set != "out_plus_home") %>% 
      filter(parameter_set %in% c("baseline", "testing_tracing", "all")) %>%
      
      mutate(share_detected_inst = n_detected / n_cases_live) %>% 
      group_by(parameter_set, sim_id, i_group) %>% 
      select(t, share_detected_inst, n_cases_live) %>% 
      summarise(share_detected_w = weighted.mean(x = share_detected_inst, w = n_cases_live)) %>% 
      group_by(parameter_set, i_group) %>% 
      summarise(
        q = c(0.025, 0.25, 0.5, 0.75, 0.975),
        across(c(share_detected_w),
               ~ quantile(.x, q = c(0.025, 0.25, 0.5, 0.75, 0.975)))
        # quibble
        # quibble(diff_prop_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9)),
        # quibble(diff_tot_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9))
      ) %>% 
      mutate(
        parameter_set = factor(parameter_set, levels = unique(group_diff_slim$parameter_set))
      )
    
    share_detected_instantaneous %>% plot_group_diffs(y = share_detected_w, 
                                                      # ylab = "Average share of infected who have tested positive"
                                                      ylab = "Avg. share detected"
                                                      )
    
    
    # ggsave("share_detected.png",width = 8, height = 4.5, scale = 0.8)
    ggsave("share_detected_testing_tracing.png", width = 8, height = 2.5, scale = 0.8)
    
    
    
    
    
    
    # V2 - ratio of confirmed cases / total cases
    
    share_confirmed <- group_diff_slim %>% 
      filter(parameter_set != "out_plus_home") %>% 
      filter(parameter_set %in% c("baseline", "testing_tracing", "all")) %>%
      
      group_by(parameter_set, sim_id, i_group) %>% 
      summarise(n_confirmed_cases = max(n_confirmed_cases),
                n_cases_cum = max(n_cases_cum)) %>% 
      mutate(share_confirmed = n_confirmed_cases / n_cases_cum) %>% 
      
      group_by(parameter_set, i_group) %>% 
     
      summarise(
        q = c(0.025, 0.25, 0.5, 0.75, 0.975),
        across(c(share_confirmed),
               ~ quantile(.x, q = c(0.025, 0.25, 0.5, 0.75, 0.975)))
        # quibble
        # quibble(diff_prop_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9)),
        # quibble(diff_tot_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9))
      ) %>% 
      mutate(
        parameter_set = factor(parameter_set, levels = unique(group_diff_slim$parameter_set))
      )
    
    
    share_confirmed %>% plot_group_diffs(y = share_confirmed, 
                                         # ylab = "Average share of infected who have tested positive"
                                         ylab = "Avg. share detected")
    
    
    
    
    

# Share isolated ----------------------------------------------------------


    
    
    share_isolated_instantaneous <- group_diffs$model_output %>% 
      map("time_series") %>% 
      bind_rows(.id = "parameter_set") %>% 
      filter(parameter_set != "out_plus_home") %>% 
      filter(parameter_set %in% c("baseline", "testing_tracing", "all")) %>%
      
      # filter(sim_id == 1, i_group == 1) %>% 
      # filter(n_cases_live > 200) %>% 
      # print(n = 200) %>% 
      # ggplot(aes(x = t, y = n_isolators / n_cases_live, colour = factor(parameter_set))) + 
      # geom_line()
      mutate(isolation_ratio_inst = n_isolators / n_cases_live) %>% 
      group_by(parameter_set, sim_id, i_group) %>% 
      select(t, isolation_ratio_inst, n_cases_live) %>% 
      summarise(isolation_ratio_w = weighted.mean(x = isolation_ratio_inst, w = n_cases_live)) %>% 
      group_by(parameter_set, i_group) %>% 
      summarise(
        q = c(0.025, 0.25, 0.5, 0.75, 0.975),
        across(c(isolation_ratio_w),
               ~ quantile(.x, q = c(0.025, 0.25, 0.5, 0.75, 0.975)))
        # quibble
        # quibble(diff_prop_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9)),
        # quibble(diff_tot_infected, q = c(0.1, 0.25, 0.5, 0.75, 0.9))
      ) %>% 
      mutate(
        parameter_set = factor(parameter_set, levels = names(group_diffs$model_output))
      )
        
    share_isolated_instantaneous %>% plot_group_diffs(y = "isolation_ratio_w", ylab = "Avg. # Isolating / # Infected")
  
    
    # ggsave("share_isolated.png",width = 8, height = 4.5, scale = 0.8)
    ggsave("share_isolated_testing_tracing.png", width = 8, height = 2.5, scale = 0.8)
  
# .................. ------------------------------------------------------


# Parameter graphs --------------------------------------------------------

    
    test_run <- group_diff_default(n_iterations = 10)
    
    params_graph_df <- test_run$params
    
    # FUNCTIONS FOR PLOTTING
    param_bar_plot <- function(param_vec, y_lab) {
      tibble(i_group = 1:4, group_size = param_vec) %>% 
        mutate(i_group = recode_i_group(i_group)) %>% 
        ggplot(aes(x = i_group, y = group_size, fill = i_group)) + 
        geom_col() + 
        labs(x = "SES group", y = y_lab) + 
        scale_fill_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE, guide = FALSE) + 
        theme_custom()
    }
    
    
    param_box_plot <- function(data, y, y_lab = NULL) {
      
      # Calculate limits with no outliers
      ylim_no_outliers <- data %>% pull({{y}}) %>% boxplot.stats() %>% .$stats %>% .[c(1, 5)]
      
      data %>% 
        mutate(i_group = recode_i_group(i_group)) %>% 
        ggplot(aes(x = factor(i_group), y = {{y}}, fill = factor(i_group))) + 
        geom_boxplot(outlier.shape = NA) + 
        scale_fill_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE,
                           guide = FALSE) + 
        coord_cartesian(ylim = ylim_no_outliers * 1.05) + 
        labs(x = "SES group", y = y_lab)
    }
    
    
    param_mean_point_plot <- function(data, y, y_lab = NULL) {
      data %>% 
        mutate(i_group = recode_i_group(i_group)) %>% 
        group_by(i_group) %>% 
        summarise(mean_se({{y}})) %>%
        ggplot(aes(x = factor(i_group), y = y, colour = factor(i_group))) +
        geom_point(size = 2) +
        geom_errorbar(aes(ymin = ymin, ymax = ymax), width = 0.15) +
        labs(x = "SES group", y = y_lab) +
        scale_colour_viridis(option = "viridis",
                             begin = 0.3,
                             discrete = TRUE, guide = FALSE) + 
        theme_custom()
    }
    
    
    # Group size
    param_bar_plot(params_graph_df$group_props, y_lab = "Group Share") + scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL)
  
    
    library("ggpubr")
    
    # Test choice delay data
    tc_box <- param_box_plot(data_save$test_delay_data, y = test_choice_delay, y_lab = "Test consulation delay")
    tc_mean <- param_mean_point_plot(data_save$test_delay_data, y = test_choice_delay, y_lab = "Test consulation delay (mean)")
    
    # Test results delay
    tr_box <- param_box_plot(data_save$test_delay_data, y = test_results_delay, y_lab = "Test results delay")
    tr_mean <- param_mean_point_plot(data_save$test_delay_data, y = test_results_delay, y_lab = "Test results delay (mean)")
    
    dist_ylim <- c(0, 17)
    mean_ylim <- c(4.75, 6.5)
    
    ggpubr::ggarrange(
      tc_box + rremove("xlab") + labs(title = "Consultation delay", y = "Days") + coord_cartesian(ylim = dist_ylim), 
      tr_box + rremove("xlab") + labs(title = "Results delay", y = element_blank()) + coord_cartesian(ylim = dist_ylim), 
      tc_mean + labs(y = "Mean Days (±1.96 SE)")+ coord_cartesian(ylim = mean_ylim), 
      tr_mean + rremove("ylab")+ coord_cartesian(ylim = mean_ylim),
      ncol = 2, nrow = 2, align = "hv"
    )
    
    ggsave("test_delay_dist.png", width = 7, height = 6, scale = 0.7)
    
    # CT delay
    params_graph_df$ct_delay_data %>% 
      ggplot(aes(x = factor(i_group), y = ct_delay, fill = factor(i_group))) + 
      geom_boxplot() + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE)
  
    
    # Probabilit of isolating
    tiled_grid <- function(data, colour_lab) {
      data %>% 
        ggplot(aes(x = factor(i_group), y = symptom_severity, fill = prob)) + 
        geom_tile(colour = "white") + 
        geom_text(aes(label = prob, colour = prob > 0.8), size = 4) + 
        scale_colour_manual(values = c("white", "black"), guide = FALSE) + 
        scale_fill_viridis(option = "plasma", limits = c(0, 1)) + 
        labs(y = "Symptom Severity Index", x = "SES Group", fill = colour_lab)
      
    }
    
    param_bar_plot(params_graph_df$probs_self_test_df %>% filter(symptom_severity == 2) %>% .$prob, y_lab = "P(Self Test)")
    param_bar_plot(params_graph_df$probs_isolate_symptoms_df %>% filter(symptom_severity == 2) %>% .$prob, y_lab = "P(Isolate at symptoms)")
    param_bar_plot(params_graph_df$probs_isolate_ct_df %>% filter(symptom_severity == 2) %>% .$prob, y_lab = "P(Isolate after CT)")
    
    # tiled_grid(params_graph_df$probs_self_test_df, "P(Self Test)")
    # tiled_grid(params_graph_df$probs_isolate_symptoms_df, "P(Isolate at Symptoms)")
    # tiled_grid(params_graph_df$probs_isolate_ct_df, "P(Isolate after CT)")
    
    

     
    # Contact if isolated
    # param_bar_plot(1 - params_graph_df$p_contact_if_isolated_home, y_lab = "P(Infection at home doesn't occur due to isolation)")
    
    # P contact traced
    param_bar_plot(params_graph_df$p_contact_traced, y_lab = "P(Contact traced)")
    
    # Household quarantine
    params_graph_df$p_hh_quarantine %>% param_bar_plot(y_lab = "P(HH Quarantine)")
    
    # CONtact matrix, contact means  - STILL TO DO 
    
    
    (params_graph_df$k_matrix / (params_graph_df$pops %*%  t(params_graph_df$pops))) %>% 
      as.vector() %>%
      {mutate(crossing(to = 1:4, from = 1:4), k_val = .)} %>% 
      ggplot(aes(x = factor(from), y = fct_rev(factor(to)), fill = k_val)) + 
      geom_tile(colour = "white", size = 0) + 
      geom_text(
        aes(
          label = round(k_val, 5),
          colour = k_val > max(k_val) / 2
        ), 
        size = 4
      ) + 
      scale_x_discrete(position = "top") + 
      scale_colour_manual(values = c("white", "black"), guide = FALSE) + 
      scale_fill_viridis(option = "plasma", guide = FALSE) +
      labs(x = "Contacts From", y = "Contacts To", fill = "")
    
    
    
    
    # HH SIZE
    hh_size_dedup <- params_graph_df$hh_size_data %>% select(-hh_ind_id) %>% 
      dups_drop(hh_id)

    
    # HISTOGRAM
    hh_size_dedup %>% 
      mutate(i_group = recode_i_group(i_group)) %>% 
      ggplot(aes(x = hh_size, fill = factor(i_group)), colour = "darkgrey") + 
      geom_histogram(aes(y=..density..), binwidth = 1, boundary = -0.499, colour = "white") + 
      facet_wrap(~ factor(i_group)) + 
      coord_cartesian(xlim = c(0, 8)) + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE, 
                         guide = FALSE) + 
      scale_x_continuous(breaks = 1:8, minor_breaks = NULL) + 
      labs(x = "Household Size", y = "Density") + 
      theme_custom()
    
    ggsave("hh_size_hist.png", width = 6, height = 4)
      
    hh_size_dedup %>% 
      mutate(i_group = recode_i_group(i_group)) %>% 
      group_by(i_group) %>% 
      summarise(mean_se(hh_size)) %>%
      ggplot(aes(x = factor(i_group), y = y, colour = factor(i_group))) +
      geom_point(size = 3) +
      geom_errorbar(aes(ymin = ymin, ymax = ymax), width = 0) +
      labs(x = "SES group", y = "Mean HH Size") +
      scale_colour_viridis(option = "viridis",
                         begin = 0.3,
                         discrete = TRUE, guide = FALSE) + 
      theme_custom()
    
    
    ggsave("hh_size_means.png", width = 4, height = 3)
      
  
      
      # geom_boxplot(outlier.shape = NA) + 
       #+ 
      #coord_cartesian(ylim = ylim_no_outliers * 1.05)
      
      param_box_plot(y = hh_size)
    
    
    # SAR
    params_graph_df$sar_home %>% param_bar_plot(y_lab = "SAR (Within home)")
    params_graph_df$sar_out %>% param_bar_plot(y_lab = "SAR (Outside home)")
    
    
  
    
    
    
    
    
    

# Timing distribution graphs ----------------------------------------------

    
    library("svglite")
    
    
    save_plot <- function(file_name, width = 6, height = 4) {
      ggsave(str_glue("figures/{file_name}.svg"), width = width, height = height)
    }
    
    
    # TEST SENSITIVITY
    data_save$test_sensitivity_data %>% 
      ggplot(aes(x = days_exposure, y = sensitivity)) + 
      geom_line(colour = "indianred") +  
      theme_classic() + 
      coord_cartesian(ylim = c(0, 1)) +
      scale_y_continuous(expand = c(0, 0)) +
      labs(x = "Days after exposure", y = "Test Sensitivity")
    
    save_plot("params_sensitivity")
    

    
    
    params_timing <- outbreak_setup_test$params
    
    
    # SYMPTOMS DISTRIBUTION
    symptom_timing_dist <- tibble(
      x = seq(0, 50, 0.1),
      y = dlnorm(x = x, 
                 meanlog = params_timing$params_symptom_timing$meanlog,
                 sdlog = params_timing$params_symptom_timing$sdlog)
    )
    
    max_x <- max(symptom_timing_dist$x[symptom_timing_dist$y > 0.001])
    
    ggplot(symptom_timing_dist, aes(x = x, y = y)) + 
      geom_area(colour = "indianred", fill = "indianred", alpha = 0.5) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
      labs(y = "Density", x = "Incubation Period (days)") + 
      annotate("text", x = 15, y = c(0.15, 0.13, 0.11), hjust = 1,
               label = c(
                 "Lognormal",
                 expression(paste(mu, " = 1.63, ", sigma, " = 0.50")),
                 "McAloon et al (2020)"
               )
      ) + 
      coord_cartesian(xlim = c(0, max_x)) + 
      theme_classic()
    
    
    save_plot("params_incubation_period")
    
    
    # SERIAL INTERVAL
    serial_interval_dist <- tibble(
      x = seq(-20, 50, 0.1),
      y = dgamma(x = x - params_timing$params_serial$shift, 
                 shape = params_timing$params_serial$shape,
                 rate = params_timing$params_serial$rate) 
    )
    
    # pgamma(
    #   q = 0 - params_timing$params_serial$shift, 
    #   shape = params_timing$params_serial$shape,
    #   rate = params_timing$params_serial$rate
    # )
    
    min_x <- min(serial_interval_dist$x[serial_interval_dist$y > 0.001])
    max_x <- max(serial_interval_dist$x[serial_interval_dist$y > 0.001])
  
    ggplot(serial_interval_dist, aes(x = x, y = y)) + 
      geom_vline(xintercept = 0, linetype = "dotted") + 
      geom_area(colour = "dodgerblue", fill = "dodgerblue", alpha = 0.5) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
      labs(y = "Density", x = "Serial Interval (days)") + 
      annotate("text", x = 20, y = c(0.08, 0.07, 0.06), hjust = 1,
               label = c(
                 "Gamma",
                 expression(paste(alpha, " = 8.12, ", beta, " = 0.64, ", Delta, "x = -7.5")),
                 "He et al (2020)"
               )
      ) +
      coord_cartesian(xlim = c(min_x, max_x)) +
      theme_classic()
    
    save_plot("params_serial_interval")
    
    
    # IMPORT THE DATA FROM IMPORT_DATA - using the draw_timings function 
    # and the gen_data_clean stuff
    
    # Secondary timing
    ggplot(gen_data_clean, aes(x = secondary_timing)) + 
      geom_density(colour = "seagreen4", fill = "seagreen4", alpha = 0.5) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
      labs(y = "Density", x = "Generation Interval (days)") + 
      coord_cartesian(xlim = c(0, 20)) +
      theme_classic()
    
  
    save_plot("params_generation_interval")
    
    # Secondary timing - symptoms [infectiousness profile]
    prop_presymptomatic <- gen_data_clean %$% round(mean(secondary_timing < primary_symptoms) * 100)
    
    ggplot(gen_data_clean, aes(x = secondary_timing - primary_symptoms)) + 
      geom_vline(xintercept = 0, linetype = "dotted") + 
      geom_density(colour = "darkorange2", fill = "darkorange2", alpha = 0.5) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
      labs(y = "Density", x = "Day of secondary infection - day of symptom onset") + 
      annotate("text", x = 20, y = c(0.08), hjust = 1,
               label = c(
                 paste0("Prop presymptomatic = ", prop_presymptomatic, "%")
               )
      ) +
      coord_cartesian(xlim = c(-10, 20)) +
      theme_classic()
    
    save_plot("params_infectiousness_profile")
    
    

# ..................... ---------------------------------------------------


# Policy change graph -----------------------------------------------------

    lockdown_scale_factor <- 0.5
    
    beta_6_lockdown <- rescale_beta(beta_matrix = beta_matrix_6,
                                    rescale_factors = rep(lockdown_scale_factor, 1)) %>% print_all
    
    contacts_mean_6_lockdown <- rescale_contacts_mean(
      rescale_factors = rep(lockdown_scale_factor, 1),
      beta_matrix = beta_matrix_6,
      sar_out = c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1),
      group_props = c(0.15, 0.3, 0.25, 0.1, 0.1, 0.1),
      contacts_mean_scale = 20,
      scale_on = 3
    ) %>% print
    
    
    policy_change_6_group <- outbreak_sims_policy_change(
      n_sims = 5,
      n_iterations = 1000,
      constant_params = list(
        n_pop = 10000,
        hh_size_data = data_save$hh_data_bogota,
        n_initial_cases = rep(10, 6), 
        group_props = c(0.15, 0.3, 0.25, 0.1, 0.1, 0.1),
        dt_approx = 1,
        recov_val = 10, # people recover 10 days after symptoms show (cuts off only ~ 1% of infections at the upper end of timing distribution)
        params_timing = data_save$params_timing,
        params_symptom_timing = data_save$params_symptom_timing,
        params_serial = data_save$params_serial,
        test_choice_delay_data = data_save$test_choice_delay_data,
        test_results_delay_data = data_save$test_results_delay_data, 
        test_sensitivity_data = data_save$test_sensitivity_data, 
        ct_delay_data = ct_delay_data_real_6,
        probs_self_test_df = probs_df_basic_6 %>%        mutate(prob = rep(probs_default, times = 6) * rep(c(0.1, 0.5, 0.6, 0.7, 0.9, 1), each = 5)),
        probs_isolate_symptoms_df = probs_df_basic_6 %>% mutate(prob = rep(probs_default, times = 6) * rep(c(0.2, 0.4, 0.5, 0.7, 0.9, 1), each = 5)),
        probs_isolate_test_df = probs_df_basic_6 %>%     mutate(prob = rep(probs_default, times = 6) * rep(c(0.6, 0.7, 0.8, 0.8, 0.7, 0.8), each = 5)),
        probs_isolate_ct_df = probs_df_basic_6 %>%       mutate(prob = rep(probs_default, times = 6) * rep(c(0.6, 0.7, 0.8, 0.8, 0.8, 0.9), each = 5)),
        p_contact_if_isolated_home = c(0.3, 0.2, 0.1, 0.1, 0.1, 0.1), 
        p_contact_traced = c(0.1, 0.2, 0.2, 0.2, 0.3, 0.3),
        p_hh_quarantine = c(0.4, 0.5, 0.8, 0.7, 0.8, 0.8),
        # beta_matrix = beta_matrix_6,
        # contacts_mean = contacts_mean_6,
        sar_out = c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1),
        sar_home = c(0.4, 0.3, 0.2, 0.2, 0.2, 0.2), 
        infectiousness_by_symptoms = c(0.7, 1, 1, 1, 1),
        alpha = c(0, 0, 0, 0, 0, 0)
      ),
      policy_start_times = c(0, 15, 50),
      time_varying_params = list(
        "prelockdown" = list(beta_matrix = beta_matrix_6,
                             contacts_mean = contacts_mean_6),
        "lockdown" = list(beta_matrix = beta_6_lockdown,
                          contacts_mean = contacts_mean_6_lockdown),
        "postlockdown" = list(beta_matrix = beta_matrix_6,
                              contacts_mean = contacts_mean_6)
      )
    )
    
    
    # FOR PLOTTING the policy change graphs
    lockdown_rect <- policy_change_6_group$time_series %>% 
      summarise(xmin = min(t[policy == "lockdown"], na.rm = TRUE), 
                xmax = max(t[policy == "lockdown"], na.rm = TRUE))
    
   # PLOT POLICY CHANGE GRAPH
    policy_change_6_group$time_series %>% 
      group_by(t, i_group, n_pop, policy) %>% 
      quantile_summarise(c(n_cases_live), conf_level = 0) %>% 
      mutate(prevalence_prop = n_cases_live_median / n_pop) %>% 
      ggplot() + 
      
      # Shaded area
      geom_rect(data = lockdown_rect,
                aes(xmin = xmin,
                    xmax = xmax,
                    ymin=0, ymax=Inf), alpha = 0.08, fill = "indianred") +
      
      # LINE
      geom_line(aes(x = t, y = prevalence_prop, 
                    colour = factor(i_group), group = factor(i_group)),
                show.legend = TRUE) + 
      # facet_wrap(~ parameter_set, labeller = as_labeller(counterfactual_labels)) + 
      
      # Formatting
      theme_custom() + 
      theme(legend.position = "right") + 
      scale_alpha_continuous(guide = FALSE) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
      labs(colour = "SES Group", fill = "SES Group", y = "% Infected at t") +
      geom_hline(yintercept = 0, colour = "darkgrey", size = 0.4) + 
      coord_cartesian(xlim = c(0, 150)) +
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      scale_x_continuous(minor_breaks = c(0, 25, 50, 75), breaks = c(0, 50, 100, 150, 200)) + 
      geom_vline(aes(xintercept = min(t[policy == "lockdown"], na.rm = TRUE)), linetype = "dashed") +
      geom_vline(aes(xintercept = max(t[policy == "lockdown"], na.rm = TRUE)), linetype = "dashed")
    
    
    ggsave("second_wave_example.png", width = 6, height = 4, scale = 0.85)
    
    
    
    
    
    
    
    
    
    
    
    
    

# ....................... -------------------------------------------------


# INEQUALITY IS BAD  ------------------------------------------------------

    params <- list(
      group_props = data_save$group_props,
      n_pop = 100000,
      
      probs_self_test_df = probs_df_basic_5 %>%        mutate(prob = rep(probs_default, times = 5) * rep(c(0.1, 0.5, 0.6, 0.7, 0.9), each = 5)),
      probs_isolate_symptoms_df = probs_df_basic_5 %>% mutate(prob = rep(probs_default, times = 5) * rep(c(0.2, 0.4, 0.5, 0.7, 0.9), each = 5)),
      probs_isolate_test_df = probs_df_basic_5 %>%     mutate(prob = rep(probs_default, times = 5) * rep(c(0.6, 0.7, 0.8, 0.8, 0.7), each = 5)),
      probs_isolate_ct_df = probs_df_basic_5 %>%       mutate(prob = rep(probs_default, times = 5) * rep(c(0.6, 0.7, 0.8, 0.8, 0.8), each = 5)),
      p_contact_if_isolated_home = c(0.3, 0.2, 0.1, 0.1, 0.1),
      p_contact_traced = c(0.1, 0.2, 0.2, 0.2, 0.3),
      p_hh_quarantine = c(0.4, 0.5, 0.8, 0.7, 0.8),
      hh_size_data = data_save$hh_data_bogota,
      test_delay_data = data_save$test_delay_data,
      ct_delay_data = ct_delay_data_real_5,
      k_matrix = data_save$k_matrix_5 * 0.8 * 100000 / 10000,
      sar_out = c(0.1, 0.1, 0.1, 0.1, 0.1),
      sar_home = c(0.4, 0.3, 0.2, 0.2, 0.2),
      alpha = c(0, 0, 0, 0, 0)
    )
    
    # probs_df_basic_6 %>%        mutate(prob = rep(probs_default, times = 6) * rep(c(0.1, 0.5, 0.6, 0.7, 0.9, 1), each = 5)) %>% print_all
 
    # CALCUALTE NEW TIGHTENED LIST OF PARAMETERS (takes a while to find rescale factors for the beta matrix, hh_size_data etc.)
    params_tightened_list <- tibble(
      tighten_factor = c(0, 0.25, 0.5, 0.75, 1),
      # tighten_factor = 0,
      params_to_scale = list(params) 
    ) %>% 
      rowwise() %>% 
      mutate(params_tightened = list(tighten_params(params_to_scale, tighten_factor = tighten_factor)))
      
  
    # CHECK THE BETA MATRIX
    # params_tightened_list$params_tightened %>% 
    #   map(
    #     ~ {
    #       pop_matrix <- data_save$group_props %*% t(data_save$group_props)
    #       beta_matrix <- .x$k_matrix / pop_matrix
    #       return(round(beta_matrix, 2))
    #     }
    #   )
    
    # OK SO IT'S BASICALLY THE WAY THE K MATRIX IS SPECIFIED is a bit confusing
    # because it's the TOTAL number of contacts between any i and j
    # meaning that when the population is larger it should be WAY higher
    # AHHHH and the mus are incorrectly specified!!
    # each row doesn't sum up to the mu of each person, it should sum up to mu * POP SIZE 
    
    
    # WELL... 
    # K matrix of TOTAL contacts in the population should be symmetric
    # but for a given person it doesn't have to be symmetric [and rows add up to mu * pop size not mu]
    

    # Transpose so it's amenable to being pmapped 
    params_tightened_transposed <- bind_cols(
      tibble(tighten_factor = params_tightened_list$tighten_factor),
      params_tightened_list$params_tightened %>% 
        purrr::transpose() %>% 
        as_tibble()
    )
    
    
    
    
    # WHAT'S GOING WRONG HERE??
    # params_tightened_transposed_OLD <- params_tightened_transposed
    
    
  
    
    # CHECK NEW HH SIZE MEANS
    
    # params_tightened_transposed$test_results_delay_data %>%
    #   set_names(as.character(c(0, 0.25, 0.5, 0.75, 1))) %>%
    #   bind_rows(.id = "tighten_factor") %>%
    #   filter(test_results_delay <= 10) %>%
    #   ggplot(aes(x = tighten_factor, y = test_results_delay)) +
    #   geom_boxplot()

    hh_size_bound <- params_tightened_transposed$hh_size_data %>%
      set_names(as.character(params_tightened_list$tighten_factor)) %>%
      bind_rows(.id = "tighten_factor")

    hh_size_bound %>%
      group_by(tighten_factor, i_group) %>%
      summarise(mean_se(hh_size)) %>%
      ggplot(aes(x = factor(i_group), y = y)) +
      geom_point() +
      geom_errorbar(aes(ymin = ymin, ymax = ymax), width = 0.2) +
      facet_wrap(~ tighten_factor)
    
    
    
    # Run all simulations with new models:
    inequality_is_bad <- params_tightened_transposed %>% 
      mutate(model_output = pmap(select(., -tighten_factor, -contact_means), 
                                 group_diff_default, 
                                 # keep_all_data = TRUE, 
                                 n_sims = 5, 
                                 # n_pop = 100000,
                                 # group_props = data_save$group_props,
                                 # n_initial_cases = round(c(0.025, 0.075, 0.15, 0.2, 0.25, 0.3) * 1000),
                                 # group_props = c(rep(0.167, 5), 1 - (0.167 * 5)),
                                 # n_initial_cases = rep(20, 6),
                                 n_iterations = 10000)) # if you keep all data it's 40GB !! bloody hell
    
    
    # Remove all the parameters (for ease)
    inequality_is_bad_slim <- inequality_is_bad %>% 
      mutate(time_series = map(model_output, "time_series")) %>% 
      select(tighten_factor, time_series) %>% 
      unnest(time_series) 
    
    save(inequality_is_bad_slim, file = "inequality_is_bad.RData")
    # load("inequality_is_bad.RData", verbose = TRUE)
    
    library("viridis")
    
    
    inequality_is_bad$model_output[[1]] %>% plot_by_i_group()
    
    # PLOT EPIDEMIC CURVE
    inequality_is_bad_slim %>% 
      group_by(tighten_factor, t, i_group, n_pop) %>% 
      quantile_summarise(c(n_cases_live), conf_level = 0) %>% 
      mutate(prevalence_prop = n_cases_live_median / n_pop) %>% 
  
      ggplot(aes(x = t, y = prevalence_prop, 
                 colour = factor(i_group), group = factor(i_group))) + 
      geom_line(show.legend = TRUE) + 
      facet_wrap(~ factor(tighten_factor)) + 
      
      # Formatting
      theme_custom() + 
      theme(legend.position = "right") + 
      scale_alpha_continuous(guide = FALSE) + 
      scale_y_continuous(labels = scales::percent_format(accuracy = 1), minor_breaks = NULL) + 
      labs(colour = "SES Group", fill = "SES Group", y = "% Infected at t") +
      geom_hline(yintercept = 0, colour = "darkgrey", size = 0.4) + 
      coord_cartesian(xlim = c(0, 100)) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      scale_x_continuous(minor_breaks = c(0, 25, 50, 75), breaks = c(0, 50, 100))
    
    
    # PLOT TOTAL INFECTED in each group
    inequality_is_bad_slim %>% 
      group_by(tighten_factor, i_group, sim_id, n_pop) %>% 
      summarise(n_cases_cum = max(n_cases_cum)) %>% 
      group_by(tighten_factor, i_group, n_pop) %>% 
      quantile_summarise(n_cases_cum) %>% 
      mutate(prop_infected_median = n_cases_cum_median / n_pop,
             prop_infected_upper = n_cases_cum_upper / n_pop,
             prop_infected_lower = n_cases_cum_lower / n_pop) %>% 
      
      ggplot(aes(x = i_group, fill = factor(i_group))) + 
      geom_col(aes(y = prop_infected_median)) + 
      geom_errorbar(aes(ymin = prop_infected_lower, ymax = prop_infected_upper), width = 0.2, size = 0.5, colour = "#374561") + 
      facet_wrap(~ tighten_factor) + 
      labs(y = "", x = "SES Group", fill = "SES Group") + 
      theme_custom() + 
      theme(legend.position = "right") + 
      geom_hline(yintercept = 0, colour = "darkgrey", size = 0.4) + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE) + 
      scale_x_continuous(breaks = 1:6)
    
    # PLOT TOTAL INFECTED OVER WHOLE EPIDEMIC
    inequality_is_bad_slim %>% 
      group_by(tighten_factor, i_group, sim_id, n_pop) %>% 
      summarise(n_cases_cum = max(n_cases_cum)) %>% print(n = 100) %>% 
      group_by(tighten_factor, sim_id) %>% 
      summarise(n_pop = sum(n_pop), n_cases_cum = sum(n_cases_cum)) %>% 
      mutate(prop_infected = n_cases_cum / n_pop) %>% 
      group_by(tighten_factor) %>% 
      quantile_summarise(prop_infected, conf_level = 0.95) %>% 
      
      ggplot(aes(x = tighten_factor, colour = factor(tighten_factor))) + 
      # geom_col(aes(y = prop_infected_median), width = 0.1,show.legend = FALSE) + 
      geom_point(aes(y = prop_infected_median)) + 
      geom_errorbar(aes(ymin = prop_infected_lower, ymax = prop_infected_upper), width = 0.02, size = 0.5, colour = "#374561") + 
      # facet_wrap(~ tighten_factor) + 
      labs(y = "", x = "Tighten factor", fill = "Tighten factor") + 
      theme_custom() + 
      theme(legend.position = "right") + 
      # geom_hline(yintercept = 0, colour = "darkgrey", size = 0.4) + 
      # scale_fill_viridis(option = "viridis",
      #                    begin = 0.3, 
      #                    discrete = TRUE) + 
      scale_x_continuous(breaks = 1:6)
    
    
    
    

# Plot parameters to check ------------------------------------------------

    named_list_to_tibble <- function(.list) {
      tib <- tibble(name = names(.list))
      tib$data <- unname(.list)
      return(tib)
    }
    
    params_tightened_long <- params_tightened_list %>% 
      select(-params_to_scale) %>% 
      ungroup %>% 
      mutate(params_tightened = map(params_tightened, named_list_to_tibble)) %>% 
      unnest(params_tightened) %>% 
      arrange(name)
    
    params_tightened_long_no_data <- params_tightened_long %>% 
      filter(!str_detect(name, "data"), map_lgl(data, ~ is_atomic(.x) & !is.matrix(.x))) %>% 
      mutate(i_group = list(1:5)) %>% 
      unnest(c(data, i_group)) %>% 
      filter(name != "alpha") %>% 
      print_all
    
    
    # PLOT ALL VECTOR BASED
    params_tightened_long_no_data %>% 
      # filter(name == "contact_means") %>% 
      
      ggplot(aes(x = tighten_factor, y = data, colour = factor(i_group))) + 
      geom_line(alpha = 0.3) + geom_point() + 
      facet_wrap(~ name, scales = "free_y")
    
    # PLOT ALL DATA BASED:
    
    # (i) ct_delay_data
    params_tightened_long %>% filter(name == "ct_delay_data") %>% #.$data %>% .[[1]] %>% 
      rowwise() %>% 
      mutate(
        summ_data = list(data %>% group_by(i_group) %>% summarise(mean_se(ct_delay)))
      ) %>% 
      unnest(summ_data) %>% 
      
      # Plot
      ggplot(aes(x = tighten_factor, y = y, colour = factor(i_group))) + 
      geom_line(alpha = 0.3) + geom_point() + 
      facet_wrap(~ name, scales = "free_y")
    
    # (ii) test delay data
    params_tightened_long %>% filter(name == "test_delay_data") %>% #.$data %>% .[[1]] %>% 
      rowwise() %>% 
      mutate(
        summ_data = list(data %>% group_by(i_group) %>% summarise(mean_se(test_results_delay)))
      ) %>% 
      unnest(summ_data) %>% 
      
      # Plot
      ggplot(aes(x = tighten_factor, y = y, colour = factor(i_group))) + 
      geom_line(alpha = 0.3) + geom_point() + 
      facet_wrap(~ name, scales = "free_y")
    
    params_tightened_long %>% filter(name == "test_delay_data") %>% #.$data %>% .[[1]] %>% 
      rowwise() %>% 
      mutate(
        summ_data = list(data %>% group_by(i_group) %>% summarise(mean_se(test_choice_delay)))
      ) %>% 
      unnest(summ_data) %>% 
      
      # Plot
      ggplot(aes(x = tighten_factor, y = y, colour = factor(i_group))) + 
      geom_line(alpha = 0.3) + geom_point() + 
      facet_wrap(~ name, scales = "free_y")
    
    
    # (iii) HH size data
    params_tightened_long %>% filter(name == "hh_size_data") %>% #.$data %>% .[[1]] %>% 
      rowwise() %>% 
      mutate(
        summ_data = list(data %>% group_by(i_group) %>% summarise(mean_se(hh_size)))
      ) %>%  
      unnest(summ_data) %>% 
      
      # Plot
      ggplot(aes(x = tighten_factor, y = y, colour = factor(i_group))) + 
      geom_line(alpha = 0.3) + geom_point() + 
      facet_wrap(~ name, scales = "free_y")
    
    
    

# Trouble shooting inequality is bad --------------------------------------

    inequality_is_bad_outbreak <- inequality_is_bad$model_output[[1]]
    
    inequality_is_bad_outbreak$params$contact_weights %>% print_all
    inequality_is_bad_outbreak$time_series %>% 
      mutate(p_infected = n_cases_live / n_pop, .before = n_susceptible) %>% 
      print(n = 200)
    
    inequality_is_bad_live <- inequality_is_bad_outbreak$outbreak_t_record[[1]] %>% map("live_cases") %>% 
      set_names(as.character(0:50)) %>% 
      bind_rows(.id = "t") %>% 
      mutate(t = as.numeric(t), i_group = factor(i_group)) %>% 
      arrange(case_id, t) %>% 
      relocate(case_id, t)
    
    inequality_is_bad_secondary <- inequality_is_bad_outbreak$outbreak_t_record[[1]] %>% map("secondary_cases") %>% 
      set_names(as.character(0:50)) %>% 
      bind_rows(.id = "t") %>% 
      mutate(t = as.numeric(t), i_group = factor(i_group)) %>% 
      arrange(case_id, secondary_case_id, t) %>% 
      relocate(case_id, secondary_case_id, t)
    
    
    # Number of secondary cases 
    inequality_is_bad_secondary %>% 
      select(case_id, secondary_case_id, i_group, secondary_i_group) %>% 
      distinct() %>% 
      group_by(case_id, i_group) %>% 
      summarise(n = n()) %>% 
      
      ggplot(aes(x = log(n + 1), colour = factor(i_group))) + 
      geom_density(adjust = 2)
    
    
    # Avg number of seconray cases
    inequality_is_bad_secondary %>% 
      select(case_id, secondary_case_id, i_group, secondary_i_group) %>% 
      distinct() %>% 
      group_by(i_group, case_id) %>% 
      summarise(n = n()) %>% 
      summarise(avg_g = mean(n))
    
    # Proportion from each group
    inequality_is_bad_secondary %>% 
      select(case_id, secondary_case_id, i_group, secondary_i_group) %>% 
      distinct() %>% 
      group_by(i_group, secondary_i_group) %>% 
      summarise(n = n()) %>% 
      mutate(p = n / sum(n))
      
      
    inequality_is_bad_outbreak %>% plot_detected_by_i_group()  # group 6 is much slower to get detected for some reason !!
    
    inequality_is_bad_outbreak %>% plot_by_i_group()
    
    
    

# ...................... --------------------------------------------------


# TARGETED POLICIES -------------------------------------------------------

# Targeted policies -------------------------------------------------------
# 
#     params <- list(
#       # hh_size_data = data_save$hh_data_bogota,
#       group_props = data_save$group_props,
#       test_choice_delay_data = data_save$test_choice_delay_data,
#       test_results_delay_data = data_save$test_results_delay_data,
#       test_sensitivity_data = data_save$test_sensitivity_data,
#       ct_delay_data = ct_delay_data_real_5,
#       probs_self_test_df = probs_df_basic_5 %>%        mutate(prob = rep(probs_default, times = 5) * rep(c(0.1, 0.5, 0.6, 0.7, 0.9), each = 5)),
#       probs_isolate_symptoms_df = probs_df_basic_5 %>% mutate(prob = rep(probs_default, times = 5) * rep(c(0.2, 0.4, 0.5, 0.7, 0.9), each = 5)),
#       probs_isolate_test_df = probs_df_basic_5 %>%     mutate(prob = rep(probs_default, times = 5) * rep(c(0.6, 0.7, 0.8, 0.8, 0.7), each = 5)),
#       probs_isolate_ct_df = probs_df_basic_5 %>%       mutate(prob = rep(probs_default, times = 5) * rep(c(0.6, 0.7, 0.8, 0.8, 0.8), each = 5)),
#       p_contact_if_isolated_home = c(0.3, 0.2, 0.1, 0.1, 0.1), 
#       p_contact_traced = c(0.1, 0.2, 0.2, 0.2, 0.3, ),
#       p_hh_quarantine = c(0.4, 0.5, 0.8, 0.7, 0.8, 0.8),
#       beta_matrix = beta_matrix_6,
#       contacts_mean = contacts_mean_6,
#       sar_out = c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1),
#       sar_home = c(0.4, 0.3, 0.2, 0.2, 0.2, 0.2), 
#       alpha = c(0, 0, 0, 0, 0, 0)
#     )
#     
#     
#     beta_matrix_6$beta_val %>% matrix(nrow = 6)
#     
#     # TRY EXAMPLE WITH HH QUARANTINE
#     params$p_hh_quarantine
#     
#     
#     # Check it makes some difference when changed a lot
#     target_hh_quarantine <- list(
#       
#       "baseline" = group_diff_default(),
#       
#       "hh_quarantine" = group_diff_default(p_hh_quarantine = c(0.8, 0.8, 0.8, 0.8, 0.8, 0.8))
#       
#     )
#     
#     target_hh_quarantine_slim <- target_hh_quarantine %>% 
#       map("time_series") %>% 
#       bind_rows(.id = "parameter_set")
#     
#     
#     target_hh_quarantine_slim %>% 
#       group_by(parameter_set, sim_id) %>% 
#       summarise(n_cases_cum = max(n_cases_cum))
#     
#     
#     
#     
#     # params_original <- params$p_hh_quarantine
#     params_original <- c(0.3, 0.4, 0.6, 0.7, 0.8, 0.8)
#     params$group_props
#     n_pops <- target_hh_quarantine$baseline$time_series$n_pop[1:6]
#     
#     budget <- 0.6
#     
#     per_capita_untargeted <- budget / sum(n_pops) # for untargeted control
#     
#     # targeted : groups 1 - 2
#     per_capita_targeted <- budget / sum(n_pops[1:2])
#   
#     (params_untargeted <- params_original + (n_pops * per_capita_untargeted))
#     (params_targeted <- params_original + (c(n_pops[1:2], 0, 0, 0, 0) * per_capita_targeted))
#     
#     
#     
#     
#     target_params <- function(params_original, n_pops, budget, target_groups = 1:2,
#                               direction = 1) {
#       
#       per_capita_untargeted <- budget / sum(n_pops)
#       per_capita_targeted <- budget / sum(n_pops[target_groups])
#       
#       n_pops_targeted <- if_else(seq_along(n_pops) %in% target_groups, n_pops, 0)
#       
#       return(
#         tibble(
#           untargeted = params_original + (n_pops * per_capita_untargeted * direction),
#           targeted = params_original + (n_pops_targeted * per_capita_targeted * direction)
#         )
#       )
#     
#     }
#     
#     n_pops <- group_diff_default(n_sims = 1, n_iterations = 2)$time_series$n_pop[1:6]
#     
#     # Test the function
#     target_params(params_original = c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1),
#                   n_pops = n_pops,
#                   budget = 0.1, 
#                   target_groups = 1:2,
#                   direction = -1)
#     
#     
#     # Make a dataframe with parameters
#     target_params_list <- tibble(
#       budget = c(0, 0.3, 0.7)
#     ) %>% 
#       rowwise() %>% 
#       mutate(target_params = list(target_params(params_original = c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1),
#                                                 n_pops = n_pops,
#                                                 budget = budget, 
#                                                 target_groups = 1:2))) %>% 
#       unnest(target_params) %>% 
#       group_by(budget) %>% 
#       summarise(untargeted = list(untargeted),
#                 targeted = list(targeted)) %>% 
#       pivot_longer(-budget, names_to = "target_type", values_to = "p_hh_quarantine") %>% 
#       print
#     
#     
#     target_results <- target_params_list %>% 
#       mutate(model_output = pmap(select(., -c(budget, target_type)), group_diff_default, n_sims = 2, n_iterations = 1000))
#     
#     target_results_slim <- target_results %>% 
#       mutate(model_output = map(model_output, "time_series")) %>% 
#       unnest(model_output)
#     
#     
#     # PLOT budget, targeted, etc. [PROP PEOPLE INFECTED!!]
#     target_results_slim %>% 
#       
#       # Calculate total infected in each run
#       group_by(budget, target_type, sim_id, i_group) %>% 
#       summarise(n_cases_cum = max(n_cases_cum)) %>% 
#       
#       # Sum up each i_group
#       summarise(n_cases_cum = sum(n_cases_cum)) %>% 
#       
#       # Calculate median and confidence intervals
#       group_by(budget, target_type) %>% 
#       quantile_summarise(n_cases_cum, conf_level = 0.95) %>% 
#       
#       # PLOT
#       ggplot(aes(x = budget, y = n_cases_cum_median, colour = target_type)) + 
#       geom_point() + 
#       geom_line() + 
#       geom_errorbar(aes(ymin = n_cases_cum_lower, ymax = n_cases_cum_upper), width = 0.02, size = 0.5)
#       
#     
#     # PEAK VALUE
#     target_results_slim %>% 
#       
#       # Calculate totals at each t (ready to calculate peak val)
#       group_by(budget, target_type, sim_id, t) %>% 
#       summarise(n_cases_live = sum(n_cases_live)) %>% 
#       
#       # Calculate peak_val
#       summarise(peak_val = max(n_cases_live)) %>% 
#       
#       # Median / conf intervals
#       quantile_summarise(peak_val, conf_level = 0.95) %>% 
#       
#       # PLOT
#       ggplot(aes(x = budget, y = peak_val_median, colour = target_type)) + 
#       geom_point() + 
#       geom_line() + 
#       geom_errorbar(aes(ymin = peak_val_lower, ymax = peak_val_upper), width = 0.02, size = 0.5)
#     
#     
    
    
      
    
    
    

# Targeted policies v2 ----------------------------------------------------

    # Above, I think the calculation of the new parameters is wrong, because you shouldn't get
    # added benefit PER PERSON from being in a larger group
    
    # NEW VERSION where reduction in params is uniform across targeted groups
    target_params <- function(params_original, n_pops, budget, target_groups = 1,
                              direction = 1) {
      
      # TESTING
      # params_original <- rep(0.1, 6)
      # n_pops <- group_diff_default(n_sims = 1, n_iterations = 2)$time_series$n_pop[1:6]
      # budget <- 10000 * 0.04
      # target_groups <- 1:2
      # direction <- -1
      
      if (length(n_pops) != length(params_original)) stop("number of groups is not same across n_pops and params_original")
      
      (per_capita_untargeted <- budget / sum(n_pops)) # reduction across all groups
      (per_capita_targeted <- budget / sum(n_pops[target_groups])) # reduction if only on 1:2 groups
      
      targeted_indices <- if_else(seq_along(n_pops) %in% target_groups, 1, 0)
      
      out <-  tibble(
        untargeted = params_original + (per_capita_untargeted * direction),
        targeted = params_original + (targeted_indices * per_capita_targeted * direction)
      ) %>% print
      
      return(out)
      
    }
    
    
    # COULD REWRITE with X = untargeted reduction per person...
    # i.e. untargeted we reduce sar_out by 0.05, what's the equivalent reduction if 
    # we expend the same "effort" on reducing only [assuming constant cost per person...]
      
    n_pops <- group_diff_default(n_sims = 1, n_iterations = 2)$time_series$n_pop[1:4]
    
    target_params(params_original = c(0.1, 0.1, 0.1, 0.1),
                  n_pops = n_pops,
                  budget = 25, 
                  target_groups = 1,
                  direction = -1)
    
    
    # Make a dataframe with parameters
    target_params_list <- tibble(
      budget = c(0, 25, 45) * 10
    ) %>% 
      rowwise() %>% 
      mutate(target_params = list(target_params(params_original = c(0.1, 0.1, 0.1, 0.1),
                                                n_pops = n_pops,
                                                budget = budget, 
                                                target_groups = 1,
                                                direction = -1))) %>% 
      unnest(target_params) %>% 
      group_by(budget) %>% 
      summarise(untargeted = list(untargeted),
                targeted = list(targeted)) %>% 
      pivot_longer(-budget, names_to = "target_type", values_to = "sar_out") %>% 
      print
    
    target_params_list %>% unnest(sar_out) %>% print_all
    

    target_results <- target_params_list %>% 
      mutate(model_output = pmap(select(., -c(budget, target_type)), group_diff_default, n_sims = 2, print_detail = FALSE, n_iterations = 1000))
    
    target_results_2 <- target_params_list %>% 
      mutate(model_output = pmap(select(., -c(budget, target_type)), group_diff_default, n_sims = 5, n_iterations = 1000))
    
    target_results_slim <- bind_rows(
      target_results %>% 
        mutate(model_output = map(model_output, "time_series")) %>% 
        unnest(model_output) %>% 
        mutate(sim_id = as.character(as.numeric(sim_id) + 5)),
      target_results_2 %>% 
        mutate(model_output = map(model_output, "time_series")) %>% 
        unnest(model_output)
    )
    
    save(target_results_slim, file = "target_results_slim.RData")
    
    # PLOT budget, targeted, etc. [PROP PEOPLE INFECTED!!]
    target_results_slim %>% 
      
      # SHADY
      # filter(!(target_type == "targeted" & sim_id == 5)) %>% 
      group_by(budget, target_type, sim_id, t) %>% 
      mutate(n_pop_total = sum(n_pop)) %>% 
      mutate(budget = budget / n_pop_total) %>% 
      ungroup %>% 
      
      # Calculate total infected in each run
      group_by(budget, target_type, sim_id, i_group) %>% 
      summarise(n_cases_cum = max(n_cases_cum)) %>% 
      
      # Sum up each i_group
      summarise(n_cases_cum = sum(n_cases_cum)) %>% 
      # print_all
      
      # Calculate median and confidence intervals
      group_by(budget, target_type) %>% 
      quantile_summarise(n_cases_cum, conf_level = 0.95) %>% 
      
      # PLOT
      ggplot(aes(x = budget, y = n_cases_cum_median, colour = target_type)) + 
      geom_line() + 
      geom_errorbar(aes(ymin = n_cases_cum_lower, ymax = n_cases_cum_upper), width = 0.001, size = 0.5) + 
      geom_point()
      # labs(x = "Untargeted per capita reduction in SAR(out)",
      #      y = "Total cases (Pop = 1000)")
    
    
    
    

# Target policies 2D ------------------------------------------------------

    # Calculate contact means
    contact_means_example <- rowSums(data_save$k_matrix_5 * 3 / n_pops)
    
    
    
    
    target_contacts <- tibble(
      budget = c(0, 10, 20, 40) * 1000,
    ) %>% 
      rowwise() %>% 
      mutate(target_params = list(target_params(params_original = contact_means_example,
                                                n_pops = n_pops,
                                                budget = budget, 
                                                target_groups = 1:2,
                                                direction = -1))) %>% 
      unnest(target_params) %>% 
      group_by(budget) %>% 
      summarise(untargeted = list(untargeted),
                targeted = list(targeted)) %>% 
      pivot_longer(-budget, names_to = "target_type", values_to = "contact_means")
    

    target_contacts %>% unnest(contact_means) %>% print_all
    
    
      
    
    
    target_k <- function(k_matrix, contact_means_aim, pops, which_groups) {
      
      if (length(contact_means_aim) == 0) return(k_matrix)
      n_groups <- length(contact_means_aim)
      
      rescale_factor_target <- nloptr::nloptr(x0 = rep(1, n_groups), 
                                              eval_f = find_the_rescale_factor_vec, 
                                              lb = rep(0, n_groups) + 1e-5,
                                              opts = list(
                                                "algorithm" = "NLOPT_LN_SBPLX",
                                                "xtol_abs"=1.0e-10,
                                                "maxeval" = 1000,
                                                "print_level" = 0
                                              ),
                                              contact_means_aim = contact_means_aim,
                                              k_matrix = k_matrix, 
                                              pops = pops,
                                              which_groups = which_groups)  
      
      rescale_factors <- rescale_factor_target$solution
      # print(rescale_factors)
      
      rescale_factors_all <- rep(1, nrow(k_matrix))
      rescale_factors_all[which_groups] <- rescale_factors
      
      k_rescaled <- rescale_k(k_matrix, rescale_factors_all)
      
      return(k_rescaled)
    }
    
    target_k(k_matrix = data_save$k_matrix_5,
             contact_means_aim = c(20, 10, 8, 7, 7),
             pops = n_pops,
             which_groups = 1:5)
    

    
    # Generate the K matrix
    target_k_list <- target_contacts %>% 
      # ONLY WANT VALUES TO OPTIMISE, remove contact_mean values that should be unchanged
      mutate(which_groups = case_when(target_type == "targeted" ~ list(1:2),
                                      target_type == "untargeted" ~ list(1:5))) %>% 
      mutate(contact_means_original = list(contact_means_example)) %>% 
      rowwise() %>% 
      mutate(contact_means = list(contact_means[abs(contact_means -contact_means_original) > 0.01])) %>%  # only want to optimise over contact menas that change
      select(-contact_means_original) %>% 
      mutate(k_matrix = list(target_k(k_matrix = (data_save$k_matrix_5 * 3),
                                      contact_means_aim = contact_means,
                                      pops = n_pops,
                                      which_groups = which_groups)))

    
    
    # NEED TO MAKE SURE THAT rescale factor is one when it's unchanged
    
    # CREATE 2D by crossing
    target_crossed <- full_join_track(
      target_params_list %>% rename(budget_sar_out = budget),
      target_k_list %>% rename(budget_contacts = budget)
    ) %>% 
      rowwise() %>% 
      mutate(contact_means_check = list(rowSums(k_matrix / n_pops))) %>% 
      ungroup
    
    target_crossed %>% unnest(c(sar_out, contact_means_check)) %>% 
      print(n = 100)
    
    target_crossed_results <- target_crossed %>% 
      mutate(model_output = pmap(select(., sar_out, k_matrix), group_diff_default, n_sims = 2, n_iterations = 10000))
    
    target_crossed_slim <- target_crossed_results %>% 
      mutate(model_output = map(model_output, "time_series")) %>% 
      unnest(model_output)
    
    save(target_crossed_slim, file = "target_crossed_slim.RData")
    
    # NEXT - plot the graph
    library("plotly")

    
    
    median_infected <- function(outbreak_sim_list) {
      outbreak_sim_list$time_series %>% 
        # Calculate total infected in each run
        group_by(sim_id, i_group) %>% 
        summarise(n_cases_cum = max(n_cases_cum)) %>%
        # Sum up each i_group
        summarise(n_cases_cum = sum(n_cases_cum)) %>% 
        # Calculate median and confidence intervals
        quantile_summarise(n_cases_cum, conf_level = 0.95) %>% 
        .$n_cases_cum_median
    }
    
    target_crossed_summ <- target_crossed_results %>% 
      rowwise() %>% 
      mutate(contact_means_check = paste0(round(contact_means_check), collapse = "-"),
             sar_out = paste0(round(sar_out, 2), collapse = "-")) %>% 
      select(-contact_means, -which_groups, -k_matrix) %>% 
      mutate(
        infected = median_infected(model_output)
      ) %>% 
      select(-model_output) %>% 
      print_all
      
 
    
    
    # 
    # target_crossed_summ <- target_crossed_slim %>% 
    #   group_by(budget_contacts, budget_sar_out, target_type, sim_id, t) %>% 
    #   # mutate(n_pop_total = sum(n_pop)) %>% 
    #   # mutate(budget = budget / n_pop_total) %>% 
    #   ungroup %>% 
    #   
    #   # Calculate total infected in each run
    #   group_by(budget_contacts, budget_sar_out, target_type, sim_id, i_group) %>% 
    #   summarise(n_cases_cum = max(n_cases_cum)) %>% 
    #   
    #   # Sum up each i_group
    #   summarise(n_cases_cum = sum(n_cases_cum)) %>% 
    #   # print_all
    #   
    #   # Calculate median and confidence intervals
    #   group_by(budget_contacts, budget_sar_out, target_type) %>% 
    #   quantile_summarise(n_cases_cum, conf_level = 0.95) %>% 
    #   arrange(budget_contacts, budget_sar_out)
    
    z_target <- target_crossed_summ %>% filter(target_type == "targeted") %>% 
      .$infected %>% 
      matrix(byrow = TRUE, nrow = length(unique(target_crossed_summ$budget_contacts)))
    z_untarget <- target_crossed_summ %>% filter(target_type == "untargeted") %>% 
      .$infected %>% 
      matrix(byrow = TRUE, nrow = length(unique(target_crossed_summ$budget_contacts)))
    
    surface_plot <- plot_ly(
      x = unique(target_crossed_summ$budget_contacts),
      y = unique(target_crossed_summ$budget_sar_out)
    ) %>%
      add_surface(z = ~ z_target,
                  colorscale = list(c(0, 1), c("rgb(300,184,214)", "rgb(300,90,124)")),
                  contours = list(
                    x = list(show = TRUE, highlight = TRUE), y= list(show = TRUE,  highlight = TRUE)
                  )) %>%
      add_surface(z = ~ z_untarget,
                  contours = list(
                    x = list(show = TRUE,  highlight = TRUE), y= list(show = TRUE,  highlight = TRUE)
                  ))
    
    
    surface_plot
    
    # PLOT (2) reduction in cases from targeting
    target_crossed_diff <- target_crossed_summ %>% 
      group_by(budget_sar_out, budget_contacts) %>% 
      summarise(infected_diff = infected[target_type == "untargeted"] - infected[target_type == "targeted"])
    
    z_diff <- target_crossed_diff$infected_diff %>% 
      matrix(byrow = TRUE, nrow = length(unique(target_crossed_diff$budget_contacts)))
    
    surface_plot_diff <- plot_ly(
      x = unique(target_crossed_diff$budget_contacts),
      y = unique(target_crossed_diff$budget_sar_out)
    ) %>%
      add_surface(z = ~ z_diff,
                  # colorscale = list(c(0, 1), c("rgb(300,184,214)", "rgb(300,90,124)")),
                  contours = list(
                    x = list(show = TRUE, highlight = TRUE), y= list(show = TRUE,  highlight = TRUE)
                  ))
    
    # CONCLUSION - very little additional benefit to doing targeting if you only do x (reduce contacts)
    # but if you do SAR out interventions that's more useful, and if you do it's especially helpful to target
    
    
    surface_plot_diff
  
    

# Rapid testing counterfactual --------------------------------------------

    # Fixed number of people who have their testing delays set to 0?
    # Testing choice delay ≈ 1/2 days
    # Testing results delay = 0.05 days
    
    # Caveats - this won't properly account for false positives in the "budget"
    
    
  
    target_rapid_testing <- tibble(
      budget = c(0, 0.15, 0.3, 0.45) * 10000
    ) %>% 
      rowwise() %>% 
      mutate(target_params = list(target_params(params_original = c(0, 0, 0, 0, 0), # no-one has rapid testing initially
                                                n_pops = n_pops,
                                                budget = budget, 
                                                target_groups = 1:2,
                                                direction = 1))) %>% 
      unnest(target_params) %>% 
      group_by(budget) %>% 
      summarise(untargeted = list(untargeted),
                targeted = list(targeted)) %>% 
      pivot_longer(-budget, names_to = "target_type", values_to = "prop_rapid_testing") %>% 
      print
    
    
    target_rapid_testing %>% unnest(prop_rapid_testing) %>% print_all
    
    
    # prop_rapid_testing <- rep(0.2, 5)
    # test_delay_data <- data_save$test_delay_data
    # rapid_choice_val <- 0.1
    # rapid_results_val <- 0.2
    
    # Convert prop_rapid_testing into the testing_delays data
    gen_rapid_testing_data <- function(prop_rapid_testing, test_delay_data, rapid_choice_val, rapid_results_val) {
      n_groups <- length(prop_rapid_testing)
      
      # link the i_groups to their prob of being rapid tested
      rapid_testing_tibble <- tibble(
        i_group = 1:n_groups,
        prop_rapid_testing = prop_rapid_testing
      )
      
      rapid_delay_data <- test_delay_data %>%
        left_join(rapid_testing_tibble, by = "i_group") %>%
        mutate(
          rapid_test_yn = bern_vec(nrow(.), p = prop_rapid_testing),
          test_choice_delay = if_else(rapid_test_yn, rapid_choice_val, test_choice_delay),
          test_results_delay = if_else(rapid_test_yn, rapid_results_val, test_results_delay),
        )
      
      return(rapid_delay_data)
      
    }

  
    target_rapid_testing_data <- target_rapid_testing %>% 
      rowwise() %>% 
      mutate(
        test_delay_data = list(gen_rapid_testing_data(prop_rapid_testing = prop_rapid_testing,
                                                      test_delay_data = data_save$test_delay_data,
                                                      rapid_choice_val = 2,
                                                      rapid_results = 0.05))
      ) %>% 
      ungroup
    
    
    
    
    # RUN THE MODELS
    rapid_testing_results <- target_rapid_testing_data %>% 
      mutate(model_output = pmap(select(., -c(budget, target_type, prop_rapid_testing)), group_diff_default, n_sims = 2, n_iterations = 10000))

    rapid_testing_results_2 <- target_rapid_testing_data %>% 
      mutate(model_output = pmap(select(., -c(budget, target_type, prop_rapid_testing)), group_diff_default, n_sims = 5, n_iterations = 10000))
    
    
    # rapid_testing_slim <- rapid_testing_results %>% 
    #   mutate(model_output = map(model_output, "time_series")) %>% 
    #   unnest(model_output)
    
    rapid_testing_slim <- bind_rows(
      rapid_testing_results %>% 
        mutate(model_output = map(model_output, "time_series")) %>% 
        unnest(model_output) %>% 
        mutate(sim_id = as.character(as.numeric(sim_id) + 5)),
      rapid_testing_results_2 %>% 
        mutate(model_output = map(model_output, "time_series")) %>% 
        unnest(model_output)
    )
    
    
    
    # PLOT
    rapid_testing_slim %>% 
      
      # SHADY
      group_by(budget, target_type, sim_id, t) %>% 
      mutate(n_pop_total = sum(n_pop)) %>% 
      mutate(budget = budget / n_pop_total) %>% 
      ungroup %>% 
      
      # Calculate total infected in each run
      group_by(budget, target_type, sim_id, i_group) %>% 
      summarise(n_cases_cum = max(n_cases_cum)) %>% 
      
      # Sum up each i_group
      summarise(n_cases_cum = sum(n_cases_cum)) %>% 
      # print_all
      
      # Calculate median and confidence intervals
      group_by(budget, target_type) %>% 
      quantile_summarise(n_cases_cum, conf_level = 0.95) %>% 
      
      # PLOT
      ggplot(aes(x = budget, y = n_cases_cum_median, colour = target_type)) + 
      geom_line() + 
      geom_errorbar(aes(ymin = n_cases_cum_lower, ymax = n_cases_cum_upper), width = 0.02, size = 0.5) + 
      geom_point()
    
    

# Random testing counterfactual -------------------------------------------

    
    target_alpha <- tibble(
      budget = c(0, 0.1, 0.2, 0.3) * 10000
    ) %>% 
      rowwise() %>% 
      mutate(target_params = list(target_params(params_original = c(0, 0, 0, 0, 0),
                                                n_pops = n_pops,
                                                budget = budget, 
                                                target_groups = 1:2,
                                                direction = 1))) %>% 
      unnest(target_params) %>% 
      group_by(budget) %>% 
      summarise(untargeted = list(untargeted),
                targeted = list(targeted)) %>% 
      pivot_longer(-budget, names_to = "target_type", values_to = "alpha") %>% 
      print
    
    
    target_alpha %>% unnest(alpha) %>% print_all
    
    
    # RUN THE MODELS
    target_alpha_results <- target_alpha %>% 
      mutate(model_output = pmap(select(., alpha), group_diff_default, n_sims = 2, n_iterations = 10000))
    
  
    
    # PLOT
    target_alpha_results %>% 
      mutate(model_output = map(model_output, "time_series")) %>%
      unnest(model_output) %>% 
      
      group_by(budget, target_type, sim_id, t) %>% 
      mutate(n_pop_total = sum(n_pop)) %>% 
      mutate(budget = budget / n_pop_total) %>% 
      ungroup %>% 
      
      # Calculate total infected in each run
      group_by(budget, target_type, sim_id, i_group) %>% 
      summarise(n_cases_cum = max(n_cases_cum)) %>% 
      
      # Sum up each i_group
      summarise(n_cases_cum = sum(n_cases_cum)) %>% 
      # print_all
      
      # Calculate median and confidence intervals
      group_by(budget, target_type) %>% 
      quantile_summarise(n_cases_cum, conf_level = 0.95) %>% 
      
      # PLOT
      ggplot(aes(x = budget, y = n_cases_cum_median, colour = target_type)) + 
      geom_line() + 
      geom_errorbar(aes(ymin = n_cases_cum_lower, ymax = n_cases_cum_upper), width = 0.02, size = 0.5) + 
      geom_point()
    
    
    

# ........................ ------------------------------------------------


# Sample selection --------------------------------------------------------


    dat_covida <- read_dta("Datos_Salesforce_treated.dta")
    
    dat_covida %>% 
      count_prop(contact, symptom) %>% 
      count_prop(isolates) %>% 
      count_prop(stratum) %>% 
      count_prop(tested)
      
      # SEPARATE BY TESTED
    dat_covida_symptoms <- dat_covida %>% filter(symptom == 1) %>% 
      group_by(stratum, tested, symptom) %>% 
      summarise(mean_se(isolates))
    
    dat_covida_contact <- dat_covida %>% 
      filter(contact == 1) %>% 
      group_by(stratum, tested, contact) %>% 
      summarise(mean_se(isolates))
      # mutate(contact_or_symptoms = contact | symptom) %>% 
      
    dat_covida_neither <- dat_covida %>% 
      filter(symptom == 0 & contact == 0) %>% 
      group_by(stratum, tested, symptom, contact) %>% 
      summarise(mean_se(isolates))
    
    dat_by_tested <- bind_rows(dat_covida_symptoms, dat_covida_contact, dat_covida_neither) %>% 
      mutate(
        case_category = case_when(
          symptom == 1 & is.na(contact) ~ "Symptoms",
          is.na(symptom) & contact == 1 ~ "Contacted case",
          symptom == 0 & contact == 0 ~ "No symptoms, no contact"
        )
      )
    
    
    dat_by_tested %>% 
      filter(stratum %in% 1:6) %>% 
      ggplot(aes(x = factor(stratum), y = y, colour = factor(tested))) + 
      geom_point(position = position_dodge(width = 0.2)) + 
      theme(legend.position = "top") + 
      geom_errorbar(aes(ymin = ymin, ymax = ymax), 
                    width = 0.2,
                    position = position_dodge(width = 0.2)) + 
      facet_grid(case_category ~ ., scales = "free_y")
    
    
    # ALL TOGETHER
    dat_covida_symptoms <- dat_covida %>% filter(symptom == 1) %>% 
      group_by(stratum, symptom) %>% 
      summarise(mean_se(isolates))
    
    dat_covida_contact <- dat_covida %>% 
      filter(contact == 1) %>% 
      group_by(stratum, contact) %>% 
      summarise(mean_se(isolates))
    # mutate(contact_or_symptoms = contact | symptom) %>% 
    
    dat_covida_neither <- dat_covida %>% 
      filter(symptom == 0 & contact == 0) %>% 
      group_by(stratum, symptom, contact) %>% 
      summarise(mean_se(isolates))
    
    
    dat_covida %>% 
      mutate(symptom_or_contact = symptom | contact) %>% 
      group_by(tested, symptom_or_contact, stratum) %>% 
      summarise(mean_se(isolates)) %>% 
      filter(stratum %in% 1:6) %>% 
    
      ggplot(aes(x = factor(stratum), y = y, colour = factor(tested))) + 
      geom_point(position = position_dodge(width = 0.2)) + 
      # geom_line(aes(y = y), alpha = 0.4) +
      theme(legend.position = "top") + 
      scale_colour_discrete(labels = c("Survey no test", "Test")) + 
      geom_errorbar(aes(ymin = ymin, ymax = ymax), width = 0.2, position = position_dodge(width = 0.2)) + 
      geom_line(aes(x = stratum, y = y, colour = factor(tested)), alpha = 0.5) + 
      facet_wrap(~ symptom_or_contact, nrow = 2,
                 labeller = as_labeller(
                   c("TRUE" = "Symptoms or contact", "FALSE" = "No symptoms, no contact")
                 )) + 
      labs(x = "SES Group", y = "P(Stayed at home over last 14 days)", colour = element_blank()) + 
      theme_custom()
    
    ggsave("sample_selection_isolates.png", width = 7, height = 5.5, scale = 0.7)
    
      
      
    dat_covida$isolates
    
    