
# Set up ------------------------------------------------------------------

    library(tidyverse)
    library(zoo)
    library(devtools)
    library(mc2d)
    # source("~/Desktop/functions.R")

    devtools::install_github("dmbwebb/dups")
    detach("package:dups", unload=TRUE)
    library(dups)
    
    devtools::install_github("dmbwebb/trackr")
    detach("package:trackr", unload=TRUE)
    library(trackr)
  
    theme_custom <- function(...) {
      theme_light() + 
        theme(plot.background = element_blank(),
              strip.background=element_rect(fill="#D1E0E6"), 
              strip.text = element_text(color = "black"),
              ...)
    }
    
    hist_basic <- function(dat, x, binwidth = NULL, boundary = 0) {
      ggplot(dat, aes(x = {{x}})) + 
        geom_histogram(boundary = boundary, binwidth = binwidth, colour = "grey", fill = "lightblue")
    }

    # Converts all NAs to false
    true_false <- function(x) {
      if (!is_logical(x)) stop("Not a logical vector")
      if_else(is.na(x), FALSE, x)
    }
    
    # Tests equality of two vectors, but deals with NAs as if they were values
    harsh_equal <- function(x, y) {
      st_equal <- x == y
      both_nas <- is.na(x) & is.na(y)
      dplyr::if_else(is.na(st_equal), both_nas, st_equal)
    }
    
    bern_vec <- function(n, p) {
      out <- as.logical(mc2d::rbern(n, p = p))
      if (sum(is.na(out)) > 0) {
        print(n)
        print(p)
        stop("Bernoulli calc is causing NAs")
      }
      out
    }



# (2) MULTIGROUP MODEL ---------------------------------------------


    
    
    

# Distributions for individual cases --------------------------------------


    # Symptom severity drawn from distribution and converted to categorical between 1 and 5
    symptom_severity <- function(i_group) {
      
      n <- length(i_group)
      
      # TO DO - enable different thresholds by i_group
      thresholds <- c(0, 0.2, 0.4, 0.6, 0.8, 1)
      labels <- as.character(1:5)
      cut(runif(n = n), breaks = thresholds, labels = labels)
    }
    
    tibble(
      symptom_severity = symptom_severity(sample(c(1,2,3), 100, replace = TRUE))
    ) %>% 
      ggplot(aes(x = symptom_severity)) + geom_bar()
    
    # Symptom timing [incubation period]- from Hellewell
    symptom_timing <- function(i_group) {
      
      # Assumes same for both groups [?]
      n <- length(i_group)
      
      rweibull(n = n, shape = 2.322737, scale = 6.492272)  # values from outbreak_model.R in Hellewell et al
    }
    

    symptom_severity_to_yn <- function(symptom_severity, i_group, probs_df) {
      
      # FOR DEBUGGING:
      # symptom_severity <- symptom_severity(n = 100)
      # i_group <- as.integer(cut(runif(n = 100), breaks = c(0, 0.1, 0.4, 1), labels = 1:3))
      # probs_default <- c(0, 0.04, 0.2, 0.3, 0.4)
      # probs_df <- tibble(
      #   i_group = c(rep(1, 5), rep(2, 5), rep(3, 5)),
      #   symptom_severity = as.factor(rep(1:5, 3)),
      #   prob = c(probs_default * 0.1, probs_default * 1, probs_default * 2.5)
      # )
      
      n_cats <- nlevels(symptom_severity)
      n_cats_df <- nlevels(probs_df$symptom_severity)
      # print(n_cats); print(n_cats_df)
      if (!is.factor(probs_df$symptom_severity)) stop("symptom_severity in probs_df is not a factor")
      if (n_cats_df != n_cats) stop("probs_df doesn't have same number of levels as symptom_severity")
      
      require(mc2d)
      
      tibble(
        symptom_severity = symptom_severity,
        i_group = i_group
      ) %>% 
        left_join(probs_df, by = c("symptom_severity", "i_group")) %>% 
        mutate(yn = as.logical(mc2d::rbern(nrow(.), p = prob))) %>%       # bernoulli with vectorised p
        .$yn
      
    }
    
    

    
    # Testing decision based on threshold for symptoms
    # Need to think about how to model the people who get a negative test [these are ignored for the moment]
    
    
    # self_test_yn <- function(symptom_severity, probs_self_test = c(0, 0.04, 0.1, 0.15, 0.4)) {
    #   symptom_severity_to_yn(symptom_severity, probs = probs_self_test)
    # }
    # 
    # isolate_after_symptoms <- function(symptom_severity, probs_isolate_symptoms = c(0, 0.05, 0.2, 0.4, 0.7)) {
    #   symptom_severity_to_yn(symptom_severity, probs = probs_isolate_symptoms)
    # }
    
    
    
    # isolate_after_test <- function()
    # 
    # isolate_after_symptoms(symptom_severity(100))
    # 
    
    
    
    
    
    
    # Delay in how long before they receive testing and get isolated after symptoms - assume 3 days for the moment
    test_result_delay <- function(i_group, test_result_delay_val = 1.5) { 
      n <- length(i_group)
      # TO DO - allow this to vary by group
      rep(test_result_delay_val, n)
    }
    

    
    # Recovery timing [not sure - need to find a source]
    recovery_timing <- function(symptom_timings, recov_val) {
      
      # Assume same by group (?)
      symptom_timings + recov_val     # assume you recover [no longer infectious] 7 days after being infected
    }
  
    
    
    # Function for combining the beta matrix and group proportions into one tibble 
    # Used in calculate_r0s and secondary_case_group
    combine_beta_group_props <- function(beta_matrix, group_props) {
      
      n_groups <- length(group_props)
      if (nrow(beta_matrix) != n_groups^2) stop ("Mismatch between number of groups in beta matrix and group_props")
      
      group_props_df <- tibble(
        to = unique(beta_matrix$to),
        group_pop_to = group_props
      )
      
      # Calculate the conditional probabilities of group A infecting group B
      combined <- beta_matrix %>% 
        left_join(group_props_df, by = "to") %>% 
        mutate(beta_by_n = beta_val * group_pop_to) %>% 
        group_by(from)
      
      combined
    }
    
    
    # CALCULATE R0 for each person based on their group, 
    # the beta matrix and the proportion of each group [fixes ratio]
    # and r0_group_1 [fixes scale / value]
    calculate_r0s <- function(beta_matrix, group_props, r0_group_1) {
      # Calculate R0 ratios
      r0_ratios <- combine_beta_group_props(beta_matrix = beta_matrix, group_props = group_props) %>% 
        summarise(total_beta_by_n = sum(beta_by_n), .groups = "drop") %>% 
        mutate(r0_ratio = total_beta_by_n / total_beta_by_n[from == 1])
      
      r0_vals_to_match <- r0_ratios %>% 
        mutate(r0 = r0_ratio * r0_group_1) %>% 
        select(from, r0)
      
      r0_vals_to_match$r0
    }
    
  
    # calculate_r0s <- function(i_group, beta_matrix, group_props, r0_group_1) {
    #   
    # 
    #   
    #   tibble(
    #     i_group = i_group
    #   ) %>% 
    #     left_join(r0_vals_to_match, by = c("i_group" = "from")) %>% 
    #     .$r0
    #   
    # }
    
    # TEST
    calculate_r0s(
      # i_group = as.integer(cut(runif(n = 1000), breaks = c(0, 0.33333333, 0.6666666, 1), labels = 1:3)),
      beta_matrix = crossing(
        to = 1:3, from = 1:3
      ) %>%
        mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4)),
      group_props = c(0.25, 0.5, 0.25), 
      r0_group_1 = 2.5
    )
  
    
    # Number of (potential) secondary cases
    secondary_cases_n <- function(i_group, r0, dispersion = 0.16) {
      
      # DEBUGGING: 
      # i_group <- as.integer(cut(runif(n = 100), breaks = c(0, 0.1, 0.4, 1), labels = 1:3))
      # r0_df <- tibble(i_group = 1:3, r0 = c(0.5, 1.8, 2.9))
      n <- length(i_group)
      rnbinom(n = n, size = dispersion, mu = r0)
      
    }
    
    # Test the function
    tibble(
      i_group = as.integer(cut(runif(n = 10000), breaks = c(0, 0.33333333, 0.6666666, 1), labels = 1:3))
    ) %>% 
      left_join(tibble(i_group = 1:3, r0 = c(0.5, 1.4, 3)), by = "i_group") %>% 
      mutate(secondary_cases = secondary_cases_n(i_group = i_group, r0 = r0, dispersion = 0.16)) %>% 
      count(i_group, secondary_cases) %>% 
      group_by(i_group) %>% 
      mutate(n_cum = cumsum(n) / max(cumsum(n))) %>% 
      ggplot(aes(x = secondary_cases, y = n_cum, colour = factor(i_group))) + geom_line()
      # tick - CDF is strictly shifted to the right when r0 is higher
    
    

    

    
   # Vectorised function that generates secondary i groups from different probabilities
   # which speeds up calculations a lot
   cut_p_breaks <- function(data, n_groups) {
     # rand <- runif(n = 100)
     # i_group_debug <- sample(1:3, size = 100, replace = TRUE)
     # p_breaks <- i_group_debug %>% map(~ case_when(. == 1 ~ c(0, 0.2, 0.5, 1),
     #                                   . == 2 ~ c(0, 0.1, 0.2, 1),
     #                                   . == 3 ~ c(0, 0.7, 0.9, 1)))
     
     
     # df <- tibble(
     #   rand = rand,
     #   p_breaks = p_breaks
     # )
     
     n_breaks <- n_groups + 1
     
     df_breaks <- data %>% 
       mutate(
         p_breaks = str_replace_all(paste0(p_breaks), "c|\\(|\\)", "")
       ) %>% 
       separate(p_breaks, into = paste0("break_", 1:n_breaks), sep = ",? ") %>% 
       mutate(
         across(starts_with("break_"), list(yn = ~ rand < .))
       )
     
     cat <- rep(NA_integer_, nrow(df_breaks))
     for (i in n_breaks:1L) {
       cat <- if_else(df_breaks[[str_glue("break_{i}_yn")]],
                      i - 1L,
                      cat)
     }
     
     data %>% mutate(secondary_i_group = cat)
     
     # ?separate
     # # Convert p_breaks to columns
     # p_breaks %>% paste0() %>% 
     #   str_replace_all("c|\\(|\\)", "") %>% 
       
   }
    
    
    # Draw the GROUP of the secondary infection
    # TO DO :
    secondary_case_group <- function(i_group, beta_matrix, group_props) {
      
      # print("i_group")
      # print(i_group)
      # print(beta_matrix)
      # print(group_props)
      
      
      # FOR DEBUGGING
      # i_group = as.integer(cut(runif(n = 100000), breaks = c(0, 0.33333333, 0.6666666, 1), labels = 1:3))
      # beta_matrix <- crossing(
      #   to = 1:3, from = 1:3
      # ) %>%
      #   mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4))
      # group_props <- c(0.25, 0.5, 0.25)
      
      n_groups <- length(group_props)
      
      p_conditional <- combine_beta_group_props(beta_matrix, group_props) %>% 
        group_by(from) %>% 
        mutate(p_conditional = beta_by_n / sum(beta_by_n)) %>% 
        arrange(from)
  
      # Calculate the breaks based on probabilities
      p_breaks <- p_conditional %>% 
        select(from, p_conditional) %>% 
        group_by(from) %>% 
        mutate(p_breaks = cumsum(p_conditional)) %>% 
        select(-p_conditional) %>% 
        nest() %>% 
        mutate(p_breaks = map(data, ~ .$p_breaks),
               p_breaks = map(p_breaks, ~ c(0, .))) %>% 
        select(-data)

      # Merge to the i_group data
      # tic()
      secondary_i_group <- tibble(
        i_group = i_group
      ) %>% 
        left_join(p_breaks, by = c("i_group" = "from")) %>% 
        mutate(rand = runif(n = nrow(.))) %>% 
        cut_p_breaks(n_groups = n_groups)
        # rowwise() %>% 
        # mutate(
        #   secondary_i_group = as.integer(cut(rand, breaks = p_breaks, labels = 1:n_groups))
        # )
      # toc()
      # OLD TIME - ~7sec
      # NEW TIME - 1.4sec
      
      return(secondary_i_group$secondary_i_group)
        
      
      # ALTERNATIVE CODING: 
      # MATRIX OPERATION - is it quicker?
      # beta_matrix <- matrix(
      #   c(10, 5, 2, 5, 7, 1, 2, 1, 4), nrow = 3
      # )
      
      
      # Multiply beta matrix by group populations (each row should be multiplied by the corresponding value in group_props)
      # p_matrix <- beta_matrix
      # 
      # for (i in 1:nrow(p_matrix)) {
      #   p_matrix[i , ] <- p_matrix[i , ] * group_props[[i]]
      # }
      # 
      # # Normalise each column to sum to 1
      # for (i in 1:ncol(p_matrix)) {
      #   p_matrix[ , i] <- p_matrix[ , i] / sum(p_matrix[ , i])
      # }
      # p_matrix
      
    }
    
    
    # TEST THE FUNCTION
    secondary_case_group_debug <- tibble(
      i_group = sample(1:3, 1000, replace = TRUE)
    ) %>% 
      mutate(
        secondary_case_group = secondary_case_group(
          i_group = i_group, 
          beta_matrix = crossing(
            to = 1:3, from = 1:3
          ) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4)),
          group_props = c(0.25, 0.5, 0.25)
        )
      ) %>% 
      group_by(i_group) %>% 
      count_prop(secondary_case_group)
    
    
    # Draw timing of secondary cases - skew normal distribution
    secondary_case_timing <- function(symptom_times = NULL) {
      
      # Assume same for both groups
      
      out <- sn::rsn(n = length(symptom_times),
                     xi = symptom_times,
                     omega = 2,
                     alpha = 5)   # this is called k in Hellewell, controls how many transmissions occur before symptom onset, 
                                   # higher alpha implies fewer cases are presymptomatic
                                   # they use k = 1.95 as central value
      
      out <- ifelse(out < 1, 1, out)
      
      return(out)
    }
    
    # ?sn::rsn

    tibble(
      symptom_times = symptom_timing(1:1000),
      secondary_case_times = secondary_case_timing(symptom_times)
    ) %>% 
      mutate(presymptomatic = secondary_case_times < symptom_times) %>% 
      count_prop(presymptomatic) %>% 
      filter(secondary_case_times / symptom_times < 4) %>% 
      hist_basic(secondary_case_times / symptom_times, binwidth = 0.2)
    
    
    set.seed(111000)
    
    contact_tracing_delay <- function(i_group) {
      # TIME FROM STARTING CONTACT TRACING TO TEST ADMINISTERED FOR THE CONTACTS
      
      # TODO: need to decide what distribution this should be - should it be drawn from the empirical CDF for each group?
      
      # WHAT DISTRIBUTION SHOULD THIS BE??
      n <- length(i_group)
      rweibull(n = n, shape = 10, scale = 1.5)
    }
    
    
    histogram(contact_tracing_delay(sample(1:3, 1000, replace = TRUE)))
    
    rm(i_group_debug)
    
    
    
    

# Functions for drawing multiple distributions at different stages ----------------------------

    # Function to update all timing variables by reducing t
    update_timing <- function(df, dt) {
      
      if (is.null(df)) return(NULL) 
      else {
        df %>% 
          mutate(across(ends_with("_timing"), ~ .x - dt))
      }
      
    }
    
    
    # Initial draw of symptoms, recovery time, isolation behaviour
    draw_symptoms_recovery <- function(ids,
                                       i_group,
                                       contact_tracing_test_timing = NULL,    
                                       contact_tracing_results_timing = NULL,
                                       # random_test_yn = NULL,
                                       # random_test_timing = NULL,
                                       # random_test_false_negative = NULL,
                                       # random_test_yn_ever = NULL,
                                       # isolate_random_test_timing = NULL,
                                       test_sensitivity,
                                       infection_timings,              # inputs from the other draws
                                       test_result_delay_val, recov_val,
                                       probs_self_test_df, probs_isolate_symptoms_df, probs_isolate_test_df, probs_isolate_ct_df) {
      
      # Needs to be run once for new cases only
      
      # DEBUGGING:
      # ids <- 1:1000
      # i_group <- as.integer(cut(runif(n = 1000), breaks = c(0, 0.33333333, 0.6666666, 1), labels = 1:3))
      # infection_timings <- 0             
      # contact_tracing_test_timing = NULL
      # contact_tracing_results_timing = NULL
      # random_test_yn = NULL
      # random_test_timing = NULL
      # isolate_random_test_timing = NULL
      # test_result_delay_val <- 1.5; recov_val <- 5
      # probs_default <- c(0.3, 0.6, 0.8, 0.9, 1)
      # probs_df_basic <- tibble(
      #   i_group = c(rep(1, 5), rep(2, 5), rep(3, 5)),
      #   symptom_severity = as.factor(rep(1:5, 3))
      # )
      # probs_self_test_df <- probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1))
      # probs_isolate_symptoms_df <- probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5))
      # probs_isolate_test_df <- probs_df_basic %>% mutate(prob = c(probs_default * 0.6, probs_default * 0.8, probs_default * 1))
      
      # PARAMETERS HERE
      
      n <- length(ids)
      if (length(i_group) != length(ids)) stop ("length(i_group) != length(ids)")
      if (length(unique(ids)) != n) warning("Duplicate IDs when calculating symptoms")
      # if (is.null(probs_self_test) | is.null(probs_isolate_symptoms) | is.null(probs_isolate_test)) stop("No value for one of the probs_*")
      # if (is.null(test_result_delay_val)) stop("No value for test_result_delay_val")
      # if (is.null(recov_val)) stop("No value for recov_val")
      # if (is.null(infection_timings)) stop("No value for infection_timing")
      

      if (is.null(contact_tracing_test_timing)) contact_tracing_test_timing <- NA_real_
      if (is.null(contact_tracing_results_timing)) contact_tracing_results_timing <- NA_real_
      # if (is.null(random_test_yn)) random_test_yn <- NA
      # if (is.null(random_test_timing)) random_test_timing <- NA_real_
      # if (is.null(random_test_false_negative)) random_test_false_negative <- NA
      # if (is.null(random_test_yn_ever)) random_test_yn_ever <- FALSE
      # if (is.null(isolate_random_test_timing)) isolate_random_test_timing <- NA_real_
      
      tibble(
        case_id = as.character(ids),
        i_group = i_group,
        infection_timing = infection_timings,
        contact_tracing_test_timing = contact_tracing_test_timing,
        contact_tracing_results_timing = contact_tracing_results_timing,
        random_test_yn = NA,
        random_test_yn_ever = FALSE,
        random_test_timing = NA_real_,
        random_test_false_negative = NA,
        isolate_random_test_timing = NA_real_,
      ) %>% 
        mutate(
          
          # Contact tracing doesn't work [test negative] if they test people before they're infectious
          # or if the test is a false negative
          # contact_tracing_test_timing = if_else(contact_tracing_test_timing < infection_timing, NA_real_, contact_tracing_test_timing), # now only the RESULTS don't do anything if test is before
          # contact_tracing_results_timing = if_else(contact_tracing_test_timing < infection_timing, NA_real_, contact_tracing_results_timing),
          ct_test_negative = contact_tracing_test_timing < infection_timing,
          ct_false_negative = bern_vec(n = nrow(.), p = 1 - test_sensitivity),
          self_test_false_negative = bern_vec(n = nrow(.), p = 1 - test_sensitivity),
          # random_test_false_negative = if_else(random_test_yn & is.na(random_test_false_negative), ) # only draw if it's not already been calculated
          
          # Symptoms and recovery
          symptom_severity = symptom_severity(i_group),
          symptom_timing = infection_timing + symptom_timing(i_group),
          recovery_timing = infection_timing + recovery_timing(symptom_timing, recov_val = recov_val),
          
          # Self testing
          self_test_yn = symptom_severity_to_yn(symptom_severity = symptom_severity, i_group = i_group, probs_df = probs_self_test_df),
          test_result_delay = test_result_delay(i_group, test_result_delay_val = test_result_delay_val),
          test_result_timing = if_else(self_test_yn, symptom_timing + test_result_delay, NA_real_),

          # Isolation behaviour
          isolate_after_symptoms = symptom_severity_to_yn(symptom_severity, i_group, probs_df = probs_isolate_symptoms_df),
          isolate_after_ct = symptom_severity_to_yn(symptom_severity, i_group, probs_df = probs_isolate_ct_df), # isolation if you here that you are contact traced
          isolate_after_test = symptom_severity_to_yn(symptom_severity, i_group, probs_df = probs_isolate_test_df), # used for whether people isolate after contact tracaing test, self test, or random test
          
          # Isolation timings
          isolate_symptoms_timing = if_else(isolate_after_symptoms, symptom_timing, NA_real_),
          isolate_ct_test_timing = if_else(isolate_after_ct, contact_tracing_test_timing, NA_real_), # assume that people isolate when they are tested for contact tracing (although in reality may be before?)
          isolate_ct_results_timing = if_else(isolate_after_test & !ct_test_negative & !ct_false_negative, contact_tracing_results_timing, NA_real_),
          # used to be called isolate_contact_tracing_timing
          isolate_test_timing = if_else(self_test_yn & isolate_after_test & !self_test_false_negative, test_result_timing, NA_real_) #
        
        ) # %>% 
        # ggplot(aes(x = self_test_yn, fill = factor(i_group))) + geom_bar(position = "dodge") # (plot self_test_yn among groups)
        # ggplot(aes(x = isolate_after_test, fill = factor(i_group))) + geom_bar(position = "dodge") # plot isolation decisions
        
    }
    
    # TEST THE FUNCTION
    probs_default <- c(0.3, 0.6, 0.8, 0.9, 1)
    probs_df_basic <- tibble(
      i_group = c(rep(1, 5), rep(2, 5), rep(3, 5)),
      symptom_severity = as.factor(rep(1:5, 3))
    )
    
    draw_symptoms_debug <- draw_symptoms_recovery(ids = 1:1000,
                                                  i_group = as.integer(cut(runif(n = 1000), breaks = c(0, 0.33333333, 0.6666666, 1), labels = 1:3)),
                                                  infection_timings = 0             ,
                                                  test_sensitivity = 0.85,
                                                  contact_tracing_test_timing = NULL,
                                                  contact_tracing_results_timing = NULL,
                                                  # random_test_yn = NULL,
                                                  # random_test_yn_ever = NULL,
                                                  # random_test_timing = NULL,
                                                  # random_test_false_negative = NULL,
                                                  # isolate_random_test_timing = NULL,
                                                  test_result_delay_val = 1.5,
                                                  recov_val = 5,
                                                  probs_self_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1)),
                                                  probs_isolate_ct_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1)),
                                                  probs_isolate_symptoms_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5)),
                                                  probs_isolate_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.5, probs_default * 1)))
    
    draw_symptoms_debug %>% 
      ggplot(aes(x = isolate_after_ct, fill = factor(i_group))) + geom_bar(position = "dodge") # plot isolation decisions
  
    
    draw_random_testing <- function(live_cases, test_sensitivity, alpha, dt_approx) {
      
      # Needs to be run on ALL live cases every period
      
      # DEBUGGING:
      # live_cases <- draw_symptoms_debug; test_sensitivity <- 0.85
      # alpha <- c(0.05, 0.1, 0.2); dt_approx <- 1
      
      if (is.null(dt_approx)) warning("dt_approx is NULL")
      n_cases <- nrow(live_cases)
      
      alpha_df <- tibble(
        i_group = 1:length(alpha),
        alpha = alpha
      )
      rm(alpha)
      
      if (sum(alpha_df$alpha * dt_approx > 1) > 0) stop("alpha * dt_approx > 1 for at least one group")
      
      live_cases_w_random <- live_cases %>% 
        
        # Match to get individual alphas
        select(-any_of("alpha")) %>%  # remove existing alpha column so it can overwrite
        left_join(alpha_df, by = "i_group") %>% 
        
        # Only do random test if you're not currently being tested, and you haven't previously tested positive
        # Because we're only looking at infected people here, if you are ever randomly tested, you will never be tested again (because you were positive by construction)
        mutate(
          currently_testing = case_when(
            self_test_yn & symptom_timing < 0 & test_result_timing > 0    ~       TRUE, # testing period for self test
            contact_tracing_test_timing < 0 & contact_tracing_results_timing > 0 ~   TRUE,       # testing period for contact tracing
            random_test_yn & random_test_timing > 0 ~ TRUE,                              # testing period for random test [no delay because test starts at 0]
            TRUE ~ FALSE
          ),
          previously_tested_positive = case_when(
            self_test_yn & test_result_timing < 0 & !self_test_false_negative ~ TRUE,
            contact_tracing_results_timing < 0 & !ct_test_negative & !ct_false_negative ~ TRUE,
            random_test_timing < 0 & !random_test_false_negative ~ TRUE,
            TRUE ~ FALSE
          )
        ) %>% 
        mutate(
          update_random_testing = (!currently_testing & !previously_tested_positive) | is.na(random_test_yn)
        ) %>% 
        mutate(
          random_test_yn_lag1 = random_test_yn,
          random_test_yn = if_else(random_test_yn & random_test_timing < 0, FALSE, random_test_yn),
          random_test_yn = if_else(update_random_testing,
                                   as.logical(mc2d::rbern(n_cases, p = alpha * dt_approx)),     # alpha * dt_approx ensures that probability is unchanged with dt_approx?? - that's not quite true...
                                   random_test_yn)
        ) %>% 
        mutate(
          new_random_test = random_test_yn > random_test_yn_lag1 | (is.na(random_test_yn_lag1) & random_test_yn),
          random_test_false_negative = if_else(new_random_test, bern_vec(nrow(.), p = test_sensitivity), random_test_false_negative),
          random_test_yn_ever = if_else(random_test_yn == TRUE & random_test_yn_ever == FALSE, TRUE, random_test_yn_ever),
          
          # Tested at t = now, receive results at random_test_timing
          random_test_timing = if_else(random_test_yn & new_random_test,
                                       test_result_delay(i_group),
                                       random_test_timing),
          isolate_random_test_timing = if_else(random_test_yn & new_random_test & isolate_after_test, random_test_timing, isolate_random_test_timing)
        )
      
      live_cases_w_random
      
    }

    
  
    
    # TEST:
    draw_random_testing_debug <- draw_symptoms_debug %>% 
      draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1, test_sensitivity = 0.5) %>% 
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1, test_sensitivity = 0.5) %>% 
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1, test_sensitivity = 0.5) %>% 
      count_nas()
      count_prop(random_test_yn, is.na(random_test_timing))
    
    draw_random_testing_debug %>% 
      ggplot(aes(x = random_test_yn, y = ..prop.., group = factor(i_group), fill = factor(i_group))) + geom_bar(position = "dodge") # plot isolation decisions
    
    
    
    # Function for removing cases that (i) occur after recovery, or (ii) have 0 potential cases
    filter_non_cases <- function(secondary_cases) {
      filtered <- secondary_cases %>% 
        filter(!is.na(secondary_case_id)) %>% 
        mutate(recovery_before_secondary = recovery_timing < secondary_case_timing) %>% 
        group_by(case_id) %>% 
        mutate(n_recovery_before_secondary = sum(recovery_before_secondary, na.rm = TRUE)) %>% 
        ungroup %>% 
        mutate(potential_secondary_cases = potential_secondary_cases - n_recovery_before_secondary) %>% 
        filter(!recovery_before_secondary | is.na(secondary_case_timing)) %>% 
        select(-recovery_before_secondary, -n_recovery_before_secondary)
      
      if (nrow(filtered) == 0) return(NULL)
      else return(filtered)
    }
    
    # new_secondary %>% 
    #   select(case_id, secondary_case_id, potential_secondary_cases, recovery_timing, secondary_case_timing) %>% 
    #   mutate(recovery_before_secondary = recovery_timing < secondary_case_timing) %>% 
    #   group_by(case_id) %>% 
    #   mutate(n_recovery_before_secondary = sum(recovery_before_secondary, na.rm = TRUE)) %>% 
    #   ungroup %>% 
    #   mutate(potential_secondary_cases = potential_secondary_cases - n_recovery_before_secondary) %>% 
    #   filter(!recovery_before_secondary | is.na(secondary_case_timing)) %>% 
    #   select(-recovery_before_secondary, -n_recovery_before_secondary)
    #%>% 
      # filter_count(recovery_timing > secondary_case_timing | is.na(secondary_case_timing)) %>% 
      # relocate(case_id, secondary_case_id, potential_secondary_cases, recovery_before_secondary)
    
    
    
    
    draw_secondary_cases <- function(new_cases_w_random, p_contact_if_isolated, p_contact_traced, r0,
                                     beta_matrix, group_props,
                                     dispersion) {
      
      # FOR DEBUGGING: 
      # new_cases_w_random <- draw_symptoms_debug %>%
      #   draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1)
      # 
      # # new_cases_w_random <- primary_cases_for_timing
      # 
      # r0 <- c(2.9, 1.6, 1); dispersion <- 0.16
      # p_contact_if_isolated <- c(0.05, 0.1, 0.2)
      # p_contact_traced <- c(0.1, 0.2, 0.3)
      # beta_matrix <- crossing(
      #   to = 1:3, from = 1:3
      # ) %>%
      #   mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4))
      # group_props <- c(0.25, 0.5, 0.25)
      
      # Check lengths are the same
      if (length(p_contact_if_isolated) != length(p_contact_traced) | length(p_contact_traced) != length(r0)) {
        print(p_contact_if_isolated)
        print(p_contact_traced)
        print(r0)
        stop("Lengths of p_contact_if_isolated, p_contact_traced, and r0 are not the same")
      }
      
      n_groups <- length(p_contact_if_isolated)
      # n_groups <- length(unique(new_cases_w_random$i_group))
      # if (length(r0_group_1) != 1)                   stop("r0_group_1 should just be a single numeric scalar")
      # if (nrow(beta_matrix) != n_groups)             stop("beta matrix doesn't have same number of groups as the cases data")
      # if (group_props != n_groups)                   stop("group_props doesn't have same number of groups as the cases data")
      # if (length(p_contact_if_isolated) != n_groups) stop("p_contact_if_isolated is not the same length as the number of groups")
      # if (length(p_contact_traced) != n_groups)      stop("p_contact_traced is not the same length as the number of groups")
      
      # Match i groups to their parameters
      params_df <- tibble(
        i_group = 1:n_groups,  
        r0 = r0,
        p_contact_if_isolated = p_contact_if_isolated,
        p_contact_traced = p_contact_traced
      )

      # Remove the values so that they're not accidentally taken instead of the ones in the dataframe
      rm(p_contact_if_isolated, p_contact_traced, r0)
      
      # PARAMETERS HERE
      n <- nrow(new_cases_w_random)
      new_secondary <- new_cases_w_random %>% 
        left_join(params_df, by = "i_group") %>% 
        mutate(potential_secondary_cases = secondary_cases_n(i_group = i_group, r0 = r0, dispersion = dispersion)) %>% 
        relocate(case_id, i_group, potential_secondary_cases, symptom_timing) %>%
        
        # Generate IDs and rows for each one
        rowwise() %>% 
        mutate(secondary_case_id = if_else(potential_secondary_cases != 0, list(paste0(case_id, "_", 1:potential_secondary_cases)), list(NA_character_))) %>% 
        ungroup %>% 
        unnest(secondary_case_id) %>% 
        mutate(secondary_case_id = as.character(secondary_case_id)) %>% 
        
        # Draw the timing
        mutate(
          secondary_case_timing = if_else(
            potential_secondary_cases > 0,
            secondary_case_timing(symptom_times = symptom_timing),
            NA_real_
          )
        ) %>% 
        
        # dups_report(case_id, secondary_case_id) %>% 
        # print
        # Draw which group the secondary case is from
        mutate(
          secondary_case_group = secondary_case_group(i_group = i_group, beta_matrix = beta_matrix, group_props = group_props)
        ) %>% 
        
        # "Deisolation" timing - if people are isolating after ct, but then get a negative test result - they deisolate
        mutate(
          deisolate_timing = if_else(isolate_after_ct & (ct_test_negative | ct_false_negative), 
                                     contact_tracing_results_timing, NA_real_),
          deisolate_timing = case_when(
            isolate_symptoms_timing < deisolate_timing ~ NA_real_, # if people are already isolating due to symptoms, they won't deisolate
            isolate_test_timing < deisolate_timing ~ NA_real_,      # if people are already isolating due to another test, assume they won't deisolate
            isolate_random_test_timing < deisolate_timing ~ NA_real_
          )
        ) %>% 
        
        # Calculate isolation
        mutate(
          isolation_timing = pmin(isolate_random_test_timing, isolate_symptoms_timing, isolate_ct_test_timing, isolate_ct_results_timing, isolate_test_timing, na.rm = TRUE),
          isolation_timing = if_else(isolation_timing > recovery_timing, NA_real_, isolation_timing)
        ) %>% 
        
        # Second isolation after deisolation is possible
        mutate(
          across(c(isolate_random_test_timing, isolate_symptoms_timing, isolate_ct_test_timing, isolate_ct_results_timing, isolate_test_timing),
                 list(`2` = ~ if_else(. > deisolate_timing, ., NA_real_)))
        ) %>% 
        mutate(
          isolation_timing_2 = pmin(isolate_random_test_timing_2, isolate_symptoms_timing_2, 
                                    isolate_ct_test_timing_2, isolate_ct_results_timing_2, isolate_test_timing_2, na.rm = TRUE)
        ) %>% 
        mutate(secondary_isolated = (isolation_timing < secondary_case_timing & (secondary_case_timing <= deisolate_timing | is.na(deisolate_timing))) | 
                 isolation_timing_2 < secondary_case_timing,
               secondary_isolated = if_else(is.na(secondary_isolated), FALSE, secondary_isolated)) %>% 
      # if_else(!is.na(isolation_timing),
                  # %>% 
               # FALSE)) %>% 
        # count_prop(!is.na(isolation_timing), !is.na(isolation_timing_2), secondary_isolated, isolation_timing < secondary_case_timing)
        # count_prop(!is.na(isolation_timing), !is.na(isolation_timing_2), !is.na(deisolate_timing), !is.na(secondary_case_timing), secondary_isolated) %>%
        mutate(contact_if_isolated = if_else(secondary_isolated, bern_vec(n = nrow(.), p = p_contact_if_isolated), NA)) %>% 
        
        # Only contact traced if you're detected, and if the row is a new potential case (so secondary case timing exists, and contact still occurs despite isolation)
        mutate(
          detected = self_test_yn | !is.na(contact_tracing_results_timing) | random_test_yn
        ) %>% 
        mutate(
          secondary_contact_traced = if_else(
            detected & !is.na(secondary_case_timing) & (is.na(contact_if_isolated) | contact_if_isolated == TRUE), # only when there is a real potential case, and the person got tested
            as.logical(mc2d::rbern(nrow(.), p = p_contact_traced)),
            NA
          )
        ) %>% 
        # mutate(secondary_contact_traced = if_else(self_test_yn, purrr::rbernoulli(nrow(.), p = p_contact_traced), NA)) %>% 
        mutate(
          secondary_contact_tracing_start_timing = if_else(secondary_contact_traced, pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE), NA_real_),
          secondary_contact_tracing_test_timing = if_else(secondary_contact_traced, secondary_contact_tracing_start_timing + contact_tracing_delay(nrow(.)), NA_real_),
          secondary_contact_tracing_results_delay = if_else(secondary_contact_traced, test_result_delay(i_group), NA_real_),
          secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
        ) 
        # Get rid of any potential cases for which recover occurs before potential transmission, or rows with 0 cases
        # filter_non_cases()       # problem if this filters to be length of 0
      
      new_secondary %>% ungroup
      
    }
  
    
  
    

    
    random_test_yn_debug <- if_else(rnorm(100, 1, 0) > 0, rbernoulli(100, p = 0.4), FALSE)
    
    
    # Test all the draws work together
    draws_debug <- draw_symptoms_recovery(ids = 1:1000,
                                          i_group = as.integer(cut(runif(n = 1000), breaks = c(0, 0.33333333, 0.6666666, 1), labels = 1:3)),
                                          infection_timings = 0             ,
                                          contact_tracing_test_timing = NULL,
                                          contact_tracing_results_timing = NULL,
                                          # random_test_yn = NULL,
                                          # random_test_timing = NULL,
                                          # isolate_random_test_timing = NULL,
                                          test_result_delay_val = 1.5,
                                          recov_val = 5,
                                          test_sensitivity = 0.85,
                                          probs_self_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1)),
                                          probs_isolate_ct_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1)),
                                          probs_isolate_symptoms_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5)),
                                          probs_isolate_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1))) %>% 
      draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1, test_sensitivity = 0.85) %>% 
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1, test_sensitivity = 0.85) %>% 
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1, test_sensitivity = 0.85) %>% 
      draw_secondary_cases(p_contact_if_isolated = c(0.05, 0.1, 0.2), p_contact_traced = c(0.1, 0.2, 0.3),
                           beta_matrix = crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4)),
                           group_props = c(0.25, 0.5, 0.25), 
                           r0 = c(1, 2, 3),
                           dispersion = 0.16) %>% 
      count_prop(is.na(secondary_case_id))
      # dups_report(secondary_case_id) %>% 
      # relocate(secondary_case_id, potential_secondary_cases) %>% 
      # dups_view(secondary_case_id)
    
    # library(haven)
    
    
    
    # group_props <- c(0.25, 0.5, 0.25)
  
    
    
    
    update_isolation <- function(live_cases_rerandom, secondary_cases) {
      
      if (is.null(secondary_cases)) return(NULL)
      
      # Which columns exist in each dataset?
      cols_in_live <- live_cases_rerandom %>% names
      cols_in_secondary <- secondary_cases %>% names
      cols_only_in_secondary <- cols_in_secondary[! (cols_in_secondary %in% cols_in_live)]
      
      # live_cases_rerandom %>% count_prop(is.na(p_contact_if_isolated))
      # secondary_cases %>% count_prop(is.na(p_contact_if_isolated))
      
      # Update the secondary cases to match the live_cases with new random testing data
      updated_secondary <- right_join(           # EDIT : changed this to right_join - implies that we drop the live_cases with no secondary cases -  is this correct?
        live_cases_rerandom, 
        secondary_cases %>% select(case_id, all_of(cols_only_in_secondary)),
        by = "case_id"
      ) # %>% dups_report(case_id, secondary_case_id)
      
      # Update the isolation numbers for the new secondary case data
      secondary_cases_with_isolation <- updated_secondary %>% 
        mutate(
          isolation_timing_lag1 = isolation_timing,
          isolation_timing = pmin(isolation_timing, isolate_random_test_timing, na.rm = TRUE),
          update_isolation_timing = !harsh_equal(isolation_timing, isolation_timing_lag1)
        ) %>% 
        
        # Recalculate second isolation as well where applicable
        mutate(
          isolation_timing_2_lag1 = isolation_timing_2,
          across(c(isolate_random_test_timing, isolate_symptoms_timing, isolate_ct_test_timing, isolate_ct_results_timing, isolate_test_timing),
                 list(`2` = ~ if_else(. > deisolate_timing, ., NA_real_))),
          isolation_timing_2 = pmin(isolate_random_test_timing_2, isolate_symptoms_timing_2, 
                                    isolate_ct_test_timing_2, isolate_ct_results_timing_2, isolate_test_timing_2, na.rm = TRUE),
          update_isolation_timing_2 = !harsh_equal(isolation_timing_2, isolation_timing_2_lag1)
        ) %>% 
        # count_prop(update_isolation_timing_2) %>% 
        # count_prop(!is.na(isolation_timing), update_isolation_timing, update_isolation_timing_2) %>% 
        mutate(secondary_isolated = if_else((update_isolation_timing | update_isolation_timing_2), 
                                            (isolation_timing < secondary_case_timing & (secondary_case_timing <= deisolate_timing | is.na(deisolate_timing))) | 
                                              isolation_timing_2 < secondary_case_timing,
                                            secondary_isolated),
               secondary_isolated = if_else(is.na(secondary_isolated), FALSE, secondary_isolated)) %>%
        mutate(contact_if_isolated = if_else((update_isolation_timing | update_isolation_timing_2) & secondary_isolated, bern_vec(nrow(.), p = p_contact_if_isolated), contact_if_isolated))
      
      
      secondary_cases_with_isolation
      
    }
    
    
    
    
    
    redraw_contact_tracing <- function(secondary_cases_w_isolation 
                                       # p_contact_traced, 
                                       # contact_if_isolated  # remove parameter inputs because it now is individual-level, comes from the dataset
                                       ) {
      
      if (is.null(secondary_cases_w_isolation)) return(NULL)
      
      else {
      
        updated_secondary_contact_tracing <- secondary_cases_w_isolation %>% 
          
          # Are cases newly detected, or already detected?
          mutate(
            detected_lag1 = detected,
            detected = (self_test_yn & !self_test_false_negative) | 
              (!is.na(contact_tracing_results_timing) & !ct_test_negative & !ct_false_negative) | 
              (random_test_yn & !random_test_false_negative),
            newly_detected = detected > detected_lag1
          ) %>% 
          
          # If newly_detected, then calculate secondary contact tracing details anew
          mutate(
            secondary_contact_traced = if_else(
              newly_detected & !is.na(secondary_case_timing) & ( is.na(contact_if_isolated) | contact_if_isolated == TRUE ), # only when there is a real potential case, and the person got tested
              as.logical(mc2d::rbern(nrow(.), p = p_contact_traced)),
              secondary_contact_traced
            ),
            secondary_contact_tracing_start_timing = if_else(newly_detected & secondary_contact_traced, pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE), secondary_contact_tracing_start_timing),
            secondary_contact_tracing_test_timing = if_else(newly_detected & secondary_contact_traced, secondary_contact_tracing_start_timing + contact_tracing_delay(i_group), secondary_contact_tracing_test_timing),
            secondary_contact_tracing_results_delay = if_else(newly_detected & secondary_contact_traced, test_result_delay(i_group), secondary_contact_tracing_results_delay),
            secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
          ) %>% 
          
          # If was already detected, then check whether new detection time is earlier, and impute if it is
          mutate(
            secondary_contact_tracing_start_timing_lag1 = secondary_contact_tracing_start_timing,
            # Possible new start timing
            secondary_contact_tracing_start_timing_candidate = pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE),
            
            # Impute if the new start timing is earlier, and if newly detected and traced
            new_secondary_contact_tracing_start_timing = 
              secondary_contact_tracing_start_timing_candidate < secondary_contact_tracing_start_timing_lag1 & 
              !newly_detected & secondary_contact_traced,
            
            secondary_contact_tracing_start_timing = if_else(
              new_secondary_contact_tracing_start_timing, 
              secondary_contact_tracing_start_timing_candidate, 
              secondary_contact_tracing_start_timing_lag1
            ),
            
            # Update the other timing values
            secondary_contact_tracing_test_timing = if_else(new_secondary_contact_tracing_start_timing,
                                                            secondary_contact_tracing_start_timing + contact_tracing_delay(i_group),
                                                            secondary_contact_tracing_test_timing),
            secondary_contact_tracing_results_delay = if_else(new_secondary_contact_tracing_start_timing,
                                                              test_result_delay(i_group),
                                                              secondary_contact_tracing_results_delay),
            secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
          )
        
      updated_secondary_contact_tracing
      
      }
      
    }
    
 
    
    
    # Takes the new contact tracing times from the updated secondary case df and feeds back into the live cases where applicable
    update_live_contact_tracing <- function(live_cases, updated_secondary_cases, print = FALSE) {
      
      if (is.null(updated_secondary_cases)) return(live_cases)
      
      else {
        
        # if (print) {
        #   semi_join(
        #     live_cases,
        #     updated_secondary_cases %>% select(case_id = secondary_case_id, 
        #                                        new_secondary_contact_tracing_start_timing,
        #                                        secondary_contact_tracing_start_timing,
        #                                        # secondary_contact_tracing_results_delay,
        #                                        secondary_contact_tracing_results_timing),
        #     by = "case_id"
        #   ) %>% nrow() %>% print()
        # }
        
        left_join(
          live_cases,
          updated_secondary_cases %>% select(case_id = secondary_case_id, 
                                             new_secondary_contact_tracing_start_timing,
                                             secondary_contact_tracing_start_timing,
                                             secondary_contact_tracing_test_timing,
                                             # secondary_contact_tracing_results_delay,
                                             secondary_contact_tracing_results_timing),
          by = "case_id"
        ) %>% 
          
          # contact_tracing_test_timing comes from secondary_contact_tracing_test_timing; 
          # contact_tracing_results_timing comes from secondary_contact_tracing_results_timing
          mutate(
            contact_tracing_test_timing = coalesce(secondary_contact_tracing_test_timing, contact_tracing_test_timing),
            contact_tracing_results_timing = coalesce(secondary_contact_tracing_results_timing, contact_tracing_results_timing)
          ) %>% 
          # If test occurs before infection, the test will return negative
          mutate(
            ct_test_negative = contact_tracing_test_timing < infection_timing
          ) %>% 
          # mutate(
          #   across(
          #     c(contact_tracing_test_timing, contact_tracing_results_timing),
          #     ~ if_else(contact_tracing_test_timing < infection_timing, NA_real_, .)
          #   )
          # ) %>% 
          # view_filter(contact_tracing_results_timing < contact_tracing_test_timing) %>%
          # count_print(contact_tracing_results_timing < contact_tracing_test_timing) %>%
          select(-secondary_contact_tracing_start_timing, - secondary_contact_tracing_test_timing, -secondary_contact_tracing_results_timing, -new_secondary_contact_tracing_start_timing)
        
      }
      
    }
    




      
  
    
    
    





    

# Functions for running an outbreak simulation ----------------------------

    # Convenience function to convert the number of initial cases c(N1, N2, N3) into vector of the i_groups at individual level
    initial_cases_to_i_group <- function(n_initial_cases) {

      i_group <- c()
      
      for (i in 1:length(n_initial_cases)) {
        i_group <- c(i_group, rep(i, n_initial_cases[[i]]))
      }
      
      i_group
      
    }
    

    # OUTBREAK SETUP FUNCTION
    # Starts with a data set of initial cases
    outbreak_setup <- function(
      n_initial_cases, group_props, n_pop_total = 10000, dt_approx,
      test_result_delay_val, recov_val, test_sensitivity,  # PARAMETERS HERE
      probs_self_test_df, probs_isolate_symptoms_df, probs_isolate_test_df, probs_isolate_ct_df,
      p_contact_if_isolated, p_contact_traced,
      beta_matrix, r0_group_1, dispersion, alpha
    ) {
      
      # DEBUGGING: 
      # n_initial_cases <- c(10, 50, 40)
      # group_props <- c(0.3, 0.5, 0.2)
      # probs_default <- c(0.3, 0.6, 0.8, 0.9, 1)
      # probs_df_basic <- tibble(
      #   i_group = c(rep(1, 5), rep(2, 5), rep(3, 5)),
      #   symptom_severity = as.factor(rep(1:5, 3))
      # )
      # probs_self_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1))
      # probs_isolate_symptoms_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5))
      # probs_isolate_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1))
      # alpha <- c(0.05, 0.1, 0.2)
      # n_pop_total <- 10000
      
      n_groups <- length(group_props)
      
      # CHECK PARAMETERS
      if (length(n_initial_cases) != n_groups) stop ("Mismatch between number of groups in initial cases and group_props")
      if (length(p_contact_if_isolated) != n_groups) stop ("Mismatch between number of groups in p_contact_if_isolated")
      if (length(p_contact_traced) != n_groups) stop ("Mismatch between number of groups in p_contact_traced")
      if (sum(group_props) != 1) stop("group_props should sum to 1")
      
      beta_symmetric <- crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4)) %>% 
        pivot_wider(names_from = from, values_from = beta_val) %>% 
        select(-to) %>% 
        as.matrix() %>% unname() %>% 
        isSymmetric()
      
      if (!beta_symmetric) stop("beta_matrix is not symmetric")
      
      total_initial_cases <- sum(n_initial_cases)
      
      # Calculate R0 values based on beta_matrix, group_props, and r0_group_1
      r0 <- calculate_r0s(beta_matrix = beta_matrix, group_props = group_props, r0_group_1 = r0_group_1)
      
      live_cases_0 <- draw_symptoms_recovery(ids = 1:total_initial_cases,
                                             i_group = initial_cases_to_i_group(n_initial_cases),
                                             infection_timings = 0             ,
                                             contact_tracing_test_timing = NULL,
                                             contact_tracing_results_timing = NULL,
                                             # random_test_yn = NULL,
                                             # random_test_timing = NULL,
                                             # random_test_false_negative = NULL,
                                             # isolate_random_test_timing = NULL,
                                             test_sensitivity = test_sensitivity,
                                             test_result_delay_val = test_result_delay_val,
                                             recov_val = recov_val,
                                             probs_self_test_df = probs_self_test_df,
                                             probs_isolate_symptoms_df = probs_isolate_symptoms_df,
                                             probs_isolate_test_df = probs_isolate_test_df, 
                                             probs_isolate_ct_df = probs_isolate_ct_df) %>% 
        draw_random_testing(alpha = alpha, dt_approx = dt_approx, test_sensitivity = test_sensitivity)

      secondary_cases_0 <- draw_secondary_cases(live_cases_0, 
                                                # old_case = NULL,
                                                p_contact_if_isolated = p_contact_if_isolated, p_contact_traced = p_contact_traced, 
                                                r0 = r0, dispersion = dispersion,
                                                beta_matrix = beta_matrix, group_props = group_props
                                                ) %>% # PARAMETERS HERE
        filter_non_cases()
      
      secondary_cases_old <- NULL
      
      counters <- tibble(
        t = 0,
        i_group = 1:n_groups,
        n_pop = group_props * n_pop_total,
        n_cases_live = n_initial_cases,
        n_susceptible = n_pop - n_initial_cases,
        n_recovered = 0,
        n_cases_cum = n_initial_cases,
        n_detected = 0,
        n_in_testing = 0,
        n_undetected = n_cases_live,
        prop_susceptible = n_susceptible / n_pop
      )

      return(
        list(live_cases = live_cases_0,
             secondary_cases = secondary_cases_0,
             secondary_cases_old = secondary_cases_old,
             t = 0,
             counters = counters,
             ind_case_counter = NULL,
             n_pop_total = n_pop_total,
             model_end = FALSE,
             params = list(
               dt_approx = dt_approx,
               test_result_delay_val = test_result_delay_val,
               recov_val = recov_val,
               test_sensitivity = test_sensitivity,
               probs_self_test_df = probs_self_test_df, probs_isolate_symptoms_df = probs_isolate_symptoms_df, 
               probs_isolate_test_df = probs_isolate_test_df, probs_isolate_ct_df = probs_isolate_ct_df,
               p_contact_if_isolated = p_contact_if_isolated, p_contact_traced = p_contact_traced, 
               beta_matrix = beta_matrix, group_props = group_props, r0_group_1 = r0_group_1, n_groups = n_groups,
               r0 = r0,
               dispersion = dispersion,
               alpha = alpha # PARAMETERS HERE
             ))
      )
      
    }
    
    
    probs_default <- c(0.3, 0.6, 0.8, 0.9, 1)
    probs_df_basic <- tibble(
      i_group = c(rep(1, 5), rep(2, 5), rep(3, 5)),
      symptom_severity = as.factor(rep(1:5, 3))
    )
    
    outbreak_setup_test <- outbreak_setup(
      n_initial_cases = c(10, 50, 40), group_props = c(0.3, 0.5, 0.2), n_pop = 10000, dt_approx = 1,
      test_result_delay_val = 2, recov_val = 7,
      test_sensitivity = 0.85, 
      probs_self_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1)),
      probs_isolate_symptoms_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5)),
      probs_isolate_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1)),
      probs_isolate_ct_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1)), 
      p_contact_if_isolated = c(0.1, 0.2, 0.3), p_contact_traced = c(0.1, 0.2, 0.4),
      beta_matrix = crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4)),
      r0_group_1 = 2.5, dispersion = 0.16, alpha =  c(0.01, 0.02, 0.02)
    )
      
    outbreak_setup_test$secondary_cases %>% count_nas()
  
      # DEBUGGING: 
      # n_initial_cases <- c(10, 50, 40)
      # group_props <- c(0.3, 0.5, 0.2)
      
      
      # alpha <- c(0.05, 0.1, 0.2)
    # 
    # outbreak_setup_test <- outbreak_setup(n_initial_cases = 100, n_pop = 10000, dt_approx = 1,
    #                                       test_result_delay_val = 2, p_contact_if_isolated = 0.2, p_contact_traced = 0.5,
    #                                       probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9), 
    #                                       probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
    #                                       probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99), 
    #                                       alpha = 0.1,
    #                                       recov_val = 7, r0 = 2, dispersion = 0.16)
    
    # outbreak_setup_test$secondary_cases %>% view()
    
    # outbreak_setup_test %>% 
    #   .$secondary_cases %>% 
    #   # view()
    #   relocate(secondary_contact_tracing_timing) %>% 
    #   print(n = 300)

    

   
    
  
    
    # OUTBREAK STEP function
    outbreak_step <- function(outbreak_t, record_times = FALSE) {
      
      # TESTING: 
      # outbreak_t <- outbreak_setup_test
      # 2nd loop:  outbreak_t <- out
      # record_times <- FALSE

      live_cases <- outbreak_t$live_cases
      secondary_cases <- outbreak_t$secondary_cases
      secondary_cases_old <- outbreak_t$secondary_cases_old
      ind_case_counter <- outbreak_t$ind_case_counter
      t <- outbreak_t$t
      counters <- outbreak_t$counters
      n_pop <- outbreak_t$n_pop
      params <- outbreak_t$params
      
      # FOR TESTING:
      # params$dt_approx <- 13
      
      
      # Find minimum next secondary case
      # dt <- min(cases_df$secondary_case_timing, na.rm = TRUE)
      # 
      # # END and output if dt is infinite (no more cases)
      # if (is.infinite(dt)) return(list(
      #   cases_df = cases_t, 
      #   t = t + 10,
      #   n_susceptible = n_susceptible,
      #   n_cases_live = n_cases_live,
      #   n_recovered = n_recovered,
      #   n_cases_cum = n_cases_cum,
      #   n_pop = n_pop,
      #   model_end = TRUE
      # ))
      
      # print(paste0("time step = ", dt + dt_approx))
      
      # SET dt to 0 if you want even time steps 
      # dt <- 0           # ****
      
      t <- t + params$dt_approx
      
      print(paste0("t = ", t))
      
      # (0) UPDATE TIMING:
      
          live_cases_dt <- update_timing(live_cases, dt = params$dt_approx) #%>% dups_stop(case_id)
          secondary_cases_dt <- update_timing(secondary_cases, dt = params$dt_approx) %>% #%>% dups_stop(case_id, secondary_case_id) %>% 
            filter_non_cases
          
          # if (sum(is.na(secondary_cases_dt$secondary_case_id))) stop ("some NA secondary_case_IDs")
          
          secondary_cases_old_dt <- update_timing(secondary_cases_old, dt = params$dt_approx)
          
      
      # (1) RECOVERIES: (I -> R)
      
          # Calculate who recovers
          live_cases_w_recovered <- live_cases_dt %>% 
            mutate(
              symptomatic = symptom_timing <= 0,
              recovered = recovery_timing <= 0
            )
          
          # Count recoveries
          new_recoveries <- live_cases_w_recovered %>% group_by(i_group) %>% summarise(n_recovered = sum(recovered, na.rm = TRUE), .groups = "drop_last") %>% 
            full_join(tibble(i_group = 1:params$n_groups), by = "i_group") %>%
            mutate(n_recovered = if_else(is.na(n_recovered), 0L, n_recovered)) %>%
            arrange(i_group)
          n_new_recoveries <- sum(new_recoveries$n_recovered, na.rm = TRUE) #%>% print()
          
          if (n_new_recoveries > 0) {
            live_cases_w_recovered <- live_cases_w_recovered %>% filter(!recovered)
          } else if (n_new_recoveries == 0) {
            # Update the counter to 0 so that it adds to the counters_upd below
            # new_recoveries <- tibble(i_group = counters$i_group,
            #                          n_recovered = 0)
          }
          
          
      # (2) RANDOM TESTING - and redraw the new isolation and contact tracing times
          
          if (record_times) tic(paste0("randomtesting_", t)) 
          
          # Only run if random testing is not all set to 0
          if (sum(params$alpha == 0) == params$n_groups)  {
            
            print("alpha = 0 so random testing not run")
            live_cases_rerandom <- live_cases_w_recovered
            secondary_cases_old_rerandom <- secondary_cases_old_dt
            live_cases_ct_upd <- live_cases_rerandom
            secondary_cases_rerandom <- secondary_cases_dt
            
          } else if (sum(params$alpha > 0) > 0) {
            # Redraw random testing for old cases
            live_cases_rerandom <- live_cases_w_recovered %>% 
              draw_random_testing(alpha = params$alpha, dt_approx = params$dt_approx, test_sensitivity = params$test_sensitivity)  # PARAMETERS HERE
            
            # Recalculate for the old cases as well, and recalculate their contact tracing times
            secondary_cases_old_rerandom <- update_isolation(
              live_cases_rerandom, secondary_cases_old_dt
            ) %>% 
              redraw_contact_tracing()
            
            # Input this new contact tracing time back into the live cases [where applicable]
            live_cases_ct_upd <- live_cases_rerandom %>% 
              update_live_contact_tracing(secondary_cases_old_rerandom, print = FALSE)
            
            # Recalculate isolation times and contact tracing for the secondary cases
            secondary_cases_rerandom <- update_isolation(
              live_cases_ct_upd, secondary_cases_dt                    # PARAMETERS HERE
            ) %>% 
              #dups_stop(case_id, secondary_case_id) %>% 
              redraw_contact_tracing() # PARAMETERS HERE
            # count_print(new_secondary_contact_tracing_start_timing) %>% 
            # view_filter(new_secondary_contact_tracing_start_timing)
          } else {
            stop("Something going wrong with alpha condition in the random testing section")
          }

          if (record_times) toc(log = TRUE, quiet = TRUE) 
          
          
      
      # (3) INFECTIONS: (S -> I)
      
          if (record_times) tic(paste0("infections_", t))
          
          # Latest probability to get infected (based on immunity)
          prop_susceptible <- counters %>% filter(t == max(t)) %>% select(i_group, prop_susceptible)
          
          if (record_times) tic(paste0("findpotentialcases_", t))
          
          # Update timing and calculate the secondary cases that could occur in this period
          cases_secondary_all <- secondary_cases_rerandom %>% 
            mutate(new_potential_case = secondary_case_timing <= 0 & secondary_case_timing < recovery_timing) %>% 
            
            # And add on how susceptible the "target" population are at the moment
            # select(-prop_susceptible) # remove old prop_susceptible value
            select(-any_of("prop_susceptible")) %>% 
            left_join(prop_susceptible, by = c("secondary_case_group" = "i_group")) %>% 
            
            # Calculate actual cases based on isolations and immunity
            mutate(
              new_actual_case = if_else(
                new_potential_case & 
                  (contact_if_isolated == TRUE | is.na(contact_if_isolated)), # get rid of people who don't contact because they are isolated [removes FALSE, keeps TRUE and NA]
                as.logical(mc2d::rbern(nrow(.), p = prop_susceptible)),
                FALSE
              )
            ) #%>% 
            # count_prop(is.na(secondary_case_id))
          
          if (record_times) toc(log = TRUE, quiet = TRUE) 
          
          # cases_secondary_all %>% count_prop(new_potential_case, new_actual_case)
          # Calculate isolations and actual cases based on immunity
          # cases_secondary_actual <- cases_secondary_all %>% 
          #   filter(new_potential_case) %>% 
          #   #
          #   filter(contact_if_isolated == TRUE | is.na(contact_if_isolated)) %>%  
          #   mutate(new_actual_case = as.logical(mc2d::rbern(nrow(.), p = prop_susceptible)))
          

          
          # Are there new cases?
          # new_cases_counter <- cases_secondary_actual %>% group_by(i_group) %>% summarise(n_new_cases = sum(new_actual_case, na.rm = TRUE), .groups = "drop_last") %>% 
          #   # Make sure all the groups are represented in the counter
          #   full_join(tibble(i_group = 1:params$n_groups), by = "i_group") %>% 
          #   mutate(n_new_cases = if_else(is.na(n_new_cases), 0L, n_new_cases)) %>% 
          #   arrange(i_group) %>% 
          #   print()
          n_new_cases <- sum(cases_secondary_all$new_actual_case, na.rm = TRUE) #%>% print()
          
          if (record_times) tic(paste0("newcases_", t))
          
          # If there are new cases, draw their details (symptoms, secondary cases)
          if (n_new_cases == 0) {
            
            new_cases <- NULL
            new_secondary_cases <- NULL
            new_cases_counter <- tibble(i_group = 1:params$n_groups, n_new_cases = 0)
            
          } else if (n_new_cases > 0) {
            
            secondary_cases_for_new <- cases_secondary_all %>% filter(new_actual_case) %>% 
              relocate(case_id, secondary_case_id) #%>% 
              #dups_stop(case_id, secondary_case_id)
            
            # Optional: print number of infections that are traced in contact tracing
            print(paste0("New transmissions that are traced: ",
                         sum(!is.na(secondary_cases_for_new$secondary_contact_tracing_results_timing), na.rm = TRUE),
                         " / ", nrow(secondary_cases_for_new)))
            
            if (record_times) tic(paste0("newcasesDrawNewCases_", t))
       
            # Draw symptoms and random testing for new cases
            new_cases <- draw_symptoms_recovery(ids = secondary_cases_for_new$secondary_case_id,
                                                i_group = secondary_cases_for_new$secondary_case_group,
                                                infection_timings = secondary_cases_for_new$secondary_case_timing,
                                                contact_tracing_test_timing = secondary_cases_for_new$secondary_contact_tracing_test_timing,
                                                contact_tracing_results_timing = secondary_cases_for_new$secondary_contact_tracing_results_timing,
                                                # random_test_yn = NULL,
                                                # random_test_timing = NULL,
                                                # random_test_false_negative = NULL,
                                                test_result_delay_val = params$test_result_delay_val,
                                                recov_val = params$recov_val,
                                                test_sensitivity = params$test_sensitivity,
                                                probs_self_test_df = params$probs_self_test_df,
                                                probs_isolate_symptoms_df = params$probs_isolate_symptoms_df,
                                                probs_isolate_test_df = params$probs_isolate_test_df,
                                                probs_isolate_ct_df = params$probs_isolate_ct_df) %>%   # PARAMETERS HERE
              draw_random_testing(alpha = params$alpha, dt_approx = params$dt_approx, test_sensitivity = params$test_sensitivity) #%>% 
              #count_prop(i_group)
              #count_prop(random_test_yn, is.na(random_test_timing))
            
            if (record_times) toc(log = TRUE, quiet = TRUE) 
            
            if (record_times) tic(paste0("newcasesNewCasesCounter_", t))
            
            # Record which group each new infection comes from (to use in the counter)
            new_cases_counter <- new_cases %>% count(i_group) %>% 
              rename(n_new_cases = n) %>% 
              # Make sure all the groups are represented in the counter
              full_join(tibble(i_group = 1:params$n_groups), by = "i_group") %>%
              mutate(n_new_cases = if_else(is.na(n_new_cases), 0L, n_new_cases)) %>%
              arrange(i_group) #%>% 
              #print()
            
            if (record_times) toc(log = TRUE, quiet = TRUE) 
            
            if (record_times) tic(paste0("newcasesNewSecondary_", t))
            
            # Draw secondary cases for the new cases
            new_secondary_cases <- new_cases %>% 
              draw_secondary_cases(
                p_contact_if_isolated = params$p_contact_if_isolated,
                p_contact_traced = params$p_contact_traced,
                r0 = params$r0,
                dispersion = params$dispersion,
                beta_matrix = params$beta_matrix,
                group_props = params$group_props
              ) #%>%  # PARAMETERS HERE
              # count_print(is.na(secondary_case_id))
            
            if (record_times) toc(log = TRUE, quiet = TRUE) 
  
          }
          
          if (record_times) toc(log = TRUE, quiet = TRUE) 
          
          if (record_times) tic(paste0("bindcases_", t))
        
          # BIND TOGETHER THE OLD AND NEW CASES
          live_cases_w_new <- bind_rows(
            live_cases_ct_upd, 
            new_cases
          )#%>% 
           # count_prop(random_test_yn, is.na(random_test_timing))
          
          # Updated secondary cases 
          secondary_cases_w_new <- cases_secondary_all %>% 
            filter(!new_potential_case) %>%      # remove the cases that would have materialised this period
            # mutate(data_source = "cases_secondary_all") %>% 
            bind_rows(new_secondary_cases) #%>% 
            # mutate(data_source = ifelse(data_source != "cases_secondary_all", "new_secondary", data_source)) %>% 
            # relocate(case_id, secondary_case_id, data_source) %>% 
            # dups_view(case_id, secondary_case_id) %>% 
            # dups_stop(case_id, secondary_case_id)
          
          # Updated ("OLD") secondary cases i.e. ones that have already been realised, but may be required to 
          # change the contact_tracing time in the future
          secondary_cases_old_w_new <- bind_rows(
            secondary_cases_old_dt,
            cases_secondary_all %>% filter(new_potential_case)
          )
          
          if (record_times) toc(log = TRUE, quiet = TRUE) # for bindcases
          
          if (record_times) toc(log = TRUE, quiet = TRUE) # for infections
            
          
        
      # (4) UPDATE COUNTERS
          
          if (record_times) tic(paste0("counters_", t)) 
          
          # # Count the cases generated by each individual
          ind_case_counter_new <- cases_secondary_all %>%
            filter(new_potential_case | new_actual_case) %>%
            select(case_id, i_group, secondary_case_id, new_potential_case, new_actual_case, infection_timing) #%>% 
            # Store infection_t
            # mutate(infection_t = t + infection_timing)
          
          # ind_case_counter <- bind_rows(
          #   ind_case_counter, 
          #   ind_case_counter_new
          # )
          
          # Count number of people detected
          live_cases_w_detected <- live_cases_w_new %>% 
            mutate(
              detected_t_self = test_result_timing <= 0 & !self_test_false_negative,
              detected_t_ct = contact_tracing_results_timing <= 0 & !ct_test_negative & !ct_false_negative,
              detected_t_random = random_test_yn_ever & random_test_timing <= 0 & !random_test_false_negative,
              detected_at_t = detected_t_self | detected_t_ct | detected_t_random
            ) %>% 
            mutate(
              in_testing_t_self = self_test_yn & symptom_timing <= 0 & test_result_timing > 0,
              in_testing_t_ct = contact_tracing_test_timing <= 0 & contact_tracing_results_timing > 0,
              in_testing_t_random = random_test_yn & random_test_timing > 0,
              in_testing_at_t = if_else(!detected_at_t | is.na(detected_at_t), 
                                        in_testing_t_self | in_testing_t_ct | in_testing_t_random,
                                        FALSE)
              # in_testing_at_t = 
              #   if_else(
              #     !detected_at_t | is.na(detected_at_t), # only calculate if not already detected
              #     (self_test_yn & symptom_timing <= 0 & test_result_timing > 0) | 
              #       (contact_tracing_test_timing <= 0 & contact_tracing_results_timing > 0) | 
              #       random_test_yn & random_test_timing > 0,
              #     FALSE
              #   )
            ) %>% 
            mutate(
              undetected_t_self = !self_test_yn | symptom_timing > 0 | (self_test_yn & test_result_timing <= 0 & self_test_false_negative),   # not (yet) detected through self testing
              undetected_t_ct = is.na(contact_tracing_test_timing) | contact_tracing_test_timing > 0 | (contact_tracing_results_timing <= 0 & (ct_test_negative | ct_false_negative)),  # not detected through contact tracing
              undetected_t_random = !random_test_yn_ever | is.na(random_test_yn_ever) | (random_test_timing <= 0 & random_test_false_negative),   # not detected through random testing
              undetected_at_t = undetected_t_self & undetected_t_ct & undetected_t_random
            ) %>% 
            mutate(across(c(detected_at_t, undetected_at_t, in_testing_at_t), true_false)) #%>% 
            # count_prop(detected_at_t, undetected_at_t, in_testing_at_t) #%>% 
            # count_print(detected_at_t & undetected_at_t) #%>%
             #%>%
            # view_filter(in_testing_at_t & undetected_at_t)
            # view_filter(!undetected_at_t & !in_testing_at_t & !detected_at_t)

          # if (live_cases_w_detected %$% sum(in_testing_at_t & undetected_at_t) > 0) stop()
          
          detection_counters <- live_cases_w_detected %>% 
            group_by(i_group) %>% 
            summarise(across(c(detected_at_t, in_testing_at_t, undetected_at_t), sum),
                      n_cases_live = n(),
                      .groups = "drop_last") %>% 
            rename(
              n_detected = detected_at_t, 
              n_in_testing = in_testing_at_t,
              n_undetected = undetected_at_t
            ) %>% 
            # Make sure all the groups are represented in the counter
            full_join(tibble(i_group = 1:params$n_groups), by = "i_group") %>%
            mutate(across(c(n_detected, n_in_testing, n_undetected, n_cases_live), ~ if_else(is.na(.x), 0L, .x))) %>%
            arrange(i_group)
                   
                   
          if (nrow(live_cases_w_detected) != sum(detection_counters$n_detected) + sum(detection_counters$n_in_testing) + sum(detection_counters$n_undetected)) {
            warning(paste0("detected counter is going wrong : n_cases = ", nrow(live_cases_w_detected), " and cases counted in detected is ", 
                           sum(detection_counters$n_detected) + sum(detection_counters$n_in_testing) + sum(detection_counters$n_undetected)))
            live_cases_w_detected %>% count_prop(
              detected_at_t,
              in_testing_at_t,
              undetected_at_t
            )
          }
          
          
          
          # NEED TO ADD THESE TWO QUANTITIES  / SUBTRACT THEM!
          counters_upd <- tibble(
              t = counters$t + params$dt_approx,
              i_group = counters$i_group,
              n_susceptible = counters$n_susceptible - new_cases_counter$n_new_cases,
              n_recovered = counters$n_recovered + new_recoveries$n_recovered,
              n_cases_cum = counters$n_cases_cum + new_cases_counter$n_new_cases
              # n_pop = n_susceptible + n_cases_live + n_recovered,
              # n_detected = !!n_detected,
              # n_in_testing = !!n_in_testing,
              # n_undetected = !!n_undetected
            ) %>%
            left_join(detection_counters, by = "i_group") %>% 
            mutate(n_pop = n_cases_live + n_susceptible + n_recovered,
                   prop_susceptible = n_susceptible / n_pop) %>% 
            relocate(t, i_group, n_pop, n_cases_live, n_susceptible, n_recovered, n_cases_cum, n_detected, n_in_testing, n_undetected, prop_susceptible)
      
          if (sum(counters_upd$n_pop != counters$n_pop) > 0) {
            warning("Population sizes have changed...?")
            print(
              # tibble(
              #   i_group = counters$i_group,
              #   before = counters$n_pop,
              #   after = counters_upd$n_pop
              # )
              counters
            )
            
            print(counters_upd)
          }
              
          if (record_times) toc(log = TRUE, quiet = TRUE) 
      
      out <- list(
        # cases_df = cases_t, 
        live_cases = live_cases_w_new,
        secondary_cases = secondary_cases_w_new,
        secondary_cases_old = secondary_cases_old_w_new,
        counters = counters_upd,
        ind_case_counter = ind_case_counter_new,
        t = t,
        # n_susceptible = n_susceptible,
        # n_cases_live = n_cases_live,
        # n_recovered = n_recovered,
        # n_cases_cum = n_cases_cum,
        n_pop = n_pop,
        model_end = FALSE,
        params = params
      )
          
      return(out)
      
    }
    
  
    # speedy_test_params <- outbreak_sims_by_params(
    #   n_sims = 10, dt_approx = 1, n_iterations = 20,
    #   probs_self_test = list(c(0.2, 0.5, 0.8, 0.9, 1)), 
    #   probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
    #   probs_isolate_test = list(c(0.4, 0.6, 0.9, 0.95, 0.99)), 
    #   p_contact_if_isolated = 0.2, 
    #   p_contact_traced = c(0.1, 0.9),
    #   test_result_delay_val = 2,
    #   recov_val = 5, r0 = 2, dispersion = 0.16
    # )
    # 
    # plot(speedy_test_params, param_group = p_contact_traced)
    
  
    # Check one step function
    # outbreak_step(outbreak_setup(), dt_approx = 1) %>% outbreak_step()
    
    
    # Run a single simulation 
    outbreak_sim <- function(n_iterations = 100, keep_all_data = FALSE, record_times = FALSE, ...) {
      
      # TESTING: n_initial_cases = 100; n_pop = 10000; dt_approx = 1; n_iterations = 100
      
      # START UP
      outbreak_t <- outbreak_setup(...)
      cases_time_series <- list(
        outbreak_t$counters
      )
      
      if (keep_all_data) outbreak_t_record <- list(outbreak_t)
      
      # LOOP ROUND n_iterations
      for (i in 1:n_iterations) {
        
        outbreak_t <- outbreak_step(outbreak_t, record_times = record_times)
        cases_time_series[[i + 1]] <- outbreak_t$counters
        
        if (keep_all_data) outbreak_t_record[[i + 1]] <- outbreak_t
        
        if (outbreak_t$model_end == TRUE) break
        
      }
      
      out <- list(
        outbreak_t = outbreak_t,
        time_series = cases_time_series %>% bind_rows()
      )
      
      if (keep_all_data) out$outbreak_t_record = outbreak_t_record
      
      return(out)
      
    }
    
    # speedy_test <- outbreak_sim(dt_approx = 1, n_iterations = 10,
    #                             
    #                             test_result_delay_val = 2, 
    #                             p_contact_if_isolated = 0.2, 
    #                             p_contact_traced = 0.4,
    #                             probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9), 
    #                             probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
    #                             probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99), 
    #                             alpha = 0.2,
    #                             recov_val = 7, r0 = 2, dispersion = 0.16)
    
    single_sim_test <- outbreak_sim(
      n_iterations = 10,
      n_initial_cases = c(10, 50, 40), group_props = c(0.3, 0.5, 0.2), n_pop = 10000, dt_approx = 1,
      test_result_delay_val = 2, recov_val = 7,
      probs_self_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1)),
      probs_isolate_symptoms_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5)),
      probs_isolate_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1)),
      probs_isolate_ct_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1)),
      test_sensitivity = 0.85,
      p_contact_if_isolated = c(0.1, 0.2, 0.3), p_contact_traced = c(0.1, 0.2, 0.4),
      beta_matrix = crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4)),
      r0_group_1 = 2.5, dispersion = 0.16, alpha =  c(0.05, 0.1, 0.15)
    )
    
    
    # RUN MULTIPLE SIMULATIONS
    outbreak_sims <- function(n_sims, keep_all_data = FALSE, record_times = FALSE, ...) {
      loop_list <- list()
      
      for (i in 1:n_sims) {
        print(paste0("Running simulation ", i, " of ", n_sims))
        loop_list[[i]] <- outbreak_sim(keep_all_data = keep_all_data, record_times = record_times, ...)
      }
  
      outbreak_t <- loop_list %>% map("outbreak_t")

      time_series <- loop_list %>% map("time_series") %>%
        bind_rows(.id = "sim_id")
    
      out <- list(
        outbreak_t = outbreak_t,
        params = outbreak_t[[1]]$params,
        time_series = time_series
      )
      
      class(out) <- c("outbreak_sims")
      
      if (keep_all_data == TRUE) {
        out$outbreak_t_record <- loop_list %>% map("outbreak_t_record")
      }
      
      return(out)

    }
    
    
    # epidemic_0.1_multi <- outbreak_sim(20, cases_start = cases_0, dt_approx = 0.1, t_max = 100)
    
    

    
    # Function for testing the effect of different parameters
    outbreak_sims_by_params <- function(...) {
      crossing(...) %>% 
        mutate(epidemic_results = pmap(., outbreak_sims)) %>%
        "class<-"(c("outbreak_sims_by_params", "tbl_df", "tbl", "data.frame"))
    }
    

    

# Functions for plotting --------------------------------------------------

    clean_up_group_names <- function(x) {
      if (is_double(x)) factor(x)
      else if (is_list(x)) map_chr(x, paste0, collapse = "_")
    }
    
    quantile_summarise <- function(data, ..., conf_level = 0.95) {
      if (is.null(conf_level)) stop("Please specify a conf_level")
      
      conf_lower <- (1 - conf_level) / 2
      conf_upper <- 1 - conf_lower
      
      data %>% 
        summarise(
          across(...,
                 list(median = ~ median(.x),
                      upper = ~ quantile(.x, conf_upper),
                      lower = ~ quantile(.x, conf_lower))),
          .groups = "drop_last"
        )
    }
    
  
    plot.outbreak_sims <- function(data, indiv_sims = FALSE, conf_level = 0.95) {
      
      if (!indiv_sims) {
        data %>% 
          .$time_series %>% 
          group_by(sim_id, t) %>% 
          summarise(across(starts_with("n_"), sum), .groups = "drop_last") %>% 
          # mutate(new_cases = n_cases_cum - lag(n_cases_cum),
          #        new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>%
          # group_by(sim_id) %>%
          group_by(t) %>% 
          select(t, sim_id, n_cases_live) %>% 
          filter(!is.na(n_cases_live)) %>% 
          # summarise(
          #   across(n_cases_live, 
          #          list(median = ~ median(.x),
          #               upper_95 = ~ quantile(.x, 0.975),
          #               lower_95 = ~ quantile(.x, 0.025)))
          # ) %>% 
          quantile_summarise(n_cases_live, conf_level = conf_level) %>% 
          ungroup %>% 
          ggplot(aes(x = t)) + 
          geom_line(aes(y = n_cases_live_median), size = 1.3) + 
          geom_ribbon(aes(ymax = n_cases_live_upper, ymin = n_cases_live_lower), alpha = 0.3) + 
          theme_custom() + theme(legend.position = "top")
        
      } else if (indiv_sims) {
        data$time_series %>% 
          group_by(sim_id, t) %>% 
          summarise(across(starts_with("n_"), sum), .groups = "drop_last") %>% 
          group_by(sim_id) %>% 
          # filter(t < 100) %>%
          # mutate(new_cases = n_cases_cum - lag(n_cases_cum),
          # new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>% 
          ggplot(aes(x = t, y = n_cases_live, colour = sim_id)) + 
          geom_line(alpha = 0.6, show.legend = FALSE) + 
          theme_custom()
      }
      
      
    }
    
    is_named_list <- function(x) {
      is_list(x) & !is.null(names(x))
    }

    plot.outbreak_sims_by_params <- function(data, param_groups, conf_level = 0.95, indiv_sims = FALSE) {
      
      # if (missing(param_group)) stop("param_group is missing")
      param_groups_syms <- syms(param_groups)
      
      data_time_series <- data %>% 
        mutate(time_series = map(epidemic_results, "time_series")) %>% 
        select(-n_pop) %>% 
        unnest(time_series) %>% 
        # Extract named parameters where applicable
        mutate(across(where(is_named_list), 
                      ~ factor(names(.)))) %>% 
        mutate(param_group = paste(!!!param_groups_syms, sep = "_"))
    
      if (!indiv_sims) {
      
        data_time_series %>%
          # mutate("{{param_group}}" := factor({{param_group}})) %>%
          # mutate("{{param_group}}" := map_chr({{param_group}}, str_c, collapse = "_")) %>%
          group_by(param_group, sim_id, t) %>% 
          summarise(across(starts_with("n_") & !where(is.list), sum), .groups = "drop_last") %>% 
          group_by(param_group, sim_id) %>%
          # mutate(new_cases = n_cases_cum - lag(n_cases_cum),
          #        new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>%
          group_by(param_group, t) %>%
          select(t, sim_id, n_cases_live) %>%
          filter(!is.na(n_cases_live)) %>%
          quantile_summarise(n_cases_live, conf_level = conf_level) %>% 
          # summarise(
          #   across(n_cases_live,
          #          list(median = ~ median(.x),
          #               upper = ~ quantile(.x, conf_upper),
          #               lower = ~ quantile(.x, conf_lower)))
          # ) %>%
          ungroup %>%
          ggplot(aes(x = t, group = param_group)) +
          geom_line(aes(y = n_cases_live_median,
                        colour = param_group), size = 1.3) +
          geom_ribbon(aes(ymax = n_cases_live_upper, ymin = n_cases_live_lower,
                          fill = param_group), alpha = 0.3) +
          theme_custom() + theme(legend.position = "top")
      } else if (indiv_sims) {

        data_time_series %>%
          group_by(param_group, sim_id, t) %>% 
          summarise(across(starts_with("n_") & !where(is.list), sum), .groups = "drop_last") %>% 
          mutate(sim_id_group = paste0(sim_id, param_group)) %>%
          ungroup %>%
          ggplot(aes(x = t, y = n_cases_live, colour = param_group, group = sim_id_group)) +
          geom_line(alpha = 0.6, show.legend = FALSE) + 
          theme_custom()

      }
    }
    
    # plot(data = speedy_test_params, param_groups = c("p_contact_traced"), indiv_sims = FALSE)
    
  

      
    
    plot_detected <- function(data, param_groups, prop = FALSE) {
      UseMethod("plot_detected")
    }
    
    plot_detected.outbreak_sims <- function(data, prop = FALSE) {
      # data <- epidemic_1_multi
      
      # BUG 
      
      print("Using method for outbreak_sims")
      
      data_detected <- data$time_series %>% 
        # mutate(
        #   across(c(n_detected, n_in_testing, n_undetected), list(prop = ~ . / n_cases_live))
        # ) %>%
        group_by(t, i_group) %>% 
        mutate(across(starts_with("n_"), sum)) %>% 
        ungroup %>% 
        pivot_longer(c(n_undetected, n_in_testing, n_detected)) %>% 
        mutate(name = fct_rev(name)) %>% 
        group_by(t, name) %>% 
        quantile_summarise(value, conf_level = 0.95)
        
      if (prop) {
        data_detected <- data_detected %>% group_by(t) %>% 
          mutate(across(-c(name), ~ . / sum(.))) %>% 
          ungroup()
      }
        

      ggplot(data_detected, aes(x = t, y = value_median, fill = name)) + 
        geom_area()
      
    }
    
    plot_detected.outbreak_sims_by_params <- function(data, param_groups, prop = FALSE) {
      
      print("Using method for outbreak_sims_by_params")
      
      param_groups_syms <- syms(param_groups)
      
      data_time_series <- data %>% 
        mutate(time_series = map(epidemic_results, "time_series")) %>% 
        select(-n_pop) %>% 
        unnest(time_series) %>% 
        # Extract named parameters where applicable
        mutate(across(where(is_named_list), 
                      ~ factor(names(.)))) %>% 
        mutate(param_group = paste(!!!param_groups_syms, sep = "_")) %>% 
        group_by(t, param_group, i_group) %>% 
        # print
        mutate(across(starts_with("n_") & where(is_numeric), sum)) %>% 
        ungroup
      
      data_detected <- data_time_series %>% 
        pivot_longer(c(n_undetected, n_in_testing, n_detected)) %>% 
        mutate(name = fct_rev(name)) %>% 
        group_by(t, param_group, name) %>% 
        quantile_summarise(value, conf_level = 0.95)
      
      if (prop) {
        data_detected <- data_detected %>% group_by(param_group, t) %>% 
          mutate(across(value_median, ~ . / sum(.))) %>% 
          ungroup()
      }
      
      ggplot(data_detected, aes(x = t, y = value_median, fill = name)) + 
        geom_area() + 
        facet_wrap(~ param_group)
      
    }

    
    
    plot_by_i_group <- function(data, stacked = FALSE, prop = FALSE, conf_level = 0.95) {
      
      data_summ <- data %>% .$time_series %>% 
        group_by(t, i_group) %>% 
        quantile_summarise(n_cases_live, conf_level = conf_level) %>% 
        ungroup
      
      if (!prop && !stacked) {
        ggplot(data_summ, aes(x = t)) + 
          geom_line(aes(y = n_cases_live_median, colour = factor(i_group)), size = 1.3) + 
          geom_ribbon(aes(x = t, ymax = n_cases_live_upper, ymin = n_cases_live_lower, fill = factor(i_group)), alpha = 0.3) + 
          theme_custom() + theme(legend.position = "top")
      } else {
        
        if (prop) {
          data_summ <- data_summ %>% group_by(t) %>% 
            mutate(n_cases_live_median = n_cases_live_median / sum(n_cases_live_median)) %>% 
            ungroup()
        } 
        
        ggplot(data_summ, aes(x = t, y = n_cases_live_median, fill = factor(i_group))) + 
          geom_area()
        
      }
      
      
      
    }
    
    
    plot_detected_by_i_group <- function(data, prop = FALSE) {
      
      data_detected <- data$time_series %>% 
        pivot_longer(c(n_undetected, n_in_testing, n_detected)) %>% 
        mutate(name = fct_rev(name)) %>% 
        group_by(t, i_group, name) %>% 
        quantile_summarise(value, conf_level = 0.95)
      
      if (prop) {
        data_detected <- data_detected %>% group_by(i_group, t) %>% 
          mutate(across(-c(name), ~ . / sum(.))) %>% 
          ungroup()
      }
      
      ggplot(data_detected, aes(x = t, y = value_median, fill = name)) + 
        geom_area() + 
        facet_wrap(~ factor(i_group)) + theme_custom()
      
    }
    
    
    
    
    
    
    print.outbreak_sims <- function(data) {
      print(str(data, max.level = 2))
      print(data$time_series)
    }
  
    
    

# ... ---------------------------------------------------------------------


# TESTING ------------------------------------------------------


    
# Test all functions -------------------------------------------------------------

    # QUICK TEST
    probs_df_basic_4 <- crossing(i_group = 1:4, symptom_severity = as.factor(1:5))
    
    
    
    speedy_test <- outbreak_sims(
      n_sims = 10,
      n_iterations = 5,
      n_pop = 10000, 
      n_initial_cases = c(10, 50, 40, 20), group_props = c(0.3, 0.2, 0.2, 0.3), dt_approx = 1,
      test_result_delay_val = 2, recov_val = 7,
      test_sensitivity = 0.85, 
      probs_self_test_df = probs_df_basic_4 %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1, probs_default * 1)),
      probs_isolate_symptoms_df = probs_df_basic_4 %>% mutate(prob = c(probs_default * 1, probs_default * 1, probs_default * 1, probs_default * 1)),
      probs_isolate_test_df = probs_df_basic_4 %>% mutate(prob = c(probs_default * 0.5, probs_default * 0.8, probs_default * 1, probs_default * 1)),
      probs_isolate_ct_df = probs_df_basic_4 %>% mutate(prob = c(probs_default * 0.6, probs_default * 0.6, probs_default * 1, probs_default * 1)),
      p_contact_if_isolated = c(0.3, 0.2, 0.1, 0.1), p_contact_traced = c(0.1, 0.2, 0.2, 0.4),
      beta_matrix = crossing(to = 1:4, from = 1:4) %>% mutate(beta_val = c(10, 5, 2, 1, 5, 7, 4, 2, 2, 4, 7, 3, 1, 2, 3, 6)),
      r0_group_1 = 5, dispersion = 0.16, alpha =  c(0.05, 0.1, 0.1, 0.1)
    )
  
    speedy_test$time_series
    speedy_test$outbreak_t[[1]]$ind_case_counter

    plot(speedy_test, indiv_sims = TRUE)
    plot_detected(speedy_test, prop = FALSE)
    plot_by_i_group(speedy_test, stacked = FALSE, prop = FALSE)
    plot_detected_by_i_group(speedy_test, prop = TRUE)
    
  
    # SLOWER TEST
    epidemic_1_multi <- outbreak_sims(
      n_sims = 50,
      n_iterations = 100,
      n_initial_cases = c(10, 50, 40), group_props = c(0.3, 0.5, 0.2), n_pop = 10000, dt_approx = 1,
      test_result_delay_val = 2, recov_val = 7,
      probs_self_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1)),
      probs_isolate_symptoms_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5)),
      probs_isolate_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1)),
      p_contact_if_isolated = c(0.3, 0.2, 0.1), p_contact_traced = c(0.1, 0.2, 0.4),
      beta_matrix = crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4)),
      r0_group_1 = 2.5, dispersion = 0.16, alpha =  c(0.05, 0.1, 0.1)
    )
    
    
    epidemic_1_multi$time_series %>% print(n = 100)
    plot(epidemic_1_multi, indiv_sims = FALSE, conf_level = 0.8)
    plot(epidemic_1_multi, indiv_sims = TRUE) 
    plot_detected(epidemic_1_multi, prop = TRUE)
    plot_by_i_group(epidemic_1_multi, stacked = FALSE)
    plot_detected_by_i_group(epidemic_1_multi, prop = TRUE)
    
  
    
    # TEST FUNCTION TO LOOK AT EFFECT OF PARAMETERS
    # PROBABILITY OF TESTING (for given symptoms) - lower values means more cases
    probs_self_test_default <- c(0, 0.04, 0.1, 0.15, 0.4)
    
    # SPEEDY 
    speedy_test_params <- outbreak_sims_by_params(
      n_sims = 3,
      n_iterations = 20,
      n_initial_cases = list(c(10, 50, 40)), 
      group_props = list(c(0.3, 0.5, 0.2)),
      n_pop = 10000, 
      dt_approx = 1,
      test_result_delay_val = 2, 
      recov_val = 7,
      test_sensitivity = c(0.5, 1),
      probs_self_test_df = list(probs_df_basic %>% mutate(prob = c(probs_default * 0.8, probs_default * 0.9, probs_default * 1))),
      # probs_self_test_df = list(
      #   "low" = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.1, probs_default * 0.1)),
      #   "medium" = probs_df_basic %>% mutate(prob = c(probs_default * 0.5, probs_default * 0.5, probs_default * 0.5)),
      #   "high" = probs_df_basic %>% mutate(prob = c(probs_default * 1, probs_default * 1, probs_default * 1))
      # ),
      probs_isolate_symptoms_df = list(probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5))),
      probs_isolate_test_df = list(probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1))),
      probs_isolate_ct_df = list(probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1))),
      p_contact_if_isolated = list(c(0.3, 0.2, 0.1)), 
      p_contact_traced = list(c(0.1, 0.2, 0.4)),
      beta_matrix = list(crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4))),
      r0_group_1 = 3, 
      dispersion = 0.16, 
      alpha =  list(c(0.05, 0.1, 0.15))
    )
    
    
     
    
    plot(data = speedy_test_params, param_groups = c("test_sensitivity"), indiv_sims = FALSE, conf_level = 0.9)
    
    plot_detected(data = speedy_test_params, param_groups = c("test_sensitivity"), prop = TRUE)
    
    
    
    
    

# CONSISTENCY CHECKS ------------------------------------------------------

    
    consistency_check_data <- outbreak_sims(
      keep_all_data = TRUE,
      n_sims = 1,
      n_iterations = 20,
      n_pop = 10000, 
      test_sensitivity = 0.85,
      n_initial_cases = c(30, 30, 30), group_props = c(0.3, 0.4, 0.3), dt_approx = 1,
      test_result_delay_val = 2, recov_val = 7,
      probs_self_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.05, probs_default * 0.5, probs_default * 1)),
      probs_isolate_symptoms_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.05, probs_default * 0.5, probs_default * 1)),
      probs_isolate_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.05, probs_default * 0.5, probs_default * 1)),
      probs_isolate_ct_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.4, probs_default * 0.7, probs_default * 1)),
      p_contact_if_isolated = c(0.6, 0.3, 0.05), p_contact_traced = c(0.1, 0.5, 0.8),
      beta_matrix = crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4)),
      r0_group_1 = 3, dispersion = 0.16, alpha =  c(0, 0.1, 0.2)
    )
    
    # Get a dataset including live cases at each moment t
    t_vec <- consistency_check_data$outbreak_t_record[[1]] %>% map_dbl("t")
    
    live_cases_list <- consistency_check_data$outbreak_t_record[[1]] %>% map("live_cases") %>% 
      set_names(t_vec) %>% 
      bind_rows(.id = "t") %>% 
      mutate(t = as.numeric(t), i_group = factor(i_group)) %>% 
      arrange(case_id, t)
    
    secondary_cases_list <- consistency_check_data$outbreak_t_record[[1]] %>% map("secondary_cases") %>% 
      set_names(t_vec) %>% 
      bind_rows(.id = "t") %>% 
      mutate(t = as.numeric(t), i_group = factor(i_group)) %>% 
      arrange(case_id, secondary_case_id, t) %>% 
      relocate(case_id, secondary_case_id, t)

    
    # secondary_cases_list %>% group_by(case_id) %>% 
    #   select(case_id, secondary_case_id, secondary_case_timing, t, new_potential_case, new_actual_case) %>% 
    #   arrange(case_id, secondary_case_id, t) %>% 
    #   print(n = 100)
    #   summarise(n_potential_cases = if_else(
    #     sum(!is.na(secondary_case_id)) == 0, 0, n_distinct(secondary_case_id)
    #     n_actual_cases = sum(new_actual_case == TRUE, na.rm = TRUE)
    #   )
    


# 1. Live case consistency checks --------------------------------------------
    
    # (1) Check testing decision based on symptom severity
    live_cases_list %>% 
      group_by(i_group, symptom_severity) %>% 
      count_prop(self_test_yn, return_count = TRUE) %>% 
      filter(self_test_yn) %>% 
      ggplot(aes(x = factor(i_group), y = prop, fill = symptom_severity), stat = "identity") + geom_col(position = "dodge")
    
   
    # (2) Check proportion of people who are randomly tested in each period - this goes way above 0.2 because it's "cumulative"
    live_cases_list %>% 
      group_by(i_group, t) %>% 
      summarise(random_test_yn = mean(random_test_yn, na.rm = TRUE)) %>% 
      ggplot(aes(x = t, y = random_test_yn, colour = factor(i_group))) + geom_line()
    
    # (3) Check proportion of "new" random tests
    live_cases_list %>% 
      arrange(case_id, t) %>% 
      mutate(new_random_test = random_test_yn_lag1 == FALSE & random_test_yn == TRUE) %>% 
      group_by(i_group, t) %>% 
      summarise(new_random_test = mean(new_random_test, na.rm = TRUE)) %>% 
      mutate(new_random_test_roll3 = rollmean(new_random_test, k = 3, na.pad = TRUE, align = "center")) %>% 
      ggplot(aes(x = t, y = new_random_test_roll3, colour = factor(i_group))) + geom_line()
    
    # (4) Check we only have isolate_symptoms_timing for people who actually isolate after symptoms
    live_cases_list %>% 
      count_prop(isolate_after_symptoms, is.na(isolate_symptoms_timing))
    
    # (5) Check contact tracing consistency
    
        # - Only isolate if you are tested
        sum(
          is.na(live_cases_list$contact_tracing_test_timing) &
            !is.na(live_cases_list$isolate_ct_results_timing)
        ) # should be 0
        
        # Only isolate if you have results
        sum(
          is.na(live_cases_list$contact_tracing_results_timing) &
            !is.na(live_cases_list$isolate_ct_results_timing)
        ) # should be 0
        
        # Check that contact tracing times never stay the same for a given person
        # Former bug - contact_tracing_timing and contact_tracing_test_timing don't update correctly over periods [should increment by 1 each time]
        live_cases_list %>% 
          group_by(case_id) %>% 
          arrange(t) %>% 
          mutate(ct_test_timing_bug = contact_tracing_test_timing == lag(contact_tracing_test_timing),
                 ct_results_timing_bug = contact_tracing_results_timing == lag(contact_tracing_results_timing)) %>% 
          ungroup %>% 
          count_prop(ct_test_timing_bug, ct_results_timing_bug) # should always be false / NA
    
    # (6) Check that symptom severity never changes for an individual
    live_cases_list %>% group_by(case_id) %>% summarise(n_distinct = n_distinct(symptom_severity)) %>% 
      count_prop(n_distinct) # should only have n_distinct = 1
    
    # (7) Check i_group never changes
    live_cases_list %>% group_by(case_id) %>% summarise(n_distinct = n_distinct(i_group)) %>% 
      count_prop(n_distinct) # should only have n_distinct = 1
    
    # (8) Check currently testing / previously tested 

        # No one is both currently_testing and previously_tested? Actually that's OK if they are - people can still self-test/contact traced after being randomly tested
        sum(live_cases_list$previously_tested_positive & live_cases_list$currently_testing)
        
        # No one is previously tested having NEVER been currently tested before?
        # YES - people come up as previously tested when they were contact tested BEFORE they were infected...
        live_cases_list %>% 
          # select(case_id, t, currently_testing, previously_tested) %>% 
          group_by(case_id) %>% 
          mutate(across(c(currently_testing, previously_tested_positive), as.numeric)) %>% 
          mutate(ever_tested_debug = cummax(currently_testing)) %>% 
          # mutate(testing_offswitch = currently_testing == 0 & lag(currently_testing == 1)) %>% 
          mutate(testing_bug = previously_tested_positive == TRUE & ever_tested_debug == FALSE) %>% 
          # ungroup %>% 
          # count_prop(testing_bug) %>% 
          mutate(traced_before_infection = sum(infection_timing > contact_tracing_test_timing, na.rm = TRUE) > 0,
                 id_has_testing_bug = sum(testing_bug) > 0) %>% 
          ungroup %>% 
          count_prop(traced_before_infection, id_has_testing_bug) 
          # there should be no people with traced_before_infection = FALSE and id_has_testing_bug = TRUE
          
    
    # (9) [Previous bug] random_test_yn_ever should never be NA
    live_cases_list %$% sum(is.na(random_test_yn_ever) | is.na(random_test_yn))
        

# 2. Secondary case consistency checks ---------------------------------------

        
    secondary_cases_list %>% group_by(case_id) %>%
      view_n(20)
  
    library(magrittr) # so I can use %$%
        
    # (1) Number of people who have an ID but don't have a secondary_case_timing - should be 0
    secondary_cases_list %$%
      sum(!is.na(secondary_case_id) & is.na(secondary_case_timing)) # should be 0
        
    # (2) Secondary case timing should always be positive
    secondary_cases_list %$%
      sum(secondary_case_timing < 0, na.rm = TRUE) # should be 0
    
    # (3) make sure isolation happens iff isolation_timing is less than secondary_case_timing
    # secondary_isolated == TRUE iff isolation_timing < secondary_case_timing == TRUE
    secondary_cases_list %>% 
      count_prop(secondary_isolated, isolation_timing < secondary_case_timing, is.na(isolation_timing) | is.na(secondary_case_timing)) # should always be TRUE at the same time
  
    # (4) Check relationship between secondary_isolated and contact_if_isolated
    secondary_cases_list %>% 
      count_prop(secondary_isolated, contact_if_isolated) # contact isolated should be NA if secondary_isolated is FALSE, and T/F when secondary_isolated is TRUE
    
    # (5) Make sure only people who don't have a secondary_case_id [i.e. "non cases"] are NA for secondary_isolated
    secondary_cases_list %$%
      sum(!is.na(secondary_case_id) & is.na(secondary_isolated))
    
    # (6) Prop susceptible never over 1 or less than 0
    secondary_cases_list %>% hist_basic(x = prop_susceptible)
    secondary_cases_list %>% filter(is.na(secondary_isolated)) %>% view() #only 
        
        

# 3. Live/secondary matching consistency checks ---------------------------

    
    # (1) Are there people in secondary cases who aren't in live_cases? - there shouldn't be
    cases_merged <- trackr::full_join_track(live_cases_list, secondary_cases_list,
                                            by = c("case_id", "t"),
                                            suffix = c("_L", "_S"),
                                            .merge = TRUE) # should be none in the y_only section
    # Previous bug - some people were in secondary cases but not live cases when they RECOVER before the secondary case is meant to happen
    
    # (2) No duplicates
    cases_merged %>% dups_report(t, case_id, secondary_case_id) 
    
    # (3) Check no duplicates for the x_only
    cases_merged %>% 
      filter(.merge == "x_only") %>% 
      dups_report(t, case_id) # there should be only one row per obs for the people only in live_cases
    
    # (4) Check whether the _L and _S variables are the same when they exist in both datasets
    
        all_identical <- function(x, include_NAs = FALSE) {
          if (!include_NAs) x <- x[!is.na(x)]
          length(unique(x)) == 1
        }
        
        # (TODO: I can create this dataset much more easily using bind_rows)
        variable_match <- cases_merged %>% 
          select(t, case_id, secondary_case_id, ends_with("_L"), ends_with("_S")) %>% 
          pivot_longer(cols = ends_with("_L") | ends_with("_S"),
                       names_to = c(".value", "dataset"),
                       names_pattern = "(.*)_(L|S)") %>% 
          relocate(t, case_id, dataset) %>% 
          group_by(t, case_id, secondary_case_id) %>% 
          # sample_n_groups(100) %>% 
          filter(!is.na(secondary_case_id)) %>% 
          mutate(
            across(
              -c(dataset),
              list(conflict = ~ !all_identical(., include_NAs = TRUE))
            )
          )
        
        # Check there are no conflicts between values across datasets
        variable_match %>% ungroup %>% summarise(across(ends_with("_conflict"), list(total = sum, prop = mean))) %>% 
          pivot_longer(everything(), names_to = c("variable", ".value"), names_pattern = "(.*)_(total|prop)") %>% 
          print_all   # there should be no conflicting variables
        
        
        # Previously, there were conflicts for contact tracing timings...
        # This is due to: the first period in which contact_tracing is "added" to a case, 
        #  it only gets added to live, although it subsequently gets added to secondary afterwards
        # Do they always get updated 1 period AFTER being infected? i.e. first period of infection it's not there, and then it's probably
        # update through the update_live_contact_tracing thing
        
        # SOLVED - by changing the order of (2) RANDOM TESTING in the outbreak_step function
        # so that secondary cases are updated AFTER live cases had their CT times updated
        
        # variable_match %>% 
        #   group_by(case_id) %>% 
        #   filter(sum(contact_tracing_test_timing_conflict > 0) | sum(contact_tracing_results_timing_conflict > 0)) %>% 
        #   select(sort(names(.))) %>% relocate(t, case_id, secondary_case_id, dataset) %>% 
        #   view_n(1)  
        # 
        # # Look at an individual case, and look at parent
        # ind_case <- cases_merged %>% 
        #   filter(case_id == "39_3_5") %>% 
        #   select(sort(names(.))) %>% relocate(t, case_id, secondary_case_id) %>% 
        #   view()
        # 
        # parent_case <- cases_merged %>% 
        #   select(sort(names(.))) %>% relocate(t, case_id, secondary_case_id) %>% 
        #   filter(case_id == "39_3") %>% 
        #   view()
        

    # (5) Why is contact_tracing stuff often added when negative? 
    # i.e. the "first" time we see a contact tracing timing is when it's negative?
    # - SOLVED - edited update_live_contact_tracing so that contact tracing timings are removed (set to NA) when they occur before infection time
        
        # Check whether timing conflict is only the people for whom it starts off negative  (FALSE)
        variable_match %>% 
          group_by(case_id) %>% 
          arrange(case_id, t) %>% 
          summarise(
            contact_tracing_test_timing = first_non_na(contact_tracing_test_timing),
            contact_tracing_results_timing = first_non_na(contact_tracing_results_timing),
            conflict = sum(contact_tracing_test_timing_conflict > 0) | sum(contact_tracing_results_timing_conflict > 0)
          ) %>% 
          view()
        
        # Look at characteristics of the negative-starters
        variable_match %>% 
          group_by(case_id) %>% 
          arrange(case_id, t) %>% 
          mutate(
            contact_tracing_test_timing_first = first_non_na(contact_tracing_test_timing),
            contact_tracing_results_timing_first = first_non_na(contact_tracing_results_timing),
            conflict = sum(contact_tracing_test_timing_conflict > 0) | sum(contact_tracing_results_timing_conflict > 0)
          ) %>% 
          filter(contact_tracing_test_timing_first < 0) %>% 
          view()
          # They are people who get tested before they are infected
  
        
        # Look at one case, and look at when parent is "detected"
        variable_match %>% 
          group_by(case_id) %>% 
          arrange(case_id, t) %>% 
          mutate(
            contact_tracing_test_timing_first = first_non_na(contact_tracing_test_timing),
            contact_tracing_results_timing_first = first_non_na(contact_tracing_results_timing),
            conflict = sum(contact_tracing_test_timing_conflict > 0) | sum(contact_tracing_results_timing_conflict > 0)
          ) %>% 
          filter(contact_tracing_test_timing_first < 0) %>% 
          view()

  
        
        
        

# Timing tests -------------------------------------------------------------

         
    tic.clearlog()
        
    timing_test <- outbreak_sims(
      record_times = TRUE,
      n_sims = 3,
      n_iterations = 30,
      n_pop = 100000, 
      n_initial_cases = c(10, 50, 40, 20), group_props = c(0.3, 0.2, 0.2, 0.3), dt_approx = 1,
      test_result_delay_val = 2, recov_val = 7,
      probs_self_test_df = probs_df_basic_4 %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1, probs_default * 1)),
      probs_isolate_symptoms_df = probs_df_basic_4 %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5, probs_default * 0.6)),
      probs_isolate_test_df = probs_df_basic_4 %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1, probs_default * 1)),
      p_contact_if_isolated = c(0.3, 0.2, 0.1, 0.1), p_contact_traced = c(0.1, 0.2, 0.2, 0.4),
      beta_matrix = crossing(to = 1:4, from = 1:4) %>% mutate(beta_val = c(10, 5, 2, 1, 5, 7, 4, 2, 2, 4, 7, 3, 1, 2, 3, 6)),
      r0_group_1 = 5, dispersion = 0.16, alpha =  c(0.1, 0.05, 0.1, 0.05)
    )
    
    plot(timing_test, indiv_sims = TRUE)
    
    
    # Store the tictoc log
    tic_log_basic <- tic.log(format = FALSE)

    # Make timings into a readable format
    tic_log_df <- tibble(
      type = map_chr(tic_log_basic, "msg"),
      tic = map_dbl(tic_log_basic, "tic"),
      toc = map_dbl(tic_log_basic, "toc"),
      time_elapsed = toc - tic
    ) %>% 
      separate(type, into = c("type", "t")) %>% 
      mutate(t = as.integer(t)) %>% 
      arrange(type, t) %>% 
      group_by(type, t) %>% 
      select(-tic, -toc) %>% 
      mutate(sim = row_number()) %>% 
      summarise(time_elapsed = mean(time_elapsed))
    
    # tic_log_previous <- tic_log_df
    
    # tic_log_comparison <- bind_rows(
    #   previous = tic_log_previous, new = tic_log_df,
    #   .id = "version"
    # )
        
    
    # Plot timings 
    tic_log_df %>% 
      filter(type %in% c("findpotentialcases", "newcases", "bindcases") | str_detect(type, "newcases")) %>%
      ggplot(aes(x = t, y = time_elapsed, colour = type)) + 
      coord_cartesian(ylim = c(0, NA)) + 
      geom_hline(yintercept = 0) + 
      geom_line()
      # facet_wrap(~ version)
    
   

    # Or plot comparison
    tic_log_comparison <- bind_rows(
      previous = tic_log_previous, new = tic_log_df,
      .id = "version"
    )
    
    tic_log_comparison %>% 
      # filter(type %in% c("findpotentialcases", "newcases", "bindcases")) %>%
      ggplot(aes(x = t, y = time_elapsed, colour = type)) + 
      coord_cartesian(ylim = c(0, NA)) + 
      geom_hline(yintercept = 0) + 
      geom_line() + 
      facet_wrap(~ version)
    
    
    
    
    # Slowness is driven by draw_secondary_cases - test this individually
    primary_cases_for_timing <- draw_symptoms_recovery(ids = 1:10000,
                                                       i_group = as.integer(cut(runif(n = 10000), breaks = c(0, 0.33333333, 0.6666666, 1), labels = 1:3)),
                                                       infection_timings = 0             ,
                                                       contact_tracing_test_timing = NULL,
                                                       contact_tracing_results_timing = NULL,
                                                       random_test_yn = NULL,
                                                       random_test_timing = NULL,
                                                       isolate_random_test_timing = NULL,
                                                       test_result_delay_val = 1.5,
                                                       recov_val = 5,
                                                       probs_self_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.5, probs_default * 1)),
                                                       probs_isolate_symptoms_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5)),
                                                       probs_isolate_test_df = probs_df_basic %>% mutate(prob = c(probs_default * 0.2, probs_default * 0.2, probs_default * 1))) %>% 
      draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1) %>% 
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1) %>% 
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = c(0.1, 0.2, 0.3), dt_approx = 1) 
    
    
    tic()
    
    primary_cases_for_timing %>% draw_secondary_cases(p_contact_if_isolated = c(0.05, 0.1, 0.2), p_contact_traced = c(0.1, 0.2, 0.3),
                                                      beta_matrix = crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4)),
                                                      group_props = c(0.25, 0.5, 0.25), 
                                                      r0 = c(1, 2, 3),
                                                      dispersion = 0.16)
    
    toc() # was approx 2.5-3 sec, now 1.15 sec
    
    
    # Within that it's mostly the secondary_case_group function !!
    
    
# Try calculating Re ------------------------------------------------------
    
    all_case_ids <- secondary_cases_list %>% 
      mutate(infection_t = t + infection_timing) %>% 
      select(case_id, potential_secondary_cases, i_group, infection_t) %>% 
      dups_drop()
    
    ind_case_counter <- consistency_check_data$outbreak_t_record[[1]] %>% last() %>% .$ind_case_counter %>% 
      group_by(case_id) %>% 
      summarise(new_potential_case = sum(new_potential_case),
                new_actual_case = sum(new_actual_case), .groups = "drop")
    
    all_case_counter <- left_join(all_case_ids, ind_case_counter, by = "case_id") %>% 
      mutate(
        across(c(new_potential_case, new_actual_case),
               ~ if_else(is.na(.), 0L, .))
      ) %>% 
      mutate(unfinished_infection_cycle = new_potential_case < potential_secondary_cases) %>% 
      count_prop(unfinished_infection_cycle)
    
    re_estimate <- all_case_counter #%>% 
    # filter(!unfinished_infection_cycle)
    
    re_estimate %>% ggplot(aes(x = infection_t)) + 
      geom_smooth(aes(y = potential_secondary_cases), colour = "indianred") + 
      geom_smooth(aes(y = new_actual_case), colour = "darkgreen")
    
    re_estimate %>% summarise(potential_secondary = mean(potential_secondary_cases),
                              actual_secondary = mean(new_actual_case))
    
    # At the moment, the gap between potential and actual is due to (1) immnunity, and (2) control measures
    # It would be good to be able to isolate the difference just to control measures
    # E.g. possibly track the "reason" that case doesn't become actual.
    
        
        
        
        
        
        

# ……... -------------------------------------------------------------------
# RESULTS -----------------------------------------------------------------


# Look at parameter effects 1 by 1 ----------------------------------------
  


    # PROBABILITY OF SELF-TESTING - if people are more likely to get tested, the virus spreads less
    effect_probs_self_test <- outbreak_sims_by_params(
      n_sims = 10,
      n_iterations = 50,
      n_initial_cases = list(c(10, 50, 40)), 
      group_props = list(c(0.3, 0.5, 0.2)), n_pop = 10000, dt_approx = 1,
      test_result_delay_val = 1, recov_val = 7,
      probs_self_test_df = list(
        "1_low" = probs_df_basic %>% mutate(prob = 0.2),
        "2_medium" = probs_df_basic %>% mutate(prob = 0.5),
        "3_high" = probs_df_basic %>% mutate(prob = 0.9)
      ),
      probs_isolate_symptoms_df = list(
        probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5))
      ),
      probs_isolate_test_df = list(
        probs_df_basic %>% mutate(prob = c(probs_default * 1, probs_default * 1, probs_default * 1))
      ),
      p_contact_if_isolated = list(c(0.3, 0.2, 0.1)), p_contact_traced = list(c(0.1, 0.2, 0.4)),
      beta_matrix = list(
        crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4))
      ),
      r0_group_1 = 2.5, dispersion = 0.16, alpha =  list(c(0.05, 0.1, 0.1))
    )
    
    
    plot(effect_probs_self_test,  
         param_groups = "probs_self_test_df", indiv_sims = FALSE,
         conf_level = 0.5)
  
    plot_detected(effect_probs_self_test, param_groups = "probs_self_test_df", prop = TRUE)

    
    # PROBABILITY OF ISOLATING - if people are less likely to isolate, the virus spreads more
    effect_probs_isolate_symptoms <- outbreak_sims_by_params(
      n_sims = 10, dt_approx = 1, n_iterations = 10,
      probs_self_test = list(probs_self_test_default), 
      probs_isolate_symptoms = list(probs_self_test_default, c(0.7, 0.8, 0.9, 1, 1)),
      probs_isolate_test = list(c(0.4, 0.6, 0.9, 0.95, 0.99)),
      test_result_delay_val = 0,
      recov_val = 5, r0 = 2, dispersion = 0.16,
      p_contact_if_isolated = c(0.1)
    )
    
    plot(effect_probs_isolate_symptoms, probs_isolate_symptoms)
    
    # PROBABILITY OF ISOLATING AFTER TEST - if people are less likely to isolate, the virus spreads more
    effect_probs_isolate_test <- outbreak_sims_by_params(
      n_sims = 10, dt_approx = 1, n_iterations = 10,
      probs_self_test = list(0.5 + (1:5) / 10), 
      probs_isolate_symptoms = list(probs_self_test_default),
      probs_isolate_test = list(1:5 / 10, c(1, 1, 1, 1, 1)),
      test_result_delay_val = 0,
      recov_val = 5, r0 = 2, dispersion = 0.16,
      p_contact_if_isolated = c(0.1)
    )
    
    plot(effect_probs_isolate_test, probs_isolate_test)
    
    
    
    
    # test_result_delay - higher means worse outbreak
    effect_test_result_delay <- outbreak_sims_by_params(
      n_sims = 10,
      n_iterations = 50,
      n_initial_cases = list(c(10, 50, 40)), 
      group_props = list(c(0.3, 0.5, 0.2)), n_pop = 10000, dt_approx = 1,
      test_result_delay_val = c(0, 0.5, 1, 2, 5), recov_val = 7,
      probs_self_test_df = list(
        probs_df_basic %>% mutate(prob = c(probs_default * 0.4, probs_default * 0.7, probs_default * 0.9))
      ),
      probs_isolate_symptoms_df = list(
        probs_df_basic %>% mutate(prob = c(probs_default * 0.1, probs_default * 0.3, probs_default * 0.5))
      ),
      probs_isolate_test_df = list(
        probs_df_basic %>% mutate(prob = c(probs_default * 1, probs_default * 1, probs_default * 1))
      ),
      p_contact_if_isolated = list(c(0.3, 0.2, 0.1)), p_contact_traced = list(c(0.1, 0.2, 0.4)),
      beta_matrix = list(
        crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4))
      ),
      r0_group_1 = 2.5, dispersion = 0.16, alpha =  list(c(0.05, 0.1, 0.1))
    )
    
    plot(effect_test_result_delay, param_group = test_result_delay_val)
    
    
    # P_CONTACT_IF_ISOLATED - higher should mean worse outbreak
    effect_isolated <- outbreak_sims_by_params(
      n_sims = 20, dt_approx = 1, n_iterations = 40, 
      probs_self_test = list(probs_self_test_default) ,    # << high probability of testing 
      probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
      probs_isolate_test = list(c(0.6, 0.6, 0.9, 0.95, 0.99)), 
      p_contact_if_isolated = 0.1, 
      p_contact_traced = 0.2,
      test_result_delay_val = c(0, 1, 3, 5, 10),
      recov_val = 5, r0 = 2, dispersion = 0.16
    )
    
    plot(effect_isolated, p_contact_if_isolated)
    
    
    # R0 - higher R0 is worse
    effect_r0 <- outbreak_sims_by_params(
      n_sims = 20, dt_approx = 1, n_iterations = 50, test_thresh = 0.35, p_contact_if_isolated = 0.35,
      test_result_delay_val = 2, recov_val = 7, dispersion = 0.16, r0 = c(0.8, 1.5, 2.5, 5)
    )
    
    plot(effect_r0, r0)
    
    
    
    # Recov val - higher recov_val is worse (slower recovery, more infectiousness)
    effect_recov_val <- outbreak_sims_by_params(
      n_sims = 20, dt_approx = 1, n_iterations = 50, test_thresh = 0.35, p_contact_if_isolated = 0.35,
      test_result_delay_val = 2, recov_val = c(3, 6.5, 10), dispersion = 0.16, r0 = 2
    )
    
    plot(effect_recov_val, recov_val)
    
    
    
    # Contact tracing effectiveness - higher p means fewer cases. 
    # You need to have a high probability of getting tested otherwise contact tracing is basically useless
    effect_contact_tracing_prob <- outbreak_sims_by_params(
      n_sims = 30, dt_approx = 1, n_iterations = 30,
      probs_self_test = list(c(0.2, 0.5, 0.8, 0.9, 1)) ,    # << high probability of testing 
      probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
      probs_isolate_test = list(c(0.4, 0.6, 0.9, 0.95, 0.99)), 
      p_contact_if_isolated = 0.1, 
      p_contact_traced = c(0.1, 0.4, 0.9),
      test_result_delay_val = 2,
      recov_val = 5, r0 = 2, dispersion = 0.16
    )
    
    plot(effect_contact_tracing_prob, p_contact_traced)
    
    effect_contact_tracing_prob$epidemic_results[[1]]$outbreak_t[[20]]$live_cases %>% 
      view()
    
    
    
    # Effect of alpha
    effect_random_testing <- outbreak_sims_by_params(
      n_sims = 30, dt_approx = 1, n_iterations = 30,
      probs_self_test = list(c(0.2, 0.5, 0.8, 0.9, 1)) ,    # << high probability of testing 
      probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
      probs_isolate_test = list(c(0.7, 0.8, 0.9, 0.95, 0.99)), 
      p_contact_if_isolated = 0.1, 
      p_contact_traced = 0.3,
      test_result_delay_val = 2,
      alpha = c(0, 0.3, 0.6),
      recov_val = 5, r0 = 3, dispersion = 0.16
    )
    
    plot(effect_random_testing, param_group = alpha)

    
    
    probs_default_high <- c(0.5, 0.7, 0.85, 0.9, 1)
    
    # Effect of test_sensitivity
    effect_test_sensitivity <- outbreak_sims_by_params(
      n_sims = 20,
      n_iterations = 60,
      n_initial_cases = list(c(10, 50, 40)), 
      group_props = list(c(0.3, 0.5, 0.2)), n_pop = 10000, dt_approx = 1,
      test_result_delay_val = 1.5, recov_val = 7,
      test_sensitivity = c(0.5, 0.8, 1),
      probs_self_test_df = list(
        probs_df_basic %>% mutate(prob = c(probs_default_high * 0.5, probs_default_high * 0.8, probs_default_high * 1))
      ),
      probs_isolate_symptoms_df = list(
        probs_df_basic %>% mutate(prob = c(probs_default_high * 0.1, probs_default_high * 0.2, probs_default_high * 0.3))
      ),
      probs_isolate_test_df = list(
        probs_df_basic %>% mutate(prob = c(probs_default_high * 0.8, probs_default_high * 0.9, probs_default_high * 1))
      ),
      probs_isolate_ct_df = list(
        probs_df_basic %>% mutate(prob = c(probs_default_high * 0.1, probs_default_high * 0.2, probs_default_high * 0.3))
      ),
      p_contact_if_isolated = list(c(0.2, 0.1, 0)), p_contact_traced = list(c(0.1, 0.2, 0.4)),
      beta_matrix = list(
        crossing(to = 1:3, from = 1:3) %>% mutate(beta_val = c(10, 5, 2, 5, 7, 1, 2, 1, 4))
      ),
      r0_group_1 = 2.5, dispersion = 0.16, alpha =  list(c(0.05, 0.1, 0.1))
    )
    
    
    plot(effect_test_sensitivity, param_groups = "test_sensitivity", indiv_sims = FALSE, conf_level = 0.5)
    
    plot_detected(effect_test_sensitivity, param_groups = "test_sensitivity", prop = TRUE)
    
    
    


    
    
    
    
    
    
    

    

# …………….. -----------------------------------------------------------------


# OLD - Don’t run ---------------------------------------------------------


# Sequence for old cases --------------------------------------------------
    
    
    # SEQUENCE FOR OLD CASES
    
#     # (1) Generate original live cases
#     old_cases <- draw_symptoms_recovery(1:100, 
#                                         infection_timings = 0,
#                                         contact_tracing_test_timing = contact_tracing_test_timing_debug,
#                                         contact_tracing_results_timing = contact_tracing_test_timing_debug + 1.5,
#                                         random_test_yn = random_test_yn_debug,
#                                         random_test_timing = if_else(random_test_yn_debug, 1.5, NA_real_),
#                                         # random_test_yn_ever = random_test_yn_debug,
#                                         test_result_delay_val = 1.5, recov_val = 7,
#                                         probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9), 
#                                         probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
#                                         probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99)) %>% 
#       draw_random_testing(alpha = 0.2, dt_approx = 1) #%>% 
#     #view()
#     
#     # (2) Calcaulcate original secondary cases
#     old_secondary_cases <- draw_secondary_cases(old_cases, p_contact_if_isolated = 0.2, p_contact_traced = 0.6, r0 = 1.5, dispersion = 0.16) %>% 
#       update_timing(dt = 2.2) #%>% view()
#     
#     # (3) Update timing for live cases and redraw random testing
#     old_cases_rerandom <- update_timing(old_cases, dt = 2.2) %>% 
#       draw_random_testing(alpha = 0.3, dt_approx = 1) #%>% 
#     #view()
#     
#     
#     # (4) "Merge" with old secondary cases
#     # full_join(
#     #   names(old_cases_rerandom) %>% enframe() %>% select(value) %>% mutate(live = TRUE),
#     #   names(old_secondary_cases) %>% enframe() %>% select(value) %>% mutate(secondary = TRUE)
#     # ) %>% 
#     #   print_all
#     
#     # Which columns in each
#     cols_in_live <- old_cases_rerandom %>% names
#     cols_in_secondary <- old_secondary_cases %>% names
#     cols_only_in_secondary <- cols_in_secondary[! (cols_in_secondary %in% cols_in_live)]
#     
#     # 
#     updated_secondary <- full_join(
#       old_cases_rerandom, 
#       old_secondary_cases %>% select(case_id, all_of(cols_only_in_secondary))
#     ) # %>% dups_report(case_id, secondary_case_id) #%>% 
#     #view()
#     
#     # IFF update_random_testing is true and random_test_yn is true, then update isolation and contact tracing variables
#     updated_secondary %>% select(random_test_yn, update_random_testing)
#     
#     # UPDATE ISOLATION
#     updated_secondary_isolation <- updated_secondary %>% 
#       mutate(
#         isolation_timing_lag1 = isolation_timing,
#         isolation_timing = pmin(isolation_timing, isolate_random_test_timing, na.rm = TRUE)
#         # isolation_timing = if_else(isolate_random_test_timing < isolation_timing & update_random_testing & random_test_yn & !is.na(secondary_case_id), 
#         # isolate_random_test_timing, 
#         # isolation_timing)
#       ) %>% 
#       mutate(
#         update_isolation_timing = isolation_timing != isolation_timing_lag1
#       ) %>% 
#       mutate(secondary_isolated = if_else(!is.na(isolation_timing) & update_isolation_timing, isolation_timing < secondary_case_timing, secondary_isolated)) %>% 
#       mutate(contact_if_isolated = if_else(update_isolation_timing & secondary_isolated, bern_vec(nrow(.), p = p_contact_if_isolated), contact_if_isolated))
#     # filter(!is.na(secondary_case_id))
#     # select(
#     #   secondary_case_id, random_test_yn, isolate_after_test,
#     #   update_random_testing,
#     #   # starts_with("isolate_"),
#     #   update_isolation_timing, isolation_timing_lag1, isolation_timing,
#     #   isolate_random_test_timing, secondary_isolated,  contact_if_isolated) %>%
#     # view()
#     
#     updated_secondary_contact_tracing <- updated_secondary_isolation %>% 
#       
#       
#       mutate(
#         detected_lag1 = detected,
#         detected = self_test_yn | !is.na(contact_tracing_results_timing) | random_test_yn,
#         newly_detected = detected > detected_lag1
#       ) %>% 
#       
#       # If newly_detected, then calculate secondary contact tracing details
#       mutate(
#         secondary_contact_traced = if_else(
#           newly_detected & !is.na(secondary_case_timing) & (is.na(contact_if_isolated) | contact_if_isolated == TRUE), # only when there is a real potential case, and the person got tested
#           purrr::rbernoulli(nrow(.), p = p_contact_traced),
#           secondary_contact_traced
#         ),
#         secondary_contact_tracing_start_timing = if_else(newly_detected & secondary_contact_traced, pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE), secondary_contact_tracing_start_timing),
#         secondary_contact_tracing_test_timing = if_else(newly_detected & secondary_contact_traced, secondary_contact_tracing_start_timing + contact_tracing_delay(nrow(.)), secondary_contact_tracing_test_timing),
#         secondary_contact_tracing_results_delay = if_else(newly_detected & secondary_contact_traced, test_result_delay(nrow(.)), secondary_contact_tracing_results_delay),
#         secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
#       ) %>% 
#       
#       # If was already detected, then check whether new detection time is earlier, and impute if it is
#       mutate(
#         secondary_contact_tracing_start_timing_lag1 = secondary_contact_tracing_start_timing,
#         secondary_contact_tracing_start_timing = if_else(!newly_detected & secondary_contact_traced, 
#                                                          pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE), 
#                                                          secondary_contact_tracing_start_timing),
#         new_secondary_contact_tracing_start_timing = secondary_contact_tracing_start_timing < secondary_contact_tracing_start_timing_lag1,
#         
#         
#         secondary_contact_tracing_test_timing = if_else(new_secondary_contact_tracing_start_timing,
#                                                         secondary_contact_tracing_start_timing + contact_tracing_delay(nrow(.)),
#                                                         secondary_contact_tracing_test_timing),
#         secondary_contact_tracing_results_delay = if_else(new_secondary_contact_tracing_start_timing,
#                                                           test_result_delay(nrow(.)),
#                                                           secondary_contact_tracing_results_delay),
#         secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
#       ) %>% 
#       
#       
#       select(
#         secondary_case_id,
#         # test_result_timing, contact_tracing_results_timing,
#         # random_test_yn,
#         # random_test_timing,
#         # detected_lag1,
#         # detected,
#         # newly_detected,
#         # new_random_test,
#         # contact_if_isolated,
#         # secondary_contact_tracing_start_timing_lag1,
#         # secondary_contact_tracing_start_timing,
#         # new_secondary_contact_tracing_start_timing,
#         secondary_contact_tracing_test_timing,
#         secondary_contact_tracing_results_delay,
#         secondary_contact_tracing_results_timing
#         # starts_with("secondary")
#       ) %>%
#       # filter(!newly_detected) %>% 
#       
#       view()
#     
#     
#     
#     # THEN need to feed the updated contact tracing times back into the live cases where applicable!!
#     updated_secondary_contact_tracing %>% 
#       filter(!is.na(secondary_contact_tracing_test_timing), !is.na(secondary_contact_tracing_results_timing)) %>% 
#       view()
#     
#     updated_secondary_new_cases <- updated_secondary_contact_tracing %>% 
#       filter(!is.na(secondary_case_id)) %>% 
#       filter(!is.na(secondary_contact_tracing_test_timing), !is.na(secondary_contact_tracing_results_timing))
#     
#     old_secondary_cases_filt <- old_secondary_cases %>% filter(!is.na(secondary_case_id)) #%>% 
#     view_select(secondary_contact_tracing_test_timing,
#                 secondary_contact_tracing_results_delay,
#                 secondary_contact_tracing_results_timing)
#     
#     new_live_cases <- draw_symptoms_recovery(ids = old_secondary_cases_filt$secondary_case_id,
#                                              infection_timings = old_secondary_cases_filt$secondary_case_timing,
#                                              contact_tracing_test_timing = old_secondary_cases_filt$secondary_contact_tracing_test_timing,
#                                              contact_tracing_results_timing = old_secondary_cases_filt$secondary_contact_tracing_results_timing,
#                                              random_test_yn = NULL,
#                                              random_test_timing = NULL,
#                                              test_result_delay_val = params$test_result_delay_val,
#                                              recov_val = params$recov_val,
#                                              probs_self_test = params$probs_self_test,
#                                              probs_isolate_symptoms = params$probs_isolate_symptoms,
#                                              probs_isolate_test = params$probs_isolate_test) %>% 
#       bind_rows(old_cases_rerandom)
#     
#     
#     
#     merge_counts(new_live_cases, updated_secondary_new_cases, by = c("case_id" = "secondary_case_id"))
#     
#     left_join(
#       new_live_cases,
#       updated_secondary_new_cases %>% select(case_id = secondary_case_id, 
#                                              new_secondary_contact_tracing_start_timing,
#                                              secondary_contact_tracing_start_timing,
#                                              # secondary_contact_tracing_results_delay,
#                                              secondary_contact_tracing_results_timing),
#       by = "case_id"
#     ) %>% 
#       mutate(
#         contact_tracing_test_timing = coalesce(secondary_contact_tracing_start_timing, contact_tracing_test_timing),
#         contact_tracing_results_timing = coalesce(secondary_contact_tracing_results_timing, contact_tracing_results_timing)
#       ) %>% 
#       select(-secondary_contact_tracing_start_timing, -secondary_contact_tracing_results_timing, -new_secondary_contact_tracing_start_timing) %>% 
#       view()
#     
#     
#     
#     select(case_id, 
#            contact_tracing_test_timing, contact_tracing_results_timing, 
#            new_secondary_contact_tracing_start_timing,
#            secondary_contact_tracing_start_timing, 
#            secondary_contact_tracing_results_delay,
#            secondary_contact_tracing_results_timing) %>% 
#       print(n = 100)
#     
#     
#     # How many transmissions are isolated for different values??
#     
#     prop_isolated <- function(secondary_df) {
#       n_isolated <- sum(secondary_df$isolated, na.rm = TRUE)
#       n_not_isolated <- sum(!secondary_df$isolated, na.rm = TRUE) 
#       prop_isolated <- n_isolated / (n_not_isolated + n_isolated)
#       prop_isolated
#     }
#     
#     draw_secondary_cases(draw_symptoms_recovery(1:1000, test_thresh = 0.05, test_result_delay_val = 1.5), p_contact_if_isolated = 0.2) %>% 
#       .$isolated %>% 
#       sum(na.rm = TRUE)
#     
#     
#     prop_isolated_df <- crossing(
#       test_thresh = seq(0, 1, 0.05),
#       test_result_delay_val = c(1.5, 0)
#     ) %>% 
#       rowwise() %>% 
#       mutate(
#         prop_isolated = prop_isolated(draw_secondary_cases(draw_symptoms_recovery(1:1000, test_thresh = test_thresh, test_result_delay_val = test_result_delay_val), p_contact_if_isolated = 0.2))
#       )
#     
#     prop_isolated_df %>% plot_line_grouped(test_thresh, prop_isolated, factor(test_result_delay_val))
#     
#     # p_isolated_infect
#     
#     # %>% 
#     #  select(case_id, self_test_yn:isolation_timing, secondary_case_timing, isolated) %>% print %>% 
#     #  count_print(isolated)
#     
#     
#     
#     
# # Other tests -------------------------------------------------------------
#     
#     
#     
#     
#     
#     
#     
#     
#     # bind_rows(list(`0.1` = epidemic_0.1_multi, `1` = epidemic_1_multi), .id = "sim_type") %>% 
#     # mutate(sim_unique_id = paste0(sim_type, "_", sim_id)) %>% 
#     
#     # CUMULATIVE CASES
#     epidemic_1_multi %>% 
#       ggplot(aes(x = t, y = n_cases, colour = sim_id)) + 
#       geom_line(alpha = 0.4, show.legend = FALSE)
#     
#     epidemic_1_multi %>% 
#       group_by(sim_id) %>% 
#       mutate(new_cases = n_cases - lag(n_cases),
#              new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>% 
#       ggplot(aes(x = t, y = new_cases_week, colour = sim_id)) + 
#       geom_line(alpha = 0.4, show.legend = FALSE)
#     
#     
#     
#     
#     cases_time_series %>% bind_rows() %>% 
#       mutate(week = floor(t / 7)) %>% 
#       group_by(week) %>% 
#       summarise(n_new_cases = max(n_cases) - min(n_cases)) %>% 
#       plot_line(week, n_new_cases)
#     