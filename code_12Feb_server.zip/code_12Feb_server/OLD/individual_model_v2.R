
# Set up ------------------------------------------------------------------

    library(tidyverse)
    library(zoo)
    source("~/Desktop/functions.R")

    theme_custom <- function(...) {
      theme_light() + 
        theme(plot.background = element_blank(),
              strip.background=element_rect(fill="#D1E0E6"), 
              strip.text = element_text(color = "black"),
              ...)
    }

    # Converts all NAs to false
    true_false <- function(x) {
      if (!is_logical(x)) stop("Not a logical vector")
      if_else(is.na(x), FALSE, x)
    }
    



# (1) SIMPLE INDIVIDUAL MODEL ---------------------------------------------


    # Initial set up
    n_initial_cases <- 100
    n_pop <- 10000
    t <- 0
    
    
    
    n_cases <- n_initial_cases
    
    
    

# Distributions for individual cases --------------------------------------


    # Symptom severity drawn from distribution and converted to categorical between 1 and 5
    symptom_severity <- function(n) {
      thresholds <- c(0, 0.2, 0.4, 0.6, 0.8, 1)
      labels <- as.character(1:5)
      cut(runif(n = n), breaks = thresholds, labels = labels)
    }
    
    tibble(
      symptom_severity = symptom_severity(100)
    ) %>% 
      ggplot(aes(x = symptom_severity)) + geom_bar()
    
    # Symptom timing [incubation period]- from Hellewell
    symptom_timing <- function(n) {
      rweibull(n = n, shape = 2.322737, scale = 6.492272)  # values from outbreak_model.R in Hellewell et al
    }
    

    symptom_severity_to_yn <- function(symptom_severity, probs) {
      # symptom_severity <- symptom_severity(n = 100)
      
      n_cats <- nlevels(symptom_severity)
      if (length(probs) != n_cats) stop("probs isn't the same length as the number of symptom categories")
      
      probs_matched <- tibble(
        symptom_severity = levels(symptom_severity),
        prob = probs
      )
      
      require(mc2d)
      
      tibble(
        symptom_severity = symptom_severity
      ) %>% 
        left_join(probs_matched, by = "symptom_severity") %>% 
        mutate(yn = as.logical(mc2d::rbern(nrow(.), p = prob))) %>%       # bernoulli with vectorised p
        .$yn
    }
    
    
    
    
    # Testing decision based on threshold for symptoms
    # Need to think about how to model the people who get a negative test [these are ignored for the moment]
    
    
    # self_test_yn <- function(symptom_severity, probs_self_test = c(0, 0.04, 0.1, 0.15, 0.4)) {
    #   symptom_severity_to_yn(symptom_severity, probs = probs_self_test)
    # }
    # 
    # isolate_after_symptoms <- function(symptom_severity, probs_isolate_symptoms = c(0, 0.05, 0.2, 0.4, 0.7)) {
    #   symptom_severity_to_yn(symptom_severity, probs = probs_isolate_symptoms)
    # }
    
    
    
    # isolate_after_test <- function()
    # 
    # isolate_after_symptoms(symptom_severity(100))
    # 
    
    
    
    
    
    
    # Delay in how long before they receive testing and get isolated after symptoms - assume 3 days for the moment
    test_result_delay <- function(n, test_result_delay_val = 1.5) { 
      rep(test_result_delay_val, n)
    }
    
    # random_test_delay <- function(n) {
    #   plain <- rnorm(n, 1.5, 0.5)
    #   if_else(plain < 0, 0, plain)
    # }
    # 
  
    
    # Recovery timing [not sure - need to find a source]
    recovery_timing <- function(symptom_timings, recov_val) {
      symptom_timings + recov_val     # assume you recover [no longer infectious] 7 days after being infected
    }
  
    
  
    
    # Number of (potential) secondary cases
    secondary_cases_n <- function(n, r0 = 2, dispersion = 0.16) {
      rnbinom(n = n, size = dispersion, mu = r0)
    }
    
    # tibble(x = secondary_cases(100)) %>% histogram_basic(x)
    
    
    # Draw timing of secondary cases - skew normal distribution
    secondary_case_timing <- function(symptom_times = NULL) {
      
      out <- sn::rsn(n = length(symptom_times),
                     xi = symptom_times,
                     omega = 2,
                     alpha = 20)   # this is called k in Hellewell, controls how many transmissions occur before symptom onset, 
                                   # higher alpha implies fewer cases are presymptomatic
                                   # they use k = 1.95 as central value
      
      out <- ifelse(out < 1, 1, out)
      
      return(out)
    }
    
    # ?sn::rsn

    tibble(
      symptom_times = symptom_timing(1000),
      secondary_case_times = secondary_case_timing(symptom_times)
    ) %>% 
      mutate(presymptomatic = secondary_case_times < symptom_times) %>% 
      count_prop(presymptomatic) %>% 
      histogram_basic(secondary_case_times)
    
    
    set.seed(111000)
    
    
    
    contact_tracing_delay <- function(n) {
      # TIME FROM STARTING CONTACT TRACING TO TEST RESULTS FOR THE CONTACTS
      
      # WHAT DISTRIBUTION SHOULD THIS BE??
      rweibull(n = n, shape = 10, scale = 1.5)
    }
    
    
    histogram(contact_tracing_delay(50))
    
    
    
    # 
    # 
    # initial_generation %>% histogram_basic(symptom_timing)
    # initial_generation %>% histogram_basic(secondary_case_timing)
    # 
    # initial_generation %>% 
    #   mutate(before_symptom_onset = secondary_case_timing < symptom_timing) %>%
    #   filter(!is.na(before_symptom_onset)) %>% 
    #   count_prop(before_symptom_onset)
    #   
    
    
    
    
    draw_symptoms_recovery <- function(ids, 
                                       infection_timings = NULL, 
                                       contact_tracing_test_timing = NULL,
                                       contact_tracing_results_timing = NULL,
                                       random_test_yn = NULL,
                                       random_test_timing = NULL,
                                       # random_test_yn_ever = NULL,
                                       isolate_random_test_timing = NULL,
                                       test_result_delay_val = NULL, recov_val = NULL,
                                       probs_self_test = NULL, probs_isolate_symptoms = NULL, probs_isolate_test = NULL) {
      
      # Needs to be run once for new cases only
      
      # PARAMETERS HERE
      
      n <- length(ids)
      if (length(unique(ids)) != n) warning("Duplicate IDs when calculating symptoms")
      if (is.null(probs_self_test) | is.null(probs_isolate_symptoms) | is.null(probs_isolate_test)) stop("No value for one of the probs_*")
      if (is.null(test_result_delay_val)) stop("No value for test_result_delay_val")
      if (is.null(recov_val)) stop("No value for recov_val")
      if (is.null(infection_timings)) stop("No value for infection_timings")
      
      if (is.null(contact_tracing_test_timing)) contact_tracing_test_timing <- NA_real_
      if (is.null(contact_tracing_results_timing)) contact_tracing_results_timing <- NA_real_
      if (is.null(random_test_yn)) random_test_yn <- NA
      if (is.null(random_test_timing)) random_test_timing <- NA_real_
      if (is.null(isolate_random_test_timing)) isolate_random_test_timing <- NA_real_
      # if (is.null(random_test_yn_ever)) random_test_yn_ever <- FALSE
      
      tibble(
        case_id = as.character(ids),
        infection_timing = infection_timings,
        contact_tracing_test_timing = contact_tracing_test_timing,
        contact_tracing_results_timing = contact_tracing_results_timing,
        random_test_yn = random_test_yn,
        random_test_timing = random_test_timing,
        isolate_random_test_timing = isolate_random_test_timing
        # random_test_yn_ever = random_test_yn_ever
      ) %>% 
        mutate(
          
          # Contact tracing doesn't work if they test people before they're infectious
          contact_tracing_test_timing = if_else(contact_tracing_test_timing < infection_timing, NA_real_, contact_tracing_test_timing),  
          contact_tracing_results_timing = if_else(contact_tracing_test_timing < infection_timing, NA_real_, contact_tracing_results_timing),
          
          # Symptoms and recovery
          symptom_severity = symptom_severity(n),
          symptom_timing = symptom_timing(n),
          recovery_timing = recovery_timing(symptom_timing, recov_val = recov_val),
          
          # Self testing
          self_test_yn = symptom_severity_to_yn(symptom_severity, probs = probs_self_test),
          test_result_delay = test_result_delay(n, test_result_delay_val = test_result_delay_val),
          test_result_timing = if_else(self_test_yn, symptom_timing + test_result_delay, NA_real_),

          # Isolation behaviour
          isolate_after_symptoms = symptom_severity_to_yn(symptom_severity, probs = probs_isolate_symptoms),
          isolate_after_test = symptom_severity_to_yn(symptom_severity, probs = probs_isolate_test), # used for whether people isolate after contact tracaing test, self test, or random test
          
          # Isolation timings
          isolate_symptoms_timing = if_else(isolate_after_symptoms, symptom_timing, NA_real_),
          isolate_contact_tracing_timing = if_else(isolate_after_test, contact_tracing_results_timing, NA_real_),
          isolate_test_timing = if_else(self_test_yn & isolate_after_test, test_result_timing, NA_real_)#,
        
        )
        # select(-isolate_symptoms_timing, -isolate_contact_tracing_timing, -isolate_test_timing) %>% 
        
    }
    
    args(symptom_severity)
    ?pmin
    
    pmin(c(2, NA_real_, NA_real_), c(NA_real_, 3, NA_real_), na.rm = TRUE)
    
    contact_tracing_test_timing_debug <- if_else(rnorm(100, 0, 1) > 0, rnorm(100, 6, 2), NA_real_)
    
    draw_symptoms_recovery(1:100, 
                           infection_timings = 0,
                           contact_tracing_test_timing = contact_tracing_test_timing_debug, 
                           contact_tracing_results_timing = contact_tracing_test_timing_debug + 1.5,
                           test_result_delay_val = 1.5, recov_val = 7,
                           probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9), 
                           probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
                           probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99)) %>% view()
    
    
    
    draw_random_testing <- function(live_cases, alpha, dt_approx) {
      
      # Needs to be run on ALL live cases every period
      
      # DEBUGGING:
      # live_cases <- draw_symptoms_recovery(1:100,
      #                                      infection_timings = 0,
      #                                      contact_tracing_test_timing = contact_tracing_test_timing_debug,
      #                                      contact_tracing_results_timing = contact_tracing_test_timing_debug + 1.5,
      #                                      random_test_yn = if_else(rnorm(100, 1, 0) > 0, rbernoulli(100, p = 0.4), NA),
      #                                      random_test_timing = 1.5,
      #                                      random_test_yn_ever = FALSE,
      #                                      test_result_delay_val = 1.5, recov_val = 7,
      #                                      probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9),
      #                                      probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
      #                                      probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99))
      # 
      # alpha <- 0.4; dt_approx <- 1
      
      if (is.null(dt_approx)) warning("dt_approx is NULL")
      if (is.null(alpha)) warning("alpha is NULL")
      n_cases <- nrow(live_cases)
      
      if (alpha * dt_approx > 1) stop("alpha * dt_approx > 1")
    
      live_cases_w_random <- live_cases %>% 
        
        # Only do random test if you're not currently being tested, and you haven't previously tested positive
        # Because we're only looking at infected people here, if you are ever randomly tested, you will never be tested again (because you were positive by construction)
        mutate(
          currently_testing = case_when(
            self_test_yn & symptom_timing < 0 & test_result_timing > 0    ~       TRUE         , # testing period for self test
            contact_tracing_test_timing < 0 & contact_tracing_results_timing > 0 ~   TRUE,       # testing period for contact tracing
            random_test_yn & random_test_timing > 0 ~ TRUE,                              # testing period for random test [no delay because test starts at 0]
            TRUE ~ FALSE
          ),
          previously_tested = case_when(
            self_test_yn & test_result_timing < 0 ~ TRUE,
            contact_tracing_results_timing < 0 ~ TRUE,
            random_test_yn & random_test_timing < 0 ~ TRUE,
            TRUE ~ FALSE
          )
        ) %>% 
        mutate(
          update_random_testing = !currently_testing & !previously_tested
        ) %>% 
        mutate(
          random_test_yn_lag1 = random_test_yn,
          random_test_yn = if_else(update_random_testing,
                                   purrr::rbernoulli(n_cases, p = alpha * dt_approx),     # alpha * dt_approx ensures that probability is unchanged with dt_approx?? - that's not quite true...
                                   random_test_yn),
          new_random_test = random_test_yn > random_test_yn_lag1 | is.na(random_test_yn_lag1),
          # random_test_yn_ever = if_else(random_test_yn == TRUE & random_test_yn_ever == FALSE, TRUE, random_test_yn_ever),
          
          # Tested at t = now, receive results at random_test_timing
          random_test_timing = if_else(random_test_yn & new_random_test,
                                       test_result_delay(nrow(.)),
                                       random_test_timing),
          isolate_random_test_timing = if_else(random_test_yn & new_random_test & isolate_after_test, random_test_timing, isolate_random_test_timing)
        )
        
      live_cases_w_random
      
    }
    
    
    
    # TEST:
    new_cases_w_random <-     draw_symptoms_recovery(1:100,
                                            infection_timings = 0,
                                            contact_tracing_test_timing = contact_tracing_test_timing_debug,
                                            contact_tracing_results_timing = contact_tracing_test_timing_debug + 1.5,
                                            test_result_delay_val = 1.5, recov_val = 7,
                                            probs_self_test = c(0, 0.2, 0.3, 0.6, 0.9),
                                            probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
                                            probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99)) %>%
      count_prop(random_test_yn, is.na(random_test_timing)) %>% 
      draw_random_testing(alpha = 0.2, dt_approx = 1) %>% 
      count_prop(random_test_yn, is.na(random_test_timing))
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = 0.2, dt_approx = 1) %>% 
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = 0.2, dt_approx = 1) %>% 
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = 0.2, dt_approx = 1) %>% 
      count_prop(random_test_yn, is.na(random_test_timing))
      view_select(contains("random_"))
    
  
    
    draw_secondary_cases <- function(new_cases_w_random, p_contact_if_isolated, p_contact_traced, r0, dispersion) {
      
      # FOR DEBUGGING: 
      # new_cases_w_random <-     draw_symptoms_recovery(1:100,
      #                                         infection_timings = 0,
      #                                         contact_tracing_test_timing = contact_tracing_test_timing_debug,
      #                                         contact_tracing_results_timing = contact_tracing_test_timing_debug + 1.5,
      #                                         test_result_delay_val = 1.5, recov_val = 7,
      #                                         probs_self_test = c(0, 0.2, 0.3, 0.6, 0.9),
      #                                         probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
      #                                         probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99)) %>%
      #   draw_random_testing(alpha = 0.2, dt_approx = 1)
      # p_contact_if_isolated <- 0.2; r0 <- 2; dispersion <- 0.16; p_contact_traced <- 0.4
      
      # PARAMETERS HERE
      
      n <- nrow(new_cases_w_random)
      if (is.null(p_contact_if_isolated)) stop("No value for p_contact_if_isolated")
      if (is.null(p_contact_traced)) stop("No value for p_contact_traced")
      if (is.null(r0)) stop("No value for r0")
      if (is.null(dispersion)) stop("No value for dispersion")
      
      # if (is.null(old_case)) old_case <- FALSE
      
      new_secondary <- new_cases_w_random %>% 
        mutate(potential_secondary_cases = secondary_cases_n(n, r0 = r0, dispersion = dispersion)) %>% 
        # mutate(old_case = old_case) %>% 
        rowwise() %>% 
        mutate(secondary_case_id = if_else(potential_secondary_cases != 0, list(paste0(case_id, "_", 1:potential_secondary_cases)), list(NA_character_))) %>% 
        unnest(secondary_case_id) %>% 
        mutate(secondary_case_id = as.character(secondary_case_id)) %>% 
        mutate(
          secondary_case_timing = if_else(
            potential_secondary_cases > 0,
            secondary_case_timing(symptom_times = symptom_timing),
            NA_real_
          )
        ) %>% 
        mutate(
          isolation_timing = pmin(isolate_random_test_timing, isolate_symptoms_timing, isolate_contact_tracing_timing, isolate_test_timing, na.rm = TRUE),
          isolation_timing = if_else(isolation_timing > recovery_timing, NA_real_, isolation_timing)
        ) %>% 
        mutate(secondary_isolated = if_else(!is.na(isolation_timing), isolation_timing < secondary_case_timing, FALSE)) %>% 
        mutate(contact_if_isolated = if_else(secondary_isolated, purrr::rbernoulli(nrow(.), p = p_contact_if_isolated), NA)) %>% 
        
        # Only contact traced if you're detected, and if the row is a new potential case (so secondary case timing exists, and contact still occurs despite isolation)
        mutate(
          detected = self_test_yn | !is.na(contact_tracing_results_timing) | random_test_yn
        ) %>% 
        mutate(
          secondary_contact_traced = if_else(
            detected & !is.na(secondary_case_timing) & (is.na(contact_if_isolated) | contact_if_isolated == TRUE), # only when there is a real potential case, and the person got tested
            purrr::rbernoulli(nrow(.), p = p_contact_traced),
            NA
          )
        ) %>% 
        # mutate(secondary_contact_traced = if_else(self_test_yn, purrr::rbernoulli(nrow(.), p = p_contact_traced), NA)) %>% 
        mutate(
          secondary_contact_tracing_start_timing = if_else(secondary_contact_traced, pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE), NA_real_),
          secondary_contact_tracing_test_timing = if_else(secondary_contact_traced, secondary_contact_tracing_start_timing + contact_tracing_delay(nrow(.)), NA_real_),
          secondary_contact_tracing_results_delay = if_else(secondary_contact_traced, test_result_delay(nrow(.)), NA_real_),
          secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
        )
      
      new_secondary %>% ungroup
      
    }
    
    
    

    
    random_test_yn_debug <- if_else(rnorm(100, 1, 0) > 0, rbernoulli(100, p = 0.4), FALSE)
    
    
    # Test all the draws work together
    draws_debug <- draw_symptoms_recovery(1:100, 
                                          infection_timings = 0,
                                          contact_tracing_test_timing = contact_tracing_test_timing_debug,
                                          contact_tracing_results_timing = contact_tracing_test_timing_debug + 1.5,
                                          random_test_yn = random_test_yn_debug,
                                          random_test_timing = if_else(random_test_yn_debug, 1.5, NA_real_),
                                          # random_test_yn_ever = random_test_yn_debug,
                                          test_result_delay_val = 1.5, recov_val = 7,
                                          probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9), 
                                          probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
                                          probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99)) %>% 
      draw_random_testing(alpha = 0.2, dt_approx = 1) %>% 
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = 0.2, dt_approx = 1) %>% 
      # view_select(random_test_yn, random_test_yn_lag1, random_test_timing, update_random_testing)
      update_timing(dt = 1) %>% 
      draw_random_testing(alpha = 0.2, dt_approx = 1) %>% 
      draw_secondary_cases(p_contact_if_isolated = 0.2, p_contact_traced = 0.6, r0 = 1.5, dispersion = 0.16) %>% view()
    
      
    
    

    
    # SEQUENCE FOR OLD CASES
    
    # (1) Generate original live cases
    old_cases <- draw_symptoms_recovery(1:100, 
                                        infection_timings = 0,
                                        contact_tracing_test_timing = contact_tracing_test_timing_debug,
                                        contact_tracing_results_timing = contact_tracing_test_timing_debug + 1.5,
                                        random_test_yn = random_test_yn_debug,
                                        random_test_timing = if_else(random_test_yn_debug, 1.5, NA_real_),
                                        # random_test_yn_ever = random_test_yn_debug,
                                        test_result_delay_val = 1.5, recov_val = 7,
                                        probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9), 
                                        probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
                                        probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99)) %>% 
      draw_random_testing(alpha = 0.2, dt_approx = 1) #%>% 
      #view()
    
    # (2) Calcaulcate original secondary cases
    old_secondary_cases <- draw_secondary_cases(old_cases, p_contact_if_isolated = 0.2, p_contact_traced = 0.6, r0 = 1.5, dispersion = 0.16) %>% 
      update_timing(dt = 2.2) #%>% view()
    
    # (3) Update timing for live cases and redraw random testing
    old_cases_rerandom <- update_timing(old_cases, dt = 2.2) %>% 
      draw_random_testing(alpha = 0.3, dt_approx = 1) #%>% 
      #view()
    
  
    # (4) "Merge" with old secondary cases
    # full_join(
    #   names(old_cases_rerandom) %>% enframe() %>% select(value) %>% mutate(live = TRUE),
    #   names(old_secondary_cases) %>% enframe() %>% select(value) %>% mutate(secondary = TRUE)
    # ) %>% 
    #   print_all
    
    # Which columns in each
    cols_in_live <- old_cases_rerandom %>% names
    cols_in_secondary <- old_secondary_cases %>% names
    cols_only_in_secondary <- cols_in_secondary[! (cols_in_secondary %in% cols_in_live)]
    
    # 
    updated_secondary <- full_join(
      old_cases_rerandom, 
      old_secondary_cases %>% select(case_id, all_of(cols_only_in_secondary))
    ) # %>% dups_report(case_id, secondary_case_id) #%>% 
      #view()
    
    # IFF update_random_testing is true and random_test_yn is true, then update isolation and contact tracing variables
    updated_secondary %>% select(random_test_yn, update_random_testing)
    
    # UPDATE ISOLATION
    updated_secondary_isolation <- updated_secondary %>% 
      mutate(
        isolation_timing_lag1 = isolation_timing,
        isolation_timing = pmin(isolation_timing, isolate_random_test_timing, na.rm = TRUE)
        # isolation_timing = if_else(isolate_random_test_timing < isolation_timing & update_random_testing & random_test_yn & !is.na(secondary_case_id), 
                                   # isolate_random_test_timing, 
                                   # isolation_timing)
      ) %>% 
      mutate(
        update_isolation_timing = isolation_timing != isolation_timing_lag1
      ) %>% 
      mutate(secondary_isolated = if_else(!is.na(isolation_timing) & update_isolation_timing, isolation_timing < secondary_case_timing, secondary_isolated)) %>% 
      mutate(contact_if_isolated = if_else(update_isolation_timing & secondary_isolated, purrr::rbernoulli(nrow(.), p = p_contact_if_isolated), contact_if_isolated))
      # filter(!is.na(secondary_case_id))
      # select(
      #   secondary_case_id, random_test_yn, isolate_after_test,
      #   update_random_testing,
      #   # starts_with("isolate_"),
      #   update_isolation_timing, isolation_timing_lag1, isolation_timing,
      #   isolate_random_test_timing, secondary_isolated,  contact_if_isolated) %>%
      # view()
      
    updated_secondary_contact_tracing <- updated_secondary_isolation %>% 
      
      
      mutate(
        detected_lag1 = detected,
        detected = self_test_yn | !is.na(contact_tracing_results_timing) | random_test_yn,
        newly_detected = detected > detected_lag1
      ) %>% 
      
      # If newly_detected, then calculate secondary contact tracing details
      mutate(
        secondary_contact_traced = if_else(
          newly_detected & !is.na(secondary_case_timing) & (is.na(contact_if_isolated) | contact_if_isolated == TRUE), # only when there is a real potential case, and the person got tested
          purrr::rbernoulli(nrow(.), p = p_contact_traced),
          secondary_contact_traced
        ),
        secondary_contact_tracing_start_timing = if_else(newly_detected & secondary_contact_traced, pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE), secondary_contact_tracing_start_timing),
        secondary_contact_tracing_test_timing = if_else(newly_detected & secondary_contact_traced, secondary_contact_tracing_start_timing + contact_tracing_delay(nrow(.)), secondary_contact_tracing_test_timing),
        secondary_contact_tracing_results_delay = if_else(newly_detected & secondary_contact_traced, test_result_delay(nrow(.)), secondary_contact_tracing_results_delay),
        secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
      ) %>% 
      
      # If was already detected, then check whether new detection time is earlier, and impute if it is
      mutate(
        secondary_contact_tracing_start_timing_lag1 = secondary_contact_tracing_start_timing,
        secondary_contact_tracing_start_timing = if_else(!newly_detected & secondary_contact_traced, 
                                                  pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE), 
                                                  secondary_contact_tracing_start_timing),
        new_secondary_contact_tracing_start_timing = secondary_contact_tracing_start_timing < secondary_contact_tracing_start_timing_lag1,
        
        
        secondary_contact_tracing_test_timing = if_else(new_secondary_contact_tracing_start_timing,
                                                        secondary_contact_tracing_start_timing + contact_tracing_delay(nrow(.)),
                                                        secondary_contact_tracing_test_timing),
        secondary_contact_tracing_results_delay = if_else(new_secondary_contact_tracing_start_timing,
                                                          test_result_delay(nrow(.)),
                                                          secondary_contact_tracing_results_delay),
        secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
      ) %>% 
      
      
      select(
        secondary_case_id,
        # test_result_timing, contact_tracing_results_timing,
        # random_test_yn,
        # random_test_timing,
        # detected_lag1,
        # detected,
        # newly_detected,
        # new_random_test,
        # contact_if_isolated,
        # secondary_contact_tracing_start_timing_lag1,
        # secondary_contact_tracing_start_timing,
        # new_secondary_contact_tracing_start_timing,
        secondary_contact_tracing_test_timing,
        secondary_contact_tracing_results_delay,
        secondary_contact_tracing_results_timing
        # starts_with("secondary")
      ) %>%
      # filter(!newly_detected) %>% 
      
      view()
    
    
    
    # THEN need to feed the updated contact tracing times back into the live cases where applicable!!
    updated_secondary_contact_tracing %>% 
      filter(!is.na(secondary_contact_tracing_test_timing), !is.na(secondary_contact_tracing_results_timing)) %>% 
      view()
    
    updated_secondary_new_cases <- updated_secondary_contact_tracing %>% 
      filter(!is.na(secondary_case_id)) %>% 
      filter(!is.na(secondary_contact_tracing_test_timing), !is.na(secondary_contact_tracing_results_timing))
    
    old_secondary_cases_filt <- old_secondary_cases %>% filter(!is.na(secondary_case_id)) #%>% 
      view_select(secondary_contact_tracing_test_timing,
                  secondary_contact_tracing_results_delay,
                  secondary_contact_tracing_results_timing)
    
    new_live_cases <- draw_symptoms_recovery(ids = old_secondary_cases_filt$secondary_case_id,
                                             infection_timings = old_secondary_cases_filt$secondary_case_timing,
                                             contact_tracing_test_timing = old_secondary_cases_filt$secondary_contact_tracing_test_timing,
                                             contact_tracing_results_timing = old_secondary_cases_filt$secondary_contact_tracing_results_timing,
                                             random_test_yn = NULL,
                                             random_test_timing = NULL,
                                             test_result_delay_val = params$test_result_delay_val,
                                             recov_val = params$recov_val,
                                             probs_self_test = params$probs_self_test,
                                             probs_isolate_symptoms = params$probs_isolate_symptoms,
                                             probs_isolate_test = params$probs_isolate_test) %>% 
      bind_rows(old_cases_rerandom)
    
      
    
    merge_counts(new_live_cases, updated_secondary_new_cases, by = c("case_id" = "secondary_case_id"))
    
    left_join(
      new_live_cases,
      updated_secondary_new_cases %>% select(case_id = secondary_case_id, 
                                             new_secondary_contact_tracing_start_timing,
                                             secondary_contact_tracing_start_timing,
                                             # secondary_contact_tracing_results_delay,
                                             secondary_contact_tracing_results_timing),
      by = "case_id"
    ) %>% 
      mutate(
        contact_tracing_test_timing = coalesce(secondary_contact_tracing_start_timing, contact_tracing_test_timing),
        contact_tracing_results_timing = coalesce(secondary_contact_tracing_results_timing, contact_tracing_results_timing)
      ) %>% 
      select(-secondary_contact_tracing_start_timing, -secondary_contact_tracing_results_timing, -new_secondary_contact_tracing_start_timing) %>% 
      view()
      
      
      
      select(case_id, 
             contact_tracing_test_timing, contact_tracing_results_timing, 
             new_secondary_contact_tracing_start_timing,
             secondary_contact_tracing_start_timing, 
             secondary_contact_tracing_results_delay,
             secondary_contact_tracing_results_timing) %>% 
      print(n = 100)
      
      
      
      
      
      
  
   
    
    # library(haven)
    
  
    
    
    
    
    
    
    
    
    
    
    old_cases_rerandom %>% 
      bind
    
    
    
    
    redraw_isolation <- function(live_cases_rerandom, secondary_cases, p_contact_if_isolated) {
      
      # Which columns exist in each dataset?
      cols_in_live <- live_cases_rerandom %>% names
      cols_in_secondary <- secondary_cases %>% names
      cols_only_in_secondary <- cols_in_secondary[! (cols_in_secondary %in% cols_in_live)]
      
      # Update the secondary cases to match the live_cases with new random testing data
      updated_secondary <- full_join(
        live_cases_rerandom, 
        secondary_cases %>% select(case_id, all_of(cols_only_in_secondary)),
        by = "case_id"
      ) # %>% dups_report(case_id, secondary_case_id)
      
      # Update the isolation numbers for the new secondary case data
      secondary_cases_with_isolation <- updated_secondary %>% 
        mutate(
          isolation_timing_lag1 = isolation_timing,
          isolation_timing = pmin(isolation_timing, isolate_random_test_timing, na.rm = TRUE),
          update_isolation_timing = isolation_timing != isolation_timing_lag1
        ) %>% 
        mutate(secondary_isolated = if_else(!is.na(isolation_timing) & update_isolation_timing, isolation_timing < secondary_case_timing, secondary_isolated)) %>% 
        mutate(contact_if_isolated = if_else(update_isolation_timing & secondary_isolated, purrr::rbernoulli(nrow(.), p = p_contact_if_isolated), contact_if_isolated))
      
      secondary_cases_with_isolation
      
    }
    
    
    
    
    redraw_contact_tracing <- function(secondary_cases_w_isolation, p_contact_traced, contact_if_isolated) {
      
      if (is.null(secondary_cases_w_isolation)) return(NULL)
      
      else {
      
      updated_secondary_contact_tracing <- secondary_cases_w_isolation %>% 
        
        # Are cases newly detected, or already detected?
        mutate(
          detected_lag1 = detected,
          detected = self_test_yn | !is.na(contact_tracing_results_timing) | random_test_yn,
          newly_detected = detected > detected_lag1
        ) %>% 
        
        # If newly_detected, then calculate secondary contact tracing details anew
        mutate(
          secondary_contact_traced = if_else(
            newly_detected & !is.na(secondary_case_timing) & (is.na(contact_if_isolated) | contact_if_isolated == TRUE), # only when there is a real potential case, and the person got tested
            purrr::rbernoulli(nrow(.), p = p_contact_traced),
            secondary_contact_traced
          ),
          secondary_contact_tracing_start_timing = if_else(newly_detected & secondary_contact_traced, pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE), secondary_contact_tracing_start_timing),
          secondary_contact_tracing_test_timing = if_else(newly_detected & secondary_contact_traced, secondary_contact_tracing_start_timing + contact_tracing_delay(nrow(.)), secondary_contact_tracing_test_timing),
          secondary_contact_tracing_results_delay = if_else(newly_detected & secondary_contact_traced, test_result_delay(nrow(.)), secondary_contact_tracing_results_delay),
          secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
        ) %>% 
        
        # If was already detected, then check whether new detection time is earlier, and impute if it is
        mutate(
          secondary_contact_tracing_start_timing_lag1 = secondary_contact_tracing_start_timing,
          # Possible new start timing
          secondary_contact_tracing_start_timing_candidate = pmin(test_result_timing, contact_tracing_results_timing, random_test_timing, na.rm = TRUE),
          
          # Impute if the new start timing is earlier, and if newly detected and traced
          new_secondary_contact_tracing_start_timing = 
            secondary_contact_tracing_start_timing_candidate < secondary_contact_tracing_start_timing_lag1 & 
            !newly_detected & secondary_contact_traced,
          
          secondary_contact_tracing_start_timing = if_else(
            new_secondary_contact_tracing_start_timing, 
            secondary_contact_tracing_start_timing_candidate, 
            secondary_contact_tracing_start_timing_lag1
          ),
          
          # Update the other timing values
          secondary_contact_tracing_test_timing = if_else(new_secondary_contact_tracing_start_timing,
                                                          secondary_contact_tracing_start_timing + contact_tracing_delay(nrow(.)),
                                                          secondary_contact_tracing_test_timing),
          secondary_contact_tracing_results_delay = if_else(new_secondary_contact_tracing_start_timing,
                                                            test_result_delay(nrow(.)),
                                                            secondary_contact_tracing_results_delay),
          secondary_contact_tracing_results_timing = secondary_contact_tracing_test_timing + secondary_contact_tracing_results_delay
        )
      
      updated_secondary_contact_tracing
      
      }
      
    }
    
 
    
    
    # Takes the new contact tracing times from the udpated secondary case df and feeds back into the live cases where applicable
    update_live_contact_tracing <- function(live_cases, updated_secondary_cases, print = FALSE) {
      
      if (is.null(updated_secondary_cases)) return(live_cases)
      
      else {
        
        # if (print) {
        #   semi_join(
        #     live_cases,
        #     updated_secondary_cases %>% select(case_id = secondary_case_id, 
        #                                        new_secondary_contact_tracing_start_timing,
        #                                        secondary_contact_tracing_start_timing,
        #                                        # secondary_contact_tracing_results_delay,
        #                                        secondary_contact_tracing_results_timing),
        #     by = "case_id"
        #   ) %>% nrow() %>% print()
        # }
        
        left_join(
          live_cases,
          updated_secondary_cases %>% select(case_id = secondary_case_id, 
                                             new_secondary_contact_tracing_start_timing,
                                             secondary_contact_tracing_start_timing,
                                             # secondary_contact_tracing_results_delay,
                                             secondary_contact_tracing_results_timing),
          by = "case_id"
        ) %>% 
          
          # contact_tracing_test_timing comes from secondary_contact_tracing_start_timing; 
          # contact_tracing_results_timing comes from secondary_contact_tracing_results_timing
          mutate(
            contact_tracing_test_timing = coalesce(secondary_contact_tracing_start_timing, contact_tracing_test_timing),
            contact_tracing_results_timing = coalesce(secondary_contact_tracing_results_timing, contact_tracing_results_timing)
          ) %>% 
          # view_filter(contact_tracing_results_timing < contact_tracing_test_timing) %>%
          # count_print(contact_tracing_results_timing < contact_tracing_test_timing) %>%
          select(-secondary_contact_tracing_start_timing, -secondary_contact_tracing_results_timing, -new_secondary_contact_tracing_start_timing)
        
      }
      
    }
    




      
  
    
    
    


# Misc --------------------------------------------------------------------

    
    # How many transmissions are isolated for different values??
    
    prop_isolated <- function(secondary_df) {
      n_isolated <- sum(secondary_df$isolated, na.rm = TRUE)
      n_not_isolated <- sum(!secondary_df$isolated, na.rm = TRUE) 
      prop_isolated <- n_isolated / (n_not_isolated + n_isolated)
      prop_isolated
    }
    
    draw_secondary_cases(draw_symptoms_recovery(1:1000, test_thresh = 0.05, test_result_delay_val = 1.5), p_contact_if_isolated = 0.2) %>% 
      .$isolated %>% 
      sum(na.rm = TRUE)
    
    
    prop_isolated_df <- crossing(
      test_thresh = seq(0, 1, 0.05),
      test_result_delay_val = c(1.5, 0)
    ) %>% 
      rowwise() %>% 
      mutate(
        prop_isolated = prop_isolated(draw_secondary_cases(draw_symptoms_recovery(1:1000, test_thresh = test_thresh, test_result_delay_val = test_result_delay_val), p_contact_if_isolated = 0.2))
      )
    
    prop_isolated_df %>% plot_line_grouped(test_thresh, prop_isolated, factor(test_result_delay_val))
    
    # p_isolated_infect
    
    # %>% 
    #  select(case_id, self_test_yn:isolation_timing, secondary_case_timing, isolated) %>% print %>% 
    #  count_print(isolated)
    
    
    

# Functions for running an outbreak simulation ----------------------------


    # OUTBREAK SETUP FUNCTION
    # Starts with a data set of initial cases
    outbreak_setup <- function(n_initial_cases = 100, n_pop = 10000, dt_approx,
                               test_result_delay_val, recov_val,   # PARAMETERS HERE
                               probs_self_test, probs_isolate_symptoms, probs_isolate_test, 
                               p_contact_if_isolated, p_contact_traced, r0, dispersion, 
                               alpha) {
    
      live_cases_0 <- draw_symptoms_recovery(1:n_initial_cases, 
                                             infection_timings = 0,
                                             contact_tracing_test_timing = NULL, 
                                             contact_tracing_results_timing = NULL,
                                             random_test_yn = NULL,
                                             random_test_timing = NULL,
                                             test_result_delay_val = test_result_delay_val, recov_val = recov_val,
                                             probs_self_test = probs_self_test, probs_isolate_symptoms = probs_isolate_symptoms, probs_isolate_test = probs_isolate_test) %>%  # PARAMETERS HERE
        draw_random_testing(alpha = alpha, dt_approx = dt_approx)

      secondary_cases_0 <- draw_secondary_cases(live_cases_0, 
                                                # old_case = NULL,
                                                p_contact_if_isolated = p_contact_if_isolated, p_contact_traced = p_contact_traced, 
                                                r0 = r0, dispersion = dispersion) # PARAMETERS HERE
      
      secondary_cases_old <- NULL
      
      counters <- tibble(
        t = 0,
        n_susceptible = n_pop - n_initial_cases,
        n_cases_live = n_initial_cases,
        n_recovered = 0,
        n_cases_cum = n_initial_cases,
        # n_detected = 0,
        n_detected = 0,
        n_in_testing = 0,
        n_undetected = n_cases_live,
        n_pop = n_pop
      )

      return(
        list(live_cases = live_cases_0,
             secondary_cases = secondary_cases_0,
             secondary_cases_old = secondary_cases_old,
             counters = counters,
             n_pop = n_pop,
             model_end = FALSE,
             params = list(
               dt_approx = dt_approx,
               test_result_delay_val = test_result_delay_val,
               recov_val = recov_val,
               probs_self_test = probs_self_test, probs_isolate_symptoms = probs_isolate_symptoms, probs_isolate_test = probs_isolate_test,
               p_contact_if_isolated = p_contact_if_isolated,
               p_contact_traced = p_contact_traced,
               alpha = alpha,
               r0 = r0, dispersion = dispersion # PARAMETERS HERE
             ))
      )
      
    }
    
    outbreak_setup_test <- outbreak_setup(n_initial_cases = 100, n_pop = 10000, dt_approx = 1,
                                          test_result_delay_val = 2, p_contact_if_isolated = 0.2, p_contact_traced = 0.5,
                                          probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9), 
                                          probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
                                          probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99), 
                                          alpha = 0.1,
                                          recov_val = 7, r0 = 2, dispersion = 0.16)
    
    outbreak_setup_test$secondary_cases %>% view()
    
    outbreak_setup_test %>% 
      .$secondary_cases %>% 
      view()
      relocate(secondary_contact_tracing_timing) %>% 
      print(n = 300)

    

    # Function to update all timing variables by reducing t
    update_timing <- function(df, dt) {
      df %>% 
        mutate(across(ends_with("_timing"), ~ .x - dt))
    }
    
  
    
    # OUTBREAK STEP function
    outbreak_step <- function(outbreak_t) {
      
      # TESTING: 
      # outbreak_t <- outbreak_setup_test; params$dt_approx <- 7

      live_cases <- outbreak_t$live_cases
      secondary_cases <- outbreak_t$secondary_cases
      secondary_cases_old <- outbreak_t$secondary_cases_old
      counters <- outbreak_t$counters
      n_pop <- outbreak_t$n_pop
      params <- outbreak_t$params
      
      # Find minimum next secondary case
      # dt <- min(cases_df$secondary_case_timing, na.rm = TRUE)
      # 
      # # END and output if dt is infinite (no more cases)
      # if (is.infinite(dt)) return(list(
      #   cases_df = cases_t, 
      #   t = t + 10,
      #   n_susceptible = n_susceptible,
      #   n_cases_live = n_cases_live,
      #   n_recovered = n_recovered,
      #   n_cases_cum = n_cases_cum,
      #   n_pop = n_pop,
      #   model_end = TRUE
      # ))
      
      # print(paste0("time step = ", dt + dt_approx))
      
      # SET dt to 0 if you want even time steps
      dt <- 0           # ****
      
      t <- t + dt + params$dt_approx     # IS THIS THE BEST WAY TO DO IT?? Cf. K&Rohani p221 on Tau-leap?
      
    
      # (0) UPDATE TIMING:
      
          live_cases_dt <- update_timing(live_cases, dt = params$dt_approx)
          secondary_cases_dt <- update_timing(secondary_cases, dt = params$dt_approx)
      
      # (1) RECOVERIES: (I -> R)
      
          # Calculate who recovers
          live_cases_w_recovered <- live_cases_dt %>% 
            mutate(
              symptomatic = symptom_timing <= 0,
              recovered = recovery_timing <= 0
            )
          
          # Count recoveries
          n_new_recoveries <- sum(live_cases_w_recovered$recovered, na.rm = TRUE) #%>% print()
          
          if (n_new_recoveries > 0) {
            live_cases_w_recovered <- live_cases_w_recovered %>% filter(!recovered)
          } else if (n_new_recoveries == 0) {
            # Don't have to update anything...
          }
          
          
      # (2) RANDOM TESTING - and redraw the new isolation and contact tracing times
          
          # Redraw random testing for old cases
          live_cases_rerandom <- live_cases_w_recovered %>% 
            draw_random_testing(alpha = params$alpha, dt_approx = params$dt_approx)  # PARAMETERS HERE
          
          secondary_cases_rerandom <- redraw_isolation(
            live_cases_rerandom, secondary_cases_dt, 
            p_contact_if_isolated = params$p_contact_if_isolated                     # PARAMETERS HERE
          ) %>% 
            redraw_contact_tracing(p_contact_traced = params$p_contact_traced, 
                                   contact_if_isolated = params$contact_if_isolated)  # PARAMETERS HERE
            # count_print(new_secondary_contact_tracing_start_timing) %>% 
            # view_filter(new_secondary_contact_tracing_start_timing)
          
          secondary_cases_old_rerandom <- redraw_contact_tracing(
            secondary_cases_old,
            p_contact_traced = params$p_contact_traced, 
            contact_if_isolated = params$contact_if_isolated
          )
          
          # Update the contact tracing times for the live cases where applicable
          live_cases_ct_upd <- live_cases_rerandom %>% 
            update_live_contact_tracing(secondary_cases_old_rerandom, print = FALSE)
          
      
      # (3) INFECTIONS: (S -> I)
      
          # Probability to get infected (based on immunity)
          prob_susceptible <- counters$n_susceptible / n_pop
          
          # Update timing and calculate the secondary cases that could occur in this period
          cases_secondary_all <- secondary_cases_rerandom %>% 
            mutate(new_potential_case = secondary_case_timing <= 0 & secondary_case_timing < recovery_timing)
          
          
          # (3b) ISOLATIONS
          # Calculate isolations and actual cases based on immunity
          
          cases_secondary_actual <- cases_secondary_all %>% 
            filter(new_potential_case) %>% 
            filter(contact_if_isolated == TRUE | is.na(contact_if_isolated)) %>%  # get rid of people who don't contact because they are isolated [removes FALSE, keeps TRUE and NA]
            mutate(new_actual_case = purrr::rbernoulli(nrow(.), p = prob_susceptible))
          
          # Are there new cases?
          n_new_cases <- sum(cases_secondary_actual$new_actual_case, na.rm = TRUE)
          
          # If there are new cases, draw their details (symptoms, secondary cases)
          if (n_new_cases == 0) {
            
            new_cases <- NULL
            new_secondary_cases <- NULL
            
          } else if (n_new_cases > 0) {
            
            secondary_cases_for_new <- cases_secondary_actual %>% filter(new_actual_case)
            
            # Optional: print number of infections that are traced in contact tracing
            print(paste0("New transmissions that are traced: ",
                         sum(!is.na(secondary_cases_for_new$secondary_contact_tracing_results_timing), na.rm = TRUE),
                         " / ", nrow(secondary_cases_for_new)))
       
            # Draw symptoms and random testing for new cases
            new_cases <- draw_symptoms_recovery(ids = secondary_cases_for_new$secondary_case_id,
                                                infection_timings = secondary_cases_for_new$secondary_case_timing,
                                                contact_tracing_test_timing = secondary_cases_for_new$secondary_contact_tracing_test_timing,
                                                contact_tracing_results_timing = secondary_cases_for_new$secondary_contact_tracing_results_timing,
                                                random_test_yn = NULL,
                                                random_test_timing = NULL,
                                                test_result_delay_val = params$test_result_delay_val,
                                                recov_val = params$recov_val,
                                                probs_self_test = params$probs_self_test,
                                                probs_isolate_symptoms = params$probs_isolate_symptoms,
                                                probs_isolate_test = params$probs_isolate_test) %>%   # PARAMETERS HERE
              draw_random_testing(alpha = params$alpha, dt_approx = params$dt_approx) #%>% 
              #count_prop(random_test_yn, is.na(random_test_timing))
            
            # Draw secondary cases for the new cases
            new_secondary_cases <- new_cases %>% 
              draw_secondary_cases(p_contact_if_isolated = params$p_contact_if_isolated,
                                   p_contact_traced = params$p_contact_traced,
                                   r0 = params$r0,
                                   dispersion = params$dispersion) # PARAMETERS HERE
            
  
          }
          
        
          # BIND TOGETHER THE OLD AND NEW CASES
          live_cases_w_new <- bind_rows(
            live_cases_ct_upd, 
            new_cases
          ) #%>% 
           # count_prop(random_test_yn, is.na(random_test_timing))
          
          # Count number of people detected
          live_cases_w_detected <- live_cases_w_new %>% 
            mutate(
              detected_at_t = test_result_timing <= 0 | contact_tracing_results_timing <= 0 | (random_test_yn & random_test_timing <= 0),
              in_testing_at_t = 
                if_else(
                  !detected_at_t | is.na(detected_at_t),
                  (self_test_yn & symptom_timing <= 0 & test_result_timing > 0) | 
                    (contact_tracing_test_timing <= 0 & contact_tracing_results_timing > 0) | 
                    random_test_yn & random_test_timing > 0,
                  FALSE
                ),
              undetected_at_t = 
                (!self_test_yn | symptom_timing > 0) &   # not (yet) detected through self testing
                (is.na(contact_tracing_test_timing) | contact_tracing_test_timing > 0) &   # not detected through contact tracing
                (!random_test_yn | is.na(random_test_yn))   # not detected through random testing
            ) %>% 
            mutate(across(c(detected_at_t, undetected_at_t, in_testing_at_t), true_false)) #%>% 
            # count_print(detected_at_t & undetected_at_t) #%>%
            # count_prop(
            #   detected_at_t,
            #   in_testing_at_t,
            #   undetected_at_t
            # )# %>%
            #view_filter(!detected_at_t & !undetected_at_t & !in_testing_at_t)
          
          n_detected <- sum(live_cases_w_detected$detected_at_t, na.rm = TRUE)
          n_in_testing <- sum(live_cases_w_detected$in_testing_at_t, na.rm = TRUE)
          n_undetected <- sum(live_cases_w_detected$undetected_at_t, na.rm = TRUE)
          
          if (nrow(live_cases_w_detected) != n_detected + n_in_testing + n_undetected) {
            warning(paste0("detected counter is going wrong : n_cases = ", nrow(live_cases_w_detected), " and cases counted in detected is ", n_detected + n_in_testing + n_undetected))
          }
          
          # Updated secondary cases 
          secondary_cases_w_new <- cases_secondary_all %>% 
            filter(!new_potential_case) %>%      # remove the cases that would have materialised this period
            bind_rows(new_secondary_cases)
          
          # Updated ("OLD") secondary cases i.e. ones that have already been realised, but may be required to 
          # change the contact_tracing time in the future
          secondary_cases_old_w_new <- bind_rows(
            secondary_cases_old,
            cases_secondary_all %>% filter(new_potential_case)
          )
            
          
        
      # (4) UPDATE COUNTERS
      counters <- counters %>% 
        mutate(
          t = t + dt + params$dt_approx,
          n_susceptible = counters$n_susceptible - n_new_cases,
          n_cases_live = nrow(live_cases_w_new),
          n_recovered = counters$n_recovered + n_new_recoveries,
          n_cases_cum = counters$n_cases_cum + n_new_cases,
          n_pop = n_susceptible + n_cases_live + n_recovered,
          n_detected = !!n_detected,
          n_in_testing = !!n_in_testing,
          n_undetected = !!n_undetected
        )
          
      # n_susceptible <- n_susceptible - n_new_cases
      # n_cases_live <- nrow(live_cases_w_new)
      # n_recovered <- n_recovered + n_new_recoveries
      # n_cases_cum <- n_cases_cum + n_new_cases
      
      if (n_pop != counters$n_pop) warning("Population size seems to have changed...?")
      
      return(
        list(
          # cases_df = cases_t, 
          live_cases = live_cases_w_new,
          secondary_cases = secondary_cases_w_new,
          secondary_cases_old = secondary_cases_old_w_new,
          counters = counters,
          # t = t,
          # n_susceptible = n_susceptible,
          # n_cases_live = n_cases_live,
          # n_recovered = n_recovered,
          # n_cases_cum = n_cases_cum,
          n_pop = n_pop,
          model_end = FALSE,
          params = params
        )
      )
      
    }
    
  
    # speedy_test_params <- outbreak_sims_by_params(
    #   n_sims = 10, dt_approx = 1, n_iterations = 20,
    #   probs_self_test = list(c(0.2, 0.5, 0.8, 0.9, 1)), 
    #   probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
    #   probs_isolate_test = list(c(0.4, 0.6, 0.9, 0.95, 0.99)), 
    #   p_contact_if_isolated = 0.2, 
    #   p_contact_traced = c(0.1, 0.9),
    #   test_result_delay_val = 2,
    #   recov_val = 5, r0 = 2, dispersion = 0.16
    # )
    # 
    # plot(speedy_test_params, param_group = p_contact_traced)
    
  
    # Check one step function
    # outbreak_step(outbreak_setup(), dt_approx = 1) %>% outbreak_step()
    
    
    # Run a single simulation 
    outbreak_sim <- function(n_initial_cases = 100, n_pop = 10000, n_iterations = 100, ...) {
      
      # TESTING: n_initial_cases = 100; n_pop = 10000; dt_approx = 1; n_iterations = 100
      
      # START UP
      cases_record <- outbreak_setup(n_initial_cases = n_initial_cases, n_pop = n_pop, ...)
      cases_time_series <- list(
        cases_record$counters
      )
      
      # LOOP ROUND n_iterations
      for (i in 1:n_iterations) {
        
        # if(i %% 100 == 0) print(i)
        cases_record <- outbreak_step(cases_record)
        
        # cases_time_series[[i]] <- tibble(t = cases_record$t, 
        #                                  n_susceptible = cases_record$n_susceptible,
        #                                  n_cases_live = cases_record$n_cases_live,
        #                                  n_recovered = cases_record$n_recovered,
        #                                  n_cases_cum = cases_record$n_cases_cum)
        cases_time_series[[i + 1]] <- cases_record$counters
        
        if (cases_record$model_end == TRUE) break
        
      }
      
      out <- list(
        outbreak_t = cases_record,
        time_series = cases_time_series %>% bind_rows()
      )
      
      return(out)
      
    }
    
    speedy_test <- outbreak_sim(dt_approx = 1, n_iterations = 10,
                                test_result_delay_val = 2, 
                                p_contact_if_isolated = 0.2, 
                                p_contact_traced = 0.4,
                                probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9), 
                                probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
                                probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99), 
                                alpha = 0.2,
                                recov_val = 7, r0 = 2, dispersion = 0.16)
    

    


    
    
    # RUN MULTIPLE SIMULATIONS
    outbreak_sims <- function(n_sims, ...) {
      loop_list <- list()
      
      for (i in 1:n_sims) {
        print(paste0("Running simulation ", i, " of ", n_sims))
        loop_list[[i]] <- outbreak_sim(...)
      }
  
      outbreak_t <- loop_list %>% map("outbreak_t")

      time_series <- loop_list %>% map("time_series") %>%
        bind_rows(.id = "sim_id")

      out <- list(
        outbreak_t = outbreak_t,
        params = outbreak_t[[1]]$params,
        time_series = time_series
      )
      
      class(out) <- c("outbreak_sims")
      
      return(out)

    }
    
    
    # epidemic_0.1_multi <- outbreak_sim(20, cases_start = cases_0, dt_approx = 0.1, t_max = 100)
    
    

    
    # Function for testing the effect of different parameters
    outbreak_sims_by_params <- function(...) {
      crossing(...) %>% 
        mutate(epidemic_results = pmap(., outbreak_sims)) %>%
        "class<-"(c("outbreak_sims_by_params", "tbl_df", "tbl", "data.frame"))
    }
    
    clean_up_group_names <- function(x) {
      if (is_double(x)) factor(x)
      else if (is_list(x)) map_chr(x, paste0, collapse = "_")
    }
    
    quantile_summarise <- function(data, ..., conf_level = 0.95) {
      conf_lower <- (1 - conf_level) / 2
      conf_upper <- 1 - conf_lower
      
      data %>% 
        summarise(
          across(...,
                 list(mean = ~ mean_na(.x),
                      median = ~ median_na(.x),
                      upper = ~ quantile(.x, conf_upper, na.rm = TRUE),
                      lower = ~ quantile(.x, conf_lower, na.rm = TRUE)))
        )
    }
    
    
    
    plot.outbreak_sims <- function(data, indiv_sims = FALSE, conf_level = 0.95) {
      
      if (!indiv_sims) {
        data %>% 
          .$time_series %>% 
          # mutate(new_cases = n_cases_cum - lag(n_cases_cum),
          #        new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>%
          # group_by(sim_id) %>%
          group_by(t) %>% 
          select(t, sim_id, n_cases_live) %>% 
          filter(!is.na(n_cases_live)) %>% 
          # summarise(
          #   across(n_cases_live, 
          #          list(median = ~ median(.x),
          #               upper_95 = ~ quantile(.x, 0.975),
          #               lower_95 = ~ quantile(.x, 0.025)))
          # ) %>% 
          quantile_summarise(n_cases_live, conf_level = conf_level) %>% 
          ungroup %>% 
          ggplot(aes(x = t)) + 
          geom_line(aes(y = n_cases_live_median), size = 1.3) + 
          geom_ribbon(aes(ymax = n_cases_live_upper, ymin = n_cases_live_lower), alpha = 0.3) + 
          theme_custom() + theme(legend.position = "top")
        
      } else if (indiv_sims) {
        data$time_series %>% 
          group_by(sim_id) %>% 
          # filter(t < 100) %>%
          # mutate(new_cases = n_cases_cum - lag(n_cases_cum),
          # new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>% 
          ggplot(aes(x = t, y = n_cases_live, colour = sim_id)) + 
          geom_line(alpha = 0.4, show.legend = FALSE)
      }
      
      
    }
    
    
    
    
    
    plot.outbreak_sims_by_params <- function(data, param_groups, conf_level = 0.95, indiv_sims = FALSE) {
      
      # if (missing(param_group)) stop("param_group is missing")
      param_groups_syms <- syms(param_groups)
      
      data_time_series <- data %>% 
        mutate(time_series = map(epidemic_results, "time_series")) %>% 
        unnest(time_series) %>% 
        mutate(param_group = paste(!!!param_groups_syms, sep = "_"))
    
      if (!indiv_sims) {
        
        

        data_time_series %>%
          # mutate("{{param_group}}" := factor({{param_group}})) %>%
          # mutate("{{param_group}}" := map_chr({{param_group}}, str_c, collapse = "_")) %>%
          group_by(param_group, sim_id) %>%
          # mutate(new_cases = n_cases_cum - lag(n_cases_cum),
          #        new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>%
          group_by(param_group, t) %>%
          select(t, sim_id, n_cases_live) %>%
          filter(!is.na(n_cases_live)) %>%
          quantile_summarise(n_cases_live, conf_level = conf_level) %>% 
          # summarise(
          #   across(n_cases_live,
          #          list(median = ~ median(.x),
          #               upper = ~ quantile(.x, conf_upper),
          #               lower = ~ quantile(.x, conf_lower)))
          # ) %>%
          ungroup %>%
          ggplot(aes(x = t, group = param_group)) +
          geom_line(aes(y = n_cases_live_median,
                        colour = param_group), size = 1.3) +
          geom_ribbon(aes(ymax = n_cases_live_upper, ymin = n_cases_live_lower,
                          fill = param_group), alpha = 0.3) +
          theme_custom() + theme(legend.position = "top")
      } else if (indiv_sims) {

        data_time_series %>%
          mutate(sim_id_group = paste0(sim_id, param_group)) %>%
          ungroup %>%
          ggplot(aes(x = t, y = n_cases_live, colour = param_group, group = sim_id_group)) +
          geom_line(alpha = 0.4, show.legend = FALSE)

      }
    }
    
    plot(data = speedy_test_params, param_groups = c("p_contact_traced", "probs_self_test"), indiv_sims = FALSE)
    
    
    

      
    
    plot_detected <- function(data, prop = FALSE) {
      UseMethod("plot_detected")
    }
    
    plot_detected.outbreak_sims <- function(data, prop = FALSE) {
      # data <- epidemic_1_multi
      
      data_detected <- data$time_series %>% 
        # mutate(
        #   across(c(n_detected, n_in_testing, n_undetected), list(prop = ~ . / n_cases_live))
        # ) %>%
        pivot_longer(c(n_detected, n_in_testing, n_undetected)) %>% 
        group_by(t, name) %>% 
        summarise(
          across(value, 
                 list(median = ~ median(.x),
                      upper_95 = ~ quantile(.x, 0.975),
                      lower_95 = ~ quantile(.x, 0.025)))
        )
        
      if (prop) {
        data_detected <- data_detected %>% group_by(t) %>% 
          mutate(across(-c(t, name), ~ . / sum(.))) %>% 
          ungroup()
      }
        

      ggplot(data_detected, aes(x = t, y = value_median, fill = name)) + 
        geom_area()
      
    }
    
    plot_detected(epidemic_1_multi, prop = FALSE)
    
    print.outbreak_sims <- function(data) {
      print(str_1(data))
      print(data$time_series)
    }
    
    
    # print.outbreak_sims_by_params <- function(data) {
    #   print(str_1(data))
    #   print(
    #     data %>% 
    #       mutate(time_series = map(epidemic_results, "time_series")) %>% 
    #       unnest(time_series)
    #   )
    # }
    
      
    
    
    
    
   
  
    
    

# ... ---------------------------------------------------------------------


# TRIALS AND RESULTS ------------------------------------------------------


# Speedy test -------------------------------------------------------------

    
    speedy_test <- outbreak_sims(n_sims = 1, dt_approx = 1.5, n_iterations = 20,
                                 test_result_delay_val = 2, 
                                 p_contact_if_isolated = 0.2, 
                                 p_contact_traced = 0.4,
                                 probs_self_test = c(0, 0.4, 0.6, 0.8, 0.9), 
                                 alpha = 0.2,
                                 probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
                                 probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99), 
                                 recov_val = 7, r0 = 5, dispersion = 0.16)
    
    
    
    
    
    plot(speedy_test, indiv_sims = FALSE)
    
    epidemic_1_multi <- outbreak_sims(n_sims = 10, dt_approx = 1.5, n_iterations = 40,
                                      p_contact_if_isolated = 0.2, 
                                      p_contact_traced = 0.1,
                                      probs_self_test = c(0, 0.6, 0.8, 0.9, 1), 
                                      probs_isolate_symptoms = c(0, 0.04, 0.1, 0.15, 0.4),
                                      probs_isolate_test = c(0.4, 0.6, 0.9, 0.95, 0.99), 
                                      test_result_delay_val = 2, 
                                      alpha = 0.05,
                                      recov_val = 7, r0 = 5, dispersion = 0.16)
    
    
    epidemic_1_multi$time_series %>% print(n = 100)
    plot(epidemic_1_multi, indiv_sims = FALSE, conf_level = 0.95)
    
    plot_detected(epidemic_1_multi, prop = TRUE)
    
    
    # Test single sim function
    # epidemic_1 <- outbreak_sim(dt_approx = 1, n_iterations = 100)
    # 
    # epidemic_1$time_series %>% 
    #   # mutate(n_recovered_cross_check = n_cases_cum - n_cases_live) %>% 
    #   # print(n = 100)
    #   select(-n_cases_cum) %>%
    #   pivot_longer(-t) %>% 
    #   plot_line_grouped(t, value, name)
    # 
    # # epidemic_0.1 <- outbreak_sim(dt_approx = 0.1, n_iterations = 10000)
    # # epidemic_1 <- outbreak_sim(dt_approx = 1, n_iterations = 100)
    
    
    
    
    
    
    
    
    # Plot individual sim paths
    epidemic_1_multi$time_series %>% 
      group_by(sim_id) %>% 
      # filter(t < 100) %>%
      # mutate(new_cases = n_cases_cum - lag(n_cases_cum),
             # new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>% 
      ggplot(aes(x = t, y = n_cases_live, colour = sim_id)) + 
      geom_line(alpha = 0.4, show.legend = FALSE)
    
    
    # Summarise the sim paths
    summary_paths <- epidemic_1_multi$time_series %>% 
      group_by(sim_id) %>% 
      mutate(new_cases = n_cases_cum - lag(n_cases_cum),
             new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>%
      group_by(t) %>% 
      select(t, sim_id, new_cases_week) %>% 
      filter(!is.na(new_cases_week)) %>% 
      summarise(
        across(new_cases_week, 
               list(median = ~ median(.x),
                    upper_95 = ~ quantile(.x, 0.975),
                    lower_95 = ~ quantile(.x, 0.025)))
      )
    
    
    summary_paths %>% 
      filter(t < 100) %>% 
      ggplot(aes(x = t)) + 
      geom_line(aes(y = new_cases_week_median), colour = "indianred", size = 1.3) + 
      geom_ribbon(aes(ymax = new_cases_week_upper_95, ymin = new_cases_week_lower_95), alpha = 0.3, fill = "indianred") + 
      theme_custom()
    
    
    
    plot(speedy_test_params, param_group = p_contact_traced, indiv_sims = FALSE)
    
    speedy_test_params %>% 
      mutate(time_series = map(epidemic_results, "time_series")) %>% 
      unnest(time_series) %>% 
      mutate(sim_id_group = paste0(sim_id, p_contact_traced)) %>% 
      # group_by(sim_id) %>% 
      # # filter(t < 100) %>%
      # # mutate(new_cases = n_cases_cum - lag(n_cases_cum),
      # # new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>% 
      ggplot(aes(x = t, y = n_cases_live, colour = factor(p_contact_traced), group = sim_id_group)) + 
      geom_line(alpha = 0.4, show.legend = FALSE)
      
    

# Look at parameter effects 1 by 1 ----------------------------------------
    
    
    

    
    # PROBABILITY OF TESTING (for given symptoms) - lower values means more cases
    probs_self_test_default <- c(0, 0.04, 0.1, 0.15, 0.4)
    
    # SPEEDY 
    speedy_test_params <- outbreak_sims_by_params(
      n_sims = 2, dt_approx = 1, n_iterations = 5,
      probs_self_test = list(probs_self_test_default * 0.2, probs_self_test_default * 1), 
      probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
      probs_isolate_test = list(c(0.4, 0.6, 0.9, 0.95, 0.99)), 
      alpha = 0.1,
      p_contact_if_isolated = 0.2, 
      p_contact_traced = c(0.1, 0.9),
      test_result_delay_val = 0,
      recov_val = 5, r0 = 2, dispersion = 0.16
    )
    
    speedy_test_params %>% 
      mutate(time_series = map(epidemic_results, "time_series")) %>% 
      unnest(time_series) %>% 
      # mutate("{{param_group}}" := factor({{param_group}})) %>% 
      mutate(probs_self_test := map_chr(probs_self_test, str_c, collapse = "_"))
    
    plot(speedy_test_params, p_contact_traced, probs_self_test, indiv_sims = TRUE)
    
    
    
    
    # PROBABILITY OF SELF-TESTING - if people are more likely to get tested, the virus spreads less
    effect_probs_self_test <- outbreak_sims_by_params(
      n_sims = 20, dt_approx = 1, n_iterations = 60,
      probs_self_test = list(probs_self_test_default * 0.2, probs_self_test_default * 1, probs_self_test_default * 2.5), 
      probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
      probs_isolate_test = list(c(0.4, 0.6, 0.9, 0.95, 0.99)), 
      test_result_delay_val = 0,
      alpha = 0.1,
      p_contact_traced = 0.2,
      recov_val = 5, r0 = 2, dispersion = 0.16,
      p_contact_if_isolated = c(0.1)
    )
    
    plot(effect_probs_self_test, #%>% mutate(probs_self_test = map_chr(probs_self_test, ~ str_c(., collapse = "_"))), 
         param_group = "probs_self_test", indiv_sims = FALSE,
         conf_level = 0.5)
    
    
    # PROBABILITY OF ISOLATING - if people are less likely to isolate, the virus spreads more
    effect_probs_isolate_symptoms <- outbreak_sims_by_params(
      n_sims = 10, dt_approx = 1, n_iterations = 10,
      probs_self_test = list(probs_self_test_default), 
      probs_isolate_symptoms = list(probs_self_test_default, c(0.7, 0.8, 0.9, 1, 1)),
      probs_isolate_test = list(c(0.4, 0.6, 0.9, 0.95, 0.99)),
      test_result_delay_val = 0,
      recov_val = 5, r0 = 2, dispersion = 0.16,
      p_contact_if_isolated = c(0.1)
    )
    
    plot(effect_probs_isolate_symptoms, probs_isolate_symptoms)
    
    # PROBABILITY OF ISOLATING AFTER TEST - if people are less likely to isolate, the virus spreads more
    effect_probs_isolate_test <- outbreak_sims_by_params(
      n_sims = 10, dt_approx = 1, n_iterations = 10,
      probs_self_test = list(0.5 + (1:5) / 10), 
      probs_isolate_symptoms = list(probs_self_test_default),
      probs_isolate_test = list(1:5 / 10, c(1, 1, 1, 1, 1)),
      test_result_delay_val = 0,
      recov_val = 5, r0 = 2, dispersion = 0.16,
      p_contact_if_isolated = c(0.1)
    )
    
    plot(effect_probs_isolate_test, probs_isolate_test)
    
    
    
    
    # test_result_delay - higher means worse outbreak
    effect_test_result_delay <- outbreak_sims_by_params(
      n_sims = 10, dt_approx = 1, n_iterations = 20, test_thresh = 0.4, p_contact_if_isolated = 0.2,
      test_result_delay_val = c(0, 1, 3, 5)
    )
    
    plot(effect_test_result_delay, param_group = test_result_delay_val)
    
    
    # P_CONTACT_IF_ISOLATED - higher should mean worse outbreak
    effect_isolated <- outbreak_sims_by_params(
      n_sims = 20, dt_approx = 1, n_iterations = 40, 
      probs_self_test = list(probs_self_test_default) ,    # << high probability of testing 
      probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
      probs_isolate_test = list(c(0.6, 0.6, 0.9, 0.95, 0.99)), 
      p_contact_if_isolated = 0.1, 
      p_contact_traced = 0.2,
      test_result_delay_val = c(0, 1, 3, 5, 10),
      recov_val = 5, r0 = 2, dispersion = 0.16
    )
    
    plot(effect_isolated, p_contact_if_isolated)
    
    
    # R0 - higher R0 is worse
    effect_r0 <- outbreak_sims_by_params(
      n_sims = 20, dt_approx = 1, n_iterations = 50, test_thresh = 0.35, p_contact_if_isolated = 0.35,
      test_result_delay_val = 2, recov_val = 7, dispersion = 0.16, r0 = c(0.8, 1.5, 2.5, 5)
    )
    
    plot(effect_r0, r0)
    
    
    
    # Recov val - higher recov_val is worse (slower recovery, more infectiousness)
    effect_recov_val <- outbreak_sims_by_params(
      n_sims = 20, dt_approx = 1, n_iterations = 50, test_thresh = 0.35, p_contact_if_isolated = 0.35,
      test_result_delay_val = 2, recov_val = c(3, 6.5, 10), dispersion = 0.16, r0 = 2
    )
    
    plot(effect_recov_val, recov_val)
    
    
    
    # Contact tracing effectiveness - higher p means fewer cases. 
    # You need to have a high probability of getting tested otherwise contact tracing is basically useless
    effect_contact_tracing_prob <- outbreak_sims_by_params(
      n_sims = 30, dt_approx = 1, n_iterations = 30,
      probs_self_test = list(c(0.2, 0.5, 0.8, 0.9, 1)) ,    # << high probability of testing 
      probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
      probs_isolate_test = list(c(0.4, 0.6, 0.9, 0.95, 0.99)), 
      p_contact_if_isolated = 0.1, 
      p_contact_traced = c(0.1, 0.4, 0.9),
      test_result_delay_val = 2,
      recov_val = 5, r0 = 2, dispersion = 0.16
    )
    
    plot(effect_contact_tracing_prob, p_contact_traced)
    
    effect_contact_tracing_prob$epidemic_results[[1]]$outbreak_t[[20]]$live_cases %>% 
      view()
    
    
    
    # Effect of alpha
    effect_random_testing <- outbreak_sims_by_params(
      n_sims = 30, dt_approx = 1, n_iterations = 30,
      probs_self_test = list(c(0.2, 0.5, 0.8, 0.9, 1)) ,    # << high probability of testing 
      probs_isolate_symptoms = list(c(0, 0.04, 0.1, 0.15, 0.4)),
      probs_isolate_test = list(c(0.7, 0.8, 0.9, 0.95, 0.99)), 
      p_contact_if_isolated = 0.1, 
      p_contact_traced = 0.3,
      test_result_delay_val = 2,
      alpha = c(0, 0.3, 0.6),
      recov_val = 5, r0 = 3, dispersion = 0.16
    )
    
    plot(effect_random_testing, param_group = alpha)
    
    
    
  d <- 1/100
  g <- 1/10
  
  p <- d / (d + g) %>% print()  
    
    
    
    
    
    

# Other tests -------------------------------------------------------------


    
    
    
    
    
    
    # bind_rows(list(`0.1` = epidemic_0.1_multi, `1` = epidemic_1_multi), .id = "sim_type") %>% 
      # mutate(sim_unique_id = paste0(sim_type, "_", sim_id)) %>% 
    
    # CUMULATIVE CASES
    epidemic_1_multi %>% 
      ggplot(aes(x = t, y = n_cases, colour = sim_id)) + 
      geom_line(alpha = 0.4, show.legend = FALSE)
    
    epidemic_1_multi %>% 
      group_by(sim_id) %>% 
      mutate(new_cases = n_cases - lag(n_cases),
             new_cases_week = rollsum(new_cases, 7, align = "right", na.pad = TRUE)) %>% 
      ggplot(aes(x = t, y = new_cases_week, colour = sim_id)) + 
      geom_line(alpha = 0.4, show.legend = FALSE)
      
    
    
    
    cases_time_series %>% bind_rows() %>% 
      mutate(week = floor(t / 7)) %>% 
      group_by(week) %>% 
      summarise(n_new_cases = max(n_cases) - min(n_cases)) %>% 
      plot_line(week, n_new_cases)
    
    
    
    
    
    
    
    

    
    