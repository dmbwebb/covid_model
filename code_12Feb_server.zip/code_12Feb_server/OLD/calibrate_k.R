d <- tibble(
  contacts = rnbinom(100000, size = 0.5, mu = 20)
) %>% 
  mutate(infections = rbinom(100000, size = contacts, prob = 0.2)) %>% 
  hist_basic(infections)


# install.packages("VGAM")
library("VGAM")


reg_contacts <- vglm(contacts ~ 1, negbinomial, data = d)
summary(reg_contacts)
exp(reg_contacts@coefficients[[1]])
exp(reg_contacts@coefficients[[2]])


reg_infections <- vglm(infections ~ 1, negbinomial, data = d)
exp(reg_infections@coefficients[[1]])
exp(reg_infections@coefficients[[2]]) # same k ! for the infections as compared to the contacts, which is great news
