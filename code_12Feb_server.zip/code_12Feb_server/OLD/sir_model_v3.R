
# Setup -------------------------------------------------------------------

    library(deSolve)
    library(tidyverse)
    source("~/Desktop/functions.R")
    library(nloptr)

theme_custom <- function(...) {
  theme_light() + 
    theme(plot.background = element_blank(),
          strip.background=element_rect(fill="#D1E0E6"), 
          strip.text = element_text(color = "black"),
          ...)
}

# Plotting functions ------------------------------------------------------

    
    plot_sir <- function(sir_values) {
      sir_values %>% 
        pivot_longer(-time) %>% 
        # filter(name == "I") %>%
        ggplot(aes(x = time, y = value)) + 
        geom_line(aes(colour = name))
    }
    
    plot_sir(sir_values_with_demo)
    
    
    plot_line <- function(dat, x, y) {
      ggplot(dat, aes(x = {{x}}, y = {{y}}))  + 
        geom_line()
    }
    
    plot_line_grouped <- function(dat, x, y, group) {
      ggplot(dat, aes(x = {{x}}, y = {{y}}, colour = {{group}})) + 
        geom_line()
    }
    
    plot_area <- function(dat, x, y, group) {
      ggplot(dat, aes(x = {{x}}, y = {{y}}, fill = {{group}})) + 
        geom_area()
    }
    
    
    plot_contours <- function(dat, x, y, z) {
      ggplot(dat, aes(x = {{x}}, y = {{y}}, z = {{z}})) + 
        geom_contour_filled(show.legend = TRUE)
    }
    
    

# …………. -------------------------------------------------------------------

# 2. ONE GROUP CONTACT TRACING MODEL --------------------------------------


    source("~/Desktop/functions.R")
    
    # Basic contact tracing model
    # sir_contact_tracing <- function(time, variables, parameters) {
    #   with(as.list(c(variables, parameters)), {
    #     dS <- nu  -   (beta * I * S) - (theta * D * S)   -     mu * S
    #     dI <- (beta * I * S) + (theta * D * S)   - delta * I - (kappa * lambda) * D  - gamma * I -     mu * I
    #     dD <- delta * I + (kappa * lambda * D)  - (tau * D) - mu * D
    #     dR <-  gamma * I   + tau * D  - mu * R
    #     # dN <- nu  - mu 
    #     return(list(c(dS, dI, dD, dR)))
    #   })
    # } 
    
    
    # Now with tau = gamma
    sir_contact_tracing <- function(time, variables, parameters) {
      with(as.list(c(variables, parameters)), {
        dS <- nu  -   (beta * I * S) - (theta * D * S)   -     mu * S
        dI <- (beta * I * S) + (theta * D * S)   - delta * I - (kappa * lambda) * D  - gamma * I -     mu * I
        dD <- delta * I + (kappa * lambda * D)  - (gamma * D) - mu * D
        dR <-  gamma * I   + gamma * D  - mu * R
        # dN <- nu  - mu 
        return(list(c(dS, dI, dD, dR)))
      })
    } 
    
    
    # Function with adaptive lambda
    sir_contact_tracing_adaptive_lambda <- function(time, variables, parameters) {
      with(as.list(c(variables, parameters)), {
        dS <- nu  -   (beta * I * S) - (theta * D * S)   -     mu * S
        dI <- (beta * I * S) + (theta * D * S)   - delta * I - (kappa * (sigma + I * (1 - sigma)) * D)  - gamma * I -     mu * I
        dD <- delta * I + (kappa * (sigma + I * (1 - sigma)) * D)  - (tau * D) - mu * D
        dR <-  gamma * I   + tau * D  - mu * R
        # dN <- nu  - mu 
        return(list(c(dS, dI, dD, dR)))
      })
    } 
    
    # calc_tau <- function(sigma, testing_rate, gamma) {
    #   
    #   ((1/gamma) - (1/testing_rate) - (1/sigma))^(-1)
    #   
    # }
    
    # calc_tau(sigma = 0.5, testing_rate = 0.05, gamma = 1/10)
    
    # FUNCTION WITH proper recovery rates
    # sir_contact_tracing_recovery_rates <- function(time, variables, parameters) {
    #   with(as.list(c(variables, parameters)), {
    #     
    #     # https://stackoverflow.com/questions/43005101/change-parameter-values-at-time-step-in-desolve
    #     tau_self <- 
    #     
    #     
    #     dS <- nu  -   (beta * I * S) - (theta * D * S)   -     mu * S
    #     dI <- (beta * I * S) + (theta * D * S)   - delta * I - (kappa * (sigma + I * (1 - sigma)) * D)  - gamma * I -     mu * I
    #     dD <- delta * I + (kappa * (sigma + I * (1 - sigma)) * D)  - (tau * D) - mu * D
    #     dR <-  gamma * I   + tau * D  - mu * R
    #     # dN <- nu  - mu 
    #     return(list(c(dS, dI, dD, dR)))
    #   })
    # } 
    
    
    
    
    
    

# Function for generating a simulation (one group) ------------------------


    
    new_sim_single <- function(beta  = 0.5 ,# infectious rate/day
                               theta = 0.5/3,
                               gamma = 1/10  , # recovery rate/day (10 days duration)
                               alpha = 0.1, 
                               pi = 0.1,
                               rho = 0.02,
                               omega = 0.5,
                               # delta = 20/365 , # self diagnosis rate / day  
                               # tau = 0.5  , # leaving quarantine     (5 day duration)
                               kappa =  0.05  ,          # contact tracing per person per day
                               lambda = 0.2,
                               sigma = 0.1,
                               nu = 15/1000 * (1/365)      ,  # birth rate / day
                               mu = 15/1000 * (1/365) ,
                               adaptive_lambda = FALSE,
                               epidemic_threshold = 0.001,
                               allow_negative_I = TRUE,
                               sim_res = 1) {
      
      initial_values <- c(
        S = 0.999,  # susceptibles
        I =   0.001,  # infectious
        D = 0,
        R =   0   # recovered (immune)
        # N = 1000
      )
      
      delta <- min(c(pi * omega, 1)) + alpha
      
      parms <- c(
        beta  =  beta,
        theta =  theta,
        gamma =  gamma,
        delta =  delta,
        # tau =    tau,
        kappa =  kappa,
        sigma = sigma,
        lambda = lambda,
        nu =     nu,
        mu =     mu
      )
      
      require(deSolve)
      
      # Basic SIR with contact tracing
      if (adaptive_lambda == FALSE) {
        results <- ode(
          y = initial_values,
          times = seq(0, 300, sim_res),
          func = sir_contact_tracing,
          parms = parms 
        )
      } else if (adaptive_lambda == TRUE) {
        results <- ode(
          y = initial_values,
          times = seq(0, 300, sim_res),
          func = sir_contact_tracing_adaptive_lambda,
          parms = parms 
        )
      }
      
      results <- results %>% as.data.frame() %>% as_tibble() %>% 
        mutate(epidemic = I > epidemic_threshold)
      
      min_I <- min(results$I)
      
      if (allow_negative_I) {
        if (min_I < 0) warning(paste0("I goes negative : ", round(min_I, 4), " (4d.p.)"))
      } else if (!allow_negative_I) {
        if (min_I < 0) stop(paste0("I goes negative : ", round(min_I, 4), " (4d.p.)"))
      }
      
      # if (tau - kappa * lambda < 0) warning("tau - kappa * lambda < 0")
      
      plot <- plot_sir(results %>% select(-epidemic))
      
      outcomes <- results %>% 
        summarise(
          time_epidemic_end =  max_na(time[epidemic]),
          peak_val =  max_na(I + D),
          time_peak =  time[I + D == peak_val],
          prop_infected = 1 - min_na(S)
        )
      
      output <- tibble(
        results = list(results),
        plot = list(plot),
        outcomes = list(outcomes),
        beta  =  beta,
        theta =  theta,
        gamma =  gamma,
        alpha = alpha,
        pi = pi,
        rho = rho,
        omega = omega,
        delta =  delta,
        # tau =    tau,
        kappa =  kappa,
        sigma = sigma,
        lambda = lambda,
        nu =     nu,
        mu =     mu,
        adaptive_lambda = adaptive_lambda,
        allow_negative_I = allow_negative_I,
        epidemic_threshold = epidemic_threshold,
        sim_res = sim_res
        # tau_kappa_lambda = tau - kappa * lambda
      ) %>% 
        unnest(outcomes)
        
      class(output) <- c("sim_single", "tbl_df", "tbl", "data.frame")
        
      return(output)
      
      
    }

    
    new_sim_single() %>% 
      .$results %>% .[[1]] %>% 
      mutate(N = S + I + D + R) %>% 
      print(n = 100)
    
    tibble(x = 1) %>% attributes()
    
    
    
    
    
    
    test_tracing_1 <- test_tracing(beta = 0.2, adaptive_lambda = FALSE) %>% print
    test_tracing(beta = 0.5, sigma = 0.15, adaptive_lambda = TRUE) %>% print
    test_tracing(beta = 0.5, lambda = 0.15, adaptive_lambda = FALSE) %>% print
    

# Calculating R0 ----------------------------------------------------------

    calc_r0 <- function(sim) {
      UseMethod("calc_r0")
    }
    
    
    calc_r0.sim_single <- function(sim) {
      
      S <- 1
      
      # t_matrix <- matrix(c(beta * nu / mu , theta * nu / mu, 0, 0), 2, 2)
      t_matrix <- matrix(c(sim$beta * S, sim$theta * S, 0, 0), 2, 2)
      
      sig_matrix <- matrix(
        c(-(sim$delta + sim$gamma + sim$mu + sim$kappa * sim$lambda), sim$delta,
          -(sim$kappa * sim$lambda), (sim$kappa * sim$lambda) - sim$gamma), 2, 2
      )
      g_matrix <- t_matrix %*% - solve(sig_matrix)
      g_eigens <- eigen(g_matrix)
      (r0 <- max(g_eigens$values))
      
      r0
      
    }
    
    
    sim_test <- new_sim_single(beta = 0.8)
    calc_r0(sim_test)
    
    
    # sim <- new_sim_single()

# Calculate outcomes ------------------------------------------------------

    calc_outcome <- function(sim, outcome) {
      UseMethod("calc_outcome")
    }
    
    calc_outcome.default <- function(sim, outcome = "peak_val") {
      
      if (outcome == "prop_infected")  return(sim$prop_infected)
      else if (outcome == "peak_val") return(sim$peak_val)
      else if (outcome == "r0") return(calc_r0(sim))
      
    }
    
    calc_outcome(sim_test, outcome = "prop_infected")
    
    
    

# Plot --------------------------------------------------------------------

    plot.sim_single <- function(sim) {
      sim$plot[[1]]
    }
    
    plot.sim_multi <- function(sim) {
      sim$plot[[1]]
    }
    

# Calc costs --------------------------------------------------------------

    
    # Cost for each t - in a tibble
    calc_cost_t <- function(sim) {
      UseMethod("calc_cost_t")
    }
    
    
    calc_cost_t.sim_single <- function(sim) {
      # sim <- new_sim_single()
      # epidemic_threshold <- 0.001
      
      time_series <- sim$results[[1]]
      
      time_series %>% 
        mutate(
          cost_self = ((sim$pi  * I) + (sim$rho * (1 - I))) * sim$omega,
          cost_random = sim$alpha,
          cost_contact = sim$kappa * D
        ) %>% 
        mutate(across(starts_with("cost_"), ~ if_else(I <= sim$epidemic_threshold, 0, .x))) %>% 
        select(-epidemic)

    }
    
    
    # Aggregate cost by each type
    calc_cost_by_type <- function(sim) {
      UseMethod("calc_cost_by_type")
    }
    
    calc_cost_by_type.default <- function(sim) {
      calc_cost_t(sim) %>% 
        select(starts_with("cost_")) %>% 
        summarise(across(everything(), ~ sum(.x * sim$sim_res)))
    }
    
    calc_cost_by_type.sim_multi <- function(sim) {
      calc_cost_t(sim) %>% 
        select(starts_with("cost_")) %>% 
        summarise(across(everything(), ~ sum(.x * sim$sim_res))) %>% 
        mutate(
          cost_p = cost_self_p + cost_random_p + cost_contact_p,
          cost_r = cost_self_r + cost_random_r + cost_contact_r,
          cost_self = cost_self_p + cost_self_r,
          cost_random = cost_random_p + cost_random_r,
          cost_contact = cost_contact_p + cost_contact_r,
          cost_total = cost_self + cost_random + cost_contact
        )
    }
    
    # calc_cost_by_type(new_sim_multi())
    
    
    # By type as a proportion of K
    calc_cost_props <- function(sim, K) {
      UseMethod("calc_cost_props")
    }
    
    calc_cost_props.default <- function(sim, K) {
      calc_cost_by_type(sim) %>% 
        mutate(across(everything(), list(prop = ~ .x / K)))
    }
    
    # rm(calc_cost_props.sim_multi)
    
    # calc_cost_props.sim_multi <- function(sim, K) {
    #   calc_cost_by_type(sim) %>% 
    #     mutate(
    #       cost_p = cost_self_p + cost_random_p + cost_contact_p,
    #       cost_r = cost_self_r + cost_random_r + cost_contact_r,
    #       cost_self = cost_self_p + cost_self_r,
    #       cost_random = cost_random_p + cost_random_r,
    #       cost_contact = cost_contact_p + cost_contact_r,
    #       cost_total = cost_self + cost_random + cost_contact
    #     ) %>% 
    #     mutate(across(everything(), list(prop = ~ .x / K))) 
    # }
    
    
    
    
    # Total cost
    calc_cost_total <- function(sim) {
      UseMethod("calc_cost_total")
    }
    
    calc_cost_total.sim_single <- function(sim) {
      sum(calc_cost_by_type(sim))
    }
    
    calc_cost_total.sim_multi <- function(sim) {
      sim %>% 
        calc_cost_by_type() %>% 
        select(matches("cost_.*_(p|r)")) %>% 
        sum()
    }
    
    
    # Cost constraint
    calc_cost_constraint <- function(sim, K) {
      UseMethod("calc_cost_constraint")
    }
    
    calc_cost_constraint.default <- function(sim, K) {
      calc_cost_total(sim) - K
    }
    
    
    calc_cost_t(new_sim_single(sim_res = 0.5))
    calc_cost_by_type(new_sim_single(sim_res = 0.01))
    calc_cost_props(new_sim_single(), K = 20)
    calc_cost_total(new_sim_single(sim_res = 0.1))
    calc_cost_constraint(new_sim_single(), K = 5)
    
    

    



    
    
    r0_plot_data <- crossing(
      delta = seq(0, 200, 10) / 365,
      kappa = seq(0, 0.2, 0.1)
    ) %>% 
      mutate(
        sim = map2(delta, kappa, possibly(~ new_sim_single(delta = .x, kappa = .y), NA)),
        r0 = map_dbl(sim, possibly(calc_r0, NA_real_))
      )
    
    ggplot(r0_plot_data, aes(x = kappa, y = delta, z = r0)) + 
      geom_contour_filled(show.legend = TRUE)

    
   
    # Delta vs R0
    tibble(
      delta = seq(0, 200, 10) / 365
    ) %>% 
      mutate(
        sim = map(delta, possibly(~ new_sim_single(delta = .x), NA)),
        r0 = map_dbl(sim, possibly(calc_r0, NA_real_))
      ) %>% 
      plot_line(delta, - r0)
    
    


    
    

# Optimisations -----------------------------------------------------------

    
    calc_optimal_policy <- function(sim, K, x0, outcome) {
      UseMethod("calc_optimal_policy")
    }
    
    calc_optimal_policy.sim_single <- function(sim, K, x0, outcome) {
      
      # Need to allow x to change
      eval_sim <- function(x, sim) {
        alpha <- x[1]
        omega <- x[2]
        
        new_sim_single(
          alpha =  alpha, # **
          omega =  omega,   # **
          beta  =  sim$beta,
          theta =  sim$theta,
          gamma =  sim$gamma,
          pi =     sim$pi,
          rho =    sim$rho,
          # tau =    sim$tau,
          kappa =  sim$kappa,
          sigma =  sim$sigma,
          lambda = sim$lambda,
          nu =     sim$nu,
          mu =     sim$mu,
          adaptive_lambda = sim$adaptive_lambda,
          allow_negative_I = sim$allow_negative_I
        )
      }
      
      
      eval_outcome <- function(x, sim, K) {
        calc_outcome(
          eval_sim(x, sim),
          outcome = outcome
        )
      }
      
      
      eval_cost <- function(x, sim, K) {
        calc_cost_constraint(
          eval_sim(x, sim),
          K = K
        )
      }
      
      # eval_cost(x0, sim = sim, K = K)
      
      opt_results <- nloptr( x0= x0,
                             eval_f=eval_outcome,
                             # eval_grad_f=eval_grad_f0,
                             lb = c(0,0),
                             ub = c(Inf,1),
                             eval_g_ineq = eval_cost,
                             # eval_jac_g_ineq = eval_jac_g0,
                             opts = list(
                               "algorithm" = "NLOPT_LN_COBYLA",
                               # "algorithm" = "NLOPT_GN_ISRES",
                               "xtol_rel"=1.0e-4,
                               "print_level" = 1
                               # "check_derivatives" = TRUE,
                               # "check_derivatives_print" = "all"
                             ),
                             sim = sim,
                             K = K
      )
      
      alpha <- opt_results$solution[1]
      omega <- opt_results$solution[2]
      outcome_val <- opt_results$objective
      sim_updated <- new_sim_single(
        alpha =  alpha, # **
        omega =  omega,   # **
        beta  =  sim$beta,
        theta =  sim$theta,
        gamma =  sim$gamma,
        pi =     sim$pi,
        rho =    sim$rho,
        # tau =    sim$tau,
        kappa =  sim$kappa,
        sigma =  sim$sigma,
        lambda = sim$lambda,
        nu =     sim$nu,
        mu =     sim$mu,
        adaptive_lambda = sim$adaptive_lambda,
        allow_negative_I = sim$allow_negative_I
      )
      
      sim_updated$outcome_choice <- outcome
      sim_updated$outcome_val <- outcome_val
      
      return(sim_updated)
      
    }
    
    
    opt_test <- calc_optimal_policy(sim = new_sim_single(lambda = 0.01), K = 20, x0 = c(0.01, 0.1), outcome = "peak_val")
    
    
    opt_test %>% plot()
    
    calc_cost_by_type(opt_test)
    
    # optimise_other <- function(K = 10, pi = 0.2, rho = 0.1,
    #                            beta  = 0.5 ,# infectious rate/day
    #                            theta = 0.5/3,
    #                            gamma = 1/20  , # recovery rate/day (10 days duration)
    #                            tau = 0.5  , # leaving quarantine     (5 day duration)
    #                            kappa =  0.5  ,          # contact tracing per person per day
    #                            lambda = 0.2,
    #                            sigma = 0.1,
    #                            nu = 15/1000 * (1/365)      ,  # birth rate / day
    #                            mu = 15/1000 * (1/365),
    #                            allow_negative_I = FALSE, 
    #                            outcome = "prop_infected") {
    #   
    #   print("Running optimisation")
    #   
    #   opt_results <- nloptr( x0=c(0.001,1),
    #                          eval_f=outcomes_policy,
    #                          # eval_grad_f=eval_grad_f0,
    #                          lb = c(0,0),
    #                          ub = c(Inf,1),
    #                          eval_g_ineq = cost_sum_constraint,
    #                          # eval_jac_g_ineq = eval_jac_g0,
    #                          opts = list(
    #                            "algorithm" = "NLOPT_LN_COBYLA",
    #                            # "algorithm" = "NLOPT_GN_ISRES",
    #                            "xtol_rel"=1.0e-4,
    #                            "print_level" = 1
    #                            # "check_derivatives" = TRUE,
    #                            # "check_derivatives_print" = "all"
    #                          ),
    #                          K = K,
    #                          pi = pi,
    #                          rho = rho,
    #                          outcome = outcome,
    #                          beta = beta, theta = theta, gamma = gamma, tau = tau, kappa = kappa, lambda = lambda, nu = nu, mu = mu, allow_negative_I = allow_negative_I
    #   )
    #   
    #   return(
    #     list(
    #       alpha = opt_results$solution[1],
    #       omega = opt_results$solution[2],
    #       outcome = opt_results$objective
    #     )
    #   )
    #   
    #   
    # }
    
    
    
    
    
    
    
    

# Try optimisations -------------------------------------------------------

  
    solutions_single_by_K <- tibble(
      K = seq(0.2, 10, 3),
      outcome = "peak_val"
      # pi = 0.1, rho = 0, beta = 1, tau = 0.7, kappa = 0.05
    ) %>% 
      rowwise() %>% 
      mutate(sim_basic = list(new_sim_single()),
             sim_opt = list(calc_optimal_policy(sim_basic, K = K, x0 = c(0.0001, 0.6), outcome = "peak_val")))
    
    
    solutions_single_by_K %>% 
      select(-sim_basic) %>% 
      mutate(
        costs = list(calc_cost_props(sim_opt, K = K))
      ) %>% 
      ungroup %>% 
      unnest(costs) %>% 
      # unnest(sim_opt) %>%
      pivot_longer(starts_with("cost") & ends_with("prop")) %>% 
      ggplot(aes(x = log(K), y = value, fill = name)) + geom_area()
    
  



    
    
    

# ………………………….. ------------------------------------------------------------

# MULTI GROUP  ------------------------------------------------------------



    sir_contact_tracing_multi <- function(time, variables, parameters) {
      with(as.list(c(variables, parameters)), {
        dS_p <- nu * N_p / (N_p + N_r) -   (beta_pp * I_p * S_p) - (beta_pr * I_r * S_p) - (theta_pp * D_p * S_p) - (theta_pr * D_r * S_p)  -  mu * S_p
        dS_r <- nu * N_r / (N_p + N_r) -   (beta_rp * I_p * S_r) - (beta_rr * I_r * S_r) - (theta_rp * D_p * S_r) - (theta_rr * D_r * S_r)  -  mu * S_r
        dI_p <- (beta_pp * I_p * S_p) + (beta_pr * I_r * S_p) + (theta_pp * D_p * S_p) - (theta_pr * D_r * S_p)  - delta_p * I_p - (kappa * lambda_pp * D_p) - (kappa * lambda_pr * D_r) - gamma * I_p - mu * I_p
        dI_r <- (beta_rp * I_p * S_r) + (beta_rr * I_r * S_r) + (theta_rp * D_p * S_r) - (theta_rr * D_r * S_r)  - delta_r * I_r - (kappa * lambda_rp * D_p) - (kappa * lambda_rr * D_r) - gamma * I_r - mu * I_r
        dD_p <- delta_p * I_p + (kappa * lambda_pp * D_p) + (kappa * lambda_pr * D_r)  - (gamma * D_p) - mu * D_p
        dD_r <- delta_r * I_r + (kappa * lambda_rp * D_p) + (kappa * lambda_rr * D_r)  - (gamma * D_r) - mu * D_r
        dR_p <-  gamma * I_p   + gamma * D_p  - mu * R_p
        dR_r <-  gamma * I_r   + gamma * D_r  - mu * R_r
        dN_p <- 0
        dN_r <- 0
        return(list(c(dS_p, dS_r, dI_p, dI_r, dD_p, dD_r, dR_p, dR_r, dN_p, dN_r)))
      })
    }
    
    
    
    new_sim_multi <- function(beta_basic = 0.75,
                              theta_basic = 0.075,
                              phi = 1.5,            # controls beta matrix shape, > 1
                              psi = 0.7,       # degree of assortative matching
                              gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
                              alpha_p = 0.01,
                              alpha_r = 0.01,
                              omega = 1,
                              pi_p = 0.02,
                              pi_r = 0.05,
                              rho_p = 0.01,
                              rho_r = 0.02,
                              # tau = 0.7        ,     # leaving quarantine     (5 day duration)
                              kappa =  0.1   ,  # contact tracing per person per day
                              lambda_basic = 0.05     ,
                              # lambda_scalar_yn = FALSE,
                              nu = 15 / 1000 * (1 / 365)      , # birth rate / day
                              mu = 15 / 1000 * (1 / 365),
                              n_p = 0.5,
                              allow_negative_I = TRUE,
                              epidemic_threshold = 0.001, 
                              sim_res = 1) {
      
      
      n_r <- 1 - n_p
      
      initial_values <- c(
        S_p = (n_p - 0.0005),  # susceptibles
        S_r = (n_r - 0.0005),
        I_p =   0.0005,  # infectious
        I_r = 0.0005,
        D_p = 0,
        D_r = 0,
        R_p =   0,   # recovered (immune)
        R_r = 0,
        N_p = n_p,
        N_r = n_r
        # N = 1000
      )
      
      transmission_structure <- matrix(
        c(
          psi * phi^2,
          (1-psi) * phi,
          (1-psi) * phi,
          psi
        ),
        2, 2
      )
      
      if (theta_basic >= beta_basic) warning("theta_basic is >= than beta_basic")
      
      beta_matrix <- beta_basic * transmission_structure
      lambda_matrix <- lambda_basic * transmission_structure
      theta_matrix <- theta_basic * transmission_structure
      
      delta_p <- pi_p * omega + alpha_p
      delta_r <- pi_r * omega + alpha_r
      
      if (pi_p < rho_p) stop("pi_p < rho_p")
      if (pi_r < rho_r) stop("pi_r < rho_r")
      
      parms <- c(
        beta_pp = beta_matrix[1, 1],
        beta_pr = beta_matrix[1, 2], 
        beta_rp = beta_matrix[2, 1],
        beta_rr = beta_matrix[2, 2],
        # theta =  theta,
        gamma =  gamma,
        delta_p =  delta_p,
        delta_r =  delta_r,
        # tau =    tau,
        kappa =  kappa,
        lambda_pp = lambda_matrix[1, 1],
        lambda_pr = lambda_matrix[1, 2], 
        lambda_rp = lambda_matrix[2, 1],
        lambda_rr = lambda_matrix[2, 2],
        theta_pp = theta_matrix[1, 1],
        theta_pr = theta_matrix[1, 2], 
        theta_rp = theta_matrix[2, 1],
        theta_rr = theta_matrix[2, 2],
        nu =     nu,
        mu =     mu
      )
      
      require(deSolve)
      
      results <- ode(
        y = initial_values,
        times = seq(0, 300, sim_res),
        func = sir_contact_tracing_multi,
        parms = parms 
      ) %>% as.data.frame() %>% as_tibble() %>% 
        mutate(epidemic = I_p + I_r > epidemic_threshold) %>% 
        mutate(I_tot = I_p + I_r,
               S_tot = S_p + S_r,
               D_tot = D_p + D_r,
               R_tot = R_p + R_r)
      
      min_I_p <- min(results$I_p, na.rm = TRUE)
      min_I_r <- min(results$I_r, na.rm = TRUE)
      
      if (allow_negative_I) {
        if (min_I_p < 0) warning(paste0("I_p goes negative : ", round(min_I_p, 4), " (4d.p.)"))
        if (min_I_r < 0) warning(paste0("I_r goes negative : ", round(min_I_r, 4), " (4d.p.)"))
      } else if (!allow_negative_I) {
        if (min_I_p < 0) stop(paste0("I_p goes negative : ", round(min_I_p, 4), " (4d.p.)"))
        if (min_I_r < 0) stop(paste0("I_r goes negative : ", round(min_I_r, 4), " (4d.p.)"))
      }
      
      plot <- plot_sir(results %>% select(time, ends_with("tot")))
      
      outcomes <- results %>% 
        summarise(
          time_epidemic_end =  max_na(time[epidemic]),
          peak_val =  max_na(I_tot + D_tot),
          time_peak =  time[I_tot + D_tot == peak_val],
          prop_infected = 1 - min_na(S_tot)
        )
      
      
      output <- tibble(
        results = list(results),
        plot = list(plot),
        outcomes = list(outcomes),
        
        alpha_p = alpha_p,
        alpha_r = alpha_r,
        omega = omega,
      
        beta_basic = beta_basic,
        beta_matrix = list(beta_matrix),
        lambda_basic = lambda_basic,
        lambda_matrix = list(lambda_matrix),
        theta_basic = theta_basic,
        theta_matrix = list(theta_matrix),
        gamma =  gamma,
        delta_p =  delta_p,
        delta_r =  delta_r,
        phi = phi,
        psi = psi,
        pi_p = pi_p,
        pi_r = pi_r,
        rho_p = rho_p,
        rho_r = rho_r,
        # tau =    tau,
        kappa =  kappa,
        nu =     nu,
        mu =     mu,
        n_p = n_p,
        n_r = n_r,
        allow_negative_I = allow_negative_I,
        epidemic_threshold = epidemic_threshold,
        sim_res = sim_res
      ) %>% 
        unnest(outcomes)
      
      class(output) <- c("sim_multi", "tbl_df", "tbl", "data.frame")
      
      return(output)
      

      
      
    }
    
    bind_rows(
      new_sim_multi(beta_basic = 0.5, sim_res = 0.2),
      new_sim_multi(beta_basic = 0.5, sim_res = 0.5),
      new_sim_multi(beta_basic = 0.5, sim_res = 1)
    ) %>% 
      select(-results, -plot) %>% 
      view()
    
    plot(new_sim_multi(beta_basic = 0.5, kappa = 0.05))
    
    
    

# Define methods ----------------------------------------------------------

    
    # R0 and outcomes
    calc_r0.sim_multi <- function(sim) {
      
      beta_matrix <- sim$beta_matrix[[1]]
      lambda_matrix <- sim$lambda_matrix[[1]]
      
      beta_pp <- beta_matrix[1, 1]
      beta_pr <- beta_matrix[1, 2] 
      beta_rp <- beta_matrix[2, 1]
      beta_rr <- beta_matrix[2, 2]

      lambda_pp <- lambda_matrix[1, 1]
      lambda_pr <- lambda_matrix[1, 2] 
      lambda_rp <- lambda_matrix[2, 1]
      lambda_rr <- lambda_matrix[2, 2]
      
      t_matrix <- matrix(
        data = rbind(
          c(beta_pp * sim$n_p, beta_pr * sim$n_p, 0, 0),
          c(beta_rp * sim$n_r, beta_rr * sim$n_r, 0, 0),
          rep(0, 4),
          rep(0, 4)
        ),
        4, 4
      )
      
      
      sig_matrix <- matrix(
        data = rbind(
          c(-(sim$delta_p + sim$gamma + sim$mu), 0, -sim$kappa * lambda_pp, -sim$kappa * lambda_pr),
          c(0, -(sim$delta_r + sim$gamma + sim$mu), -sim$kappa * lambda_rp, -sim$kappa * lambda_rr),
          c(sim$delta_p , 0, sim$kappa*lambda_pp - sim$gamma - sim$mu, sim$kappa * lambda_pr),
          c(0, sim$delta_r, sim$kappa * lambda_rp, sim$kappa*lambda_rr - sim$gamma - sim$mu)
        ),
        4, 4
      )

      g_matrix <- t_matrix %*% - solve(sig_matrix)
      
      g_eigens <- eigen(g_matrix)
      
      eigenvals <- g_eigens$values
      
      if (sum(Im(eigenvals) != 0) > 0) warning("Complex eigenvalues used when calculating R0")
      
      (r0 <- max(Re(eigenvals)))
      
      r0
      
    }
    
    
    calc_r0(new_sim_multi(kappa = 0.05))
    calc_outcome(new_sim_multi(kappa = 0.05), outcome = "r0")
    
    plot(new_sim_multi())
    
    
    
    
    # CHECK - this g_matrix has negative values? Which doesn't make sense
    # because it should always be strictly greater than 0
    # actually maybe it's fine.. One more case in D_p will DECREASE the number of cases in I?
    # Because of detection?
    

# Costs -------------------------------------------------------------------

    calc_cost_t.sim_multi <- function(sim) {
      
      time_series <- sim$results[[1]]
      
      time_series %>% 
        mutate(
          cost_self_p   = ((sim$pi_p * I_p) + (sim$rho_p * (sim$n_p - I_p))) * sim$omega,
          cost_self_r   = ((sim$pi_r * I_r) + (sim$rho_r * (sim$n_r - I_r))) * sim$omega,
          cost_random_p = sim$alpha_p,
          cost_random_r = sim$alpha_r,
          cost_contact_p = sim$kappa * D_p,
          cost_contact_r = sim$kappa * D_r
        ) %>% 
        mutate(across(starts_with("cost_"), ~ if_else(I_tot <= sim$epidemic_threshold, 0, .x))) %>% 
        select(-epidemic)
  
    }
    
    calc_cost_t(new_sim_multi()) %>% pivot_longer(starts_with("cost")) %>% ggplot(aes(x = time, y = value, colour = name)) + geom_line()
    calc_cost_by_type(new_sim_multi())
    calc_cost_total(new_sim_multi(beta = 0.2))
    calc_cost_constraint(new_sim_multi(), 5)
    
    
    
    

# Optimise ----------------------------------------------------------------

    sim <- new_sim_multi()
    calc_optimal_policy.sim_multi <- function(sim, K, x0, outcome) {
      
      # sim <- new_sim_multi(); K <- 5; x0 <- c(0.001, 0.001, 0.5); outcome <- "peak_val"
      
      # Need to allow x to change
      eval_sim <- function(x, sim) {
        alpha_p <- x[[1]]
        alpha_r <- x[[2]]
        omega <- x[[3]]
        
        new_sim_multi(
          alpha_p =  alpha_p, # **
          alpha_r = alpha_r,
          omega =  omega,   # **
          
          beta_basic = sim$beta_basic,
          phi =     sim$phi ,
          psi =     sim$psi ,
          gamma =   sim$gamma,
          pi_p =    sim$pi_p,
          pi_r =    sim$pi_r,
          rho_p =   sim$rho_p,
          rho_r =   sim$rho_r,
          # tau =     sim$tau,
          kappa =   sim$kappa,
          lambda_basic =  sim$lambda_basic,
          theta_basic = sim$theta_basic,
          nu =      sim$nu,
          mu =      sim$mu,
          n_p =     sim$n_p,
          allow_negative_I = sim$allow_negative_I,
          epidemic_threshold = sim$epidemic_threshold
        )
      }

      eval_outcome <- function(x, sim, K) {
        calc_outcome(
          eval_sim(x, sim),
          outcome = outcome
        )
      }
      
      
      
      eval_cost <- function(x, sim, K) {
        calc_cost_constraint(
          eval_sim(x, sim),
          K = K
        )
      }

      opt_results <- nloptr(x0= x0,
                            eval_f=eval_outcome,
                            # eval_grad_f=eval_grad_f0,
                            lb = c(0,0,0),
                            ub = c(1,1,1),
                            eval_g_ineq = eval_cost,
                            # eval_jac_g_ineq = eval_jac_g0,
                            opts = list(
                              # "algorithm" = "NLOPT_LN_AUGLAG",
                              
                              "algorithm" = "NLOPT_LN_COBYLA",
                              # "algorithm" = "NLOPT_LN_BOBYQA", - no non linear constraints
                              # "algorithm" = "NLOPT_LN_SBPLX", - doesn't work with non linear constraints
                              # "algorithm" = "NLOPT_GN_ORIG_DIRECT_L", - always gives Inf?
                              # "algorithm" = "NLOPT_GN_ISRES", - seems to always revert to x0
                              "xtol_rel"=1.0e-4,
                              "maxeval" = 200,
                              # local_opts = list( "algorithm" = "NLOPT_LN_SBPLX",
                              #                    "xtol_rel"  = 1.0e-7),
                              "print_level" = 2
                            ),
                            sim = sim,
                            K = K
      )
      
      alpha_p <- opt_results$solution[1]
      alpha_r <- opt_results$solution[2]
      omega <- opt_results$solution[3]
      outcome_val <- opt_results$objective

      sim_updated <- new_sim_multi(
        alpha_p =  alpha_p, # **
        alpha_r = alpha_r,
        omega =  omega,   # **
        
        beta_basic = sim$beta_basic,
        phi =     sim$phi ,
        psi =     sim$psi ,
        gamma =   sim$gamma,
        pi_p =    sim$pi_p,
        pi_r =    sim$pi_r,
        rho_p =   sim$rho_p,
        rho_r =   sim$rho_r,
        # tau =     sim$tau,
        kappa =   sim$kappa,
        lambda_basic =  sim$lambda_basic,
        theta_basic = sim$theta_basic,
        nu =      sim$nu,
        mu =      sim$mu,
        n_p =     sim$n_p,
        allow_negative_I = sim$allow_negative_I,
        epidemic_threshold = sim$epidemic_threshold
      )
      
      sim_updated$K <- K
      sim_updated$x0 <- list(x0)
      sim_updated$outcome_choice <- outcome
      sim_updated$outcome_val <- outcome_val
      
      return(sim_updated)
      
    }
    
      
      
    opt_test_multi <- calc_optimal_policy(new_sim_multi(), K = 2, x0 = c(0.001, 0.001, 0.4), outcome = "peak_val")

  
    
    opt_test_multi %>% class()
    
    # 
    # opt_test_multi %>% calc_cost_by_type() %>%
    #   view()
    # 
    # opt_test_multi %>% calc_cost_total()
    # 
    # opt_test_multi %>% calc_cost_t() %>% 
    #   select(starts_with("cost_")) %>% 
    #   summarise(across(everything(), ~ sum(.x * sim$sim_res)))
    
    

# Solutions DF ------------------------------------------------------------

    solutions_df <- function(parameters_df) {
      # parameters_df <- tibble(beta_basic = c(0.2, 0.5))
      
      default_opt_parameters <- tibble(
        K = 5, x0 = list(c(0.001, 0.001, 0.5)), outcome = "peak_val"
      )
      
      parameters_sim <- parameters_df %>% select(-any_of(names(default_opt_parameters)))
      parameters_opt <- parameters_df %>% 
        crossing(select(default_opt_parameters, -any_of(names(parameters_df)))) %>% 
        select(any_of(names(default_opt_parameters)))
     
      sim <- parameters_sim %>% 
        mutate(sim = pmap(., new_sim_multi)) %>% 
        select(sim)
      
      bind_cols(
        sim, parameters_opt
      ) %>% 
        rowwise() %>% 
        mutate(solutions = list(calc_optimal_policy(sim, K, x0, outcome))) %>% 
        select(solutions) %>%
        rowwise() %>% 
        mutate(costs = list(calc_cost_props(solutions, K = solutions$K))) %>% 
        unnest(costs) %>% 
        unnest(solutions)
      
    }
    
    solutions_test <- solutions_df(crossing(beta_basic = c(0.5),
                                            K = c(2, 5)))
    
    plot_all(solutions_test, K)
    
    

# ………... ------------------------------------------------------------------


# PLOTS AND RESULTS -------------------------------------------------------

# Basic graphs of relationships -------------------------------------------


    

    # GRAPH OF BETA
  
    tibble(beta_basic = seq(0.2, 2, 0.1)) %>%
      # mutate(
      #     beta_pp = pi ^ 2 * beta_basic,
      #     beta_rp = pi * beta_basic,
      #     beta_pr = pi * beta_basic,
      #     beta_rr = beta_basic
      #   ) %>% 
      rowwise() %>% 
      mutate(
        results_all = list(test_tracing_multi(beta_basic = beta_basic,
                                              phi = 1.5))
      ) %>% 
      mutate(
        peak_val = results_all$peak_val,
        prop_infected = results_all$prop_infected
        # tau_kappa_lambda = results_all$tau_kappa_lambda
      ) %>% 
      plot_line(x = beta_basic, y = prop_infected) + coord_cartesian(ylim = c(0, 1))
      

    
    # GRAPH OF PHI
    tibble(phi = seq(1, 3, 0.1)) %>%
      rowwise() %>% 
      mutate(
        results_all = list(test_tracing_multi(phi = phi, beta_basic = 0.2))
      ) %>% 
      mutate(
        peak_val = results_all$peak_val,
        prop_infected = results_all$prop_infected
      ) %>% 
      plot_line(x = phi, y = prop_infected) + coord_cartesian(ylim = c(0, 1))
    
    
    # GRAPH of DELTA (same for both groups)
    tibble(delta_p = seq(0.01, 1.5, 0.1),
           delta_r = delta_p) %>% 
      rowwise() %>% 
      mutate(results_all = list(test_tracing_multi(delta_p = delta_p, delta_r = delta_r))) %>% 
      mutate(peak_val = results_all$peak_val,
             prop_infected = results_all$prop_infected) %>% 
      plot_line(x = delta_p, y = prop_infected) + coord_cartesian(ylim = c(0, 1))
    
    
    # GRAPH OF DELTA (different for each group?)
    delta_p_r_test <- crossing(
      delta_p = seq(0.01, 1.5, 0.05),
      delta_r = seq(0.01, 1.5, 0.05)
    ) %>% 
      rowwise() %>% 
      mutate(results_all = list(test_tracing_multi(delta_p = delta_p, 
                                                   delta_r = delta_r,
                                                   phi = 3))) %>% 
      mutate(peak_val = results_all$peak_val,
             prop_infected = results_all$prop_infected)
    
    
    # 
    # delta_p_r_test_measures <- delta_p_r_test %>% 
    #   mutate(total_delta = delta_p + delta_r) %>% 
    #   mutate(peak_val_round = floor(peak_val * 100)/ 100) %>% 
    #   group_by(peak_val_round) %>% 
    #   mutate(min_total_delta_val = min_na(total_delta),
    #          min_total_delta_yn =  total_delta == min_total_delta_val) %>% 
    #   select(-results_all) %>% 
    #   view()
    # 
    # delta_p_r_test_measures %>% ungroup %>% plot_contours(x = delta_p, y = delta_r, z = prop_infected) + 
    #   geom_point(data = delta_p_r_test_measures %>% filter(min_total_delta_yn))
    # 
    
    
    
    
    
    delta_p_r_test_measures <- delta_p_r_test %>% 
      mutate(total_delta = round(delta_p + delta_r, 2)) %>% 
      group_by(total_delta) %>% 
      mutate(min_prop_infected_val = min_na(prop_infected),
             min_prop_infected_yn = prop_infected == min_prop_infected_val) %>% 
      ungroup() %>% 
      select(-results_all) %>% 
      view()
    
    delta_p_r_test_measures %>% ungroup %>% plot_contours(x = delta_p, y = delta_r, z = prop_infected) +
      geom_line(
        data = filter(
          delta_p_r_test_measures,
          min_prop_infected_yn,
          delta_p != max(delta_p),
          delta_r != max(delta_r),
          delta_p != min(delta_p),
          delta_r != min(delta_r)
        ),
        se = FALSE,
        colour = "indianred"
      )
    
    
    # Work out the AVERAGE ratio of the optimal delta_p / delta_r and see how it varies with different parametsr
    # (Slope of the optimal line)
    
    
    opt_ratio <- delta_p_r_test_measures %>% 
      filter(
        min_prop_infected_yn,
        delta_p != max(delta_p),
        delta_r != max(delta_r),
        delta_p != min(delta_p),
        delta_r != min(delta_r)
      ) %>% 
      summarise(opt_prop = mean(delta_p / (delta_r + delta_p)))
    
    
    
    # Calculate optimal ratios as phi varies
    
    
    ratio_by_phi <- function(phi) {
      delta_p_r_test <- crossing(
        delta_p = seq(0.01, 1.5, 0.05),
        delta_r = seq(0.01, 1.5, 0.05)
      ) %>% 
        rowwise() %>% 
        mutate(results_all = list(test_tracing_multi(delta_p = delta_p, 
                                                     delta_r = delta_r,
                                                     phi = phi))) %>% 
        mutate(peak_val = results_all$peak_val,
               prop_infected = results_all$prop_infected)
      
      delta_p_r_test_measures <- delta_p_r_test %>% 
        mutate(total_delta = round(delta_p + delta_r, 2)) %>% 
        group_by(total_delta) %>% 
        mutate(min_prop_infected_val = min_na(prop_infected),
               min_prop_infected_yn = prop_infected == min_prop_infected_val) %>% 
        ungroup() %>% 
        select(-results_all)
      
      opt_prop <- delta_p_r_test_measures %>% 
        filter(
          min_prop_infected_yn,
          delta_p != max(delta_p),
          delta_r != max(delta_r),
          delta_p != min(delta_p),
          delta_r != min(delta_r)
        ) %>% 
        summarise(opt_prop = mean(delta_p / (delta_r + delta_p)))
      
      opt_prop$opt_prop
      

    }
    
    
    test_ratio_by_phi <- tibble(
      phi = c(1.2, 1.5, 1.8, 2.1, 2.4, 3, 5, 10)
    ) %>% 
      rowwise() %>% 
      mutate(opt_prop = ratio_by_phi(phi))
    
    
    test_ratio_by_phi %>% plot_line(x = phi, y = opt_prop)
    
    
    
    
    
    
    
    
    
    
    
    
    # Stronger complements when phi is lower?
    
    # What's the effect of stronger associativity (e.g. alpha)
    
    
    

    
  
    
    
    
    
    



# >> ----------------------------------------------------------------------

# COMPLEMENTARITYS BETWEEN D's ---------------------------------------------

    

# R0 ----------------------------------------------------------------------
  
    # For the diagonal
    total_delta <- 0.2
    
    # Plot an example with indifference curves
    d_complementarity <- crossing(
      delta_p = seq(0, 0.3, 0.01),
      delta_r = seq(0, 0.3, 0.01),
      phi = 1, n_p = 0.5, beta_basic = 0.7
    ) %>% 
      mutate(r0 = pmap_dbl(., r0_multigroup),
             epidemic_results = pmap(., test_tracing_multi),
             outcomes = map(epidemic_results, "outcomes"),
             peak_val = map_dbl(outcomes, "peak_val"),
             prop_infected = map_dbl(outcomes, "prop_infected")) %>% 
      select(-epidemic_results, -outcomes)
    
    # Plot for R0
    d_complementarity %>% plot_contours(delta_p, delta_r, r0) +
      geom_abline(intercept = total_delta, slope = -1, linetype = "dashed", colour = "indianred") + 
      labs(fill = expression(R[0]))
    
    ggsave("delta_indiff_r0.png", width = 5, height = 4)
    
    # Plot for peak_val
    d_complementarity %>% plot_contours(delta_p, delta_r, peak_val) +
      geom_abline(intercept = total_delta, slope = -1, linetype = "solid", colour = "indianred") + 
      labs(fill = "Peak Value of Infecteds")
    
    # Plot for prop_infected
    d_complementarity %>% plot_contours(delta_p, delta_r, prop_infected) +
      geom_abline(intercept = total_delta, slope = -1, linetype = "dashed", colour = "indianred") + 
      labs(fill = "% Infected")
    
    ggsave("delta_indiff_prop_infected.png", width = 5, height = 4)
    
    
    # Plot R0 when moving along the diagonal
    d_diffs <- crossing(
      delta_p = seq(0, total_delta, 0.001),
      phi = 1,
      psi = c(0.6, 0.8, 1),
      n_p = c(0.4, 0.5, 0.6)
    ) %>% 
      mutate(
        delta_r = total_delta - delta_p  
      ) %>% 
      mutate(r0 = pmap_dbl(., r0_multigroup)) %>% 
      mutate(delta_diff = delta_p - delta_r,
             psi = factor(psi), n_p = factor(n_p))
    
    
    # By amount of assortative mixing
    plot_line_grouped(d_diffs %>% filter(n_p == 0.5), delta_diff, r0, psi) + 
      theme_custom() + 
      labs(x = expression(delta[A] - delta[B]),
           y = expression(R[0]),
           colour = expression(psi)) + 
      geom_vline(xintercept = 0, linetype = "dashed")
    
    # By group size
    plot_line_grouped(d_diffs %>% filter(psi == 0.8), delta_diff, r0, n_p)
    
    

# Other outcomes ----------------------------------------------------------

    total_delta <- 0.2
    
    delta_diff <- function(parameters_df, total_delta) {
      
      cols_in_parameters_df <- names(parameters_df)
      
      default_parameters <- tibble(
        beta_basic = 0.75,
        phi = 1.5,
        psi = 0.7,
        gamma = 1 / 20    ,
        tau = 0.7        ,
        kappa =  0.3   ,
        lambda_basic = 0.2     ,
        lambda_scalar_yn = FALSE,
        nu = 15 / 1000 * (1 / 365)      ,
        mu = 15 / 1000 * (1 / 365),
        n_p = 0.5
      ) %>%
        select(-any_of(cols_in_parameters_df))
      
      final_parameters_df <- parameters_df %>% 
        crossing(default_parameters) %>% 
        mutate(delta_r = total_delta - delta_p)
      
      delta_diff_outcomes <- final_parameters_df %>% 
        rowwise() %>% 
        group_by_all() %>% 
        summarise(
          test_tracing_multi(
            beta_basic = beta_basic, delta_p = delta_p, delta_r = delta_r, phi = phi, psi = psi, 
            gamma = gamma, tau = tau, kappa = kappa, lambda_basic = lambda_basic, 
            nu = nu, mu = mu, n_p = n_p, 
            allow_negative_I = TRUE)$outcomes,
          r0 = r0_multigroup(
            beta_basic = beta_basic,
            delta_p = delta_p,  delta_r = delta_r, phi = phi, psi = psi, 
            gamma = gamma, tau = tau, kappa = kappa, lambda_basic = lambda_basic, lambda_scalar_yn = lambda_scalar_yn,
            nu = nu, mu = mu, n_p = n_p
          )
          ) %>% 
        ungroup() %>% 
        mutate(delta_diff = delta_p - delta_r)
      
      delta_diff_outcomes
    }
    
    
    plot_delta_diff <- function(dat, group) {
      plot <- dat %>% 
        pivot_longer(c(prop_infected, peak_val, r0)) %>% 
        
        ggplot(aes(x = delta_diff, y = value, colour = name, linetype = factor({{group}}))) + 
        geom_line() + 
        # plot_line_grouped(delta_diff, value, name) + 
        theme_custom() + 
        facet_wrap(~ name, scales = "free_y", nrow = 3) + 
        labs(x = expression(delta[A] - delta[B])) + 
        geom_vline(xintercept = 0, linetype = "dashed")
      
      print(plot)
    }
    
    
  
    delta_diff_even <- delta_diff(
      crossing(
        delta_p = seq(0, total_delta, 0.01),
        # tau = 1,
        phi = 1,
        # phi = 1, n_p = 0.5, beta_basic = 0.4
        beta_basic = 0.4,
        psi = seq(0.5, 1, 0.05),
        kappa = c(0, 0.3),
        n_p = 0.5
      ),
      total_delta = total_delta
    )
    
    
    delta_diff_even %>% filter(psi %in% c(0.6), kappa == 0.3) %>% 
      pivot_longer(c(prop_infected, peak_val, r0)) %>% 
      mutate(name = fct_recode(name, 
                               "Epidemic Peak Value" = "peak_val", "Prop. Infected" = "prop_infected",
                               "R0" = "r0")) %>% 
      ggplot(aes(x = delta_diff, y = value, colour = name)) + 
      geom_line(show.legend = FALSE) + 
      # plot_line_grouped(delta_diff, value, name) + 
      theme_custom() + 
      facet_wrap(~ name, scales = "free_y", nrow = 3) + 
      labs(x = expression(pi[A] - pi[B]), y = element_blank()) + 
      geom_vline(xintercept = 0, linetype = "dashed")
    
    ggsave("delta_diff_evens_simple.png", width = 4, height = 5)
    
    
    
    # Plot shapes - even sized, equal risk group
    delta_diff_even %>% filter(psi %in% c(0.6, 0.9), kappa == 0.3) %>% 
      plot_delta_diff(psi)
    
    ggsave("delta_diff_evens.png", width = 5, height = 7)
    
    
    # PLot 0.5, 1
    # Plot shapes - even sized, equal risk group
    delta_diff_even %>% 
      filter(psi %in% c(0.5, 1), kappa == 0.3) %>% 
      plot_delta_diff(psi)
    
    ggsave("delta_diff_evens_extreme_psi.png", width = 5, height = 7)
    
    # delta_diff_no_contact <- delta_diff(
    #   crossing(
    #     delta_p = seq(0, total_delta, 0.01),
    #     # tau = 1,
    #     phi = 1,
    #     # phi = 1, n_p = 0.5, beta_basic = 0.4
    #     beta_basic = 0.4,
    #     lambda_basic = 0,
    #     psi = c(0.5, 1),
    #     n_p = 0.5
    #   ),
    #   total_delta = total_delta
    # ) %>% plot_delta_diff(psi)
    
    
    # Contact tracing on / off
    delta_diff_even %>% filter(psi %in% c(0.7)) %>% 
      plot_delta_diff(kappa)
    
    
    # Plot as a function of psi
    objective_diff_by_psi <- delta_diff_even %>% 
      filter(delta_r == delta_p | delta_p == 0.2 & delta_r == 0) %>% 
      relocate(delta_diff) %>% 
      pivot_longer(c(peak_val, prop_infected, r0), names_to = "objective") %>% 
      group_by(psi, objective) %>% 
      summarise(
        objective_diff = value[delta_diff == 0.2] - value[delta_diff == 0]
      )
      
    # Plot objective diff ≈ "cost" of having different testing propensities
    ggplot(objective_diff_by_psi, aes(x = psi, y = objective_diff, colour = objective)) + 
      geom_line() + 
      facet_wrap(~ objective, nrow = 3, scales = "free_y")
    
    ggsave("delta_diff_by_psi.png", width = 5, height = 7)
    
    
    # High risk group
    delta_diff_high_risk <- delta_diff(
      crossing(
        delta_p = seq(0, total_delta, 0.01),
        # tau = 1,
        phi = 2,
        beta_basic = 0.2,
        psi = c(0.6, 0.9),
        n_p = 0.5,
        kappa = c(0, 0.3)
      ),
      total_delta = total_delta
    )
    
    delta_diff_high_risk %>% 
      filter(kappa == 0.3) %>%
      pivot_longer(c(prop_infected, peak_val, r0)) %>% 
      
      ggplot(aes(x = delta_diff, y = value, colour = name, linetype = factor(psi))) + 
      geom_line() + 
      # plot_line_grouped(delta_diff, value, name) + 
      theme_custom() + 
      facet_wrap(~ name, scales = "free_y", nrow = 3) + 
      labs(x = expression(delta[A] - delta[B])) + 
      geom_vline(xintercept = 0, linetype = "dashed")
    
    
    ggsave("delta_diff_high_risk_group.png", width = 5, height = 7)
    
    
    # Contact tracing on/off
    delta_diff_high_risk %>% filter(psi %in% c(0.9)) %>% 
      plot_delta_diff(kappa)
    
    
    
    # SMALL (0.2), High risk group
    delta_diff_small_high_risk <- delta_diff(
      crossing(
        delta_p = seq(0, total_delta, 0.01),
        # tau = 1,
        phi = 2,
        beta_basic = 0.2,
        psi = c(0.6, 0.9),
        n_p = 0.2
      ),
      total_delta = total_delta
    )
    
    delta_diff_small_high_risk %>% 
      # filter(psi == 0.8) %>% 
      pivot_longer(c(prop_infected, peak_val, r0)) %>% 
      
      ggplot(aes(x = delta_diff, y = value, colour = name, linetype = factor(psi))) + 
      geom_line() + 
      # plot_line_grouped(delta_diff, value, name) + 
      theme_custom() + 
      facet_wrap(~ name, scales = "free_y", nrow = 3) + 
      labs(x = expression(delta[A] - delta[B])) + 
      geom_vline(xintercept = 0, linetype = "dashed")
    
    
    ggsave("delta_diff_small_high_risk_group.png", width = 5, height = 7)
    
    
    
    
    
    
    
    
    
    # Look at how it varies by psi
   
    
    
    
    
    

# >> ---------------------------------------------------------------------

# OPTIMAL PROPORTION ------------------------------------------------------




    
    

# 1. By phi ---------------------------------------------------------------

    
    optimal_prop_by_phi <- crossing(
      delta_p = seq(0.01, 1.5, 0.05),
      delta_r = seq(0.01, 1.5, 0.05),
      phi = c(seq(0.1, 1, 0.1), 1.2, 1.5, 1.8, 2.1, 2.4, 3, 5, 10),
      lambda_scalar_yn = c(T, F)
    ) %>% 
      rowwise() %>% 
      mutate(r0 = r0_multigroup(delta_p = delta_p, delta_r = delta_r, phi = phi, lambda_scalar_yn = lambda_scalar_yn)) %>% 
      mutate(total_delta = round(delta_p + delta_r, 2)) %>% 
      group_by(total_delta, phi, lambda_scalar_yn) %>% 
      mutate(
        min_r0_val = min(r0),
        min_r0_yn = r0 == min(r0)
      ) %>% 
      ungroup() %>% 
      mutate(min_r0_yn = ifelse(
        delta_p == max(delta_p) | 
        delta_r == max(delta_r) |
        delta_p == min(delta_p) |
        delta_r == min(delta_r), 
        NA, min_r0_yn
      ))
      
    
    # PLOT an example
    plot_contours_r0 <- function(dat) {
      dat %>% 
        plot_contours(delta_p, delta_r, r0) +
        geom_line(
          dat = filter(
            dat,
            min_r0_yn
          ),
          se = FALSE,
          colour = "indianred"
        )
      
    }
    
    plot_contours_r0(optimal_prop_by_phi %>% filter(phi== 1.5, lambda_scalar_yn == FALSE))
    
    
   
    
    
    
    # calculate linear slope and then 
    # beta / (beta + 1) gives you the ratio
    
    optimal_prop_by_phi %>% 
      filter(min_r0_yn) %>% 
      group_by(phi, lambda_scalar_yn) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(lm = list(lm(delta_r ~ delta_p, data = data)),
             coeff = lm$coefficients[2],
             ratio = 1 / (1 + coeff)) %>% 
      ggplot(aes(x = phi, y = ratio, colour = lambda_scalar_yn)) + 
      geom_line() +
      coord_cartesian(ylim = c(0, 1)) + 
      geom_hline(yintercept = 0.5, linetype = "dashed")
    
 
    

# 2. Group size -----------------------------------------------------------


    
    
    # Effect of group size
    optimal_prop_by_n <- crossing(
      delta_p = seq(0.01, 1.5, 0.05),
      delta_r = seq(0.01, 1.5, 0.05),
      n_p = seq(0.1, 0.9, 0.1)
    ) %>% 
      rowwise() %>% 
      mutate(r0 = r0_multigroup(delta_p = delta_p, delta_r = delta_r, n_p = n_p)) %>% 
      mutate(total_delta = round(delta_p + delta_r, 2)) %>% 
      group_by(total_delta, n_p) %>% 
      mutate(
        min_r0_val = min(r0),
        min_r0_yn = r0 == min(r0)
      ) %>% 
      ungroup() %>% 
      mutate(min_r0_yn = ifelse(
        delta_p == max(delta_p) | 
          delta_r == max(delta_r) |
          delta_p == min(delta_p) |
          delta_r == min(delta_r), 
        NA, min_r0_yn
      ))
    
    
    # Plot the relationship
    optimal_prop_by_n %>% 
      filter(min_r0_yn) %>% 
      group_by(n_p) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(lm = list(lm(delta_r ~ delta_p, data = data)),
             coeff = lm$coefficients[2],
             ratio = 1 / (1 + coeff)) %>% 
      plot_line(n_p, ratio) + coord_cartesian(ylim = c(0, 1), xlim = c(0, 1)) + 
      geom_hline(yintercept = 0.5, linetype = "dashed") + 
      geom_abline(intercept = 0, slope = 1, linetype = "dotted")
 
    

# 3. Kappa ---------------------------------------------------------------------


    
    
    # Effect of kappa_lambda
    optimal_prop_by_kappa <- crossing(
      delta_p = seq(0.01, 1.5, 0.05),
      delta_r = seq(0.01, 1.5, 0.05),
      kappa = seq(0.1, 2, 0.1), 
      lambda_basic = 0.05,
      lambda_scalar_yn = c(T, F)
    ) %>% 
      rowwise() %>% 
      mutate(r0 = r0_multigroup(delta_p = delta_p, delta_r = delta_r, 
                                 kappa = kappa, lambda_scalar_yn = lambda_scalar_yn,
                                 lambda_basic = lambda_basic)) %>% 
      mutate(total_delta = round(delta_p + delta_r, 2)) %>% 
      group_by(total_delta, kappa, lambda_scalar_yn) %>% 
      mutate(
        min_r0_val = min(r0),
        min_r0_yn = r0 == min(r0)
      ) %>% 
      ungroup() %>% 
      mutate(min_r0_yn = ifelse(
        delta_p == max(delta_p) | 
          delta_r == max(delta_r) |
          delta_p == min(delta_p) |
          delta_r == min(delta_r), 
        NA, min_r0_yn
      ))
    
    
    # Plot the relationship
    optimal_prop_by_kappa %>% 
      filter(min_r0_yn) %>% 
      group_by(kappa, lambda_scalar_yn) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(lm = list(lm(delta_r ~ delta_p, data = data)),
             coeff = lm$coefficients[2],
             ratio = 1 / (1 + coeff)) %>% 
      ggplot(aes(x = kappa, y = ratio, colour = lambda_scalar_yn)) + 
      geom_line() +
      coord_cartesian(ylim = c(0, 1)) + 
      geom_hline(yintercept = 0.5, linetype = "dashed")
    
    
    

# 4. Beta --------------------------------------------------------------------


    
    
    # Effect of beta
    optimal_prop_by_beta <- crossing(
      delta_p = seq(0.01, 1.5, 0.05),
      delta_r = seq(0.01, 1.5, 0.05),
      beta_basic = seq(0.3, 3, 0.1)
    ) %>% 
      rowwise() %>% 
      mutate(r0 = r0_multigroup(delta_p = delta_p, delta_r = delta_r, beta_basic = beta_basic)) %>% 
      mutate(total_delta = round(delta_p + delta_r, 2)) %>% 
      group_by(total_delta, beta_basic) %>% 
      mutate(
        min_r0_val = min(r0),
        min_r0_yn = r0 == min(r0)
      ) %>% 
      ungroup() %>% 
      mutate(min_r0_yn = ifelse(
        delta_p == max(delta_p) | 
          delta_r == max(delta_r) |
          delta_p == min(delta_p) |
          delta_r == min(delta_r), 
        NA, min_r0_yn
      ))
    
    
    # Plot the relationship
    optimal_prop_by_beta %>% 
      filter(min_r0_yn) %>% 
      group_by(beta_basic) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(lm = list(lm(delta_r ~ delta_p, data = data)),
             coeff = lm$coefficients[2],
             ratio = 1 / (1 + coeff)) %>% 
      plot_line(beta_basic, ratio) + coord_cartesian(ylim = c(0, 1)) + 
      geom_hline(yintercept = 0.5, linetype = "dashed")
    
    
    

# 5. Psi ------------------------------------------------------------------

    # Effect of psi
    optimal_prop <- function(df_parameter, ...) {
      
      df_parameter_with_delta <- crossing(df_parameter, 
                                          delta_p = seq(0.01, 1.5, 0.05),
                                          delta_r = seq(0.01, 1.5, 0.05))
      df_parameter_with_delta$r0 <-  pmap_dbl(df_parameter_with_delta, r0_multigroup)
      
      df_contours <- df_parameter_with_delta %>% 
        mutate(total_delta = round(delta_p + delta_r, 2)) %>% 
        group_by(total_delta, ...) %>% 
        mutate(
          min_r0_val = min(r0),
          min_r0_yn = r0 == min(r0)
        ) %>% 
        ungroup() %>% 
        mutate(min_r0_yn = ifelse(
          delta_p == max(delta_p) | 
            delta_r == max(delta_r) |
            delta_p == min(delta_p) |
            delta_r == min(delta_r), 
          NA, min_r0_yn
        ))
      
      df_optimal_prop <- df_contours %>% 
        filter(min_r0_yn) %>% 
        group_by(...) %>% 
        nest() %>% 
        rowwise() %>% 
        mutate(lm = list(lm(delta_r ~ delta_p, data = data)),
               coeff = lm$coefficients[2],
               ratio = 1 / (1 + coeff))
      
      return(
        list(df_contours = df_contours,
             df_optimal_prop = df_optimal_prop)
      )
    }
    
    optimal_prop_by_psi <- optimal_prop(
      df_parameter = crossing(
        psi = seq(0, 1, 0.1),
        lambda_scalar_yn = c(T, F)
      ), psi, lambda_scalar_yn
    )
    
    # Plot the relationship
    optimal_prop_by_psi$df_optimal_prop %>% 
      ggplot(aes(x = psi, y = ratio, colour = lambda_scalar_yn)) + 
      geom_line() + coord_cartesian(ylim = c(0, 1)) + 
      geom_hline(yintercept = 0.5, linetype = "dashed")

    
    # MORE ASSORTATIVE MATCHING >> higher optimal ratio, and also more complementarity
    # (i.e. higher punishment for deviating from optimal -- think about marginal effects)
    # they coincide at psi = 0.5
    # less assortative matching: contact tracing captures everyone evenly, so makes sense to tar
    # more assortative matching: 
    
    # BUT not when lambda is not a scalar...
    # What's the intuition here?
    # Taking into account the contact tracing affects things
        # When more associative, I can only contact trace the groups when they come in and 
        # self diagnose themselves
    
    
    plot_contours_r0(optimal_prop_by_psi$df_contours %>% filter(psi == 0.8, lambda_scalar_yn))
    plot_contours_r0(optimal_prop_by_psi %>% filter(psi == 0.8, !lambda_scalar_yn))
    
    plot_contours_r0(optimal_prop_by_psi %>% filter(psi == 0.2, lambda_scalar_yn))
    
    
    
    
    # Plot phi vs psi vs optimal ratio
    optimal_prop_by_psi_and_phi <- optimal_prop(
      df_parameter = crossing(
        psi = seq(0, 1, 0.1),
        phi = c(
          # seq(0.1, 1, 0.1), 
          # 1.2, 1.5, 1.8, 2.1, 2.4, 3
          seq(1, 1.5, 0.1)
        ),
        lambda_scalar_yn = c(T, F)
      ), psi, lambda_scalar_yn, phi
    )
    
    plot_contours(optimal_prop_by_psi_and_phi$df_optimal_prop %>% 
                    filter(lambda_scalar_yn == TRUE), x = psi, y = phi, z = ratio)
    
    

    

# ⇒> ----------------------------------------------------------------------

# UNderstanding alpha at high budgets -------------------------------------
    
  
    # Run all solutions
    sims_by_alpha <- crossing(
      alpha_p = seq(0, 0.1, 0.001), alpha_r = seq(0, 0.1, 0.001),
      omega = 1, sim_res = 0.1
    ) %>% 
      mutate(sim = pmap(., new_sim_multi))
    
    
    
    
    # Calculate budget and outcome curves
    budget_outcome_curves <- sims_by_alpha %>% 
      select(sim) %>% 
      rowwise() %>% 
      mutate(costs = list(calc_cost_by_type(sim))) %>% 
      unnest(costs) %>% 
      unnest(sim)
    
    # Calculate optimal paths
    
    opt_path <- budget_outcome_curves %>% 
      mutate(cost_categ = cut_width(cost_total, 0.1)) %>%
      group_by(cost_categ) %>% 
      filter(peak_val == min_na(peak_val))
    


    
    # Plot (1) - Total cost
    plot_contours(budget_outcome_curves, x = alpha_p, y = alpha_r, z = cost_total)
    
    
    

    
    # Plot (2) Other costs
    budget_outcome_curves %>% 
      mutate(cost_self = cost_self_p + cost_self_r,
             cost_random = cost_random_p + cost_random_r,
             cost_contact = cost_contact_p + cost_contact_r) %>% 
      plot_contours(x = alpha_p, y = alpha_r, z = cost_random)
    
    # Cost of self- and contact- is decreasing in alpha (because the epidemic is shorter...)
    
    
    # Plot (3) - length of epidemic
    budget_outcome_curves %>% 
      mutate(time_epidemic_end = map_dbl(sim, "time_epidemic_end")) %>% 
      plot_contours(x = alpha_p, y = alpha_r, z = time_epidemic_end) + 
      geom_abline(intercept = 0, slope = 1, colour = "white", linetype = "dashed")
    
    
    # Intuition is: in order to get the epidemic to die out, you need to have BOTH groups being random tested
    # So at some point you want to do random testing of both groups
    
    
    
    # Plot (4) - outcome curves
    plot_contours(budget_outcome_curves, x = alpha_p, y = alpha_r, z = peak_val)
    
    
    
    # Plot (5) - optimal path
    ggplot(budget_outcome_curves, aes(x = alpha_p, y = alpha_r)) + 
      geom_contour(aes(z = peak_val), colour = "red", linetype = "dashed", bins = 30) + 
      geom_contour(aes(z = cost_total), colour = "blue", bins = 10) + 
      geom_point(
        data = opt_path, aes(colour = cost_total)
      ) + 
      geom_abline(slope = 1, intercept = 0, linetype = "dotted")
    
    
    
    ?geom_contour
    
    
    
    
    
    # Run all solutions
    sims_by_alpha_test_res <- crossing(
      alpha_p = seq(0, 0.1, 0.005), alpha_r = seq(0, 0.1, 0.005),
      omega = 1, sim_res = c(0.1, 1)
    ) %>% 
      mutate(sim = pmap(., new_sim_multi)) %>% 
      rowwise() %>% 
      mutate(costs = list(calc_cost_by_type(sim))) %>% 
      unnest(costs)
    
    # Plot the different contours
    ggplot() + 
      geom_contour(data = sims_by_alpha_test_res %>% filter(sim_res == 0.1), 
                   aes(x = alpha_p, y = alpha_r, z = cost_total),
                   colour = "red") + 
      geom_contour(data = sims_by_alpha_test_res %>% filter(sim_res == 1), 
                   aes(x = alpha_p, y = alpha_r, z = cost_total), 
                   colour = "blue")
    
    
    # Seems like this is enough to smooth out the jagged curves! At least at this resolution
    
    
    
    
    
    
    
    
    # Calculate the omega corner solution for the sims that exceeeded budget constraint
    opt_alphas_df <- final_parameters_df %>% 
      filter(K > 2) %>% 
      mutate(K = 9) %>% 
      crossing(
        # alpha_p = seq(0, 0.06, 0.003), alpha_r = seq(0, 0.04, 0.003),
        # alpha_p = seq(0.015, 0.025, 0.001), alpha_r = seq(0, 0.005, 0.0001),
        alpha_p = seq(0, 0.1, 0.001), alpha_r = seq(0, 0.1, 0.001),
        omega = 1
      ) %>% 
      relocate(alpha_p:omega) %>%
      rowwise() %>%
      mutate(
        x = list(c(alpha_p, alpha_r, omega)),
        cost_constraint_opt_alphas = cost_sum_multi(
          x = x, K = K,
          pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r,
          n_p = n_p, beta_basic = beta_basic, phi = phi, gamma = gamma, tau = tau, kappa = kappa,
          lambda_basic = lambda_basic, nu = nu, mu = mu, psi = psi,
          allow_negative_I = allow_negative_I, outcome = outcome, epidemic_threshold = epidemic_threshold
        )
      )
    
    
    
    
    
    
    
    
    
    opt_alphas_solution <- opt_alphas_df %>% 
      filter(
        # cost_constraint_opt_alphas < 0
        # alpha_p + alpha_r > 0.018
      ) %>%
      rowwise() %>%
      mutate(
        x = list(c(alpha_p, alpha_r, omega))
      ) %>% 
      mutate(
        objective_result_opt_alphas = outcomes_policy_multi(
          x = x, K = K,
          pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r,
          n_p = n_p, beta_basic = beta_basic, phi = phi, gamma = gamma, tau = tau, kappa = kappa,
          lambda_basic = lambda_basic, nu = nu, mu = mu, psi = psi,
          allow_negative_I = allow_negative_I, outcome = outcome, epidemic_threshold = epidemic_threshold
        )
      ) %>% 
      relocate(objective_result_opt_alphas)
    
    
    opt_path <- opt_alphas_solution %>% 
      select(alpha_p:omega, cost_constraint_opt_alphas, objective_result_opt_alphas) %>% 
      mutate(cost_constraint_cat = cut_width(cost_constraint_opt_alphas, 0.1)) %>%
      group_by(cost_constraint_cat) %>% 
      filter(objective_result_opt_alphas == min_na(objective_result_opt_alphas)) %>% 
      print 
    
    opt_alphas_df %>% relocate(cost_constraint_opt_alphas) %>% 
      # filter(cost_constraint_opt_alphas < 0) %>%
      drop_na() %>% 
      plot_contours(alpha_p, alpha_r, cost_constraint_opt_alphas) + 
      geom_abline(intercept = 0, slope = 1, colour = "white", linetype = "dotted")
    # geom_point(aes(x = alpha_p, y = alpha_r, colour = factor(cost_constraint_opt_alphas < 0)), alpha = 0.1)
    # geom_point(data = opt_path, aes(x = alpha_p, y = alpha_r), colour = "indianred")
    
    ggsave("opt_alphas_budget_constraint.png", width = 5, height = 3)
    
    
    # Plot marginal cost of increasing alpha_p as a function of alpha_r
    marg_cost_alpha <- opt_alphas_df %>% 
      filter(alpha_p %in% c(0, 0.03, 0.07, 0.1)) %>% 
      select(alpha_p, alpha_r, cost_constraint_opt_alphas) %>% 
      group_by(alpha_p) %>% 
      mutate(d_cost = cost_constraint_opt_alphas - lag(cost_constraint_opt_alphas)) %>% 
      mutate(d_cost = rollmean(d_cost, 5, "center")) %>% 
      mutate(alpha_p = factor(alpha_p)) %>% 
      print
    
    ggplot(marg_cost_alpha) + 
      geom_smooth(aes(x = alpha_r, y = d_cost, colour = alpha_p)) + 
      geom_hline(yintercept = 0, linetype = "dashed")
    
    
    
    
    
    
    
    
    
    
    
    library(zoo)
    
    # Filter and smooth the optimal path
    opt_path_smooth <- opt_path %>% 
      filter(abs(alpha_p - alpha_r) < 0.08) %>% 
      group_by(alpha_p) %>% 
      summarise(alpha_r = mean(alpha_r)) %>% 
      arrange(alpha_p) %>% 
      mutate(alpha_r = rollmean(alpha_r, 6, "centre")) %>% 
      mutate(alpha_r = ifelse(alpha_p < 0.004, 0, alpha_r)) %>% 
      print
    
    
    
    opt_alphas_solution %>% 
      ggplot(aes(x = alpha_p, y = alpha_r)) + 
      geom_contour_filled(aes(z = objective_result_opt_alphas), show.legend = TRUE, bins = 10) + 
      geom_line(data = opt_path_smooth, 
                aes(x = alpha_p, y = alpha_r), colour = "indianred", size = 1.5) + 
      geom_abline(intercept = 0, slope = 1, colour = "white", linetype = "dotted")
    
    
    ggsave("opt_alphas_solution.png", width = 5, height = 3)
    
    
    # opt_alphas_solution %>% 
    #   solutions_to_costs() %>% 
    #   .$solutions_with_costs
    
    
    
    
    
    
    
    
    
    #     alpha_omega_combos_with_outcomes <- alpha_omega_combos %>% 
    #       drop_na_count() %>% 
    #       rowwise() %>% 
    #       mutate(
    #         x = list(c(alpha, best_omega)),
    #         outcomes_policy = outcomes_policy(
    #           x = x, K = K, pi = 0.1, rho = 0.02, outcome = "prop_infected"
    #         ))
    #     
    #     alpha_omega_combos_with_outcomes %>% 
    #       mutate(one_minus_best_omega = 1 - best_omega) %>% 
    #       pivot_longer(c(one_minus_best_omega, outcomes_policy)) %>% 
    #       plot_line_grouped(alpha, value, name) + facet_wrap(~ name, scales = "free_y")
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
# Manual graph of the solution --------------------------------------------
    
    # 
    K <- 5
    alpha_p <- 0.02; alpha_r <- 0.02
    
    best_omega_multi <- function(K, alpha_p, alpha_r, resolution = 0.1) {
      
      results <- tibble(
        omega = seq(0, 1, resolution)
      ) %>% 
        rowwise() %>% 
        mutate(
          x = list(c(alpha_p, alpha_r, omega)),
          cost_constraint = cost_sum_multi(
            x = x, K = K, 
            pi_p = 0.02, pi_r = 0.05, rho_p = 0.001, rho_r = 0.005,
            n_p = 0.5,
            # K = 6, #eta_self_max = 0.7, 
            beta_basic = 1, 
            phi = 1.5, 
            gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
            tau = 1        ,     # leaving quarantine     (5 day duration)
            kappa =  0.5   ,  # contact tracing per person per day
            lambda_basic = 0.2     ,
            nu = 15 / 1000 * (1 / 365)      , # birth rate / day
            mu = 15 / 1000 * (1 / 365),
            psi = 0.7,
            allow_negative_I = TRUE,
            outcome = "peak_val",
            epidemic_threshold = 0.001)
        )
      
      return(results)
      
      
      
      # min_na(results$omega[results$cost_constraint < 0])
      
    }
    
    
    # NO TARGETING - alphas are the same
    alpha_omega_combos_multi <- crossing(
      alpha_p = c(0.005, 0.01, 0.02, 0.03, 0.04, 0.05)
    ) %>% 
      mutate(alpha_r = alpha_p) %>% 
      rowwise() %>% 
      mutate(best_omega = list(best_omega_multi(K = 5, alpha_p = alpha_p, alpha_r = alpha_r,
                                                resolution = 0.1)))
    
    
    # alpha_omega_combos_multi %>% 
    #   unnest(best_omega) %>% 
    #   group_by(alpha_p, alpha_r) %>% 
    #   summarise(best_omega = min_na(omega[cost_constraint < 0])) %>% 
    #   print_all %>% 
    #   plot_line(alpha_p, 1 - best_omega)
    
    
    alpha_omega_combos_multi_with_outcomes <- alpha_omega_combos_multi %>% 
      unnest(best_omega) %>% 
      group_by(alpha_p, alpha_r) %>% 
      summarise(best_omega = min_na(omega[cost_constraint < 0])) %>% 
      # print() %>% 
      drop_na_count(best_omega) %>% 
      rowwise() %>% 
      mutate(
        x = list(c(alpha_p, alpha_r, best_omega))
      ) %>% print() %>% 
      mutate(
        peak_val = outcomes_policy_multi(
          x = x, K = K, 
          pi_p = 0.02, pi_r = 0.05, rho_p = 0.001, rho_r = 0.005,
          n_p = 0.5,
          # K = 6, #eta_self_max = 0.7, 
          beta_basic = 1, 
          phi = 1.5, 
          gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
          tau = 1        ,     # leaving quarantine     (5 day duration)
          kappa =  0.5   ,  # contact tracing per person per day
          lambda_basic = 0.2     ,
          nu = 15 / 1000 * (1 / 365)      , # birth rate / day
          mu = 15 / 1000 * (1 / 365),
          psi = 0.7,
          allow_negative_I = TRUE,
          outcome = "peak_val",
          epidemic_threshold = 0.001
        )
      ) %>% 
      mutate(total_alpha = alpha_p + alpha_r)
    
    alpha_omega_combos_multi_with_outcomes %>% print_all
    
    
    alpha_omega_combos_multi_with_outcomes %>% plot_line(alpha_p, peak_val)
    
    
    
    
    
    # WITH TARGETING ***
    alpha_omega_with_targeting <- crossing(
      alpha_p = seq(0.01, 0.05, 0.01)
    ) %>% 
      mutate(alpha_r = 0) %>% 
      rowwise() %>% 
      mutate(best_omega = list(best_omega_multi(K = 5, alpha_p = alpha_p, alpha_r = alpha_r,
                                                resolution = 0.1)))
    
    
    
    
    alpha_omega_with_targeting_outcomes <- alpha_omega_with_targeting %>% 
      unnest(best_omega) %>% 
      group_by(alpha_p, alpha_r) %>% 
      summarise(best_omega = min_na(omega[cost_constraint < 0])) %>% 
      # print() %>% 
      drop_na_count(best_omega) %>% 
      rowwise() %>% 
      mutate(
        x = list(c(alpha_p, alpha_r, best_omega))
      ) %>% print() %>% 
      mutate(
        peak_val = outcomes_policy_multi(
          x = x, K = K, 
          pi_p = 0.02, pi_r = 0.05, rho_p = 0.001, rho_r = 0.005,
          n_p = 0.5,
          # K = 6, #eta_self_max = 0.7, 
          beta_basic = 1, 
          phi = 1.5, 
          gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
          tau = 1        ,     # leaving quarantine     (5 day duration)
          kappa =  0.5   ,  # contact tracing per person per day
          lambda_basic = 0.2     ,
          nu = 15 / 1000 * (1 / 365)      , # birth rate / day
          mu = 15 / 1000 * (1 / 365),
          psi = 0.7,
          allow_negative_I = TRUE,
          outcome = "peak_val",
          epidemic_threshold = 0.001
        )
      ) %>% 
      mutate(total_alpha = alpha_p + alpha_r)
    
    
    
    bind_rows(
      uniform = alpha_omega_combos_multi_with_outcomes,
      targeted = alpha_omega_with_targeting_outcomes,
      .id = "control_method"
    ) %>% 
      plot_line_grouped(total_alpha, peak_val, control_method)    
    
    
    

# …….. --------------------------------------------------------------------
# OLD  ----------------------------------------------------------------------


# Non-linear optimisation - R0 -------------------------------------------------
    
    # install.packages("nloptr")
    library(nloptr)
    # https://cran.r-project.org/web/packages/nloptr/vignettes/nloptr.pdf
    # https://nlopt.readthedocs.io/en/latest/NLopt_Algorithms/
    
    # Objective function - the effective reproduction number
    re_policy_multi <- function(
      # x, I, K, pi, rho
      x, pi_p, pi_r, rho_p, rho_r, I_p, I_r, n_p, K, 
      beta_basic, phi, gamma, tau, kappa, lambda_basic, lambda_scalar_yn, nu, mu, psi
    ) {
      stopifnot(length(x) == 3)
      # alpha <- x[1]
      # delta <- x[2]
      
      alpha_p <- x[1]
      alpha_r <- x[2]
      omega <- x[3]
      # eta_self <- x[3]
      
      # delta_p <- min(c(pi_p * (1 + omega), 1))
      # delta_r <- min(c(pi_r * (1 + omega), 1))
      
      delta_p <- pi_p * omega + alpha_p
      delta_r <- pi_r * omega + alpha_r
      
      if (pi_p < rho_p) stop("pi_p < rho_p")
      if (pi_r < rho_r) stop("pi_r < rho_r")
      
      r0_multigroup(
        delta_p = delta_p,
        delta_r = delta_r,
        n_p = n_p,
        beta_basic = beta_basic, 
        phi = phi,
        gamma = gamma, 
        tau = tau, 
        kappa = kappa, 
        lambda_basic = lambda_basic, 
        lambda_scalar_yn = lambda_scalar_yn, 
        nu = nu, 
        mu = mu, 
        psi = psi
      )
    }
    
    
    # re_policy_multi(x = c(20/365, 5/365, 0.1), pi_p = 0.6, pi_r = 0.8, n_p = 0.5)
    
    
    
    cost_constraint_multi <- function(
      x, pi_p, pi_r, rho_p, rho_r, I_p, I_r, n_p, K, 
      beta_basic, phi, gamma, tau, kappa, lambda_basic, lambda_scalar_yn, nu, mu, psi
    ) {
      # alpha <- x[1]
      # delta <- x[2]
      # return((alpha + (delta * I) - K))
      
      alpha_p <- x[1]
      alpha_r <- x[2]
      omega <- x[3]
      
      n_r <- 1 - n_p
      
      if (I_r > n_r) stop ("I_r > n_r")
      if (I_p > n_p) stop ("I_p > n_p")
      
      cost_self_p <- ((pi_p * I_p) + (rho_p * (n_p - I_p))) * (omega)
      cost_self_r <- ((pi_r * I_r) + (rho_r * (n_r - I_r))) * (omega)
      cost_random_p <- alpha_p
      cost_random_r <- alpha_r
      
      return(cost_self_p + cost_self_r + cost_random_p + cost_random_r - K)
      
    }
    
    cost_constraint_multi(c(0.3, 0.2, 0.2), 
                          pi_p = 0.5, pi_r = 0.8, rho_p = 0.2, rho_r = 0.2,
                          I_p = 0.1, I_r = 0.1, n_p = 0.5,
                          K = 0.5)
    
    
   
    
    # optimal_multi_test <- nloptr( x0=c(0.1,0.1,0.1),
    #                               eval_f=re_policy_multi,
    #                               # eval_grad_f=eval_grad_f0,
    #                               lb = c(0, 0, 0),
    #                               ub = c(Inf, Inf, 0.7),
    #                               eval_g_ineq = cost_constraint_multi,
    #                               # eval_jac_g_ineq = eval_jac_g0,
    #                               opts = list("algorithm" = "NLOPT_LN_COBYLA",
    #                                           "xtol_rel"=1.0e-8,
    #                                           "print_level" = 3
    #                                           # "check_derivatives" = TRUE,
    #                                           # "check_derivatives_print" = "all"
    #                               ),
    #                               pi_p = 0.5, pi_r = 0.8, rho_p = 0.2, rho_r = 0.2,
    #                               I_p = 0.1, I_r = 0.1, n_p = 0.5,
    #                               K = 0.5, beta_basic = 1.5, phi = 1.5
    # )
    # 
    # optimal_multi_test$solution
    
    
    
    optimise_r0_multi <- function(pi_p = 0.5, pi_r = 0.8, rho_p = 0.2, rho_r = 0.2,
                                  I_p = 0.2, I_r = 0.2, n_p = 0.5,
                                  K = 0.8, eta_self_max = 0.7, 
                                  beta_basic, phi, gamma, tau, kappa, lambda_basic, lambda_scalar_yn, nu, mu, psi) {
      
      opt_results <- nloptr( x0=c(0.1,0.1,0.1),
                             eval_f=re_policy_multi,
                             # eval_grad_f=eval_grad_f0,
                             lb = c(0, 0, 0),
                             ub = c(Inf, Inf, 1),
                             eval_g_ineq = cost_constraint_multi,
                             # eval_jac_g_ineq = eval_jac_g0,
                             opts = list("algorithm" = "NLOPT_LN_COBYLA",
                                         "xtol_rel"=1.0e-8
                                         # "print_level" = 1
                                         # "check_derivatives" = TRUE,
                                         # "check_derivatives_print" = "all"
                             ),
                             pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r,
                             I_p = I_p, I_r = I_r, n_p = n_p,
                             K = K, 
                             beta_basic = beta_basic, 
                             phi = phi,
                             gamma = gamma, 
                             tau = tau, 
                             kappa = kappa, 
                             lambda_basic = lambda_basic, 
                             lambda_scalar_yn = lambda_scalar_yn, 
                             nu = nu, 
                             mu = mu, 
                             psi = psi)
      
      tibble(
        alpha_p = opt_results$solution[1],
        alpha_r = opt_results$solution[2],
        omega = opt_results$solution[3],
        r0 = opt_results$objective
      )
      
    }
    
    # optimise_r0_multi(n_p = 0.6)
  
    
    
    solutions_r0_multi <- function(parameters_df) {
      
      cols_in_parameters_df <- names(parameters_df)
      
      default_parameters <- tibble(
        pi_p = 0.5, pi_r = 0.8, rho_p = 0.2, rho_r = 0.2,
        I_p = 0.2, I_r = 0.2, n_p = 0.5,
        K = 0.8, #eta_self_max = 0.7, 
        beta_basic = 0.5, 
        phi = 1.5, 
        gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
        tau = 0.5        ,     # leaving quarantine     (5 day duration)
        kappa =  0.5   ,  # contact tracing per person per day
        lambda_basic = 0.2     ,
        lambda_scalar_yn = FALSE,
        nu = 15 / 1000 * (1 / 365)      , # birth rate / day
        mu = 15 / 1000 * (1 / 365),
        psi = 0.7  
      ) %>% 
        select(-all_of(cols_in_parameters_df))
      
      final_parameters_df <- parameters_df %>% 
        crossing(default_parameters)
    
      solutions <- final_parameters_df %>%  rowwise() %>% 
        mutate(
          solution = list(optimise_r0_multi(I_p = I_p, I_r = I_r, 
                                            pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r,
                                            n_p = n_p, beta_basic = beta_basic, 
                                            phi = phi,
                                            gamma = gamma, 
                                            tau = tau, 
                                            kappa = kappa, 
                                            lambda_basic = lambda_basic, 
                                            lambda_scalar_yn = lambda_scalar_yn, 
                                            K = K,
                                            nu = nu, 
                                            mu = mu, 
                                            psi = psi))
        ) %>% 
        # select(all_of(cols_in_parameters_df), solution) %>% 
        unnest(solution) %>% 
        mutate(
          n_r = 1 - n_p,
          # delta_p = eta_self * pi_p,
          # delta_r = eta_self * pi_r,
          cost_self_p   = ((pi_p * I_p) + (rho_p * (n_p - I_p))) * (omega),
          cost_self_r   = ((pi_r * I_r) + (rho_r * (n_r - I_r))) * (omega),
          cost_random_p = alpha_p,
          cost_random_r = alpha_r,
          cost_p = cost_self_p + cost_random_p,
          cost_r = cost_self_r + cost_random_r,
          cost_self = cost_self_p + cost_self_r,
          cost_random = cost_random_p + cost_random_r,
          cost_self_prop = cost_self / K,
          cost_random_prop = cost_random / K
        ) %>%
        relocate(cost_p, cost_r)
      
      solutions
    } 
    
    
    
    # Examine relationship with pi_p
    solutions_r0_multi(
      crossing(pi_p = seq(0.01, 0.2, 0.02),
               pi_r = 0.8,
               rho_p = 0.005,
               rho_r = 0.3,
               n_p = 0.5,
               I_p = 0.01,
               I_r = 0.01)
    ) %>% 
      select(pi_p, alpha_p, alpha_r, omega) %>%
      pivot_longer(-pi_p) %>%
      plot_line_grouped(pi_p, value, name)
    
    
    # Relationship with I_p, I_r 
    solutions_r0_multi(
      crossing(
        I_p = seq(0.1, 0.45, 0.1),
        I_r = seq(0.1, 0.45, 0.1)
      )
    ) %>%
      select(I_p, I_r, alpha_p, alpha_r) %>%
      pivot_longer(c(alpha_p, alpha_r)) %>%
      plot_contours(x = I_p, y = I_r, z = value) + facet_wrap(~ name)
    
    # You have more budget leftover when I is low to spend on alpha-type tests
    
    # Relationship with N_p
    solutions_r0_multi(
      tibble(n_p = seq(0.2, 0.7, 0.01),
             beta_basic = 2)
    ) %>% 
      select(n_p, alpha_p, alpha_r, r0) %>%
      pivot_longer(-n_p) %>%
      plot_line_grouped(n_p, value, name) + coord_cartesian(ylim = c(0, NA))
    
    # SOME ERROR HERE - R0 is calculated as a complex value
    
    
    
    
    
    # Relationship if p is MORE likely to get diagnosed
    # Examine relationship with pi_p
    solutions_r0_multi(
      tibble(pi_p = seq(0.3, 0.9, 0.05),
             pi_r = 0.5)
    ) %>% 
      mutate(pi_p_over_pi_r = pi_p/pi_r) %>% 
      select(pi_p_over_pi_r, alpha_p, alpha_r, eta_self) %>%
      pivot_longer(-pi_p_over_pi_r) %>%
      plot_line_grouped(pi_p_over_pi_r, value, name) + 
      geom_vline(xintercept = 1, linetype = "dashed")
    
    # PHI
    solutions_r0_multi(
      crossing(phi = seq(0.2, 3, 0.05),
               lambda_basic = seq(0, 0.4, 0.1))
    ) %>% 
      # print(n = 100) %>% 
      # select(phi, alpha_p, alpha_r, pi_p, I_p) %>%
      pivot_longer(c(alpha_p, alpha_r)) %>%
      plot_line_grouped(phi, value, name) + facet_wrap( ~ lambda_basic)
    
    # When phi is very high - target the rich?? Why?!
    # Link to contact tracing
    
    
    
    # LAMBDA
    solutions_r0_multi(
      crossing(lambda_basic = seq(0, 0.6, 0.05))
    ) %>% 
      pivot_longer(c(alpha_p, alpha_r)) %>%
      plot_line_grouped(lambda_basic, value, name) #+ facet_wrap( ~ lambda_basic)
    
    
    # LAMBDA x PHI
    solutions_r0_multi(
      crossing(lambda_basic = seq(0, 0.4, 0.02),
               phi = seq(1, 3, 0.05))
    ) %>% 
      # pivot_longer(c(alpha_p, alpha_r)) %>%
      mutate(alpha_p_r = alpha_p - alpha_r) %>% 
      plot_contours(lambda_basic, phi, alpha_p_r)
    
    
    # When contact tracing is not so effective... it makes sense to target the higher risk group
    # with random testing
    # But if contact tracing is really effective, it means that you will easily track most of the high
    # risk group through contact tracing, because they transmit and can be detected more easily?
    # So you should target low risk group with random testing because they are less likely to be contact traced
    
    
    
    
    
    
    
    
    # BETA - doesn't matter!
    solutions_r0_multi(
      crossing(beta_basic = seq(0.5, 3, 0.2),
               pi_p = c(0.5, 0.8),
               I_p = c(0.05, 0.2))
    ) %>% 
      # print(n = 100) %>% 
      select(beta_basic, alpha_p, alpha_r, pi_p, I_p) %>%
      pivot_longer(c(alpha_p, alpha_r)) %>%
      plot_line_grouped(beta_basic, value, name) + facet_grid(I_p ~ pi_p)
    
    
    
    
    
    # PLOT proportion of budget spent on each type of testing
    solutions_r0_multi(
      crossing(
        # pi_p = seq(0.01, 0.2, 0.02),
        pi_p = c(0.02, 0.05, 0.1),
        pi_r = 0.2,
        rho_p = 0.01,
        rho_r = 0.05,
        n_p = 0.3,
        I_p = 0.1,
        # I_p = seq(0.01, 0.25, 0.05),
        I_r = 0.1,
        K = seq(0.2, 2, 0.05)
      )
    ) %>% 
      pivot_longer(c(cost_random_prop, cost_self_prop)) %>%
      ggplot(aes(x = K, y = value, fill = name)) + 
      geom_area() + 
      facet_wrap(~ factor(pi_p))
    
    
    solutions_r0_multi(
      crossing(
        # pi_p = seq(0.01, 0.2, 0.02),
        pi_p = c(0.02, 0.05, 0.1),
        pi_r = 0.2,
        rho_p = 0.01,
        rho_r = 0.05,
        n_p = 0.3,
        # I_p = 0.01,
        I_p = 0.1,
        I_r = 0.1,
        K = seq(0.2, 2, 0.05)
        # I_p = seq(0.01, 0.25, 0.05),
      )
    ) %>% 
      pivot_longer(c(alpha_p, alpha_r, omega)) %>%
      plot_line_grouped(K, value, name) + 
      facet_wrap(~ factor(pi_p))
    
    
    
    
    
    # Plot pi_p / pi_r, vs alpha_p / alpha_r
    
    
    
    
    
    
    
    

# Non linear optimisation - other outcomes --------------------------------

    
    # Objective function - gives you the proportion infected
    outcomes_policy_multi <- function(
      x, pi_p, pi_r, rho_p, rho_r, n_p, K, 
      beta_basic, phi, gamma, tau, kappa, lambda_basic, nu, mu, psi,
      outcome, allow_negative_I, epidemic_threshold, return_costs_disagg = NULL
    ) {
      stopifnot(length(x) == 3)
      
      alpha_p <- x[1]
      alpha_r <- x[2]
      omega <- x[3]
      # PROBLEM HERE - alpha + delta surely can't be above one??
      
      # delta_p <- min(c(pi_p * (1 + omega) + alpha_p, 1))
      # delta_r <- min(c(pi_r * (1 + omega) + alpha_r, 1))
      
      delta_p <- pi_p * omega + alpha_p
      delta_r <- pi_r * omega + alpha_r
      
      if (pi_p < rho_p) stop("pi_p < rho_p")
      if (pi_r < rho_r) stop("pi_r < rho_r")
      
      results <- test_tracing_multi(
        delta_p = delta_p,
        delta_r = delta_r,
        n_p = n_p,
        beta_basic = beta_basic, 
        phi = phi,
        gamma = gamma, 
        tau = tau, 
        kappa = kappa, 
        lambda_basic = lambda_basic, 
        # lambda_scalar_yn = lambda_scalar_yn, 
        nu = nu, 
        mu = mu, 
        psi = psi,
        allow_negative_I = allow_negative_I
      )
      
      if (outcome == "prop_infected")  return(results$outcomes$prop_infected)
      else if (outcome == "peak_val") return(results$outcomes$peak_val)
      
    }
    
    
    outcomes_policy_multi(x = c(0.1, 0.1, 1), pi_p = 0.05, pi_r = 0.1, rho_p = 0.001, rho_r = 0.005,
                          n_p = 0.5,
                          K = 40, #eta_self_max = 0.7,
                          beta_basic = 0.5, 
                          phi = 1.5, 
                          gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
                          tau = 0.5        ,     # leaving quarantine     (5 day duration)
                          kappa =  0.5   ,  # contact tracing per person per day
                          lambda_basic = 0.2     ,
                          nu = 15 / 1000 * (1 / 365)      , # birth rate / day
                          mu = 15 / 1000 * (1 / 365),
                          psi = 0.7,
                          allow_negative_I = TRUE,
                          outcome = "prop_infected")
    
    
    
    
    
    # re_policy(c(20/365, 10/365), I = 0.5)
    
    # Cost of testing for a given T
    cost_t_multi <- function(
      x,
      pi_p, pi_r, rho_p, rho_r, kappa, 
      I_p, I_r, D_p, D_r, n_p, 
      epidemic_threshold = 0.001,
      return_costs_disagg = FALSE
    ) {
      stopifnot(length(x) == 3)
      alpha_p <- x[1]
      alpha_r <- x[2]
      omega <- x[3]

      I_tot <- I_p + I_r
      n_r <- 1 - n_p
      
      if (I_r > n_r) stop ("I_r > n_r")
      if (I_p > n_p) stop ("I_p > n_p")
      
      if (I_tot <= epidemic_threshold) {
        if (!return_costs_disagg) return(0)
        else if (return_costs_disagg) {
          costs <- tibble(
            cost_self_p   = 0,
            cost_self_r   = 0,
            cost_random_p = 0,
            cost_random_r = 0,
            cost_contact_p = 0,
            cost_contact_r = 0
          )
        }
      } else if (I_tot > epidemic_threshold) {
        costs <- tibble(
          # cost_self_p   = ((pi_p * I_p) + (rho_p * (n_p - I_p))) * (1 + omega),
          # cost_self_r   = ((pi_r * I_r) + (rho_r * (n_r - I_r))) * (1 + omega),
          cost_self_p   = ((pi_p * I_p) + (rho_p * (n_p - I_p))) * omega,
          cost_self_r   = ((pi_r * I_r) + (rho_r * (n_r - I_r))) * omega,
          cost_random_p = alpha_p,
          cost_random_r = alpha_r,
          cost_contact_p = kappa * D_p,
          cost_contact_r = kappa * D_r
        )
      }

      if (!return_costs_disagg) {
        return(sum(costs))
      } else if (return_costs_disagg) {
        return(costs)
      }
        
    }
    

    
    cost_t_multi(x = c(0.4, 0.1, 2), 
                 pi_p = 0.5, pi_r = 0.8, rho_p = 0.2, rho_r = 0.2,
                 I_p = 0.01, I_r = 0, n_p = 0.5, D_p = 0.01, D_r = 0.02, kappa = 2,
                 return_costs_disagg = FALSE)
    
    
    # cost_overall_multi <- function(x, pi_p, pi_r, rho_p, rho_r, kappa, n_p, K, 
    #                                beta_basic, phi, gamma, tau, lambda_basic, nu, mu, psi,
    #                                outcome, allow_negative_I, epidemic_threshold) {
    #   
    #   stopifnot(length(x) == 3)
    #   alpha_p <- x[1]
    #   alpha_r <- x[2]
    #   omega <- x[3]
    #   delta_p <- pi_p * omega + alpha_p
    #   delta_r <- pi_r * omega + alpha_r
    #   
    #   
    # }
    
    # Overall cost constraint
    cost_sum_multi <- function(
      x, pi_p, pi_r, rho_p, rho_r, kappa, n_p, K, 
      beta_basic, phi, gamma, tau, lambda_basic, nu, mu, psi,
      outcome, allow_negative_I, epidemic_threshold,
      return_costs_disagg = FALSE
    ) {
      stopifnot(length(x) == 3)
      alpha_p <- x[1]
      alpha_r <- x[2]
      omega <- x[3]
      
      # PROBLEM HERE - alpha + delta surely can't be above one??
      
      # delta_p <- min(c(pi_p * (1 + omega) + alpha_p, 1))
      # delta_r <- min(c(pi_r * (1 + omega) + alpha_r, 1))
      
      delta_p <- pi_p * omega + alpha_p
      delta_r <- pi_r * omega + alpha_r
    
      epidemic_profile <- test_tracing_multi(delta_p = delta_p,
                                             delta_r = delta_r,
                                             beta_basic = beta_basic, phi = phi, gamma = gamma, tau = tau,
                                             kappa = kappa, lambda_basic = lambda_basic, nu = nu, mu = mu, psi = psi,
                                             n_p = n_p,
                                             allow_negative_I = allow_negative_I) %>% 
        .$results %>%
        rowwise()
      
      if (!return_costs_disagg) {
        
        epidemic_with_costs <- epidemic_profile %>% 
          mutate(cost_t = cost_t_multi(x = x,
                                       I_p = I_p, I_r = I_r, D_p = D_p, D_r = D_r,
                                       pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r,
                                       n_p = n_p, kappa = kappa, epidemic_threshold = epidemic_threshold))
        
        return(sum(epidemic_with_costs$cost_t) - K)
        
      } else if (return_costs_disagg) {
        
        epidemic_with_costs <- epidemic_profile %>% 
          mutate(cost_t = list(cost_t_multi(x = x,
                                       I_p = I_p, I_r = I_r, D_p = D_p, D_r = D_r,
                                       pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r,
                                       n_p = n_p, kappa = kappa, epidemic_threshold = epidemic_threshold,
                                       return_costs_disagg = TRUE))) %>% 
          unnest(cost_t) %>% 
          summarise(across(starts_with("cost"), sum))
        
        return(epidemic_with_costs)

                 
      }
  


    }
    
    
    
    
    
    
    
    
    cost_sum_multi(x = c(0.01, 0.01, 0.5), pi_p = 0.1, pi_r = 0.1, rho_p = 0.001, rho_r = 0.005,
                              n_p = 0.5,
                              K = 16, #eta_self_max = 0.7,
                              beta_basic = 0.5, 
                              phi = 1.5, 
                              gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
                              tau = 0.5        ,     # leaving quarantine     (5 day duration)
                              kappa =  0.5   ,  # contact tracing per person per day
                              lambda_basic = 0.2     ,
                              nu = 15 / 1000 * (1 / 365)      , # birth rate / day
                              mu = 15 / 1000 * (1 / 365),
                              psi = 0.7,
                   allow_negative_I = TRUE,
                   outcome = "prop_infected",
                   epidemic_threshold = 0.001,
                   return_costs_disagg = TRUE)
    
    
    
    crossing(
      alpha_p = 0.025, alpha_r = 0.025,
      omega = seq(0, 1, 0.1)
    ) %>% 
      rowwise() %>% 
      mutate(x = list(c(alpha_p = alpha_p, alpha_r = alpha_r, omega))) %>% 
      mutate(costs = list(cost_sum_multi(
        x = x, pi_p = 0.1, pi_r = 0.1, rho_p = 0.001, rho_r = 0.005,
        n_p = 0.5,
        K = 5, #eta_self_max = 0.7,
        beta_basic = 1, 
        phi = 1.5, 
        gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
        tau = 0.5        ,     # leaving quarantine     (5 day duration)
        kappa =  0.5   ,  # contact tracing per person per day
        lambda_basic = 0.2     ,
        nu = 15 / 1000 * (1 / 365)      , # birth rate / day
        mu = 15 / 1000 * (1 / 365),
        psi = 0.7,
        allow_negative_I = TRUE,
        outcome = "prop_infected",
        epidemic_threshold = 0.001,
        return_costs_disagg = TRUE
      ))) %>% 
      unnest(costs)
      mutate(cost = cost_constraint + 5)
  
    # Next - why does increasing omega [decreasing self-diagnosis] increase the cost?
      # Because it makes the epidemic last longer and therefore random testing is much more expensive...
    
    
    
    
    optimise_other_multi <- function(pi_p, pi_r, rho_p, rho_r, 
                                     n_p, K, beta_basic, phi, gamma, tau,
                                     kappa, lambda_basic, nu, mu, psi,
                                     outcome, allow_negative_I, epidemic_threshold,
                                     tolerance_level = 1.0e-4, x0 = c(0.01, 0.01, 0.99)) {
      
      print("Calculating optimums")
      
      opt_results <- nloptr( x0 = x0,
                             eval_f=outcomes_policy_multi,
                             # eval_grad_f=eval_grad_f0,
                             lb = c(0,0,0),
                             ub = c(1,1,1),
                             eval_g_ineq = cost_sum_multi,
                             # eval_jac_g_ineq = eval_jac_g0,
                             opts = list(
                               "algorithm" = "NLOPT_LN_AUGLAG",
                               
                               # "algorithm" = "NLOPT_LN_COBYLA", 
                               # "algorithm" = "NLOPT_LN_BOBYQA", - no non linear constraints
                               # "algorithm" = "NLOPT_LN_SBPLX", - doesn't work with non linear constraints
                               # "algorithm" = "NLOPT_GN_ORIG_DIRECT_L", - always gives Inf?
                               # "algorithm" = "NLOPT_GN_ISRES", - seems to always revert to x0
                               "xtol_rel"=tolerance_level,
                               "print_level" = 2,
                               local_opts = list( "algorithm" = "NLOPT_LN_SBPLX",
                                                   "xtol_rel"  = 1.0e-7)
                               # "check_derivatives" = TRUE,
                               # "check_derivatives_print" = "all"
                             ),
                             pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r, 
                             n_p = n_p, K = K, beta_basic = beta_basic, phi = phi, gamma = gamma, tau = tau,
                             kappa = kappa, lambda_basic = lambda_basic, nu = nu, mu = mu, psi = psi,
                             outcome = outcome, allow_negative_I = allow_negative_I, epidemic_threshold = epidemic_threshold,
                             return_costs_disagg = FALSE
      )
      
      # ?'nloptr-package' 

      return(
        tibble(
          alpha_p = opt_results$solution[1],
          alpha_r = opt_results$solution[2],
          omega = opt_results$solution[3],
          objective_result = opt_results$objective,
          status = opt_results$message
        )
        # opt_results
      )
      
      
    }
  
    
    # TEST
    test <- optimise_other_multi(
      pi_p = 0.01, pi_r = 0.02, rho_p = 0.001, rho_r = 0.005,
      n_p = 0.5,
      K = 1, #eta_self_max = 0.7,
      beta_basic = 1.2, 
      phi = 1.5, 
      gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
      tau = 0.5        ,     # leaving quarantine     (5 day duration)
      kappa =  0.5   ,  # contact tracing per person per day
      lambda_basic = 0.2     ,
      nu = 15 / 1000 * (1 / 365)      , # birth rate / day
      mu = 15 / 1000 * (1 / 365),
      psi = 0.7,
      allow_negative_I = TRUE,
      outcome = "peak_val",
      epidemic_threshold = 0.001,
      tolerance_level = 1.0e-3
    )
    

    
    #   alpha_p alpha_r omega objective_result status                                                                          
    #     1.91   0.814  14.9          0.00157 NLOPT_MAXEVAL_REACHED: Optimization stopped because maxeval (above) was reached.
    
    # alpha_p alpha_r omega objective_result status
      # 0.353   0.911  83.9          0.00157 NLOPT_MAXEVAL_REACHED: Optimization stopped because maxeval (above) was reached.
    
    
    
    
    
    solutions_to_costs <- function(solution_df) {
      
      # Data with full simulation timeline
      solutions_with_sim <- solution_df %>% 
        rowwise() %>%
        mutate(
          sim_result = list(test_tracing_multi(
            # delta_p = alpha_p + pi_p * (1 + omega),
            # delta_r = alpha_r + pi_r * (1 + omega),
            delta_p = pi_p * omega + alpha_p,
            delta_r = pi_r * omega + alpha_r,
            beta_basic = beta_basic, phi = phi, gamma = gamma, tau = tau,
            kappa = kappa, lambda_basic = lambda_basic, nu = nu, mu = mu, psi = psi,
            allow_negative_I = allow_negative_I
          ))
        ) %>% 
        rowwise() %>% 
        mutate(sim_result_table = list(sim_result$results),
               sim_id = row_number()) %>% 
        unnest(sim_result_table) %>% 
        mutate(
          n_r = 1 - n_p
        ) %>% 
        # group_by_all() %>% 
        rowwise() %>%
        mutate(x = list(c(alpha_p, alpha_r, omega))) %>% 
        ungroup %>% 
        
        mutate(costs = pmap(list(x = x, pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r, kappa = kappa, 
                                 I_p = I_p, I_r = I_r, D_p = D_p, D_r = D_r, n_p = n_p, epidemic_threshold = epidemic_threshold, return_costs_disagg = TRUE), 
                            cost_t_multi)) %>% 
        unnest(costs)
      # print()
      
      
      solutions_with_costs <- solutions_with_sim %>% 
        select(-c(time:R_tot), x) %>%
        group_by(across(-c(starts_with("cost_")))) %>% 
        summarise(across(starts_with("cost_"), ~ sum(., na.rm = TRUE))) %>% 
        ungroup() %>% 
        mutate(
          cost_p = cost_self_p + cost_random_p + cost_contact_p,
          cost_r = cost_self_r + cost_random_r + cost_contact_r,
          cost_self = cost_self_p + cost_self_r,
          cost_random = cost_random_p + cost_random_r,
          cost_contact = cost_contact_p + cost_contact_r,
          cost_total = cost_self + cost_random + cost_contact,
          cost_self_prop = cost_self / K,
          cost_random_prop = cost_random / K,
          cost_contact_prop = cost_contact / K,
          cost_prop_of_K = cost_total / K,
          exceeds_budget = cost_prop_of_K > 1.1
        )
      
      
      return(
        list(
          solutions_with_sim = solutions_with_sim,
          solutions_with_costs = solutions_with_costs
        )
      )
      
    }
    
    
    
    
    
    
    
    
    solutions_outcomes_multi <- function(parameters_df, tolerance_level = 1.0e-4, x0 = c(0.01, 0.01, 0.99)) {
      
      # Test: parameters_df <- crossing(K = c(0.3, 5)); x0 = c(0.01, 0.01, 0.99)
      
      cols_in_parameters_df <- names(parameters_df)
      
      default_parameters <- tibble(
        pi_p = 0.01, pi_r = 0.02, rho_p = 0.001, rho_r = 0.005,
        n_p = 0.5,
        K = 1, #eta_self_max = 0.7, 
        beta_basic = 1.2, 
        phi = 1.5, 
        gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
        tau = 1        ,     # leaving quarantine     (5 day duration)
        kappa =  0.5   ,  # contact tracing per person per day
        lambda_basic = 0.2     ,
        lambda_scalar_yn = FALSE,
        nu = 15 / 1000 * (1 / 365)      , # birth rate / day
        mu = 15 / 1000 * (1 / 365),
        psi = 0.7,
        allow_negative_I = TRUE,
        outcome = "peak_val",
        epidemic_threshold = 0.001
      ) %>% 
        select(-all_of(cols_in_parameters_df))
      
      final_parameters_df <- parameters_df %>% 
        crossing(default_parameters) %>% 
        mutate(row_id = row_number()) %>% relocate(row_id)
      
      solutions <- final_parameters_df %>%  rowwise() %>% 
        mutate(
          solution = list(optimise_other_multi(pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r, 
                                               n_p = n_p, K = K, beta_basic = beta_basic, phi = phi, gamma = gamma, tau = tau,
                                               kappa = kappa, lambda_basic = lambda_basic, nu = nu, mu = mu, psi = psi,
                                               outcome = outcome, allow_negative_I = allow_negative_I, epidemic_threshold = epidemic_threshold,
                                               x0 = x0))
        ) %>%
        unnest(solution)
      
      # NEW SIM - to calculate costs
      
      solutions_with_costs <- solutions_to_costs(solutions)
      
      solutions_with_costs_sim <- solutions_with_costs$solutions_with_sim
      solutions_with_costs_summ <- solutions_with_costs$solutions_with_costs
      
      
      solutions_with_costs_summ %>% relocate(alpha_p:objective_result, cost_prop_of_K, exceeds_budget)


      # Which simulations exceed the budget constraint
      budget_exceeders <- solutions_with_costs_summ %>% 
        filter(exceeds_budget == TRUE)
      
      if (nrow(budget_exceeders) > 0) {
        
        # Calculate the omega corner solution for the sims that exceeeded budget constraint
        max_omega_df <- final_parameters_df %>% 
          semi_join(budget_exceeders) %>% 
          crossing(
            alpha_p = 0, alpha_r = 0,
            omega = seq(0, 1, 0.01)
          ) %>%
          relocate(alpha_p:omega) %>%
          rowwise() %>%
          mutate(
            x = list(c(alpha_p, alpha_r, omega)),
            cost_constraint_max_omega = cost_sum_multi(
              x = x, K = K,
              pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r,
              n_p = n_p, beta_basic = beta_basic, phi = phi, gamma = gamma, tau = tau, kappa = kappa,
              lambda_basic = lambda_basic, nu = nu, mu = mu, psi = psi,
              allow_negative_I = allow_negative_I, outcome = outcome, epidemic_threshold = epidemic_threshold
            )
          )
        
        # max_omega_df %>% relocate(cost_constraint_max_omega)
        
        # Calculate outcomes and costs for the omega corner solutions
        max_omega_solution <- max_omega_df %>%
          select(-x) %>%
          group_by(across(-c(omega, cost_constraint_max_omega))) %>%
          summarise(
            max_omega = max_na(omega[cost_constraint_max_omega < 0])
          ) %>%
          relocate(max_omega) %>%
          rowwise() %>%
          mutate(
            alpha_p = 0, alpha_r = 0,
            x = list(c(alpha_p, alpha_r, max_omega))
          ) %>%
          mutate(
            objective_result_max_omega = outcomes_policy_multi(
              x = x, K = K,
              pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r,
              n_p = n_p, beta_basic = beta_basic, phi = phi, gamma = gamma, tau = tau, kappa = kappa,
              lambda_basic = lambda_basic, nu = nu, mu = mu, psi = psi,
              allow_negative_I = allow_negative_I, outcome = outcome, epidemic_threshold = epidemic_threshold
            )
          ) %>% 
          relocate(objective_result_max_omega) %>% 
          mutate(omega = max_omega) %>% 
          solutions_to_costs() %>% 
          .$solutions_with_costs
        
        
        # Keep only best solutions
        solutions_both_types <- bind_rows(
          max_omega = max_omega_solution,
          numerical_opt = solutions_with_costs_summ,
          .id = "solution_type"
        ) %>% 
          group_by(row_id) %>% 
          relocate(objective_result, objective_result_max_omega, omega) %>% 
          mutate(objective_result = coalesce(objective_result, objective_result_max_omega)) %>% 
          # view()
          filter(
            exceeds_budget == FALSE
          ) %>% 
          filter(
            objective_result == min(objective_result)
          )
        
      } else {
        
        solutions_both_types <- solutions_with_costs_summ %>% 
          mutate(solution_type = "numerical_opt")
        
        
        
      }

      
      
      
      
      
      
      
      
      return(solutions_both_types)
      
      # 
      # 
      # max_omega %>% filter(K > 0.3) %>% relocate(cost_constraint_max_omega)
      
      
      
      
      # return(
      #   list(
      #     solutions_with_sim = solutions_with_sim,
      #     solutions_with_costs = solutions_with_costs
      #   )
      # )

    }
    

    
    opt_K_test <- solutions_outcomes_multi(
      tibble(K = c(0.2, 1.5))
    )
    
    plot_all(opt_K_test, K)
    
    
    
    
    



    
    
    
    
    
    
    
    
    
    

# Simulation results ------------------------------------------------------

    
    # Functions for plotting
    plot_alpha_omega <- function(dat, x_var) {
      dat %>% pivot_longer(c(alpha_p, alpha_r, omega)) %>% 
        plot_line_grouped({{x_var}}, value, name) + facet_wrap(~ name %in% c("alpha_p", "alpha_r"), scales = "free_y", nrow = 3) + 
        theme(
          strip.background = element_blank(),
          strip.text.x = element_blank()
        )
    }
    
    plot_budget_prop <- function(dat, x_var) {
      dat %>% 
        pivot_longer(matches("cost_.*_(p|r)_prop")) %>% 
        mutate(test_type = factor(
          str_replace_all(name, c("cost_" = "", "_prop" = "")),
          levels = c("random_p", "random_r", "contact_p", "contact_r", "self_p", "self_r")
        )) %>%
        plot_area({{x_var}}, value, test_type)
    }
    
    
    
    plot_cost_over_time <- function(dat, colour_var) {
      dat %>%
        mutate(I_D = I_p + I_r + D_p + D_r,
               cost_self = cost_self_p + cost_self_r,
               cost_random = cost_random_p + cost_random_r,
               cost_contact = cost_contact_p + cost_contact_r) %>% 
        pivot_longer(c(I_D, cost_self_p, cost_random, cost_contact)) %>% 
        # filter(time < 80) %>% 
        ggplot(aes(x = time, y = value, colour = factor({{colour_var}}))) + 
        geom_line(alpha = 0.5) + facet_wrap(~ name)
    }
    
    
    plot_objective <- function(dat, x) {
      dat %>% 
        plot_line(x = {{x}}, y = outcome_val)
    }
    
    
    plot_all <- function(dat, x) {
      
      p_alpha_omega <- plot_alpha_omega(dat, {{x}}) + theme(legend.position = "top")
      
      p_objective <- plot_objective(dat, {{x}}) #%>% print

      p_budget <- plot_budget_prop(dat, {{x}}) + theme(legend.position = "bottom")


      require(ggpubr)

      plot_final <- ggarrange(
        p_alpha_omega, p_objective, p_budget,
        nrow = 3,
        heights = c(3, 2, 3),
        align = "v"
      )

      plot_final
      
      
    }
    
    # ?ggarrange
    
  
    plot_all(opt_by_K_evens$solutions_with_costs, K)

# K -graphs ---------------------------------------------------------------

    # 
    opt_by_K_updated <- solutions_df(
      crossing(
        K = c(seq(0.1, 2, 0.1), seq(2, 9, 0.1)),
        outcome = "peak_val",
        phi = 1,
        sim_res = 0.1
      )
    )
    
    
    opt_by_K_updated %>% 
      # select(matches("cost"))
      select(cost_total, K)
    
    
    opt_by_K_updated %>% filter(K < 8) %>% 
      plot_budget_prop(K)
    
    opt_by_K_updated %>% filter(K < 8) %>% 
      plot_alpha_omega(K)
    
    opt_by_K_updated %>% 
      filter(K < 8) %>% 
      plot_objective(K)
    
    opt_by_K_updated %>% 
      filter(K < 8) %>% 
      plot_all(K)
    
    ggsave("solutions_by_K.png", height = 9, width = 4)
    
    
    

# Try and find non-corner solutions ---------------------------------------

    # Maximise how "expensive" self testing is - rho is the same as pi
    opt_by_K_expensive <- solutions_df(
      crossing(
        K = c(seq(0.1, 2, 0.1), seq(2, 11, 2)),
        outcome = "peak_val",
        phi = 1,
        pi_p = 0.02, rho_p = 0.02, pi_r = 0.05, rho_r = 0.05,
        sim_res = 0.1
      )
    )
    
    plot_all(opt_by_K_expensive, K)
    
    
    
    
    opt_by_K_psi <- solutions_df(
      crossing(
        K = c(seq(0.1, 2, 0.1), seq(2, 11, 2)),
        outcome = "peak_val",
        phi = 1,
        # pi_p = 0.02, rho_p = 0.02, pi_r = 0.05, rho_r = 0.05,
        psi = 1,
        sim_res = 0.1
      )
    )
    
    plot_all(opt_by_K_psi, K)
    
    
    
    # ALL THE SAME SHAPE
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # NO HIGH RISK GROUP (phi = 1), but still pi is lower for p 
    # TAKES A LONG TIME - DON'T DELETE!!
    opt_by_K_new <- solutions_outcomes_multi(
      crossing(
        K = seq(0.1, 3, 0.1),
        # K = c(0.5, 1),
        outcome = "peak_val", 
        phi = 1),
      tolerance_level = 1.0e-5
    )
    
    plot_all(opt_by_K_new, K)
    
 
    
    
    
    
    
    # NO HIGH RISK GROUP (phi = 1), but still pi is lower for p 
    # TAKES A LONG TIME - DON'T DELETE!!
    opt_by_K_evens <- solutions_outcomes_multi(
      crossing(
        K = seq(0.2, 3, 0.1),
        # K = c(0.5, 1),
        outcome = "peak_val", 
        phi = 1),
      tolerance_level = 1.0e-6
    )
    
    # plot_all(opt_by_K_evens$solutions_with_costs %>% filter(K > 0.11, K < 1), K)
    plot_all(opt_by_K_evens$solutions_with_costs %>% filter(K > 0.4), K)
    
    
    
    
    
    
    
    plot_alpha_omega(opt_by_K_evens$solutions_with_cost, K)
    plot_budget_prop(opt_by_K_evens$solutions_with_cost, K)
    
    
    
    # K graph with different starting point
    # opt_by_K_low_start <- solutions_outcomes_multi(
    #   crossing(
    #     K = seq(0.2, 1, 0.2),
    #     # K = c(0.5, 1),
    #     outcome = "peak_val", 
    #     phi = 1),
    #   tolerance_level = 1.0e-6,
    #   x0 = c(0.00, 0.00, 0.01)
    # )
    # 
    # plot_all(opt_by_K_low_start$solutions_with_costs, K)
    
    # WHY DOESN"T THIS WORK BRO -- !!!
    #  MAybe should use a global and then refine??
    
    
    
    
    
    
    
    
    
    
    
    # BY K
    
    
    # test <- solutions_other(crossing(K = c(1:5, 10, 15, 20, 25)))
    opt_by_K <- solutions_outcomes_multi(
      # crossing(K = c(0.5, 1, 1.5, 2, 2.5, 3, 4, 5, 7, 9)),
      # crossing(K = c(0.2, 0.5, 0.6, 0.7, 0.8, 2, 3), outcome = "peak_val"),
      crossing(K = c(0.3, 0.5, 0.55, 0.6, 0.65, 0.7, 2, 3), outcome = "peak_val"),
      tolerance_level = 1.0e-4
    )
    
    
    plot_budget_prop(opt_by_K$solutions_with_cost, K)
    
    
    
    opt_by_K$solutions_with_cost %>% 
      # filter(K >1) %>% 
      # plot_line(K, cost_total) 
      pivot_longer(c(alpha_p, alpha_r, omega)) %>% 
      plot_line_grouped(K, value, name)
    
    opt_by_K$solutions_with_cost %>% 
      pivot_longer(c(cost_self, cost_random, cost_contact)) %>% 
      ggplot(aes(x = K, y = value, fill = name)) + 
      geom_area()
      # geom_abline(slope =1, intercept = 0)
    
    opt_by_K$solutions_with_cost %>% 
      # select(starts_with("cost")) %>% 
      view()
    
    plot_alpha_omega(opt_by_K$solutions_with_cost, K)
    
    
    opt_by_K$solutions_with_cost %>% plot_line(x = K, y = objective_result)
    
    # plot_budget_prop(opt_by_K$solutions_with_cost %>% filter(K >= 1, K < 5), K)
    plot_budget_prop(opt_by_K$solutions_with_cost, K)
    
    plot_cost_over_time(opt_by_K$solutions_with_sim %>% filter(time < 100), K)

    # opt_by_K %>% 
    #   pivot_longer(c(cost_self_p, cost_self_r, cost_random_p, cost_random_r, cost_contact)) %>% 
    #   mutate(value_prop = value / K) %>% 
    #   filter(K >= 1, K < 5) %>% 
    #   ggplot(aes(x = K, y = value_prop, fill = name)) + 
    #   geom_area()
    # geom_abline(slope =1, intercept = 0)
    
    
    opt_by_K_peak_val <- solutions_outcomes_multi(crossing(K = c(1, 1.5, 2, 2.5, 3, 4, 5, 7, 9),
                                                  outcome = "peak_val"))
    
    
    opt_by_K_peak_val$solutions_with_costs %>% plot_alpha_omega(x = K)
    opt_by_K_peak_val$solutions_with_costs %>% plot_budget_prop(x = K)
    
    opt_by_K_peak_val$solutions_with_sim %>% 
      filter(K < 5, time < 100) %>% 
      plot_cost_over_time(K)
    
    opt_by_K_peak_val$solutions_with_costs %>% plot_line(K, objective_result)
    
    
    
    opt_by_K_peak_val_new_starter <- solutions_outcomes_multi(crossing(K = c(0.1, 0.5, 1),
                                                                       outcome = "peak_val"))
    
    opt_by_K_peak_val_new_starter$solutions_with_costs %>% plot_alpha_omega(K)
    opt_by_K_peak_val_new_starter$solutions_with_costs %>% plot_budget_prop(K)
    opt_by_K_peak_val_new_starter$solutions_with_costs %>% plot_line(K, objective_result)
    
    opt_by_K_peak_val %>% 
      plot_line(K, objective_result)
    
    
    
    
    
    # CHECK sensitivity to "epidemic threshold"
    opt_by_K_epidemic_thresh <- solutions_outcomes_multi(
      crossing(K = c(1:5), epidemic_threshold = c(0.1, 0.001, 0.00001))
    )
    
    plot_budget_prop(opt_by_K_epidemic_thresh, K) + facet_wrap(~ factor(epidemic_threshold))
    
    
    
    
    
    
    
    # In this model, only ever have omega at its maximum because
    # we also have to pick a single value of alpha/omega (rather than 
    # varying over time - and it's always going to be cheaper to choose omega


    # LOOK AT PI_p = 0, PSI = 1
    opt_pi_psi <- solutions_outcomes_multi(
      # crossing(K = c(0.5, 1, 1.5, 2, 2.5, 3, 4, 5, 7, 9)),
      crossing(K = c(0.5, 0.8, 1.5, 2), pi_p = 0, rho_p = 0, psi = 1, outcome = "peak_val"),
      tolerance_level = 1.0e-3
    )
    

    
    # 2. By N_p
    opt_by_n <- solutions_outcomes_multi(crossing(n_p = seq(0.1, 0.5, 0.05)))
    
    plot_alpha_omega(opt_by_n, n_p)
    
    plot_budget_prop(opt_by_n, n_p)
  
    # This is interesting - it's better to increase omega when n_p is high,
    # because you want to encourage self testing from the less prone group
    
    
    # 3. By pi_p
    opt_by_pi_p <- solutions_outcomes_multi(
      crossing(pi_p = seq(0.01, 0.2, 0.02), 
               pi_r = 0.1, rho_p = 0, rho_r = 0,
               beta_basic = 0.5, kappa = 0.05,
               K = 3),
      tolerance_level = 1.0e-4
    )
    
    opt_by_pi_p %>% pivot_longer(c(alpha_p, alpha_r, omega)) %>% plot_line_grouped(pi_p, value, name) + facet_wrap(~ name, scales = "free_y", nrow = 3)
    
    opt_by_pi_p %>% pivot_longer(c(cost_self_p, cost_self_r, cost_random_p, cost_random_r)) %>% 
      mutate(value_prop = value / K) %>% 
      plot_area(pi_p, value_prop, name)
    
    opt_by_pi_p$sim_result[[1]]
    
    
    # SEEMS LIKE SLIGHTLY LOWER RATES OF INFECTION AND CONTACT TRACING
    # make the epidemic less sharp and may improve approximation
    test_other_params <- solutions_outcomes_multi(
      crossing(beta_basic = 0.3, kappa = 0),
      tolerance_level = 1.0e-8
    )
    
    test_other_params$alpha_r
    
    test_other_params$sim_result
    
    test_other_params$sim_result
    
    
    
    
    
    # By kappa
    opt_by_kappa <- solutions_outcomes_multi(
      crossing(beta_basic = 0.3, kappa = seq(0, 0.1, 0.02)),
      tolerance_level = 1.0e-8
    )
    
    opt_by_kappa %>% pivot_longer(c(alpha_p, alpha_r, omega)) %>% plot_line_grouped(kappa, value, name) + facet_wrap(~ name %in% c("alpha_p", "alpha_r"), scales = "free_y", nrow = 3)
    
    opt_by_kappa %>% pivot_longer(c(cost_self_p, cost_self_r, cost_random_p, cost_random_r, cost_contact)) %>% 
      mutate(value_prop = value / K) %>% 
      plot_area(pi_p, value_prop, name)
    
    
    # By psi
    opt_by_psi <- solutions_outcomes_multi(
      crossing(psi = seq(0.5, 0.95, 0.05))
    )
    
    plot_alpha_omega(opt_by_psi, psi)
    
    plot_budget_prop(opt_by_psi, psi)
    
    
    
    
    
    
    t <- solutions_outcomes_multi(
      tibble(pi_p = 0.02, pi_r = 0.05, beta_basic = 1.5, K = 0.5, gamma = 0.002, kappa = 0.002, lambda_basic = 0.002)
    )
    
    t$solutions_with_sim %>% select(time, ends_with("tot")) %>% plot_sir()
    
    # Effect of rho
    opt_by_rho <- solutions_outcomes_multi(
      crossing(
        pi_p = 0.02, pi_r = 0.05, beta_basic = 1.5, K = 5, gamma = 0.002, kappa = 0.002, lambda_basic = 0.002,
        rho_factor = c(0, 0.3, 0.8, 0.99), 
        outcome = "peak_val"
      ) %>% 
        mutate(
          rho_p = pi_p * rho_factor, 
          rho_r = pi_r * rho_factor
        ) %>% 
        select(-rho_factor)
    )
    
    opt_by_rho$solutions_with_costs %>% mutate(rho_factor = rho_p / pi_p) %>% 
      plot_alpha_omega(rho_factor)
    
    opt_by_rho$solutions_with_costs %>% view()
    
    opt_by_rho$solutions_with_costs %>% plot_line(x = rho_p / pi_p, y = objective_result)
    
    
    
    
    
    # NEXT - look at case when pi_p = 0!! - so that the ONLY way to target the poor is through 
    # alpah_p
    opt_with_pi_p_0 <- solutions_outcomes_multi(
      crossing(
        pi_p = 0, pi_r = 0.05, rho_p = 0, beta_basic = 1.5, psi = c(1, 0.5), K = c(1, 2.5, 5), gamma = 0.002, kappa = 0.002, lambda_basic = 0.002,
        outcome = "peak_val"
      )
    )
    
    opt_with_pi_p_0$solutions_with_costs %>% plot_alpha_omega(K) + facet_wrap(~ factor(psi))
    opt_with_pi_p_0$solutions_with_costs %>% plot_line(K, objective_result) + facet_wrap(~ factor(psi))
    
    opt_with_pi_p_0$solutions_with_costs %>% plot_alpha_omega(K) + facet_wrap(~ factor(psi))
    
    
    
    
    