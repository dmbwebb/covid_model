    # Sim policy:
    
    sim_policy_multi <- function(
      x, pi_p, pi_r, rho_p, rho_r, n_p, K, 
      beta_basic, phi, gamma, tau, kappa, lambda_basic, nu, mu, psi,
      allow_negative_I, epidemic_threshold
    ) {
      
      stopifnot(length(x) == 3)
      
      alpha_p <- x[1]
      alpha_r <- x[2]
      omega <- x[3]
      # PROBLEM HERE - alpha + delta surely can't be above one??
      
      # delta_p <- min(c(pi_p * (1 + omega) + alpha_p, 1))
      # delta_r <- min(c(pi_r * (1 + omega) + alpha_r, 1))
      
      delta_p <- pi_p * (1 - omega) + alpha_p
      delta_r <- pi_r * (1 - omega) + alpha_r
      
      if (pi_p < rho_p) stop("pi_p < rho_p")
      if (pi_r < rho_r) stop("pi_r < rho_r")
      
      results <- test_tracing_multi(
        delta_p = delta_p,
        delta_r = delta_r,
        n_p = n_p,
        beta_basic = beta_basic, 
        phi = phi,
        gamma = gamma, 
        tau = tau, 
        kappa = kappa, 
        lambda_basic = lambda_basic, 
        # lambda_scalar_yn = lambda_scalar_yn, 
        nu = nu, 
        mu = mu, 
        psi = psi,
        allow_negative_I = allow_negative_I
      )
      
      results
    }
    
    
    sim_policy_multi(x = c(0.1, 0.1, 1), pi_p = 0.05, pi_r = 0.1, rho_p = 0.001, rho_r = 0.005,
                     n_p = 0.5,
                     K = 40, #eta_self_max = 0.7,
                     beta_basic = 0.5, 
                     phi = 1.5, 
                     gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
                     tau = 0.5        ,     # leaving quarantine     (5 day duration)
                     kappa =  0.5   ,  # contact tracing per person per day
                     lambda_basic = 0.2     ,
                     nu = 15 / 1000 * (1 / 365)      , # birth rate / day
                     mu = 15 / 1000 * (1 / 365),
                     psi = 0.7,
                     allow_negative_I = TRUE)
    
    
    outcomes_policy_multi <- function(..., outcome = "prop_infected") {
      
      results <- sim_policy_multi(...)
      
      if (outcome == "prop_infected")  return(results$outcomes$prop_infected)
      else if (outcome == "peak_val") return(results$outcomes$peak_val)
      
    }
    
    outcomes_policy_multi(
      x = c(0.1, 0.1, 1), pi_p = 0.05, pi_r = 0.1, rho_p = 0.001, rho_r = 0.005,
      n_p = 0.5,
      K = 10, #eta_self_max = 0.7,
      beta_basic = 0.5, 
      phi = 1.5, 
      gamma = 1 / 20    ,    # recovery rate/day (10 days duration)
      tau = 0.5        ,     # leaving quarantine     (5 day duration)
      kappa =  0.5   ,  # contact tracing per person per day
      lambda_basic = 0.2     ,
      nu = 15 / 1000 * (1 / 365)      , # birth rate / day
      mu = 15 / 1000 * (1 / 365),
      psi = 0.7,
      allow_negative_I = TRUE,
      outcome = "prop_infected"
    )
    
    
    
    
    
    
    
    
    # Cost of testing for a given T
    cost_t_multi <- function(
      x,
      pi_p, pi_r, rho_p, rho_r, kappa, 
      I_p, I_r, D_p, D_r, n_p, 
      epidemic_threshold = 0.001,
      return_costs_disagg = FALSE
    ) {
      stopifnot(length(x) == 3)
      alpha_p <- x[1]
      alpha_r <- x[2]
      omega <- x[3]
      
      I_tot <- I_p + I_r
      n_r <- 1 - n_p
      
      if (I_r > n_r) stop ("I_r > n_r")
      if (I_p > n_p) stop ("I_p > n_p")
      
      if (I_tot <= epidemic_threshold) {
        if (!return_costs_disagg) return(0)
        else if (return_costs_disagg) {
          costs <- tibble(
            cost_self_p   = 0,
            cost_self_r   = 0,
            cost_random_p = 0,
            cost_random_r = 0,
            cost_contact_p = 0,
            cost_contact_r = 0
          )
        }
      } else if (I_tot > epidemic_threshold) {
        costs <- tibble(
          # cost_self_p   = ((pi_p * I_p) + (rho_p * (n_p - I_p))) * (1 + omega),
          # cost_self_r   = ((pi_r * I_r) + (rho_r * (n_r - I_r))) * (1 + omega),
          cost_self_p   = ((pi_p * I_p) + (rho_p * (n_p - I_p))) * (1 - omega),
          cost_self_r   = ((pi_r * I_r) + (rho_r * (n_r - I_r))) * (1 - omega),
          cost_random_p = alpha_p,
          cost_random_r = alpha_r,
          cost_contact_p = kappa * D_p,
          cost_contact_r = kappa * D_r
        )
      }
      
      if (!return_costs_disagg) {
        return(sum(costs))
      } else if (return_costs_disagg) {
        return(costs)
      }
      
    }
    
    
    
    cost_t_multi(x = c(0.4, 0.1, 2), 
                 pi_p = 0.5, pi_r = 0.8, rho_p = 0.2, rho_r = 0.2,
                 I_p = 0.01, I_r = 0, n_p = 0.5, D_p = 0.01, D_r = 0.02, kappa = 2,
                 return_costs_disagg = FALSE)
    
    # Overall cost constraint
    cost_sum_constraint_multi <- function(
      x, pi_p, pi_r, rho_p, rho_r, kappa, n_p, K, 
      beta_basic, phi, gamma, tau, lambda_basic, nu, mu, psi,
      outcome, allow_negative_I, epidemic_threshold
    ) {
      stopifnot(length(x) == 3)
      alpha_p <- x[1]
      alpha_r <- x[2]
      omega <- x[3]
      
      # PROBLEM HERE - alpha + delta surely can't be above one??
      
      # delta_p <- min(c(pi_p * (1 + omega) + alpha_p, 1))
      # delta_r <- min(c(pi_r * (1 + omega) + alpha_r, 1))
      
      delta_p <- pi_p * (1 - omega) + alpha_p
      delta_r <- pi_r * (1 - omega) + alpha_r
      
      epidemic_profile <- test_tracing_multi(delta_p = delta_p,
                                             delta_r = delta_r,
                                             beta_basic = beta_basic, phi = phi, gamma = gamma, tau = tau,
                                             kappa = kappa, lambda_basic = lambda_basic, nu = nu, mu = mu, psi = psi,
                                             n_p = n_p,
                                             allow_negative_I = allow_negative_I) %>% 
        .$results %>%
        rowwise() %>% 
        mutate(cost_t = cost_t_multi(x = x,
                                     I_p = I_p, I_r = I_r, D_p = D_p, D_r = D_r,
                                     pi_p = pi_p, pi_r = pi_r, rho_p = rho_p, rho_r = rho_r,
                                     n_p = n_p, kappa = kappa, epidemic_threshold = epidemic_threshold))
      
      
      # epidemic_profile
      return(sum(epidemic_profile$cost_t) - K)
      
    }