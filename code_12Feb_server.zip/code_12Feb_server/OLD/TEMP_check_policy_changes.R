    # WITH MOBILITY CHANGES -------------------------------------------------------
    
    
    # lockdown_scale_factor <- 0.5
    # 
    # beta_6_lockdown <- rescale_beta(beta_matrix = beta_matrix_6,
    #                                 rescale_factors = rep(lockdown_scale_factor, 1)) %>% print_all
    # 
    # contacts_mean_6_lockdown <- rescale_contacts_mean(
    #   rescale_factors = rep(lockdown_scale_factor, 1),
    #   beta_matrix = beta_matrix_6,
    #   sar_out = c(0.1, 0.1, 0.1, 0.1, 0.1, 0.1),
    #   group_props = c(0.15, 0.3, 0.25, 0.1, 0.1, 0.1),
    #   contacts_mean_scale = 20,
    #   scale_on = 3
    # ) %>% print
    
    n_pop <- 100000
    n_initial_cases <- round(data_save$group_props * n_pop / 5000) # 5000th of the pop is infected at the model start
    group_props <- c(
      round(data_save$group_props[1:3] * n_pop) / n_pop,
      1 - sum(round(data_save$group_props[1:3] * n_pop) / n_pop)
    )
    
    # When does each phase start/end
    policy_start_times <- c(
      0,
      # 23 + interval_days(data_save$start_date, data_save$lockdown_end_date[[1]]),
      23 + interval_days(data_save$start_date, data_save$lockdown_end_date[[1]])
    ) # 23 is equivalent to April 1st
    
    # Number of contacts is scaled by mobility factor in each phase
    time_varying_params <- list(
      "1_severe_lockdown" = list(
        k_matrix = data_save$k_matrix * data_save$k_scale_factor * (n_pop / data_save$k_matrix_pop)
      ),
      # "2_lighter_lockdown" = list(
      #   k_matrix = data_save$k_matrix * data_save$k_scale_factor * (n_pop / data_save$k_matrix_pop) * data_save$lockdown_end_mobility_increase[[1]]
      # ),
      "3_loose" = list(
        k_matrix = data_save$k_matrix * data_save$k_scale_factor * (n_pop / data_save$k_matrix_pop) * data_save$lockdown_end_mobility_increase[[1]]
      )
    )
    # ) %>% map(~ {            # add in contact means calculation
    #   .$contact_means <- rowSums(.$k_matrix)
    #   return(.)
    # })
    
    
    
    set.seed(12345)
    policy_change_test <- outbreak_sims_policy_change(
      n_sims = 1,
      n_iterations = 150,
      keep_all_data = TRUE,
      print_detail = TRUE,
      constant_params = list(
        n_pop = n_pop, 
        hh_size_data = data_save$hh_data_bogota,
        n_initial_cases = n_initial_cases, # calculated within function if remains NULL
        group_props = group_props,     # ditto
        dt_approx = 1,
        recov_val = 10, # people recover 10 days after symptoms show (cuts off only ~ 1% of infections at the upper end of timing distribution)
        params_timing = data_save$params_timing,
        params_symptom_timing = data_save$params_symptom_timing,
        params_serial = data_save$params_serial,
        test_delay_data = data_save$test_delay_data,
        test_sensitivity_data = data_save$test_sensitivity_data, 
        ct_delay_data = data_save$ct_delay_data,
        probs_self_test_df = data_save$probs_self_test,
        probs_isolate_symptoms_df = data_save$probs_isolate_symptoms,
        probs_isolate_test_df = data_save$probs_isolate_test,
        probs_isolate_ct_df =   data_save$probs_isolate_ct,
        p_contact_if_isolated_home = rep(1, 4), 
        p_contact_traced = data_save$params_data$p_contact_traced,
        p_hh_quarantine = data_save$params_data$p_hh_quarantine,
        
        contact_dispersion = data_save$contact_dispersion,
        sar_out = data_save$params_data$sar_out_input,
        sar_home = data_save$params_data$sar_home_input, 
        infectiousness_by_symptoms = c(0.7, 1),
        alpha = c(0, 0, 0, 0)
      ),
      policy_start_times = policy_start_times,
      time_varying_params = time_varying_params
    )
    
    str_1 <- function(x) { str(x, max.level = 1) }
    
    
    
    t_vec <- policy_change_test$outbreak_t_record[[1]] %>% map_dbl("t")
    
    
    policy_change_test$outbreak_t_record[[1]][[1]]$params$k_matrix
    k_check <- policy_change_test$outbreak_t_record[[1]] %>% map("params") %>% map("k_matrix") %>% map_dbl(~ .[[1]]) %>% enframe() %>% 
      print_all
    
    # K MATRIX CHANGES
    
    secondary_cases_list <- policy_change_test$outbreak_t_record[[1]] %>% map("secondary_cases") %>% 
      set_names(t_vec) %>% 
      bind_rows(.id = "t") %>% 
      mutate(t = as.numeric(t), i_group = factor(i_group)) %>% 
      arrange(case_id, secondary_case_id, t) %>% 
      relocate(case_id, secondary_case_id, t)
    
    
    secondary_cases_list$infection_type
    
    secondary_cases_dedup <- secondary_cases_list %>% 
      select(case_id, secondary_case_id, t, infection_timing, secondary_case_timing, infection_type, n_contacts_out) %>% 
      mutate(infection_t = infection_timing + t,
             secondary_case_t = secondary_case_timing + t) %>% 
      select(-ends_with("timing"), -t) %>% 
      dups_drop()
    
    
    ex_post_r0 <- secondary_cases_dedup %>% 
      mutate(infection_t = round(infection_t)) %>% 
      group_by(infection_t) %>% 
      summarise(n_contacts_out = mean(n_contacts_out),
                # sd = sd(n_contacts_out),
                n = n()) %>% 
      mutate(phase = case_when(
        infection_t < policy_start_times[[2]] ~ "early",
        infection_t >= policy_start_times[[2]] & infection_t < policy_start_times[[3]] ~ "middle",
        infection_t >= policy_start_times[[3]] ~ "late"
      )) %>% 
      group_by(phase) %>% 
      mutate(avg = weighted.mean(x = n_contacts_out, w = n))
    
    
    ggplot(ex_post_r0, aes(x = infection_t, y = n_contacts_out)) + 
      geom_point() + 
      geom_line(aes(y = avg), colour = "indianred")
    
    
    
    
    policy_change_test$time_series %>% group_by(t) %>% summarise(across(where(is.numeric), sum)) %>% tail()

    # EXAMINE the confirmed cases
    confirmed_cases_list <- policy_change_test$outbreak_t_record[[1]][-1] %>% map("confirmed_cases") %>% 
      set_names(t_vec[-1]) %>% 
      bind_rows(.id = "t") %>% 
      mutate(t = as.numeric(t), i_group = factor(i_group)) %>% 
      select(-i_group) %>% 
      group_by(t) %>% 
      summarise(across(everything(), sum)) %>% 
      tail() %>% print
    
    
    
    
