dp2cpMv <- function (dp, family, cp.type = "proper", fixed.nu = NULL, aux = FALSE, 
                     upto = NULL) 
{
  cp.type <- match.arg(cp.type, c("proper", "pseudo", "auto"))
  family <- toupper(family)
  if (!(family %in% c("SN", "ESN", "ST", "SC"))) 
    stop(gettextf("family '%s' is not supported", family), 
         domain = NA)
  if (family %in% c("SN", "ESN")) {
    if (cp.type == "pseudo") 
      warning("'cp.type=pseudo' makes no sense for SN and ESN families")
    cp <- sn:::msn.dp2cp(dp, aux = aux)
    if (!is.null(upto)) 
      cp <- cp[1:upto]
  }
  if (family %in% c("SC", "ST")) {
    if (cp.type == "auto") 
      cp.type <- if (family == "SC" || dp[[4]] <= 4) 
        "pseudo"
    else "proper"
    if (family == "SC") 
      fixed.nu <- 1
    cp <- mst.dp2cp(dp, cp.type = cp.type, fixed.nu = fixed.nu, 
                    aux = aux, upto = upto)
    if (is.null(cp)) {
      warning("no CP could be found")
      return(invisible())
    }
  }
  return(cp)
}

cond_dist
library("tidyverse")



# IMPORT DATA -------------------------------------------------------------

# JOINT - to be used to test
params_timings <- c(3.632810,  3.151445,  1.749993,  2.000000, -2.000000,  3.585770,  0.218750,  3.828127) %>% 
  .[1:7] %>% as.list() %>% set_names(
    c("var_symp", "var_serial", "cov_serial_primary", "cov_serial_secondary",
      "alpha_primary", "alpha_secondary", "alpha_serial")
  )

params_timings$Omega <- matrix(
  c(params_timings$var_symp, 0, params_timings$cov_serial_primary, 
    0,  params_timings$var_symp, params_timings$cov_serial_secondary, 
    params_timings$cov_serial_primary, params_timings$cov_serial_secondary, params_timings$var_serial),
  nrow = 3
)
  

joint_dist <- sn::makeSECdistr(
  dp = list(xi = c(0, 0, 0), 
            Omega = params_timings$Omega, 
            alpha = c(params_timings$alpha_primary, params_timings$alpha_secondary, params_timings$alpha_serial)),
  family = "SN",
  compNames = c("primary_symp", "secondary_symp", "serial")
)

marg_dist_primary <- sn::marginalSECdistr(joint_dist, comp = 1)
marg_dist_secondary <- sn::marginalSECdistr(joint_dist, comp = 2)
marg_dist_serial <- sn::marginalSECdistr(joint_dist, comp = 3)


# FOR TESTING:
# CONDITIONAL DISTIRBUTION - how do they extract tau?
cond_dist <- sn::conditionalSECdistr(
  object = joint_dist,
  fixed.comp = 1,  # fixes primary symptoms
  fixed.values = -1 # fixes at what value
) %>% print



# FUNCTION TO EXTRACT TAU ----------------------------------------------------------

# Calculates the parameter of the conditional SN distributions, 
# when given the first parameter (VECTORISED)
conditional_sn_vec <- function(object, fixed.comp, fixed.values) {
  # TESTING:
  # object <- joint_dist
  # fixed.comp <- 1
  # fixed.values <- c(-2, -1, 0, 1, 2)
  
  
  # Extract parmaters:
  dp <- slot(object, "dp")
  xi <- dp$xi
  Omega <- dp$Omega
  alpha <- dp$alpha
  d <- length(alpha)
  fix <- fixed.comp
  h <- length(fix)
  
  # Calculate stuff that's common to all distributions, ready to get tau_vec
  omega <- sqrt(diag(Omega))
  omega1 <- omega[fix]
  omega2 <- omega[-fix]
  R <- cov2cor(Omega)
  R11 <- R[fix, fix, drop = FALSE]
  R12 <- R[fix, -fix, drop = FALSE]
  R21 <- R[-fix, fix, drop = FALSE]
  R22 <- R[-fix, -fix, drop = FALSE]
  alpha1 <- matrix(alpha[fix], ncol = 1)
  alpha2 <- matrix(alpha[-fix], ncol = 1)
  iR11 <- mnormt::pd.solve(R11)
  R22.1 <- R22 - R21 %*% iR11 %*% R12
  a.sum <- as.vector(t(alpha2) %*% R22.1 %*% alpha2)
  alpha1_2 <- as.vector(alpha1 + iR11 %*% R12 %*% alpha2)/sqrt(1 + 
                                                                 a.sum)
  
  tau_new_vec <- alpha1_2 * (fixed.values - xi[fix])/omega1
  
  
  # Calculate other common stuff, ready to get xi_vec
  
  O11 <- Omega[fix, fix, drop = FALSE]
  O12 <- Omega[fix, -fix, drop = FALSE]
  O21 <- Omega[-fix, fix, drop = FALSE]
  O22 <- Omega[-fix, -fix, drop = FALSE]
  iO11 <- (1/omega1) * iR11 * rep(1/omega1, each = h)
  reg <- O21 %*% iO11
  O22.1 <- O22 - reg %*% O12
  omega22.1 <- sqrt(diag(O22.1))
  alpha2.1 <- as.vector((omega22.1/omega2) * alpha2)
  
  xi_new_matrix <- t(xi[-fix] + reg %*% (fixed.values - xi[fix]))
  
  dp_out <- list(
    xi = xi_new_matrix,
    Omega = O22.1,
    alpha = alpha2.1,
    tau = tau_new_vec
  )
  
  return(dp_out)

}









function (object, fixed.comp, fixed.values, name, drop = TRUE) 
{
  
  # object <- timings_dist$joint_dist
  # fixed.comp <- 1
  # fixed.values <- 2.1
  
  family <- slot(object, "family")
  if (!(family %in% c("SN", "ESN"))) 
    stop("family must be either SN or ESN")
  dp <- slot(object, "dp")
  xi <- dp$xi
  Omega <- dp$Omega
  alpha <- dp$alpha
  tau <- if (family == "SN") 
    0
  else dp$tau
  d <- length(alpha)
  fix <- fixed.comp
  h <- length(fix)
  if (any(fix != round(fix)) | !all(fix %in% 1:d) | h == d) 
    stop("fixed.comp makes no sense")
  if (length(fixed.values) != h) 
    stop("length(fixed.comp) != lenght(fixed.values)")
  compNames <- slot(object, "compNames")
  # if (missing(name)) {
  #   basename <- if (object@name != "") 
  #     object@name
  #   else deparse(substitute(object))
  #   name <- paste(basename, "|(", paste(compNames[fix], 
  #                                       collapse = ","), ")=(", paste(format(fixed.values), 
  #                                                                     collapse = ","), ")", sep = "")
  # }
  # else name <- as.character(name)[1]
  omega <- sqrt(diag(Omega))
  omega1 <- omega[fix]
  omega2 <- omega[-fix]
  R <- cov2cor(Omega)
  R11 <- R[fix, fix, drop = FALSE]
  R12 <- R[fix, -fix, drop = FALSE]
  R21 <- R[-fix, fix, drop = FALSE]
  R22 <- R[-fix, -fix, drop = FALSE]
  alpha1 <- matrix(alpha[fix], ncol = 1)
  alpha2 <- matrix(alpha[-fix], ncol = 1)
  iR11 <- mnormt::pd.solve(R11)
  R22.1 <- R22 - R21 %*% iR11 %*% R12
  a.sum <- as.vector(t(alpha2) %*% R22.1 %*% alpha2)
  alpha1_2 <- as.vector(alpha1 + iR11 %*% R12 %*% alpha2)/sqrt(1 + 
                                                                 a.sum)
  tau2.1 <- (tau * sqrt(1 + sum(alpha1_2 * as.vector(iR11 %*% alpha1_2))) + sum(alpha1_2 * (fixed.values - xi[fix])/omega1))
  
  # first half disappears when tau of joint_dist is 0
  sum(alpha1_2 * (fixed.values - xi[fix])/omega1)
  # xi = 0
  
  
  
  
  O11 <- Omega[fix, fix, drop = FALSE]
  O12 <- Omega[fix, -fix, drop = FALSE]
  O21 <- Omega[-fix, fix, drop = FALSE]
  O22 <- Omega[-fix, -fix, drop = FALSE]
  iO11 <- (1/omega1) * iR11 * rep(1/omega1, each = h)
  reg <- O21 %*% iO11
  xi2.1 <- as.vector(xi[-fix] + reg %*% (fixed.values - xi[fix]))
  O22.1 <- O22 - reg %*% O12
  omega22.1 <- sqrt(diag(O22.1))
  alpha2.1 <- as.vector((omega22.1/omega2) * alpha2)
  dp2.1 <- list(xi = xi2.1, Omega = O22.1, alpha = alpha2.1, 
                tau = tau2.1)
  obj <- if ((d - h) == 1 & drop) {
    dp2.1 <- unlist(dp2.1)
    dp2.1[2] <- sqrt(dp2.1[2])
    names(dp2.1) <- c("xi", "omega", "alpha", "tau")
    new("SECdistrUv", dp = dp2.1, family = "ESN", name = name)
  }
  else new("SECdistrMv", dp = dp2.1, family = "ESN", name = name, 
           compNames = compNames[-fix])
  return(obj)
}






# FUNCTION TO CALCULATE SECONDARY SYMPTOMS AND SERIAL ---------------------


# INITIAL DRAW TO GET PRIMARY SYMPTOMS
# TESTING:
primary_symptoms <- sn::rsn(n = 1000, dp = marg_dist_primary@dp)
n_times_vec <- sample(0:10, size = 1000, replace = TRUE)

# Repeat the symptoms vector n_times each
primary_symptoms_rep <- rep(primary_symptoms, times = n_times_vec)

# Calculate TAU and XI for the conditional distributions based on those primary symptom times
conditional_params <- conditional_sn_vec(object = joint_dist, 
                                         fixed.comp = 1, # fix first value (primary symptoms)
                                         fixed.values = primary_symptoms_rep)

tau_vec <- conditional_params$tau
xi_matrix <- conditional_params$xi

n_times <- sum(n_times_vec)

# THIS IS BASED ON THE CODE IN SN::RMSN
# Randomly generate 2 normal variables to be psi-ed (correlated) and then tau-ed
norm_vals <- rnorm(n_times * (2))
y <- matrix(norm_vals, n_times, 2, byrow = FALSE) %*% chol(lot$aux$Psi)   # Psi is invariant across conditional distributions

truncN <- qnorm(runif(n = n_times, min = pnorm(-tau_vec), max = 1))
truncN <- matrix(rep(truncN, 2), ncol = 2)
delta <- lot$aux$delta      #  delta is invariant across conditional distributions
z <- delta * t(truncN) + sqrt(1 - delta^2) * t(y)
y <- t(t(xi_matrix) + lot$aux$omega * z)
# attr(y, "family") <- "SN"
# attr(y, "parameters") <- dp0


serial_parameters <- list("shape" = 8.123758, "rate"  = 0.6361684, "shift" = -7.5)


tibble_bind <- bind_cols(
  tibble(primary_symptoms = primary_symptoms_rep),
  as_tibble(y)
) %>% 
  # rename(primary_symptoms_timing = primary_symptoms) %>% 
  
  # CONVERT TO Qs
  mutate(
    primary_symptoms_timing = sn::psn(x = -primary_symptoms, dp = marg_dist_primary@dp), # note the minus sign !!!
    secondary_symptoms_delay = sn::psn(x = secondary_symp, dp = marg_dist_secondary@dp),
    serial_interval = sn::psn(x = serial, dp = marg_dist_serial@dp)
  ) %>% 
  select(-primary_symptoms, -secondary_symp, -serial) %>% 
  
  # CONVERT TO actual distributions
  mutate(
    primary_symptoms_timing = qlnorm(primary_symptoms_timing, meanlog = 1.63, sdlog = 0.5),
    secondary_symptoms_delay = qlnorm(secondary_symptoms_delay, meanlog = 1.63, sdlog = 0.5),
    serial_interval = qgamma(p = serial_interval, shape = serial_parameters$shape, rate = serial_parameters$rate) + serial_parameters$shift
  ) %>% 
  mutate(secondary_case_timing = primary_symptoms_timing + serial_interval - secondary_symptoms_delay,
         secondary_symptoms_timing = secondary_case_timing + secondary_symptoms_delay)

ggplot(tibble_bind, aes(x = primary_symptoms_timing, y = secondary_case_timing)) + 
  geom_point(alpha = 0.1) + 
  stat_density_2d(aes(fill = ..level..), geom = "polygon")




dim(xi_matrix)
dim(lot$aux$omega * z)





# Calculate the dp
cond_dist <- sn::conditionalSECdistr(
  object = joint_dist,
  fixed.comp = 1,  # fixes primary symptoms
  fixed.values = -5 # fixes at what value
)


dp <- cond_dist@dp

if (!is.null(dp)) {
  dp0 <- dp
  dp0$nu <- NULL
  if (is.null(dp0$tau)) 
    dp0$tau <- 0
  if (names(dp)[1] == "beta") {
    dp0[[1]] <- as.vector(dp[[1]])
    names(dp0)[1] <- "xi"
  }
}
# else dp0 <- list(xi = xi, Omega = Omega, alpha = alpha, 
#                  tau = tau)
# if (any(is.infinite(dp0$alpha))) 
#   stop("Inf's in alpha are not allowed")
lot <- sn:::dp2cpMv(dp = dp0, family = "SN", aux = TRUE)
lot$aux$delta
# lot$aux$Psi



d <- length(dp0$alpha)


# function (n = 1, xi = rep(0, length(alpha)), Omega, alpha, tau = 0, 
#           dp = NULL) 
# {
  
  # n <- 100
 
  
  y <- matrix(norm_vals, n_times, d - 1, byrow = FALSE) %*% chol(lot$aux$Psi)   # Psi is invariant across conditional distributions
  
  # https://sci-hub.ren/https://www.jstor.org/stable/2337278
  # See page 717

  # CALCULATE TAU VEC
  conditional_params <- conditional_sn_vec(object = joint_dist, 
                                           fixed.comp = 1, # fix first value (primary symptoms)
                                           fixed.values = y[, 1])
  
  tau_vec <- conditional_params$tau
  xi_matrix <- conditional_params$xi
  
  # if (dp0$tau == 0) {truncN <- abs(rnorm(n_times))}
  # else {truncN <- qnorm(runif(n, min = pnorm(-dp0$tau), max = 1))}
# runif(n = 2, min = c(0, 0.9))
  
  
  # COULD WE GET A VECTOR OF TAU??
  
  Y0_vals <- c(
    abs(rep(rnorm(n), times = n_times_vec))
  )
  
  truncN <- matrix(rep(Y0_vals, d), ncol = d)
  delta <- lot$aux$delta
  z <- delta * t(truncN) + sqrt(1 - delta^2) * t(y)
  y <- t(dp0$xi + lot$aux$omega * z)
  attr(y, "family") <- "SN"
  attr(y, "parameters") <- dp0
  return(y)
}
