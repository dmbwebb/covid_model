tibble(x = rbinom(n = 100000, size = 5, p = 0.15)) %>% 
  ggplot(aes(x = x)) + geom_bar()

bar_plot <- function(dat, x) {ggplot(dat, aes(x = {{x}})) + geom_bar()}

N <- 1000
r_data <- tibble(
  r_home = rbinom(n = N, size = 5, p = 0.2), # size = num. daily contacts = Number of people in the hh, p = SA
  daily_contacts_out = rnbinom(n = N, size = 0.16, mu = 2 * 10)
) %>% 
  rowwise() %>% 
  mutate(
    r_out = rbinom(n = 1, size = daily_contacts_out, p = 0.05),
  ) %>%
  ungroup %>% 
  mutate(
    r_total = r_home + r_out
  )



pdf_r_home <- tibble(
  r_home = 0:50,
  pdf_r_home = dbinom(r_home, size = 5, prob = 0.2)
)
  
pdf_r_out <- crossing(
  r_out = 0:50,
  D = 0:100
) %>% 
  rowwise() %>% 
  mutate(
    pdf_r_out = dbinom(x = r_out, size = D, prob = 0.05)
  ) %>% 
  ungroup %>% 
  arrange(D, r_out) %>% 
  relocate(D, r_out)


calc_pdf_r_total <- function(r_total, D) {
  
  # r_total <- 5; D <- 100
  
  # i <- 0
  sum <- 0
  
  for (i in 0:r_total) {
    k <- r_total
    
    p_r_home <- pdf_r_home %>% filter(r_home == i) %>% .$pdf_r_home
    p_r_out <- pdf_r_out %>% filter(r_out == k - i,
                                    D == !!D) %>% 
      .$pdf_r_out
    
    p_mult <- p_r_home * p_r_out
    
    sum <- sum + p_mult
  }
  
  return(sum)
  
}

pdf_r_total <- crossing(
  r_total = 0:10,
  D = 0:10
) %>% 
  rowwise() %>% 
  mutate(
    pdf_r_total = calc_pdf_r_total(r_total, D)
  )


ggplot(pdf_r_total, aes(x = r_total, y = pdf_r_total, colour = factor(D))) + 
  geom_line()
  


# Should probably do max likelihood here, but problem is that we're trying to calculate DISTRIBUTION of D rather than 
# a constant D! There's probably many possible answers, not just 1-1 mapping

n_binom_data <- 

  
  




r_data %>% bar_plot(x = r_home)
r_data %>% bar_plot(x = daily_contacts_out)
r_data %>% bar_plot(x = r_out)
r_data %>% bar_plot(x = r_total)

