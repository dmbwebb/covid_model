
# Setup -------------------------------------------------------------------

    # Packages
    library("haven")
    library("readxl")
    library("tidyverse")
    library("sn")
    library("nloptr")
    library("lubridate")


    # Functions
    hist_basic <- function(dat, x, binwidth = NULL, boundary = 0) {
      plot <- ggplot(dat, aes(x = {{x}})) + 
        geom_histogram(boundary = boundary, binwidth = binwidth, colour = "grey", fill = "lightblue")
      
      print(plot)
      
      invisible(dat)
    }


    # List of data to be filled and saved to disk 
    data_save <- list()
    # load("data_save.RData")
    # data_save


# 1. HH size (Census data) -------------------------------------------------------------

    # Downloaded from
    # http://microdatos.dane.gov.co/index.php/catalog/643/data_dictionary
  
    # Directory for folder with Bogota census data
    dir_bogota_census <- "data/bogota census/11_Bogota_DTA"

    # Accommodation data (with stratum) - housing block
    building <- read_dta(str_glue("{dir_bogota_census}/CNPV2018_1VIV_A2_11.DTA"))
    
    building_cleaned <- building %>% 
      count_prop(l_tot_perl) %>% 
      count_prop(u_dpto) %>% 
      select(building_id = cod_encuestas,
             n_hh_in_housing = v_tot_hog,
             stratum = va1_estrato)

    # Household
    households <- read_dta(str_glue("{dir_bogota_census}/CNPV2018_2HOG_A2_11.DTA"))
    
    households_cleaned <- households %>% 
      select(building_id = cod_encuestas,
             hh_id = h_nrohog,
             n_rooms = h_nro_cuartos,
             n_bedrooms = h_nro_dormit,
             hh_size = ha_tot_per)
      
    # households_cleaned %>% dups_report(building_id)        # multiple hh per building
    # households_cleaned %>% dups_report(building_id, hh_id) # no dups
    
    
    # Individuals
    # ind <- read_dta(str_glue("{dir_bogota_census}/CNPV2018_5PER_A2_11.DTA"))
    
    # Location (to restrict to metropolitan area)
    # geo <- read_dta(str_glue("{dir_bogota_census}/CNPV2018_MGN_A2_11.DTA"))
    
    
    # Merge building and household data
    hh_data_merged <- inner_join_track(building_cleaned, households_cleaned, by = "building_id")
    
    hh_data_cleaned <- hh_data_merged %>% 
      mutate(
        building_id = as.character(as.integer(building_id)),
        hh_id = as.character(as.integer(hh_id)),
        hh_id = paste0(building_id, hh_id)
      ) %>% 
      select(-building_id) %>% 
      relocate(hh_id) %>% 
      count_prop(stratum) %>% 
      filter_track(stratum %in% 1:6) %>% 
      mutate(stratum = factor(stratum))

    
    # PLOT THE CDFs of housing size
    hh_data_cleaned %>%
      ggplot(aes(x = hh_size, colour = factor(stratum))) +
      stat_ecdf(aes(colour = stratum), geom = "point") + 
      stat_ecdf(aes(colour = stratum), geom = "step", alpha = 0.4) + 
      facet_wrap(~ stratum) + 
      coord_cartesian(xlim = c(0, 6))
    
    # What are the mean hh_size, and size of each group
    hh_sizes <- hh_data_cleaned %>% group_by(stratum) %>% 
      summarise(mean_hh_size = mean(hh_size, na.rm = TRUE),
                group_n = sum(hh_size, na.rm = TRUE)) %>% 
      mutate(group_prop = group_n / sum(group_n))
    
    group_props_bogota <- hh_sizes$group_prop
    n_pop_bogota <- sum(hh_sizes$group_n)
    
    # Measures of overcrowding
    hh_data_cleaned %>%
      mutate(people_per_room = hh_size / n_rooms,
             people_per_bedroom = hh_size / n_bedrooms) %>% 
      group_by(stratum) %>% 
      summarise(across(c(people_per_room, people_per_bedroom), mean))
    
    # Create long version (at individual level)
    hh_data_long <- hh_data_cleaned %>% 
      group_by(hh_id, stratum, hh_size) %>% 
      summarise(
        hh_ind_id = 1:hh_size
      ) %>% 
      mutate(
        hh_ind_id = paste0(hh_id, "_", hh_ind_id)
      ) %>% 
      ungroup %>% 
      rename(i_group = stratum)
    
    hh_data_bogota <- hh_data_long %>% 
      mutate(i_group = as.integer(i_group), 
             hh_id = as.numeric(hh_id),
             i_group = case_when(i_group %in% c(1, 2) ~ 1L,
                                 i_group %in% c(3, 4) ~ i_group - 1L,
                                 i_group %in% c(5, 6) ~ 4L))
      
    # Add onto data_save
    data_save$hh_data_bogota <- hh_data_bogota
    
    

    # 
    # # OUTPUT A GRAPH of HH SIZE
    # hh_size_means <- data_save$hh_data_bogota %>% 
    #   select(-hh_ind_id) %>% 
    #   dups_drop(hh_id) %>% 
    #   group_by(i_group) %>% 
    #   summarise(mean_se(hh_size))
    # 
    # 
    # hh_size_means %>% 
    #   ggplot(aes(x = i_group, y = y, colour = factor(i_group))) + 
    #   geom_point() + 
    #   geom_errorbar(aes(ymin = ymin, ymax = ymax), width = 0.3) + 
    #   labs(x = "SES group", y = "Estimate") + 
    #   scale_fill_viridis(option = "viridis",
    #                      begin = 0.3, 
    #                      discrete = TRUE)
    
    
    
      

# 1b. Group size --------------------------------------------------------------

    group_props <- data_save$hh_data_bogota %>% 
      group_by(i_group) %>% summarise(n = n()) %>% 
      mutate(group_props = n / sum(n)) %>% 
      pull(group_props)
    
    data_save$group_props <- group_props
    
    
    
    
# 2. Import test sensitivity data --------------------------------------------
    
    test_sensitivity_data <- read_csv(file = "data/grassly_test_sensitivity.txt",
                                      col_types = cols(day_exposure = col_integer(),
                                                       sens = col_double())) %>% 
      rename(days_exposure = day_exposure, sensitivity = sens) %>% 
      bind_rows(
        tibble(
          days_exposure = c(0, 36:50),
          sensitivity = 0
        )
      ) %>% 
      arrange(days_exposure)
    
    
    # Add to data_save
    data_save$test_sensitivity_data <- test_sensitivity_data
    
    

    
    
    



    
    




    
    


    
    



    
    
    
    
    
    
    
# 3. Test delay data ---------------------------------------------------------
    
    
    # Import SDS delay data
    # dir_sds <- "/Users/user/Dropbox/covid-project/data/SDS"
    
    # WITH DATES
    # sds_old <- read_excel(str_glue("{dir_sds}/processed/casos_2020_08_06_cleaned_dates.xlsx"),
    #                       col_types = c(rep("guess", 7),
    #                                     "date",
    #                                     rep("guess", 25)))
    # sds <- read_excel(str_glue("{dir_sds}/originals/casos_2020_09_18.xlsx"))
    # n_max = 200
    # col_types = c("numeric", "text", "text", 
    #               "text", "text", "text", "text", "date", 
    #               "date", "date", "date", "text", "text", 
    #               "numeric", "text", "text", "text", 
    #               "text", "text", "text", "text", "text", 
    #               "text", "text", "text", "text", "text", 
    #               "text", "text", "text", "text", "text", 
    #               "numeric")
    # ?read_excel
    
    sds_jobs <- read_dta(str_glue("data/casos_SDS_poblaciones.dta"))
    

    
    # sds_old %>% count_prop(`ESTRATO SOCIOECONOMICO`)
    
    # COUNT HOW MANY MISSING STRATA
    # sds %>% 
    #   rename_with(janitor::make_clean_names) %>% 
    #   select(starts_with("estrato")) %>% 
    #   mutate(across(starts_with("estrato"), ~ if_else(as.numeric(.) %in% 1:6, as.numeric(.), NA_real_))) %>% 
    #   count_nas()
    
    library("lubridate")
    library("data.table")
    
    
    
    # Clean up date variable names
    clean_sds <- function(.data) {
      .data %>% 
        rename_with(janitor::make_clean_names) %>% 
        mutate(
          across(starts_with("fecha_"), as.Date)
        ) %>% 
        # print_names %>% 
        rename(
          any_of(c(
            "case_id" = "caso",
            "date_symptoms" = "fecha_de_inicio_de_sintomas",
            "date_consultation" = "fecha_de_consulta",
            "date_results" = "fecha_de_diagnostico_fecha_resultado_de_laboratorio",
            "stratum_sivigila" = "estrato_sivigila",
            "stratum_econ" = "estrato_socioeconomico"
          ))
        ) %>% 
        # group_by(month(date_symptoms)) %>% 
        count_prop(date_consultation < date_symptoms)
    }
    
    # Clean the datasets 
    # sds_old_clean <- sds_old %>% clean_sds()
    # sds_clean <- sds %>% clean_sds()
    
    sds_jobs_clean <- sds_jobs %>% 
      rename(
        any_of(c(
          "case_id" = "caso",
          "date_symptoms" = "fechainiciosintomas",
          "date_consultation" = "fecha_consulta",
          "date_results" = "fechadiagnostresultlaboratorio",
          "stratum" = "estratosocioeconomico",
          "stratum_pop" = "poblacion_estrato"
        ))
      ) %>% 
      mutate_track(across(stratum, ~ if_else(as.numeric(.x) %in% 1:6, as.numeric(.x), NA_real_))) %>% 
      mutate(across(starts_with("date"), as.Date)) %>% 
      count_prop(stratum, stratum_pop) %>% 
      mutate(across(c(date_symptoms, date_consultation, date_results), ~ update(., year = 2020))) %>% 
      count_prop(year(date_symptoms), year(date_results), year(date_consultation))
  
    
    
    # Calculate delays
    interval_days <- function(x, y) {interval(x, y) %/% days(1)}
    
    
    
    
    
    # harsh_equal <- function(x, y) {
    #   st_equal <- x == y
    #   both_nas <- is.na(x) & is.na(y)
    #   dplyr::if_else(is.na(st_equal), both_nas, st_equal)
    # }
    
    # # CHeck (in)consistency between the datasets
    # sds_matching <- left_join_track(
    #   sds_old_clean %>% select(case_id, matches("date|stratum")),
    #   sds_clean %>% select(case_id, matches("date|stratum")),
    #   by = "case_id",
    #   .merge = TRUE
    # ) %>% 
    #   mutate(date_symptoms_match = harsh_equal(date_symptoms.x, date_symptoms.y),
    #          date_consultation_match = harsh_equal(date_consultation.x, date_consultation.y),
    #          date_results_match = harsh_equal(date_results.x, date_results.x),
    #          stratum_sivigila_match = harsh_equal(stratum_sivigila.x, stratum_sivigila.y)) %>% 
    #   count_prop(date_symptoms_match) %>% 
    #   count_prop(date_consultation_match) %>% 
    #   count_prop(date_results_match) %>% 
    #   count_prop(stratum_sivigila_match)
    # 
    # 
    # # See relationship between stratum_econ and stratum_sivigila
    # # sds_old_clean %>% 
    # #   select(case_id, matches("date|stratum")) %>% 
    # #   mutate(across(matches("stratum"), ~ if_else(as.numeric(.x) %in% 1:6, as.numeric(.x), NA_real_))) %>% 
    # #   mutate(stratum_match = harsh_equal(stratum_econ, stratum_sivigila)) %>% 
    # #   count_prop(stratum_match, value(stratum_econ) & value(stratum_sivigila)) #  %>%  # only 68% have stratum_econ == stratum_sivigila
    # 
    # # Merge the datasets
    # replace_many_xy <- function(tbl, vars, takes_precedent = "y"){
    #   for(var in vars){
    #     x <- paste0(var,".x")
    #     y <-  paste0(var,".y")
    #     
    #     if (takes_precedent == "y") {
    #       tbl <- mutate(tbl, !!sym(var) := coalesce(!!sym(y), !!sym(x))) %>%
    #         select(-all_of(c(x,y)))
    #     } else if (takes_precedent == "x") {
    #       tbl <- mutate(tbl, !!sym(var) := coalesce(!!sym(x), !!sym(y))) %>%
    #         select(-all_of(c(x,y)))
    #     }
    #     
    #   }
    #   tbl
    # }
    # 
    # 
    # # Merge old and new database
    # sds_merged <- full_join_track(
    #   sds_old_clean %>% select(case_id, matches("date|stratum")),
    #   sds_clean,
    #   by = "case_id",
    #   .merge = TRUE
    # ) %>% 
    #   mutate(across(matches("stratum"), ~ if_else(as.numeric(.x) %in% 1:6, as.numeric(.x), NA_real_))) %>% 
    #   replace_many_xy(vars = c("date_symptoms", "date_consultation", "date_results", "stratum_sivigila"),
    #                   takes_precedent = "y") %>% 
    #   mutate(
    #     stratum = coalesce(stratum_econ, stratum_sivigila)
    #   )
    
    
    
    # Calculate delays
    sds_delays <- sds_jobs_clean %>% 
      mutate(consultation_delay = interval_days(date_symptoms, date_consultation),
             results_delay = interval_days(date_consultation, date_results)) %>% 
      count_prop(consultation_delay, !is.na(date_symptoms)) %>% 
      count_prop(stratum) %>% 
      filter_track(stratum %in% 1:6) %>%     # 35% is unknown (0) !!
      # count_prop()
      count_prop(consultation_delay == 0) %>%   # lots of unkown
      mutate(consultation_delay = if_else(consultation_delay <= 0, NA_real_, consultation_delay),
             results_delay = if_else(results_delay < 0, NA_real_, results_delay)) %>% 
      mutate(total_delay = consultation_delay + results_delay)
    # filter_track(consultation_delay > 0)     # removes asympotmatic people
    
    
    
    
    
    sds_delays %>% summarise(total_delay = mean_na(total_delay)) %>% .$total_delay
    
    
    # What's happening with zero consulation delay people
    # sds_delays %>% 
    #   filter(consultation_delay == 0) %>% 
    #   view_n()
    
    # sds_delays_median <- sds_delays %>% 
    #   filter(stratum %in% 1:6) %>% 
    #   filter(consultation_delay != 0) %>%
    #   group_by(stratum) %>% 
    #   summarise(
    #     across(ends_with("delay"), 
    #            list(median = median_na, mean = mean_na, sub_3 = ~ mean_na(. <= 5)))
    #   ) %>% 
    #   print
    
    # How many below 
    sds_delays %>% nrow()
    
    
    
    
    
    
    # PLOT DISTRIBUTIONS
    # sds_delays %>% 
    #   filter(stratum %in% 1:6) %>% 
    #   # filter(total_delay %between% c(quantile(total_delay, 0.02, na.rm = TRUE), quantile(total_delay, 0.98, na.rm = TRUE))) %>% 
    #   ggplot(aes(x = total_delay)) + geom_density(aes(colour = factor(stratum)), adjust = 2) + 
    #   coord_cartesian(xlim = c(0, 25))
    # 
    # sds_delays %>% 
    #   filter(stratum %in% 1:6) %>% 
    #   filter(consultation_delay != 0) %>% 
    #   # filter(results_delay %between% c(quantile(total_delay, 0.02, na.rm = TRUE), quantile(total_delay, 0.98, na.rm = TRUE))) %>% 
    #   ggplot(aes(x = results_delay)) + geom_density(aes(colour = factor(stratum)), adjust = 2) + 
    #   coord_cartesian(xlim = c(0, 25))
    # 
    # sds_delays %>% 
    #   filter(stratum %in% 1:6) %>% 
    #   filter(consultation_delay != 0) %>% 
    #   ggplot(aes(x = total_delay)) + 
    #   geom_density(aes(colour = factor(stratum))) + 
    #   # geom_histogram(aes(y = ..density.., fill = factor(stratum)), binwidth = 0.5, boundary = -0.25, position = "dodge") + 
    #   coord_cartesian(xlim = c(0, 25))
    # 
    # sds_delays %>% 
    #   filter(stratum %in% 1:6) %>% 
    #   # filter(consultation_delay > 0) %>%
    #   ggplot(aes(x = consultation_delay)) + 
    #   geom_histogram(aes(y = ..density.., fill = factor(stratum)), colour = "white", size = 0.2, binwidth = 0.5, boundary = -0.25, position = "dodge")
    # # coord_cartesian(xlim = c(2, 10))
    
    
    
    # plot_density(sds_delays, x = consultation_delay, y = results_delay)
    
    # ggplot(sds_delays, aes(x = consultation_delay, y = results_delay)) + 
    #   geom_smooth()
    
    
    
    
    
    
    
    
    # Export to data_save
    
    testing_delays_data <- sds_delays %>% 
      select(i_group = stratum, 
             test_choice_delay = consultation_delay,
             test_results_delay = results_delay) %>% 
      mutate(i_group = case_when(i_group %in% 1:2 ~ 1,
                                 i_group %in% 3:4 ~ i_group - 1,
                                 i_group %in% 5:6 ~ 4)) %>% 
      mutate(test_choice_delay = if_else(test_choice_delay == 0, 0.05, test_choice_delay),
             test_results_delay = if_else(test_results_delay == 0, 0.05, test_results_delay)) # add a small delay to the 0s [avoids errors in the model]
    
    testing_delays_data %>% count_prop(value(test_choice_delay), value(test_results_delay))
    
    testing_delays_data %$% cor(test_choice_delay, test_results_delay, use = "pairwise.complete.obs") # basically no correlation
    
    data_save$test_delay_data <- testing_delays_data %>% drop_na()
    
    # save(data_save, file = "data_save")
    # load("data_save")
    # data_save$test_choice_delay_data <- testing_delays_data %>% select(i_group, test_choice_delay) %>% drop_na()
    # 
    # data_save$test_results_delay_data <- testing_delays_data %>% select(i_group, test_results_delay) %>% drop_na()
    
    
# 4. Tracing delays (from testing delays) ---------------------------------------------------------------
    
    
    
    ct_delay_data <- tibble(
      i_group = c(rep(1, 1000), rep(2, 1000), rep(3, 1000), rep(4, 1000)),
      ct_delay = sample(testing_delays_data$test_choice_delay[!is.na(testing_delays_data$test_choice_delay)], 
                        4000, replace = TRUE)
    )
    
    
    data_save$ct_delay_data <- ct_delay_data
    
    
    # Contact tracing delay
    # ct_delay_data_real <- tibble(
    #   i_group = c(rep(1, 1000), rep(2, 1000), rep(3, 1000)),
    #   ct_delay = c(runif(1000, 5, 7), runif(1000, 3, 5), runif(1000, 1, 3))
    # )
    
    # ct_delay_data_real_6 <- tibble(
    #   i_group = c(rep(1, 1000), rep(2, 1000), rep(3, 1000), rep(4, 1000), rep(5, 1000), rep(6, 1000)),
    #   ct_delay = c(runif(1000, 5, 7), runif(1000, 3, 5), runif(1000, 1, 3), runif(1000, 1, 3), runif(1000, 1, 3), runif(1000, 1, 3))
    # )
    
    
    
# 5. Import calculated parameters (from Rachid) -----------------------------------------------------------
    
    library("readxl")
    
    param_file <- "data/params_final.xlsx"
    
    params_data <- read_excel(param_file, n_max = 5)
    
    contact_matrix <- read_excel(param_file, sheet = "contact_matrix") %>% 
      select(-1) %>% 
      as.matrix()
    
    
    # CALCULATE FULL PROBABILITY TIBBLES
    probs_basic_4 <- crossing(
      i_group = 1L:4L, 
      symptom_severity = 1L:2L
    )
    
    probs_self_test <- probs_basic_4 %>% 
      mutate(prob = rep(params_data$prob_self_test, each = 2),
             prob = if_else(symptom_severity == 1, 0, prob)) # asymptomatics (severity = 1) have 0 probability of isolating
    
    
    probs_isolate_symptoms <- probs_basic_4 %>% 
      mutate(prob = rep(params_data$p_isolate_symp, each = 2),
             prob = if_else(symptom_severity == 1, 0, prob)) # asymptomatics (severity = 1) have 0 probability of isolating
    
    
    probs_isolate_test <- probs_basic_4 %>% 
      mutate(prob = rep(params_data$p_isolate_test, each = 2)) # independent of symptom severity
    
    probs_isolate_ct <- probs_basic_4 %>% 
      mutate(prob = rep(params_data$p_isolate_ct, each = 2))   # independent of symptom severity
    
    
    
    
    
    
    data_save$params_data <- params_data
    data_save$contact_matrix <- contact_matrix    
    
    data_save$probs_self_test <- probs_self_test
    data_save$probs_isolate_symptoms <- probs_isolate_symptoms
    data_save$probs_isolate_test <- probs_isolate_test
    data_save$probs_isolate_ct <- probs_isolate_ct
    
    
    


# 6. Contact dispersion ---------------------------------------------------

    # From Bi et al 2020
    data_save$contact_dispersion <- 0.58
    


# ..... -------------------------------------------------------------------


    
# EXPORT TO DISK ----------------------------------------------------------
    
    save(data_save, file = "data_save.RData")
    


    STOP_SOURCED_SCRIPT()
    
    

# .......... --------------------------------------------------------------


    
    
# OUTPUT TABLES/FIGS -----------------------------------------------------------

# Prevalence in each group ------------------------------------------------

    
    cases_by_stratum_by_month <- sds_jobs_clean %>% 
      # rename(stratum = stratum_econ) %>%
      # count_prop(stratum) %>% 
      mutate(stratum = as.integer(stratum)) %>%
      filter(stratum %in% 1:6) %>%
      mutate(stratum = if_else(stratum == 6, 5L, stratum)) %>% 
      mutate(month = lubridate::month(date_results, label = TRUE)) %>% 
      count_prop(month) %>% 
      group_by(stratum, month) %>% 
      summarise(n_cases = n())
    
    group_n <- data_save$hh_data_bogota %>% 
      group_by(i_group) %>% 
      summarise(n = n())
    
    case_rate <- left_join(cases_by_stratum_by_month, group_n, by = c("stratum" = "i_group")) %>% 
      mutate(cases_per_100k = (n_cases / n) * as.integer(1e5))
    
    # PLOT CASE RATE
    case_rate %>% 
      filter(!month %in% c("Mar", "Oct", NA), ! stratum %in% NA) %>% 
      ggplot() + 
      geom_col(aes(x = month, y = cases_per_100k, fill = factor(stratum)), 
               colour = "white", position = "dodge") + 
      geom_hline(yintercept = 0, colour = "darkgrey") + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE) + 
      theme_custom() + 
      labs(x = "Month (2020)", y = "New cases in Bogota per 100,000 population", fill = "SES Group")
    
    ggsave("cases_by_month.png", width = 6, height = 4, scale = 0.85)
    
    
    
    
    # SDS OLD 
    sds_jobs_clean %>% 
      mutate(stratum = as.integer(stratum_econ)) %>%
      filter(stratum %in% 1:6) %>%
      mutate(stratum = if_else(stratum == 6, 5L, stratum)) %>% 
      group_by(stratum, date_results) %>% 
      summarise(n_cases_day = n()) %>% 
      full_join(
        crossing(stratum = 1:5, date_results = ymd("2020-03-01") + days(1:400))
      ) %>% 
      mutate(n_cases_day = if_else(is.na(n_cases_day), 0L, n_cases_day)) %>% 
      arrange(stratum, date_results) %>% 
      group_by(stratum) %>% 
      mutate(n_new_cases_week_roll = zoo::rollsum(n_cases_day, k = 7, fill = NA, align = "right")) %>% 
      left_join(
        group_n, by = c("stratum" = "i_group")
      ) %>% 
      mutate(new_cases_per_cap = (n_new_cases_week_roll / n) * as.integer(1e5)) %>% 
      filter(date_results <= ymd("2020-08-01"), date_results > ymd("2020-04-01")) %>% 
      
      ggplot(aes(x = date_results, y = new_cases_per_cap, colour = factor(stratum))) + 
      geom_line(size = 1) + 
      # geom_label(aes(label = factor(stratum))) + 
      scale_colour_viridis(option = "viridis",
                         begin = 0.25, end = 1,
                         discrete = TRUE) + 
      theme_custom() + 
      labs(x = "Date (2020)", y = "Weekly new confirmed cases per 100k", fill = "SES Group")
    
    
    
    
    # CONFIRMED CASES 
    sds_old_clean %>% 
      mutate(stratum = as.integer(stratum_econ)) %>%
      filter(stratum %in% 1:6) %>% 
      filter(date_results <= ymd("2020-08-01"), date_results > ymd("2020-04-01")) %>% 
      group_by(stratum) %>% 
      summarise(n_confirmed_cases = n()) %>% 
      left_join(
        group_n, by = c("stratum" = "i_group")
      ) %>% 
      mutate(p = n_confirmed_cases / n) %>% 
      mutate(p_ratio = p / p[stratum == 6])
    
    
    
    

# New prevalence df -----------------------------------------------------------------

    # sds_new <- read_excel(str_glue("{dir_sds}/originals/10_03 octubre Covid-19_273481 andes.xlsx"))
    
    stratum_pops <- sds_jobs_clean %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>% 
      group_by(stratum, stratum_pop) %>% summarise() %>% filter(!is.na(stratum)) %>% 
      summarise(stratum_pop = sum(stratum_pop))
    
    # weekly_prev <- 
    sds_jobs_clean %>% 
      # print_names %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>%
      filter(!is.na(stratum)) %>% 
      group_by(stratum, date_results) %>% 
      summarise(n_cases_day = n()) %>% 
      full_join(
        crossing(stratum = 1:4, date_results = ymd("2020-03-01") + days(1:400)), by = c("stratum", "date_results")
      ) %>% 
      left_join(
        stratum_pops, by = c("stratum")
      ) %>% 
      mutate(n_cases_day = if_else(is.na(n_cases_day), 0L, n_cases_day)) %>% 
      arrange(stratum, date_results) %>% 
      group_by(stratum, stratum_pop) %>% 
      mutate(n_new_cases_week_roll = zoo::rollsum(n_cases_day, k = 7, fill = NA, align = "right")) %>% 
      mutate(new_cases_per_cap = (n_new_cases_week_roll / stratum_pop)) %>% 
      filter(date_results <= ymd("2020-11-01"), date_results > ymd("2020-04-01")) %>% 
    
    
    
      ggplot(aes(x = date_results, y = new_cases_per_cap, colour = factor(stratum))) + 
      geom_line(size = 1) + 
      # geom_label(aes(label = factor(stratum))) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      theme_custom() + 
      theme(legend.position = c(0.12, 0.67)) + 
      labs(x = "Date (2020)", y = "Weekly new confirmed cases per capita in group", fill = "SES Group",
           colour = "SES Group") + # + 
      geom_hline(yintercept = 0, colour = "darkgrey")
      # ggrepel::geom_label_repel(data = . %>% filter(date_results == ymd("2020-07-01")),
      #                           # nudge_x = -5,
      #                           # colour = "black",
      #                           aes(label = factor(stratum)))
      
    
    ggsave("cases_by_week_bogota.png", width = 6, height = 4, scale = 0.85)
    
    
    
    

# Starting prevalence -----------------------------------------------------

    sds_jobs_clean %>% 
      # print_names %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>% 
      arrange(date_results, stratum) %>% 
      group_by(date_results) %>% 
      # group_by(date_results, stratum) %>%
      summarise(n = n()) %>% 
      mutate(cum_n = cumsum(n)) %>% 
      print(n = 100)
    
    # Start date at April 1st - 489 confirmed cases
    start_date <- ymd("2020-04-01")
    
    
    
    best_guess_initial_cases <- sds_jobs_clean %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>% 
      group_by(date_results, stratum) %>%
      summarise(n = n()) %>% 
      ungroup %>% 
      filter(date_results <= start_date) %>% 
      group_by(stratum) %>% 
      filter(!is.na(stratum)) %>% 
      summarise(n = sum(n))
    
    
    
    
    
    
    
    
    
    
# Output tables etc. ------------------------------------------------------
    
    
    # lm_coeff <- function(x) {summary(x)$coefficients[ , 1]}
    # lm_se <- function(x) {summary(x)$coefficients[ , 2]}
    
    # sds_mean_se <- sds_delays %>% 
    #   pivot_longer(matches("delay"), names_to = "delay_var", values_to = "delay_val") %>% 
    #   group_by(stratum, delay_var) %>% 
    #   summarise(mean_se(delay_val, mult = qnorm(0.975)))
    
    # sds_mean_se
    
    
    lm_coeff <- function(x) {summary(x)$coefficients}
    
    
    library("broom")
    
    sds_delays %>% count_prop(
      value(consultation_delay), value(results_delay), value(total_delay)
    )
    
    
    # Get means from group-level regressions
    sds_means <- sds_delays %>% 
      select(case_id, stratum, ends_with("delay")) %>% 
      pivot_longer(matches("delay"), names_to = "delay_var", values_to = "delay_val") %>% 
      group_by(stratum, delay_var) %>% 
      arrange(delay_var, stratum) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(
        N = sum(!is.na(data[["delay_val"]])),
        reg = list(lm("delay_val ~ 1", data = data))
      ) %>% 
      summarise(broom::tidy(reg, conf.int = TRUE), N = N) %>% 
      select(-term, -statistic, -p.value)
      
      
    # Get comparison to group 1
    sds_mean_diffs <- sds_delays %>% 
      select(case_id, stratum, ends_with("delay")) %>% 
      pivot_longer(-c(stratum, case_id), names_to = "delay_var", values_to = "delay_val") %>% 
      group_by(delay_var) %>% 
      mutate(stratum = factor(stratum, levels = as.character(1:6))) %>% 
      arrange(delay_var, stratum) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(
        reg = list(lm("delay_val ~ stratum", data = data))
      ) %>% 
      summarise(broom::tidy(reg, conf.int = TRUE))
    
    signif_stars <- function(x) {
      case_when(x <= 0.01 ~ "***",
                x <= 0.05 ~ "**",
                x <= 0.1 ~ "*",
                x > 0.1 ~ "n.s.")
    }
    
    
    test_delay_plot <- function(delay_var) {
      
      p_val_data <- sds_mean_diffs %>% 
        filter(delay_var == !!delay_var) %>% 
        select(term, p = p.value) %>% 
        mutate(group1 = 1,
               group2 = as.numeric(str_replace(term, "stratum", ""))) %>% 
        drop_na() %>% 
        mutate(stratum = group2) %>% 
        mutate(signif = signif_stars(p)) %>% 
        print
      
      ggplot(data = sds_means %>% filter(delay_var == !!delay_var),
             aes(x = stratum, y = estimate, colour = factor(stratum))) + 
        geom_point() + 
        geom_errorbar(aes(x = stratum, ymin = conf.low, ymax = conf.high),
                      width = 0.1) + 
        ggpubr::stat_pvalue_manual(
          data = p_val_data,
          y.position = max(sds_means %>% filter(delay_var == !!delay_var) %>% .$conf.high) - 0.03, #step.increase = 0.2,
          xmin = "stratum",
          label = "signif"
        ) + 
        theme_custom()
    }
    
    test_delay_plot("consultation_delay")
    ggsave("consultation_delay.png", width = 4, height = 3)
    
    test_delay_plot("results_delay")
    ggsave("results_delay.png", width = 4, height = 3)
    
    test_delay_plot("total_delay")
    ggsave("total_delay.png", width = 4, height = 3)
    
    
    library("texreg")
    library("xtable")
    
    
    
    
    
    
    
    
    
    format_dbl <- function(x, n_digits) {
      as.character(format(round(x, n_digits), nsmall = n_digits))
    }
    
    format_chr <- function(x) {
      str_replace_all(x, "_", " ") %>% 
        str_to_title(locale = "en")
    }
    
    
    
    out_table <- sds_means %>% 
      ungroup %>% 
      mutate(p.value = sds_mean_diffs$p.value) %>% 
      select(-conf.low, -conf.high) %>% 
      mutate(
        stratum = as.integer(stratum),
        p.value = format_dbl(p.value, 3),
        p.value = if_else(stratum == 1, "-", p.value),
        std.error = format_dbl(std.error, 2),
        estimate = format_dbl(estimate, 2),
        delay_var = format_chr(delay_var)
      ) %>% 
      mutate(mean_se = str_glue("{estimate} ({std.error})")) %>% 
      mutate(delay_var = if_else(delay_var == lag(delay_var) & !is.na(lag(delay_var)), "", delay_var)) %>% 
      select("Delay Type" = delay_var, 
             "SES stratum" = stratum, 
             "Mean (SE)" = mean_se,
             "p val diff (to stratum 1)" = p.value,
             "N" = N)
    
    
    
    
    print.xtable(
      xtable(out_table, caption = "Testing Delay Means"),
      # type = "html",
      caption.placement = "top",
      table.placement = "!htbp",
      file = "test_delay_means.tex",
      include.rownames = FALSE
    )
    
    
    
    
    
    
    
    
# Testing delay distribution ----------------------------------------------
    
    # Get means from group-level regressions
    sds_prop <- sds_delays %>% 
      select(case_id, stratum, ends_with("delay")) %>% 
      pivot_longer(-c(stratum, case_id), names_to = "delay_var", values_to = "delay_val") %>% 
      group_by(stratum, delay_var) %>% 
      arrange(delay_var, stratum) %>% 
      mutate(delay_thresh = if_else(delay_var %in% c("consultation_delay", "results_delay"),
                                    delay_val <= 3,
                                    delay_val <= 6)) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(
        N = sum(!is.na(data[["delay_val"]])),
        reg = list(lm("delay_thresh ~ 1", data = data))
      ) %>% 
      summarise(broom::tidy(reg, conf.int = TRUE), N = N) %>% 
      select(-term, -statistic, -p.value)
    
    # Get comparison to group 1
    sds_prop_diff <- sds_delays %>% 
      select(case_id, stratum, ends_with("delay")) %>% 
      pivot_longer(-c(stratum, case_id), names_to = "delay_var", values_to = "delay_val") %>% 
      group_by(delay_var) %>% 
      mutate(stratum = factor(stratum, levels = as.character(1:6))) %>% 
      arrange(delay_var, stratum) %>% 
      mutate(delay_thresh = if_else(delay_var %in% c("consultation_delay", "results_delay"),
                                    delay_val <= 3,
                                    delay_val <= 6)) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(
        reg = list(lm("delay_thresh ~ stratum", data = data))
      ) %>% 
      summarise(tidy(reg, conf.int = TRUE))   
    
    
    out_table_prop <- sds_prop %>% 
      ungroup %>% 
      mutate(p.value = sds_prop_diff$p.value) %>% 
      select(-conf.low, -conf.high) %>% 
      mutate(
        stratum = as.integer(stratum),
        p.value = format_dbl(p.value, 3),
        p.value = if_else(stratum == 1, "-", p.value),
        std.error = format_dbl(std.error, 3),
        estimate = format_dbl(estimate, 3),
        delay_var = format_chr(delay_var)
      ) %>% 
      mutate(
        delay_var = case_when(delay_var %in% c("Consultation Delay", "Results Delay") ~ paste0(delay_var, " <=3 days"),
                              delay_var == "Total Delay" ~ paste0(delay_var, " <=6 days"))
      ) %>% 
      mutate(mean_se = str_glue("{estimate} ({std.error})")) %>% 
      mutate(delay_var = if_else(delay_var == lag(delay_var) & !is.na(lag(delay_var)), "", delay_var)) %>% 
      select("Delay Type" = delay_var, 
             "SES stratum" = stratum, 
             "P(Below threshold) (SE)" = mean_se,
             "p val diff (to stratum 1)" = p.value, 
             N)
    
    
    print.xtable(
      xtable(out_table_prop, caption = "Testing Delays Below 3 day thresholds"),
      # type = "html",
      caption.placement = "top",
      table.placement = "!htbp",
      file = "test_delay_thresh.tex",
      include.rownames = FALSE
    )
    
    
    
    
    
    

# TRACKING DATA (Uni Los Andes) -------------------------------------------

    # dir_tracking <- "/Users/user/Dropbox/RepositorioUniandes/Datos Salesforce/TodosLosDatosConSeguimiento_20201006.csv"
    # 
    # tracking <- read_delim(file = dir_tracking, delim = ";", encoding = locale(encoding = "latin1"))
    # tracking <- read.delim(dir_tracking, sep = ";", header=TRUE, stringsAsFactors=FALSE, fileEncoding="latin1")
    # 
    tracking_tibble <- tracking %>% as_tibble() %>%
      rename_with(janitor::make_clean_names) %>%
      glimpse()
    
    nrow(tracking_tibble)
    
    
    
    
    
    



    
    
    
    

# ............ ------------------------------------------------------------



# OLD ---------------------------------------------------------------------


# # Recovery data -----------------------------------------------------------
    # 
    #     # Byrne et al BMJ - Inferred duration of infectious period
    #     
    #     # As in Cochrane handbook, use:
    #     # SD = sqrt(n) * (Upper CI - Lower CI) / 3.92
    #     
    #     # AFTER SYMPTOM ONSET
    #     mean_recov <- 13.4
    #     recov_upper_ci <- 15.8
    #     recov_lower_ci <- 10.9
    #     
    #     # N is seen in supplementary material 3
    #     recov_n <- sum(
    #       c(10, 298, 1, 242, 1, 24, 8, 1, 5, 2, 1, 1, 1, 1, 66, 10, 76, 1, 2, 36, 1, 1, 1, 7, 74, 3, 18, 25, 191)
    #     )
    #     
    #     sd <- sqrt(recov_n) * (recov_upper_ci - recov_lower_ci) / 3.92
    #     
    
    
    # SAR home ----------------------------------------------------------------
    
    sar_home_vals <- rep(0.188, 3)  # from https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7402051/
    
    
    
    

# Testing delays (old dummy data) -----------------------------------------

    # Testing choice delay (not yet in the model)
    
    
    
    
    
    # # Testing result delay
    # test_results_delay_data <- tibble(
    #   i_group = c(rep(1, 1000), rep(2, 1000), rep(3, 1000)),
    #   test_results_delay = c(runif(1000, 5, 7), runif(1000, 3, 5), runif(1000, 1, 3))
    # )
    # 
    # test_results_delay_data_6 <- tibble(
    #   i_group = c(rep(1, 1000), rep(2, 1000), rep(3, 1000), rep(4, 1000), rep(5, 1000), rep(6, 1000)),
    #   test_results_delay = c(runif(1000, 5, 7), runif(1000, 3, 5), runif(1000, 1, 3), runif(1000, 1, 3), runif(1000, 1, 3), runif(1000, 1, 3))
    # )
    
    # test_sensitivity_data <- test_results_delay_data %>% rename(test_)
    
    # tibble(
    #   i_group = sample(1:3, size = 1000, replace = TRUE),
    #   x = 1:1000
    # ) %>% 
    #   sample_by_i_group(
    #     sample_dat = test_result_delay_data,
    #     sample_vars = c("test_result_delay")
    #   ) %>% 
    #   ggplot(aes(x = test_result_delay, fill = factor(i_group))) + geom_histogram()
    
    