# OUTPUT TABLES/FIGS -----------------------------------------------------------
    
# Prevalence in each group ------------------------------------------------
    
    
    cases_by_stratum_by_month <- sds_jobs_clean %>% 
      # rename(stratum = stratum_econ) %>%
      # count_prop(stratum) %>% 
      mutate(stratum = as.integer(stratum)) %>%
      filter(stratum %in% 1:6) %>%
      mutate(stratum = if_else(stratum == 6, 5L, stratum)) %>% 
      mutate(month = lubridate::month(date_results, label = TRUE)) %>% 
      count_prop(month) %>% 
      group_by(stratum, month) %>% 
      summarise(n_cases = n())
    
    group_n <- data_save$hh_data_bogota %>% 
      group_by(i_group) %>% 
      summarise(n = n())
    
    case_rate <- left_join(cases_by_stratum_by_month, group_n, by = c("stratum" = "i_group")) %>% 
      mutate(cases_per_100k = (n_cases / n) * as.integer(1e5))
    
    # PLOT CASE RATE
    case_rate %>% 
      filter(!month %in% c("Mar", "Oct", NA), ! stratum %in% NA) %>% 
      ggplot() + 
      geom_col(aes(x = month, y = cases_per_100k, fill = factor(stratum)), 
               colour = "white", position = "dodge") + 
      geom_hline(yintercept = 0, colour = "darkgrey") + 
      scale_fill_viridis(option = "viridis",
                         begin = 0.3, 
                         discrete = TRUE) + 
      theme_custom() + 
      labs(x = "Month (2020)", y = "New cases in Bogota per 100,000 population", fill = "SES Group")
    
    ggsave("cases_by_month.png", width = 6, height = 4, scale = 0.85)
    
    
    
    
    # SDS OLD 
    sds_jobs_clean %>% 
      mutate(stratum = as.integer(stratum_econ)) %>%
      filter(stratum %in% 1:6) %>%
      mutate(stratum = if_else(stratum == 6, 5L, stratum)) %>% 
      group_by(stratum, date_results) %>% 
      summarise(n_cases_day = n()) %>% 
      full_join(
        crossing(stratum = 1:5, date_results = ymd("2020-03-01") + days(1:400))
      ) %>% 
      mutate(n_cases_day = if_else(is.na(n_cases_day), 0L, n_cases_day)) %>% 
      arrange(stratum, date_results) %>% 
      group_by(stratum) %>% 
      mutate(n_new_cases_week_roll = zoo::rollsum(n_cases_day, k = 7, fill = NA, align = "right")) %>% 
      left_join(
        group_n, by = c("stratum" = "i_group")
      ) %>% 
      mutate(new_cases_per_cap = (n_new_cases_week_roll / n) * as.integer(1e5)) %>% 
      filter(date_results <= ymd("2020-08-01"), date_results > ymd("2020-04-01")) %>% 
      
      ggplot(aes(x = date_results, y = new_cases_per_cap, colour = factor(stratum))) + 
      geom_line(size = 1) + 
      # geom_label(aes(label = factor(stratum))) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.25, end = 1,
                           discrete = TRUE) + 
      theme_custom() + 
      labs(x = "Date (2020)", y = "Weekly new confirmed cases per 100k", fill = "SES Group")
    
    
    
    
    # CONFIRMED CASES 
    sds_old_clean %>% 
      mutate(stratum = as.integer(stratum_econ)) %>%
      filter(stratum %in% 1:6) %>% 
      filter(date_results <= ymd("2020-08-01"), date_results > ymd("2020-04-01")) %>% 
      group_by(stratum) %>% 
      summarise(n_confirmed_cases = n()) %>% 
      left_join(
        group_n, by = c("stratum" = "i_group")
      ) %>% 
      mutate(p = n_confirmed_cases / n) %>% 
      mutate(p_ratio = p / p[stratum == 6])
    
    
    
    
    
# New prevalence df -----------------------------------------------------------------
    
    # sds_new <- read_excel(str_glue("{dir_sds}/originals/10_03 octubre Covid-19_273481 andes.xlsx"))
    
    stratum_pops <- sds_jobs_clean %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>% 
      group_by(stratum, stratum_pop) %>% summarise() %>% filter(!is.na(stratum)) %>% 
      summarise(stratum_pop = sum(stratum_pop))
    
    # weekly_prev <- 
    sds_jobs_clean %>% 
      # print_names %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>%
      filter(!is.na(stratum)) %>% 
      group_by(stratum, date_results) %>% 
      summarise(n_cases_day = n()) %>% 
      full_join(
        crossing(stratum = 1:4, date_results = ymd("2020-03-01") + days(1:400)), by = c("stratum", "date_results")
      ) %>% 
      left_join(
        stratum_pops, by = c("stratum")
      ) %>% 
      mutate(n_cases_day = if_else(is.na(n_cases_day), 0L, n_cases_day)) %>% 
      arrange(stratum, date_results) %>% 
      group_by(stratum, stratum_pop) %>% 
      mutate(n_new_cases_week_roll = zoo::rollsum(n_cases_day, k = 7, fill = NA, align = "right")) %>% 
      mutate(new_cases_per_cap = (n_new_cases_week_roll / stratum_pop)) %>% 
      filter(date_results <= ymd("2020-11-01"), date_results > ymd("2020-04-01")) %>% 
      
      
      
      ggplot(aes(x = date_results, y = new_cases_per_cap, colour = factor(stratum))) + 
      geom_line(size = 1) + 
      # geom_label(aes(label = factor(stratum))) + 
      scale_colour_viridis(option = "viridis",
                           begin = 0.3, 
                           discrete = TRUE) + 
      theme_custom() + 
      theme(legend.position = c(0.12, 0.67)) + 
      labs(x = "Date (2020)", y = "Weekly new confirmed cases per capita in group", fill = "SES Group",
           colour = "SES Group") + # + 
      geom_hline(yintercept = 0, colour = "darkgrey")
    # ggrepel::geom_label_repel(data = . %>% filter(date_results == ymd("2020-07-01")),
    #                           # nudge_x = -5,
    #                           # colour = "black",
    #                           aes(label = factor(stratum)))
    
    
    ggsave("cases_by_week_bogota.png", width = 6, height = 4, scale = 0.85)
    
    
    
    
    
# Starting prevalence -----------------------------------------------------
    
    sds_jobs_clean %>% 
      # print_names %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>% 
      arrange(date_results, stratum) %>% 
      group_by(date_results) %>% 
      # group_by(date_results, stratum) %>%
      summarise(n = n()) %>% 
      mutate(cum_n = cumsum(n)) %>% 
      print(n = 100)
    
    # Start date at April 1st - 489 confirmed cases
    start_date <- ymd("2020-04-01")
    
    
    best_guess_initial_cases <- sds_jobs_clean %>% 
      mutate(stratum = as.integer(stratum)) %>% 
      mutate(stratum = case_when(stratum %in% c(1, 2) ~ 1L,
                                 stratum %in% c(3, 4) ~ stratum - 1L,
                                 stratum %in% c(5, 6) ~ 4L)) %>% 
      group_by(date_results, stratum, stratum_pop) %>%
      summarise(n = n()) %>% 
      ungroup %>% 
      filter(date_results <= start_date) %>% 
      group_by(stratum, stratum_pop) %>% 
      filter(!is.na(stratum)) %>% 
      summarise(n = sum(n)) %>% 
      group_by(stratum) %>% 
      summarise(stratum_pop = sum(stratum_pop),
                n = sum(n))
    
    
    
    
    
    
    
    
    
    
# Output tables etc. ------------------------------------------------------
    
    
    # lm_coeff <- function(x) {summary(x)$coefficients[ , 1]}
    # lm_se <- function(x) {summary(x)$coefficients[ , 2]}
    
    # sds_mean_se <- sds_delays %>% 
    #   pivot_longer(matches("delay"), names_to = "delay_var", values_to = "delay_val") %>% 
    #   group_by(stratum, delay_var) %>% 
    #   summarise(mean_se(delay_val, mult = qnorm(0.975)))
    
    # sds_mean_se
    
    
    lm_coeff <- function(x) {summary(x)$coefficients}
    
    
    library("broom")
    
    sds_delays %>% count_prop(
      value(consultation_delay), value(results_delay), value(total_delay)
    )
    
    
    # Get means from group-level regressions
    sds_means <- sds_delays %>% 
      select(case_id, stratum, ends_with("delay")) %>% 
      pivot_longer(matches("delay"), names_to = "delay_var", values_to = "delay_val") %>% 
      group_by(stratum, delay_var) %>% 
      arrange(delay_var, stratum) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(
        N = sum(!is.na(data[["delay_val"]])),
        reg = list(lm("delay_val ~ 1", data = data))
      ) %>% 
      summarise(broom::tidy(reg, conf.int = TRUE), N = N) %>% 
      select(-term, -statistic, -p.value)
    
    
    # Get comparison to group 1
    sds_mean_diffs <- sds_delays %>% 
      select(case_id, stratum, ends_with("delay")) %>% 
      pivot_longer(-c(stratum, case_id), names_to = "delay_var", values_to = "delay_val") %>% 
      group_by(delay_var) %>% 
      mutate(stratum = factor(stratum, levels = as.character(1:6))) %>% 
      arrange(delay_var, stratum) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(
        reg = list(lm("delay_val ~ stratum", data = data))
      ) %>% 
      summarise(broom::tidy(reg, conf.int = TRUE))
    
    signif_stars <- function(x) {
      case_when(x <= 0.01 ~ "***",
                x <= 0.05 ~ "**",
                x <= 0.1 ~ "*",
                x > 0.1 ~ "n.s.")
    }
    
    
    test_delay_plot <- function(delay_var) {
      
      p_val_data <- sds_mean_diffs %>% 
        filter(delay_var == !!delay_var) %>% 
        select(term, p = p.value) %>% 
        mutate(group1 = 1,
               group2 = as.numeric(str_replace(term, "stratum", ""))) %>% 
        drop_na() %>% 
        mutate(stratum = group2) %>% 
        mutate(signif = signif_stars(p)) %>% 
        print
      
      ggplot(data = sds_means %>% filter(delay_var == !!delay_var),
             aes(x = stratum, y = estimate, colour = factor(stratum))) + 
        geom_point() + 
        geom_errorbar(aes(x = stratum, ymin = conf.low, ymax = conf.high),
                      width = 0.1) + 
        ggpubr::stat_pvalue_manual(
          data = p_val_data,
          y.position = max(sds_means %>% filter(delay_var == !!delay_var) %>% .$conf.high) - 0.03, #step.increase = 0.2,
          xmin = "stratum",
          label = "signif"
        ) + 
        theme_custom()
    }
    
    test_delay_plot("consultation_delay")
    ggsave("consultation_delay.png", width = 4, height = 3)
    
    test_delay_plot("results_delay")
    ggsave("results_delay.png", width = 4, height = 3)
    
    test_delay_plot("total_delay")
    ggsave("total_delay.png", width = 4, height = 3)
    
    
    library("texreg")
    library("xtable")
    
    
    
    
    
    
    
    
    
    format_dbl <- function(x, n_digits) {
      as.character(format(round(x, n_digits), nsmall = n_digits))
    }
    
    format_chr <- function(x) {
      str_replace_all(x, "_", " ") %>% 
        str_to_title(locale = "en")
    }
    
    
    
    out_table <- sds_means %>% 
      ungroup %>% 
      mutate(p.value = sds_mean_diffs$p.value) %>% 
      select(-conf.low, -conf.high) %>% 
      mutate(
        stratum = as.integer(stratum),
        p.value = format_dbl(p.value, 3),
        p.value = if_else(stratum == 1, "-", p.value),
        std.error = format_dbl(std.error, 2),
        estimate = format_dbl(estimate, 2),
        delay_var = format_chr(delay_var)
      ) %>% 
      mutate(mean_se = str_glue("{estimate} ({std.error})")) %>% 
      mutate(delay_var = if_else(delay_var == lag(delay_var) & !is.na(lag(delay_var)), "", delay_var)) %>% 
      select("Delay Type" = delay_var, 
             "SES stratum" = stratum, 
             "Mean (SE)" = mean_se,
             "p val diff (to stratum 1)" = p.value,
             "N" = N)
    
    
    
    
    print.xtable(
      xtable(out_table, caption = "Testing Delay Means"),
      # type = "html",
      caption.placement = "top",
      table.placement = "!htbp",
      file = "test_delay_means.tex",
      include.rownames = FALSE
    )
    
    
    
    
    
    
    
    
# Testing delay distribution ----------------------------------------------
    
    # Get means from group-level regressions
    sds_prop <- sds_delays %>% 
      select(case_id, stratum, ends_with("delay")) %>% 
      pivot_longer(-c(stratum, case_id), names_to = "delay_var", values_to = "delay_val") %>% 
      group_by(stratum, delay_var) %>% 
      arrange(delay_var, stratum) %>% 
      mutate(delay_thresh = if_else(delay_var %in% c("consultation_delay", "results_delay"),
                                    delay_val <= 3,
                                    delay_val <= 6)) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(
        N = sum(!is.na(data[["delay_val"]])),
        reg = list(lm("delay_thresh ~ 1", data = data))
      ) %>% 
      summarise(broom::tidy(reg, conf.int = TRUE), N = N) %>% 
      select(-term, -statistic, -p.value)
    
    # Get comparison to group 1
    sds_prop_diff <- sds_delays %>% 
      select(case_id, stratum, ends_with("delay")) %>% 
      pivot_longer(-c(stratum, case_id), names_to = "delay_var", values_to = "delay_val") %>% 
      group_by(delay_var) %>% 
      mutate(stratum = factor(stratum, levels = as.character(1:6))) %>% 
      arrange(delay_var, stratum) %>% 
      mutate(delay_thresh = if_else(delay_var %in% c("consultation_delay", "results_delay"),
                                    delay_val <= 3,
                                    delay_val <= 6)) %>% 
      nest() %>% 
      rowwise() %>% 
      mutate(
        reg = list(lm("delay_thresh ~ stratum", data = data))
      ) %>% 
      summarise(tidy(reg, conf.int = TRUE))   
    
    
    out_table_prop <- sds_prop %>% 
      ungroup %>% 
      mutate(p.value = sds_prop_diff$p.value) %>% 
      select(-conf.low, -conf.high) %>% 
      mutate(
        stratum = as.integer(stratum),
        p.value = format_dbl(p.value, 3),
        p.value = if_else(stratum == 1, "-", p.value),
        std.error = format_dbl(std.error, 3),
        estimate = format_dbl(estimate, 3),
        delay_var = format_chr(delay_var)
      ) %>% 
      mutate(
        delay_var = case_when(delay_var %in% c("Consultation Delay", "Results Delay") ~ paste0(delay_var, " <=3 days"),
                              delay_var == "Total Delay" ~ paste0(delay_var, " <=6 days"))
      ) %>% 
      mutate(mean_se = str_glue("{estimate} ({std.error})")) %>% 
      mutate(delay_var = if_else(delay_var == lag(delay_var) & !is.na(lag(delay_var)), "", delay_var)) %>% 
      select("Delay Type" = delay_var, 
             "SES stratum" = stratum, 
             "P(Below threshold) (SE)" = mean_se,
             "p val diff (to stratum 1)" = p.value, 
             N)
    
    
    print.xtable(
      xtable(out_table_prop, caption = "Testing Delays Below 3 day thresholds"),
      # type = "html",
      caption.placement = "top",
      table.placement = "!htbp",
      file = "test_delay_thresh.tex",
      include.rownames = FALSE
    )
    
    
    
    
    
    
    
# TRACKING DATA (Uni Los Andes) -------------------------------------------
    
    # dir_tracking <- "/Users/user/Dropbox/RepositorioUniandes/Datos Salesforce/TodosLosDatosConSeguimiento_20201006.csv"
    # 
    # tracking <- read_delim(file = dir_tracking, delim = ";", encoding = locale(encoding = "latin1"))
    # tracking <- read.delim(dir_tracking, sep = ";", header=TRUE, stringsAsFactors=FALSE, fileEncoding="latin1")
    # 
    tracking_tibble <- tracking %>% as_tibble() %>%
      rename_with(janitor::make_clean_names) %>%
      glimpse()
    
    nrow(tracking_tibble)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # ............ ------------------------------------------------------------
    
    
    
    # OLD ---------------------------------------------------------------------
    
    
    # # Recovery data -----------------------------------------------------------
    # 
    #     # Byrne et al BMJ - Inferred duration of infectious period
    #     
    #     # As in Cochrane handbook, use:
    #     # SD = sqrt(n) * (Upper CI - Lower CI) / 3.92
    #     
    #     # AFTER SYMPTOM ONSET
    #     mean_recov <- 13.4
    #     recov_upper_ci <- 15.8
    #     recov_lower_ci <- 10.9
    #     
    #     # N is seen in supplementary material 3
    #     recov_n <- sum(
    #       c(10, 298, 1, 242, 1, 24, 8, 1, 5, 2, 1, 1, 1, 1, 66, 10, 76, 1, 2, 36, 1, 1, 1, 7, 74, 3, 18, 25, 191)
    #     )
    #     
    #     sd <- sqrt(recov_n) * (recov_upper_ci - recov_lower_ci) / 3.92
    #     
    
    
    # SAR home ----------------------------------------------------------------
    
    sar_home_vals <- rep(0.188, 3)  # from https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7402051/
    
    
    
    
    
    # Testing delays (old dummy data) -----------------------------------------
    
    # Testing choice delay (not yet in the model)
    
    
    
    
    
    # # Testing result delay
    # test_results_delay_data <- tibble(
    #   i_group = c(rep(1, 1000), rep(2, 1000), rep(3, 1000)),
    #   test_results_delay = c(runif(1000, 5, 7), runif(1000, 3, 5), runif(1000, 1, 3))
    # )
    # 
    # test_results_delay_data_6 <- tibble(
    #   i_group = c(rep(1, 1000), rep(2, 1000), rep(3, 1000), rep(4, 1000), rep(5, 1000), rep(6, 1000)),
    #   test_results_delay = c(runif(1000, 5, 7), runif(1000, 3, 5), runif(1000, 1, 3), runif(1000, 1, 3), runif(1000, 1, 3), runif(1000, 1, 3))
    # )
    
    # test_sensitivity_data <- test_results_delay_data %>% rename(test_)
    
    # tibble(
    #   i_group = sample(1:3, size = 1000, replace = TRUE),
    #   x = 1:1000
    # ) %>% 
    #   sample_by_i_group(
    #     sample_dat = test_result_delay_data,
    #     sample_vars = c("test_result_delay")
    #   ) %>% 
    #   ggplot(aes(x = test_result_delay, fill = factor(i_group))) + geom_histogram()
    
